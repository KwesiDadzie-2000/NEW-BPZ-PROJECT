import {
  pgTable,
  text,
  serial,
  integer,
  numeric,
  bigint,
  boolean,
  timestamp,
  index,
  uniqueIndex,
  primaryKey,
} from "drizzle-orm/pg-core";

// ============================================================
// IDENTITY & MULTI-TENANCY
// ============================================================

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  active: boolean("active").notNull().default(true),
  sector: text("sector").notNull().default("services"),
  serviceLines: text("service_lines").notNull().default(""),
  feeModel: text("fee_model").notNull().default(""),
  baseCurrency: text("base_currency").notNull().default("GHS"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("client"), // owner | admin | accountant | viewer
  clientId: integer("client_id"),
  active: boolean("active").notNull().default(true),
  mustChangePassword: boolean("must_change_password").notNull().default(false),
  totpSecret: text("totp_secret").notNull().default(""),
  totpEnabled: boolean("totp_enabled").notNull().default(false),
  /** Hashed one-time 2FA recovery code — the only way back in if the phone is lost. */
  recoveryHash: text("recovery_hash").notNull().default(""),
  /** True while the documented bootstrap password is still in force. */
  usesBootstrapPassword: boolean("uses_bootstrap_password").notNull().default(false),
  passwordChangedAt: timestamp("password_changed_at"),
  acceptedTermsAt: timestamp("accepted_terms_at"),
  tempLoginLink: text("temp_login_link").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  /** True until the second factor (TOTP) is verified. Pending sessions see no data. */
  pending: boolean("pending").notNull().default(false),
  ip: text("ip").notNull().default(""),
});

// ============================================================
// MASTER DATA (shared reference)
// ============================================================

export const accounts = pgTable("accounts", {
  accountNo: text("account_no").primaryKey(),
  description: text("description").notNull(),
  type: text("type").notNull(),
});

export const partners = pgTable(
  "partners",
  {
    bpNo: text("bp_no").notNull(),
    clientId: integer("client_id").notNull().default(1),
    name: text("name").notNull(),
    type: text("type").notNull(), // Vendor | Customer | Employee
    tin: text("tin").notNull().default(""),
    phone: text("phone").notNull().default(""),
    email: text("email").notNull().default(""),
    defaultExpenseAccount: text("default_expense_account").notNull().default(""),
  },
  (t) => [primaryKey({ columns: [t.bpNo, t.clientId] }), index("idx_bp_client").on(t.clientId)]
);

export const costCenters = pgTable("cost_centers", {
  ccCode: text("cc_code").primaryKey(),
  ccName: text("cc_name").notNull(),
});

export const materials = pgTable("materials", {
  materialNo: text("material_no").primaryKey(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  stdPrice: numeric("std_price", { precision: 12, scale: 2 }).notNull(),
});

// ============================================================
// UNIVERSAL JOURNAL (ACDOCA) — per client, fiscal period
// ============================================================

export const journalLines = pgTable(
  "journal_lines",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull().default(1),
    period: text("period").notNull().default("2026-02"), // YYYY-MM
    docNo: text("doc_no").notNull(),
    postDate: text("post_date").notNull(),
    module: text("module").notNull(),
    docType: text("doc_type").notNull(), // WE RE RV DZ PY AA AF KG KZ SA OPEN PREPAY REV ADJ FX
    account: text("account").notNull(),
    bp: text("bp").notNull().default(""),
    costCenter: text("cost_center").notNull().default(""),
    material: text("material").notNull().default(""),
    description: text("description").notNull().default(""),
    debit: numeric("debit", { precision: 16, scale: 2 }).notNull().default("0"),
    credit: numeric("credit", { precision: 16, scale: 2 }).notNull().default("0"),
    createdBy: text("created_by").notNull().default("SYSTEM"),
    reference: text("reference").notNull().default(""),
  },
  (t) => [
    index("idx_jl_client_doc").on(t.clientId, t.docNo),
    index("idx_jl_client_period").on(t.clientId, t.period),
    index("idx_jl_client_account").on(t.clientId, t.account),
    index("idx_jl_client_module").on(t.clientId, t.module),
    index("idx_jl_client_bp").on(t.clientId, t.bp),
  ]
);

export const fiscalPeriods = pgTable(
  "fiscal_periods",
  {
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    status: text("status").notNull().default("open"), // open | closed
    closedBy: text("closed_by").notNull().default(""),
    closedAt: timestamp("closed_at"),
  },
  (t) => [primaryKey({ columns: [t.clientId, t.period] })]
);

// ============================================================
// MODULE DOCUMENTS
// ============================================================

export const purchaseOrders = pgTable(
  "purchase_orders",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull().default(1),
    poNo: text("po_no").notNull(),
    vendor: text("vendor").notNull(),
    material: text("material").notNull(),
    qty: integer("qty").notNull(),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    total: numeric("total", { precision: 14, scale: 2 }).notNull(),
    cc: text("cc").notNull().default(""),
    status: text("status").notNull().default("Open"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_po_client").on(t.clientId), uniqueIndex("uq_po_client_po_no").on(t.clientId, t.poNo)]
);

export const salesOrders = pgTable(
  "sales_orders",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull().default(1),
    soNo: text("so_no").notNull(),
    customer: text("customer").notNull(),
    material: text("material").notNull(),
    qty: integer("qty").notNull(),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    total: numeric("total", { precision: 14, scale: 2 }).notNull(),
    status: text("status").notNull().default("Open"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_so_client").on(t.clientId), uniqueIndex("uq_so_client_so_no").on(t.clientId, t.soNo)]
);

// Quotes / Invoices / Credit & Debit notes (sales + purchase)
export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    direction: text("direction").notNull(), // sales | purchase
    docType: text("doc_type").notNull(), // quote | invoice | credit | debit
    no: text("no").notNull(),
    bp: text("bp").notNull(),
    currency: text("currency").notNull().default("GHS"),
    rate: numeric("rate", { precision: 14, scale: 6 }).notNull().default("1"),
    subtotal: numeric("subtotal", { precision: 14, scale: 2 }).notNull(),
    vat: numeric("vat", { precision: 14, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 14, scale: 2 }).notNull(),
    status: text("status").notNull().default("open"),
    period: text("period").notNull().default(""),
    docNo: text("doc_no").notNull().default(""),
    note: text("note").notNull().default(""),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    /** goods | service | statutory — statutory items never enter the procurement cycle */
    recurrence: text("recurrence").notNull().default("none"),
    recurrenceNext: text("recurrence_next").notNull().default(""),
    /** goods | service | utilities | tax | payroll | insurance | regulatory | penalty | finance */
    expenseCategory: text("expense_category").notNull().default("goods"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_inv_client").on(t.clientId, t.direction)]
);

// ============================================================
// MULTICURRENCY & TAX
// ============================================================

export const currencies = pgTable("currencies", {
  code: text("code").primaryKey(),
  name: text("name").notNull(),
  rateGhs: numeric("rate_ghs", { precision: 14, scale: 6 }).notNull().default("1"),
  source: text("source").notNull().default("manual"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const taxRates = pgTable("tax_rates", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // VAT | WHT_RES | WHT_NR | CIT | ...
  name: text("name").notNull(),
  rate: numeric("rate", { precision: 12, scale: 3 }).notNull(),
  effectiveFrom: text("effective_from").notNull().default("2026-01-01"),
  notes: text("notes").notNull().default(""),
});

export const taxBands = pgTable("tax_bands", {
  id: serial("id").primaryKey(),
  tax: text("tax").notNull().default("PAYE"),
  lower: numeric("lower", { precision: 14, scale: 2 }).notNull(),
  upper: numeric("upper", { precision: 14, scale: 2 }),
  rate: numeric("rate", { precision: 7, scale: 3 }).notNull(),
  effectiveFrom: text("effective_from").notNull().default("2026-09-01"),
});

// ============================================================
// PAYROLL
// ============================================================

export const payComponents = pgTable("pay_components", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  base: text("base").notNull().default("basic"), // gross | basic | net
  rate: numeric("rate", { precision: 7, scale: 3 }),
  fixedAmount: numeric("fixed_amount", { precision: 14, scale: 2 }).notNull().default("0"),
  side: text("side").notNull().default("deduction"), // deduction | income | employer
  ordinal: integer("ordinal").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const payOverrides = pgTable(
  "pay_overrides",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    bpNo: text("bp_no").notNull(),
    period: text("period").notNull(),
    basic: numeric("basic", { precision: 14, scale: 2 }).notNull(),
    allowance: numeric("allowance", { precision: 14, scale: 2 }).notNull().default("0"),
    note: text("note").notNull().default(""),
  },
  (t) => [uniqueIndex("uq_pay_override").on(t.clientId, t.bpNo, t.period)]
);

export const payrollRuns = pgTable("payroll_runs", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  period: text("period").notNull(),
  bpNo: text("bp_no").notNull(),
  basic: numeric("basic", { precision: 14, scale: 2 }).notNull(),
  allowance: numeric("allowance", { precision: 14, scale: 2 }).notNull().default("0"),
  gross: numeric("gross", { precision: 14, scale: 2 }).notNull(),
  paye: numeric("paye", { precision: 14, scale: 2 }).notNull().default("0"),
  ssnitT1: numeric("ssnit_t1", { precision: 14, scale: 2 }).notNull().default("0"),
  ssnitT2: numeric("ssnit_t2", { precision: 14, scale: 2 }).notNull().default("0"),
  nhil: numeric("nhil", { precision: 14, scale: 2 }).notNull().default("0"),
  housing: numeric("housing", { precision: 14, scale: 2 }).notNull().default("0"),
  otherDed: numeric("other_ded", { precision: 14, scale: 2 }).notNull().default("0"),
  net: numeric("net", { precision: 14, scale: 2 }).notNull(),
  employerCost: numeric("employer_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  docNo: text("doc_no").notNull().default(""),
  paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
});

// ============================================================
// BANKING & RECONCILIATION
// ============================================================

export const bankAccounts = pgTable("bank_accounts", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  bank: text("bank").notNull(),
  accountCode: text("account_code").notNull().default("101000"),
  currency: text("currency").notNull().default("GHS"),
  opening: numeric("opening", { precision: 14, scale: 2 }).notNull().default("0"),
  active: boolean("active").notNull().default(true),
});

export const bankLines = pgTable(
  "bank_lines",
  {
    id: serial("id").primaryKey(),
    accountId: integer("account_id").notNull(),
    ref: text("ref").notNull().default(""),
    txnDate: text("txn_date").notNull(),
    description: text("description").notNull().default(""),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    status: text("status").notNull().default("unmatched"),
    journalLineId: integer("journal_line_id"),
    note: text("note").notNull().default(""),
  },
  (t) => [index("idx_banklines_acc").on(t.accountId, t.status)]
);

// ============================================================
// FIXED ASSETS
// ============================================================

export const assetClasses = pgTable("asset_classes", {
  code: text("code").primaryKey(),
  name: text("name").notNull(),
  scope: text("scope").notNull().default("general"),
  method: text("method").notNull().default("sl"),
  rate: numeric("rate", { precision: 6, scale: 3 }).notNull(),
  lifeYears: integer("life_years").notNull().default(5),
});

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  classCode: text("class_code").notNull(),
  cost: numeric("cost", { precision: 14, scale: 2 }).notNull(),
  accumDep: numeric("accum_dep", { precision: 14, scale: 2 }).notNull().default("0"),
  nbv: numeric("nbv", { precision: 14, scale: 2 }).notNull(),
  inService: text("in_service").notNull(),
  cc: text("cc").notNull().default(""),
  active: boolean("active").notNull().default(true),
  docNo: text("doc_no").notNull().default(""),
});

// ============================================================
// INVENTORY / PRODUCTION / CONTRACTS
// ============================================================

export const stockMoves = pgTable("stock_moves", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  material: text("material").notNull(),
  moveDate: text("move_date").notNull(),
  period: text("period").notNull().default(""),
  qtyIn: numeric("qty_in", { precision: 14, scale: 2 }).notNull().default("0"),
  qtyOut: numeric("qty_out", { precision: 14, scale: 2 }).notNull().default("0"),
  amountIn: numeric("amount_in", { precision: 14, scale: 2 }).notNull().default("0"),
  amountOut: numeric("amount_out", { precision: 14, scale: 2 }).notNull().default("0"),
  docNo: text("doc_no").notNull().default(""),
  ref: text("ref").notNull().default(""),
});

export const productionOrders = pgTable("production_orders", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  no: text("no").notNull(),
  material: text("material").notNull(),
  rawMaterial: text("raw_material").notNull().default(""),
  rawQty: numeric("raw_qty", { precision: 14, scale: 2 }).notNull().default("0"),
  qty: integer("qty").notNull(),
  status: text("status").notNull().default("open"),
  period: text("period").notNull().default(""),
  docs: text("docs").notNull().default(""),
});

export const contracts = pgTable("contracts", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  no: text("no").notNull(),
  title: text("title").notNull().default(""),
  counterparty: text("counterparty").notNull(),
  sector: text("sector").notNull().default("construction"),
  startDate: text("start_date").notNull().default(""),
  endDate: text("end_date").notNull().default(""),
  /** cost_to_cost | input_survey | output_milestone | straight_line */
  method: text("method").notNull().default("cost_to_cost"),
  totalValue: numeric("total_value", { precision: 14, scale: 2 }).notNull(),
  estimatedCost: numeric("estimated_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  pctComplete: numeric("pct_complete", { precision: 5, scale: 1 }).notNull().default("0"),
  costToDate: numeric("cost_to_date", { precision: 14, scale: 2 }).notNull().default("0"),
  recognisedRevenue: numeric("recognised_revenue", { precision: 14, scale: 2 }).notNull().default("0"),
  recognisedCost: numeric("recognised_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  billed: numeric("billed", { precision: 14, scale: 2 }).notNull().default("0"),
  retentionPct: numeric("retention_pct", { precision: 5, scale: 2 }).notNull().default("0"),
  retentionHeld: numeric("retention_held", { precision: 14, scale: 2 }).notNull().default("0"),
  retentionReleased: numeric("retention_released", { precision: 14, scale: 2 }).notNull().default("0"),
  advances: numeric("advances", { precision: 14, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("GHS"),
  cc: text("cc").notNull().default(""),
  lossProvision: numeric("loss_provision", { precision: 14, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("active"),
}, (t) => [uniqueIndex("uq_contract_no_client").on(t.clientId, t.no)]);

// ============================================================
// BUDGET & SCENARIOS
// ============================================================

export const budgetScenarios = pgTable("budget_scenarios", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
});

export const budgetLines = pgTable("budget_lines", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  scenarioId: integer("scenario_id").notNull(),
  account: text("account").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  note: text("note").notNull().default(""),
});

// ============================================================
// BPZ SERVICES — advisory, engagements, fee billing
// ============================================================

export const workTemplates = pgTable("work_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  serviceLine: text("service_line").notNull(),
  checklist: text("checklist").notNull().default("[]"),
});

export const engagements = pgTable("engagements", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  serviceLine: text("service_line").notNull(),
  template: text("template").notNull().default(""),
  period: text("period").notNull().default(""),
  status: text("status").notNull().default("in_progress"),
  quant: text("quant").notNull().default("{}"),
  qual: text("qual").notNull().default(""),
  updatedBy: text("updated_by").notNull().default(""),
});

export const feeInvoices = pgTable("fee_invoices", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  serviceLine: text("service_line").notNull(),
  period: text("period").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  status: text("status").notNull().default("open"),
  docNo: text("doc_no").notNull().default(""),
});

// ============================================================
// COUNTERS & SETTINGS
// ============================================================

export const meta = pgTable(
  "meta",
  {
    key: text("key").notNull(),
    clientId: integer("client_id").notNull().default(1),
    value: bigint("value", { mode: "number" }).notNull(),
  },
  (t) => [primaryKey({ columns: [t.key, t.clientId] })]
);

export const systemSettings = pgTable("system_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

// ============================================================
// SECURITY, AUDIT & EVIDENCE
// ============================================================

/** Immutable user activity log — who did what, when, in which workspace. */
export const activityLog = pgTable(
  "activity_log",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    workspace: text("workspace").notNull().default(""),
    username: text("username").notNull(),
    role: text("role").notNull().default(""),
    action: text("action").notNull(),
    ok: boolean("ok").notNull().default(true),
    detail: text("detail").notNull().default(""),
    ip: text("ip").notNull().default(""),
    at: timestamp("at").notNull().defaultNow(),
  },
  (t) => [index("idx_al_client").on(t.clientId, t.at)]
);

/** FX rate history — evidences the rate used for each IAS 21 revaluation. */
export const fxHistory = pgTable(
  "fx_history",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull(),
    rate: numeric("rate", { precision: 14, scale: 6 }).notNull(),
    source: text("source").notNull().default(""),
    capturedAt: timestamp("captured_at").notNull().defaultNow(),
  },
  (t) => [index("idx_fxh_code").on(t.code, t.capturedAt)]
);

/** Login attempts — brute-force lockout evidence. */
export const loginAttempts = pgTable(
  "login_attempts",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull(),
    ip: text("ip").notNull().default(""),
    ok: boolean("ok").notNull().default(false),
    at: timestamp("at").notNull().defaultNow(),
  },
  (t) => [index("idx_la_user").on(t.username, t.at)]
);

// ============================================================
// PRODUCTION HARDENING
// ============================================================

export const backupRuns = pgTable(
  "backup_runs",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    scope: text("scope").notNull().default("workspace"),
    kind: text("kind").notNull().default("manual"),
    sizeBytes: integer("size_bytes").notNull().default(0),
    docs: integer("docs").notNull().default(0),
    takenBy: text("taken_by").notNull().default(""),
    takenAt: timestamp("taken_at").notNull().defaultNow(),
  },
  (t) => [index("idx_br_client").on(t.clientId, t.takenAt)]
);

/** Retained server errors — visible in Diagnostics instead of lost to a console. */
export const errorLog = pgTable(
  "error_log",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    workspace: text("workspace").notNull().default(""),
    username: text("username").notNull().default(""),
    action: text("action").notNull().default(""),
    route: text("route").notNull().default(""),
    message: text("message").notNull().default(""),
    stack: text("stack").notNull().default(""),
    at: timestamp("at").notNull().defaultNow(),
  },
  (t) => [index("idx_el_at").on(t.at)]
);

// ============================================================
// IFRS 15 — LONG-TERM CONTRACTS & OVER-TIME REVENUE RECOGNITION
// ============================================================

export const contractCertificates = pgTable(
  "contract_certificates",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    contractId: integer("contract_id").notNull(),
    certNo: text("cert_no").notNull(),
    period: text("period").notNull(),
    certDate: text("cert_date").notNull().default(""),
    grossValue: numeric("gross_value", { precision: 14, scale: 2 }).notNull().default("0"),
    retention: numeric("retention", { precision: 14, scale: 2 }).notNull().default("0"),
    netPayable: numeric("net_payable", { precision: 14, scale: 2 }).notNull().default("0"),
    cumulativePct: numeric("cumulative_pct", { precision: 5, scale: 1 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    status: text("status").notNull().default("open"),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("idx_cc_contract").on(t.clientId, t.contractId),
    uniqueIndex("uq_certificate_no_client").on(t.clientId, t.certNo),
  ]
);

export const contractCosts = pgTable(
  "contract_costs",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    contractId: integer("contract_id").notNull(),
    period: text("period").notNull(),
    account: text("account").notNull().default("505000"),
    description: text("description").notNull().default(""),
    vendor: text("vendor").notNull().default(""),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_cst_contract").on(t.clientId, t.contractId)]
);

// ============================================================
// IFRS 9 — FINANCIAL INSTRUMENTS & EXPECTED CREDIT LOSSES
// ============================================================

export const financialInstruments = pgTable(
  "financial_instruments",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull().default("amortised_cost"),
    instrumentType: text("instrument_type").notNull().default("loan_receivable"),
    counterparty: text("counterparty").notNull().default(""),
    principal: numeric("principal", { precision: 16, scale: 2 }).notNull().default("0"),
    effectiveRate: numeric("effective_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    issueDate: text("issue_date").notNull().default(""),
    maturityDate: text("maturity_date").notNull().default(""),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    eclAllowance: numeric("ecl_allowance", { precision: 16, scale: 2 }).notNull().default("0"),
    stage: integer("stage").notNull().default(1),
    stage2Since: text("stage2_since").notNull().default(""),
    collateralValue: numeric("collateral_value", { precision: 16, scale: 2 }).notNull().default("0"),
    creditGrade: text("credit_grade").notNull().default(""),
    currency: text("currency").notNull().default("GHS"),
    lastEclPeriod: text("last_ecl_period").notNull().default(""),
    notes: text("notes").notNull().default(""),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_fi_client").on(t.clientId, t.status)]
);

export const eclAssessments = pgTable(
  "ecl_assessments",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    instrumentId: integer("instrument_id").notNull(),
    stage: integer("stage").notNull().default(1),
    exposure: numeric("exposure", { precision: 16, scale: 2 }).notNull().default("0"),
    pd: numeric("pd", { precision: 7, scale: 4 }).notNull().default("0"),
    lgd: numeric("lgd", { precision: 7, scale: 4 }).notNull().default("0"),
    ecl: numeric("ecl", { precision: 16, scale: 2 }).notNull().default("0"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    horizonMonths: integer("horizon_months").notNull().default(12),
    movement: numeric("movement", { precision: 16, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    notes: text("notes").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_ecl_client").on(t.clientId, t.period)]
);

export const eclProvisionMatrix = pgTable(
  "ecl_provision_matrix",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    bucket: text("bucket").notNull(),
    label: text("label").notNull().default(""),
    pd: numeric("pd", { precision: 7, scale: 4 }).notNull().default("0"),
  },
  (t) => [uniqueIndex("uq_matrix_bucket").on(t.clientId, t.bucket)]
);

// ============================================================
// IFRS 16 — LEASES
// ============================================================

export const leases = pgTable(
  "leases",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    description: text("description").notNull().default(""),
    lessor: text("lessor").notNull().default(""),
    leaseType: text("lease_type").notNull().default("property"),
    startDate: text("start_date").notNull().default(""),
    termMonths: integer("term_months").notNull().default(12),
    payment: numeric("payment", { precision: 16, scale: 2 }).notNull().default("0"),
    frequency: text("frequency").notNull().default("monthly"),
    timing: text("timing").notNull().default("arrears"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    initialDirectCosts: numeric("initial_direct_costs", { precision: 16, scale: 2 }).notNull().default("0"),
    incentives: numeric("incentives", { precision: 16, scale: 2 }).notNull().default("0"),
    restorationCost: numeric("restoration_cost", { precision: 16, scale: 2 }).notNull().default("0"),
    rouAsset: numeric("rou_asset", { precision: 16, scale: 2 }).notNull().default("0"),
    leaseLiability: numeric("lease_liability", { precision: 16, scale: 2 }).notNull().default("0"),
    accumulatedDepreciation: numeric("accumulated_depreciation", { precision: 16, scale: 2 }).notNull().default("0"),
    lowValueExemption: boolean("low_value_exemption").notNull().default(false),
    cc: text("cc").notNull().default(""),
    lastDepPeriod: text("last_dep_period").notNull().default(""),
    lastInterestPeriod: text("last_interest_period").notNull().default(""),
    status: text("status").notNull().default("active"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_lease_client").on(t.clientId, t.status)]
);

// ============================================================
// IAS 36 — IMPAIRMENT OF ASSETS
// ============================================================

export const impairmentTests = pgTable(
  "impairment_tests",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    unitName: text("unit_name").notNull(),
    unitType: text("unit_type").notNull().default("cgu"),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    fairValueLessCosts: numeric("fair_value_less_costs", { precision: 16, scale: 2 }).notNull().default("0"),
    cashFlows: numeric("cash_flows", { precision: 16, scale: 2 }).notNull().default("0"),
    terminalValue: numeric("terminal_value", { precision: 16, scale: 2 }).notNull().default("0"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    horizonYears: integer("horizon_years").notNull().default(5),
    valueInUse: numeric("value_in_use", { precision: 16, scale: 2 }).notNull().default("0"),
    recoverableAmount: numeric("recoverable_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    impairmentLoss: numeric("impairment_loss", { precision: 16, scale: 2 }).notNull().default("0"),
    reversalAvailable: numeric("reversal_available", { precision: 16, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    notes: text("notes").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_imp_client").on(t.clientId, t.period)]
);

// ============================================================
// IFRS 5 — NON-CURRENT ASSETS HELD FOR SALE
// ============================================================

export const heldForSale = pgTable(
  "held_for_sale",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    assetCode: text("asset_code").notNull().default(""),
    description: text("description").notNull().default(""),
    originalCost: numeric("original_cost", { precision: 16, scale: 2 }).notNull().default("0"),
    accumulatedDepreciation: numeric("accumulated_depreciation", { precision: 16, scale: 2 }).notNull().default("0"),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    fairValueLessCosts: numeric("fair_value_less_costs", { precision: 16, scale: 2 }).notNull().default("0"),
    writeDown: numeric("write_down", { precision: 16, scale: 2 }).notNull().default("0"),
    discontinuedOperation: boolean("discontinued_operation").notNull().default(false),
    expectedSaleDate: text("expected_sale_date").notNull().default(""),
    docNo: text("doc_no").notNull().default(""),
    status: text("status").notNull().default("held_for_sale"),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_hfs_client").on(t.clientId, t.period)]
);

// ============================================================
// LOANS & BORROWINGS — amortised cost with full schedules
// ============================================================

export const loans = pgTable(
  "loans",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    lender: text("lender").notNull().default(""),
    facilityType: text("facility_type").notNull().default("amortising"),
    principal: numeric("principal", { precision: 16, scale: 2 }).notNull().default("0"),
    annualRate: numeric("annual_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    termMonths: integer("term_months").notNull().default(12),
    startDate: text("start_date").notNull().default(""),
    frequency: text("frequency").notNull().default("monthly"),
    timing: text("timing").notNull().default("arrears"),
    moratoriumMonths: integer("moratorium_months").notNull().default(0),
    arrangementFee: numeric("arrangement_fee", { precision: 16, scale: 2 }).notNull().default("0"),
    feeMonths: integer("fee_months").notNull().default(0),
    drawdownAccount: text("drawdown_account").notNull().default("101000"),
    loanAccount: text("loan_account").notNull().default("290000"),
    interestAccount: text("interest_account").notNull().default("575000"),
    feeAccount: text("fee_account").notNull().default("576000"),
    currency: text("currency").notNull().default("GHS"),
    cc: text("cc").notNull().default(""),
    outstanding: numeric("outstanding", { precision: 16, scale: 2 }).notNull().default("0"),
    interestPaidTo: text("interest_paid_to").notNull().default(""),
    lastPeriod: text("last_period").notNull().default(""),
    status: text("status").notNull().default("active"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_loan_client").on(t.clientId, t.status)]
);

export const loanSchedules = pgTable(
  "loan_schedules",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    loanId: integer("loan_id").notNull(),
    seq: integer("seq").notNull(),
    period: text("period").notNull(),
    paymentDate: text("payment_date").notNull().default(""),
    opening: numeric("opening", { precision: 16, scale: 2 }).notNull().default("0"),
    interest: numeric("interest", { precision: 16, scale: 2 }).notNull().default("0"),
    fee: numeric("fee", { precision: 16, scale: 2 }).notNull().default("0"),
    principal: numeric("principal", { precision: 16, scale: 2 }).notNull().default("0"),
    payment: numeric("payment", { precision: 16, scale: 2 }).notNull().default("0"),
    closing: numeric("closing", { precision: 16, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    status: text("status").notNull().default("scheduled"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_ls_loan").on(t.clientId, t.loanId)]
);

// ============================================================
// BIG FOUR HARDENING — group, disclosures, SSO, API, standards
// ============================================================

/** Corporate group structure for IFRS 10 consolidation. */
export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  parentClientId: integer("parent_client_id").notNull(),
  reportingCurrency: text("reporting_currency").notNull().default("GHS"),
  consolidationMethod: text("consolidation_method").notNull().default("line_by_line"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Group membership — control %, method (full / equity / NCI). */
export const groupMembers = pgTable(
  "group_members",
  {
    id: serial("id").primaryKey(),
    groupId: integer("group_id").notNull(),
    clientId: integer("client_id").notNull(),
    ownershipPct: numeric("ownership_pct", { precision: 7, scale: 4 }).notNull().default("100"),
    method: text("method").notNull().default("full"), // full | equity | nci
    acquisitionDate: text("acquisition_date").notNull().default(""),
    goodwill: numeric("goodwill", { precision: 16, scale: 2 }).notNull().default("0"),
    nciShare: numeric("nci_share", { precision: 7, scale: 4 }).notNull().default("0"),
    active: boolean("active").notNull().default(true),
  },
  (t) => [uniqueIndex("uq_group_member").on(t.groupId, t.clientId), index("idx_gm_group").on(t.groupId)]
);

/** Intercompany balances flagged for elimination (IFRS 10.B86). */
export const intercompanyLinks = pgTable(
  "intercompany_links",
  {
    id: serial("id").primaryKey(),
    groupId: integer("group_id").notNull(),
    fromClientId: integer("from_client_id").notNull(),
    toClientId: integer("to_client_id").notNull(),
    nature: text("nature").notNull().default("trade"), // trade | loan | dividend | management_fee | inventory
    fromAccount: text("from_account").notNull().default(""),
    toAccount: text("to_account").notNull().default(""),
    amount: numeric("amount", { precision: 16, scale: 2 }).notNull().default("0"),
    period: text("period").notNull().default(""),
    eliminated: boolean("eliminated").notNull().default(false),
    elimDocNo: text("elim_doc_no").notNull().default(""),
    notes: text("notes").notNull().default(""),
  },
  (t) => [index("idx_ic_group").on(t.groupId, t.period)]
);

/** IFRS 8 operating segments. */
export const operatingSegments = pgTable(
  "operating_segments",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    chiefOperatingDecisionMaker: text("codm").notNull().default("CEO"),
    revenueAccountPrefix: text("revenue_account_prefix").notNull().default("4"),
    costCenter: text("cost_center").notNull().default(""),
    externalRevenue: numeric("external_revenue", { precision: 16, scale: 2 }).notNull().default("0"),
    interSegmentRevenue: numeric("inter_segment_revenue", { precision: 16, scale: 2 }).notNull().default("0"),
    segmentProfit: numeric("segment_profit", { precision: 16, scale: 2 }).notNull().default("0"),
    segmentAssets: numeric("segment_assets", { precision: 16, scale: 2 }).notNull().default("0"),
    segmentLiabilities: numeric("segment_liabilities", { precision: 16, scale: 2 }).notNull().default("0"),
    depreciation: numeric("depreciation", { precision: 16, scale: 2 }).notNull().default("0"),
    capitalExpenditure: numeric("capital_expenditure", { precision: 16, scale: 2 }).notNull().default("0"),
    period: text("period").notNull().default(""),
    active: boolean("active").notNull().default(true),
  },
  (t) => [uniqueIndex("uq_seg_client_code").on(t.clientId, t.code), index("idx_seg_client").on(t.clientId)]
);

/** IAS 24 related-party register. */
export const relatedParties = pgTable(
  "related_parties",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    relationship: text("relationship").notNull(), // parent | subsidiary | associate | key_management | close_family | joint_venture | other
    bpNo: text("bp_no").notNull().default(""),
    controlPct: numeric("control_pct", { precision: 7, scale: 4 }).notNull().default("0"),
    nature: text("nature").notNull().default(""),
    active: boolean("active").notNull().default(true),
  },
  (t) => [uniqueIndex("uq_rp_client_code").on(t.clientId, t.code), index("idx_rp_client").on(t.clientId)]
);

/** IAS 24 related-party transactions. */
export const relatedPartyTxns = pgTable(
  "related_party_txns",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    relatedPartyId: integer("related_party_id").notNull(),
    period: text("period").notNull(),
    txnDate: text("txn_date").notNull().default(""),
    nature: text("nature").notNull().default("sale"), // sale | purchase | loan | guarantee | management_fee | dividend | compensation | other
    description: text("description").notNull().default(""),
    amount: numeric("amount", { precision: 16, scale: 2 }).notNull().default("0"),
    outstanding: numeric("outstanding", { precision: 16, scale: 2 }).notNull().default("0"),
    terms: text("terms").notNull().default("arm's length"),
    docNo: text("doc_no").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_rpt_client").on(t.clientId, t.period)]
);

/** IAS 37 provisions, contingent liabilities and contingent assets. */
export const provisions = pgTable(
  "provisions",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    title: text("title").notNull(),
    category: text("category").notNull().default("legal"), // legal | warranty | restructuring | decommissioning | onerous | environmental | other
    recognitionDate: text("recognition_date").notNull().default(""),
    bestEstimate: numeric("best_estimate", { precision: 16, scale: 2 }).notNull().default("0"),
    minEstimate: numeric("min_estimate", { precision: 16, scale: 2 }).notNull().default("0"),
    maxEstimate: numeric("max_estimate", { precision: 16, scale: 2 }).notNull().default("0"),
    probability: numeric("probability", { precision: 7, scale: 4 }).notNull().default("50"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    yearsToSettlement: numeric("years_to_settlement", { precision: 7, scale: 2 }).notNull().default("1"),
    presentValue: numeric("present_value", { precision: 16, scale: 2 }).notNull().default("0"),
    unwindingInterest: numeric("unwinding_interest", { precision: 16, scale: 2 }).notNull().default("0"),
    utilised: numeric("utilised", { precision: 16, scale: 2 }).notNull().default("0"),
    reversed: numeric("reversed", { precision: 16, scale: 2 }).notNull().default("0"),
    added: numeric("added", { precision: 16, scale: 2 }).notNull().default("0"),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    contingent: boolean("contingent").notNull().default(false),
    contingentAsset: boolean("contingent_asset").notNull().default(false),
    obligatingEvent: text("obligating_event").notNull().default(""),
    expectedOutflow: text("expected_outflow").notNull().default(""),
    account: text("account").notNull().default("293000"),
    expenseAccount: text("expense_account").notNull().default("584000"),
    period: text("period").notNull().default(""),
    docNo: text("doc_no").notNull().default(""),
    status: text("status").notNull().default("recognised"), // recognised | contingent | settled | reversed
    notes: text("notes").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("uq_prov_client_code").on(t.clientId, t.code), index("idx_prov_client").on(t.clientId, t.status)]
);

/** IAS 19 employee benefits — defined benefit / long-service / gratuity. */
export const employeeBenefitPlans = pgTable(
  "employee_benefit_plans",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    planType: text("plan_type").notNull().default("defined_benefit"), // defined_benefit | defined_contribution | long_service | gratuity | other_long_term
    currency: text("currency").notNull().default("GHS"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    salaryGrowth: numeric("salary_growth", { precision: 7, scale: 4 }).notNull().default("0"),
    inflationRate: numeric("inflation_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    members: integer("members").notNull().default(0),
    averageServiceYears: numeric("average_service_years", { precision: 7, scale: 2 }).notNull().default("0"),
    averageSalary: numeric("average_salary", { precision: 16, scale: 2 }).notNull().default("0"),
    definedBenefitObligation: numeric("dbo", { precision: 16, scale: 2 }).notNull().default("0"),
    planAssets: numeric("plan_assets", { precision: 16, scale: 2 }).notNull().default("0"),
    netLiability: numeric("net_liability", { precision: 16, scale: 2 }).notNull().default("0"),
    currentServiceCost: numeric("current_service_cost", { precision: 16, scale: 2 }).notNull().default("0"),
    netInterest: numeric("net_interest", { precision: 16, scale: 2 }).notNull().default("0"),
    actuarialGainLoss: numeric("actuarial_gain_loss", { precision: 16, scale: 2 }).notNull().default("0"),
    contributions: numeric("contributions", { precision: 16, scale: 2 }).notNull().default("0"),
    benefitsPaid: numeric("benefits_paid", { precision: 16, scale: 2 }).notNull().default("0"),
    period: text("period").notNull().default(""),
    docNo: text("doc_no").notNull().default(""),
    status: text("status").notNull().default("active"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("uq_ebp_client_code").on(t.clientId, t.code), index("idx_ebp_client").on(t.clientId)]
);

/** IFRS 13 fair value hierarchy measurements. */
export const fairValueMeasurements = pgTable(
  "fair_value_measurements",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    description: text("description").notNull(),
    assetClass: text("asset_class").notNull().default("financial"), // financial | investment_property | biological | other
    level: integer("level").notNull().default(2), // 1 | 2 | 3
    valuationTechnique: text("valuation_technique").notNull().default("market"), // market | income | cost
    observableInputs: text("observable_inputs").notNull().default(""),
    unobservableInputs: text("unobservable_inputs").notNull().default(""),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    fairValue: numeric("fair_value", { precision: 16, scale: 2 }).notNull().default("0"),
    unrealisedGainLoss: numeric("unrealised_gain_loss", { precision: 16, scale: 2 }).notNull().default("0"),
    period: text("period").notNull().default(""),
    recurring: boolean("recurring").notNull().default(true),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_fv_client").on(t.clientId, t.period)]
);

/** IAS 33 earnings per share inputs & results. */
export const epsComputations = pgTable(
  "eps_computations",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    profitAttributable: numeric("profit_attributable", { precision: 16, scale: 2 }).notNull().default("0"),
    preferenceDividends: numeric("preference_dividends", { precision: 16, scale: 2 }).notNull().default("0"),
    weightedAvgShares: numeric("weighted_avg_shares", { precision: 18, scale: 4 }).notNull().default("0"),
    dilutiveShares: numeric("dilutive_shares", { precision: 18, scale: 4 }).notNull().default("0"),
    basicEps: numeric("basic_eps", { precision: 16, scale: 6 }).notNull().default("0"),
    dilutedEps: numeric("diluted_eps", { precision: 16, scale: 6 }).notNull().default("0"),
    discontinuedProfit: numeric("discontinued_profit", { precision: 16, scale: 2 }).notNull().default("0"),
    continuingBasicEps: numeric("continuing_basic_eps", { precision: 16, scale: 6 }).notNull().default("0"),
    notes: text("notes").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("uq_eps_client_period").on(t.clientId, t.period)]
);

/** IAS 12 deferred tax temporary differences. */
export const deferredTaxItems = pgTable(
  "deferred_tax_items",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    description: text("description").notNull(),
    origin: text("origin").notNull().default("ppe"), // ppe | provisions | ecl | leases | tax_loss | other
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    taxBase: numeric("tax_base", { precision: 16, scale: 2 }).notNull().default("0"),
    temporaryDifference: numeric("temporary_difference", { precision: 16, scale: 2 }).notNull().default("0"),
    taxRate: numeric("tax_rate", { precision: 7, scale: 4 }).notNull().default("25"),
    deferredTaxAsset: numeric("dta", { precision: 16, scale: 2 }).notNull().default("0"),
    deferredTaxLiability: numeric("dtl", { precision: 16, scale: 2 }).notNull().default("0"),
    throughOci: boolean("through_oci").notNull().default(false),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_dt_client").on(t.clientId, t.period)]
);

/** IAS 29 hyperinflation restatement factors. */
export const hyperinflationFactors = pgTable(
  "hyperinflation_factors",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    jurisdiction: text("jurisdiction").notNull().default(""),
    period: text("period").notNull(),
    cpiIndex: numeric("cpi_index", { precision: 14, scale: 6 }).notNull().default("100"),
    baseCpi: numeric("base_cpi", { precision: 14, scale: 6 }).notNull().default("100"),
    restatementFactor: numeric("restatement_factor", { precision: 14, scale: 8 }).notNull().default("1"),
    monetaryGainLoss: numeric("monetary_gain_loss", { precision: 16, scale: 2 }).notNull().default("0"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("uq_hyp_client_period").on(t.clientId, t.period)]
);

/** Disclosure note overrides / applicability flags (IAS 1). */
export const disclosureNotes = pgTable(
  "disclosure_notes",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    noteKey: text("note_key").notNull(),
    title: text("title").notNull(),
    standardRef: text("standard_ref").notNull().default(""),
    applicable: boolean("applicable").notNull().default(true),
    notApplicableReason: text("not_applicable_reason").notNull().default(""),
    body: text("body").notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    autoGenerated: boolean("auto_generated").notNull().default(true),
    updatedBy: text("updated_by").notNull().default(""),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("uq_dn_client_period_key").on(t.clientId, t.period, t.noteKey), index("idx_dn_client").on(t.clientId, t.period)]
);

/** Significant accounting policies (IAS 1 / IAS 8). */
export const accountingPolicies = pgTable(
  "accounting_policies",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    policyKey: text("policy_key").notNull(),
    title: text("title").notNull(),
    standardRef: text("standard_ref").notNull().default(""),
    body: text("body").notNull().default(""),
    active: boolean("active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (t) => [uniqueIndex("uq_pol_client_key").on(t.clientId, t.policyKey)]
);

/** Enterprise SSO identity providers (SAML / OIDC / SCIM). */
export const ssoProviders = pgTable("sso_providers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  protocol: text("protocol").notNull().default("oidc"), // oidc | saml | scim
  enabled: boolean("enabled").notNull().default(false),
  issuer: text("issuer").notNull().default(""),
  clientId: text("client_id").notNull().default(""),
  clientSecretEnc: text("client_secret_enc").notNull().default(""),
  authorizationUrl: text("authorization_url").notNull().default(""),
  tokenUrl: text("token_url").notNull().default(""),
  userInfoUrl: text("user_info_url").notNull().default(""),
  jwksUrl: text("jwks_url").notNull().default(""),
  samlEntryPoint: text("saml_entry_point").notNull().default(""),
  samlCert: text("saml_cert").notNull().default(""),
  scimEndpoint: text("scim_endpoint").notNull().default(""),
  scimTokenEnc: text("scim_token_enc").notNull().default(""),
  defaultRole: text("default_role").notNull().default("viewer"),
  allowedDomains: text("allowed_domains").notNull().default(""),
  metadata: text("metadata").notNull().default("{}"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** Federated identity links (SSO subject → local user). */
export const ssoIdentities = pgTable(
  "sso_identities",
  {
    id: serial("id").primaryKey(),
    providerId: integer("provider_id").notNull(),
    userId: integer("user_id").notNull(),
    subject: text("subject").notNull(),
    email: text("email").notNull().default(""),
    lastLoginAt: timestamp("last_login_at"),
  },
  (t) => [uniqueIndex("uq_sso_subject").on(t.providerId, t.subject), index("idx_sso_user").on(t.userId)]
);

/** Public API keys for integration (scoped, hashed). */
export const apiKeys = pgTable(
  "api_keys",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    name: text("name").notNull(),
    keyPrefix: text("key_prefix").notNull(),
    keyHash: text("key_hash").notNull(),
    scopes: text("scopes").notNull().default("read:reports,read:journal"),
    createdBy: text("created_by").notNull().default(""),
    lastUsedAt: timestamp("last_used_at"),
    expiresAt: timestamp("expires_at"),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_apikey_prefix").on(t.keyPrefix), index("idx_apikey_client").on(t.clientId)]
);

/** Outbound webhooks for period close, invoice, payroll events. */
export const webhooks = pgTable(
  "webhooks",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    name: text("name").notNull(),
    url: text("url").notNull(),
    secret: text("secret").notNull().default(""),
    events: text("events").notNull().default("period.closed,invoice.posted,payroll.run"),
    active: boolean("active").notNull().default(true),
    failureCount: integer("failure_count").notNull().default(0),
    lastStatus: integer("last_status").notNull().default(0),
    lastDeliveredAt: timestamp("last_delivered_at"),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_wh_client").on(t.clientId)]
);

/** Webhook delivery log (SOC evidence). */
export const webhookDeliveries = pgTable(
  "webhook_deliveries",
  {
    id: serial("id").primaryKey(),
    webhookId: integer("webhook_id").notNull(),
    event: text("event").notNull(),
    payload: text("payload").notNull().default("{}"),
    statusCode: integer("status_code").notNull().default(0),
    responseBody: text("response_body").notNull().default(""),
    ok: boolean("ok").notNull().default(false),
    attempts: integer("attempts").notNull().default(1),
    deliveredAt: timestamp("delivered_at").notNull().defaultNow(),
  },
  (t) => [index("idx_whd_webhook").on(t.webhookId, t.deliveredAt)]
);

/** Attachments stored as filesystem paths (NOT base64 in Postgres). */
export const attachments = pgTable(
  "attachments",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    entityType: text("entity_type").notNull(), // invoice | journal | asset | contract | provision | other
    entityId: text("entity_id").notNull(),
    fileName: text("file_name").notNull(),
    mimeType: text("mime_type").notNull().default("application/octet-stream"),
    sizeBytes: integer("size_bytes").notNull().default(0),
    storagePath: text("storage_path").notNull(), // relative path under /data/attachments
    checksumSha256: text("checksum_sha256").notNull().default(""),
    uploadedBy: text("uploaded_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_att_entity").on(t.clientId, t.entityType, t.entityId)]
);

/** Events after reporting period (IAS 10). */
export const subsequentEvents = pgTable(
  "subsequent_events",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    eventDate: text("event_date").notNull().default(""),
    category: text("category").notNull().default("non_adjusting"), // adjusting | non_adjusting
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    financialImpact: numeric("financial_impact", { precision: 16, scale: 2 }).notNull().default("0"),
    adjustingEntryDocNo: text("adjusting_entry_doc_no").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_se_client").on(t.clientId, t.period)]
);

/** Contingencies register (IAS 37 disclosure companion). */
export const contingencies = pgTable(
  "contingencies",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    title: text("title").notNull(),
    kind: text("kind").notNull().default("liability"), // liability | asset
    likelihood: text("likelihood").notNull().default("possible"), // remote | possible | probable
    estimateLow: numeric("estimate_low", { precision: 16, scale: 2 }).notNull().default("0"),
    estimateHigh: numeric("estimate_high", { precision: 16, scale: 2 }).notNull().default("0"),
    description: text("description").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_cont_client").on(t.clientId, t.period)]
);

/** Capital & financial risk disclosures (IFRS 7). */
export const riskDisclosures = pgTable(
  "risk_disclosures",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    riskType: text("risk_type").notNull(), // credit | liquidity | market | currency | interest | capital
    title: text("title").notNull(),
    exposure: numeric("exposure", { precision: 16, scale: 2 }).notNull().default("0"),
    mitigation: text("mitigation").notNull().default(""),
    sensitivity: text("sensitivity").notNull().default(""),
    body: text("body").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_risk_client").on(t.clientId, t.period)]
);

/** Share capital register for IAS 33 / equity notes. */
export const shareCapital = pgTable(
  "share_capital",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    className: text("class_name").notNull().default("Ordinary"),
    parValue: numeric("par_value", { precision: 14, scale: 4 }).notNull().default("1"),
    authorisedShares: numeric("authorised_shares", { precision: 18, scale: 0 }).notNull().default("0"),
    issuedShares: numeric("issued_shares", { precision: 18, scale: 0 }).notNull().default("0"),
    paidUpCapital: numeric("paid_up_capital", { precision: 16, scale: 2 }).notNull().default("0"),
    sharePremium: numeric("share_premium", { precision: 16, scale: 2 }).notNull().default("0"),
    treasuryShares: numeric("treasury_shares", { precision: 18, scale: 0 }).notNull().default("0"),
    period: text("period").notNull().default(""),
  },
  (t) => [index("idx_sc_client").on(t.clientId)]
);

/** SOC / backup / HA evidence trail entries. */
export const socEvidence = pgTable(
  "soc_evidence",
  {
    id: serial("id").primaryKey(),
    category: text("category").notNull(), // backup | ha | access | change | monitoring | restore_test
    title: text("title").notNull(),
    detail: text("detail").notNull().default(""),
    status: text("status").notNull().default("pass"),
    evidenceRef: text("evidence_ref").notNull().default(""),
    takenBy: text("taken_by").notNull().default("system"),
    takenAt: timestamp("taken_at").notNull().defaultNow(),
  },
  (t) => [index("idx_soc_cat").on(t.category, t.takenAt)]
);
