/**
 * Jurisdiction coverage — the platform runs in Ghana (full statutory depth) and
 * in any other economy via a configurable jurisdiction profile. Rates are
 * seeded here and remain owner-editable in Admin & Compliance, so when a
 * statute changes the owner amends it once and every workspace follows.
 */

export type Jurisdiction = {
  code: string;
  name: string;
  currency: string;
  vatName: string;
  vatRate: number;
  citRate: number;
  payrollScheme: "ghana" | "generic";
  notes: string;
};

export const JURISDICTIONS: Jurisdiction[] = [
  {
    code: "GH", name: "Ghana", currency: "GHS", vatName: "VAT", vatRate: 20, citRate: 25,
    payrollScheme: "ghana",
    notes: "Income Tax Act 896 (as amended) · VAT 20% full input credit, no cascading · PAYE bands effective 1 Sep 2026 · SSNIT T1 5.5% + T2 5% (13% employer) · NHIL 2.5% · GRA monthly PAYE/VAT filing.",
  },
  {
    code: "NG", name: "Nigeria", currency: "NGN", vatName: "VAT", vatRate: 7.5, citRate: 30,
    payrollScheme: "generic",
    notes: "CITA · VAT 7.5% · PAYE progressive (PITA) · Pension 8% employee / 10% employer · NHF 2.5%.",
  },
  {
    code: "KE", name: "Kenya", currency: "KES", vatName: "VAT", vatRate: 16, citRate: 30,
    payrollScheme: "generic",
    notes: "Income Tax Act · VAT 16% · PAYE progressive (KRA) · NSSF & SHIF statutory deductions.",
  },
  {
    code: "ZA", name: "South Africa", currency: "ZAR", vatName: "VAT", vatRate: 15, citRate: 27,
    payrollScheme: "generic",
    notes: "Income Tax Act · VAT 15% · SITE/PAYE (SARS) · UIF 1% + SDL 1%.",
  },
  {
    code: "GB", name: "United Kingdom", currency: "GBP", vatName: "VAT", vatRate: 20, citRate: 25,
    payrollScheme: "generic",
    notes: "CTA 2009 · VAT 20% standard · PAYE + National Insurance (HMRC RTI) · Auto-enrolment pension.",
  },
  {
    code: "US", name: "United States", currency: "USD", vatName: "Sales tax", vatRate: 0, citRate: 21,
    payrollScheme: "generic",
    notes: "IRC · Federal CIT 21% (+state) · Federal/state income tax withholding · FICA 7.65% each side · FUTA/SUTA.",
  },
  {
    code: "EU", name: "European Union (generic)", currency: "EUR", vatName: "VAT", vatRate: 20, citRate: 24,
    payrollScheme: "generic",
    notes: "EU VAT Directive 2006/112/EC · IFRS-EU endowment · payroll varies by member state — configure bands in Admin.",
  },
  {
    code: "AE", name: "United Arab Emirates", currency: "AED", vatName: "VAT", vatRate: 5, citRate: 9,
    payrollScheme: "generic",
    notes: "UAE CT 9% (2023) · VAT 5% · No personal income tax · End-of-service gratuity accrual required (UAE Labour Law).",
  },
  {
    code: "ZA-X", name: "Other / International", currency: "USD", vatName: "Indirect tax", vatRate: 0, citRate: 0,
    payrollScheme: "generic",
    notes: "Configure the jurisdiction profile (indirect tax, CIT, payroll bands) in Admin & Compliance for any other economy. IFRS reporting applies regardless.",
  },
];

export const jurisdictionByCode = (code: string): Jurisdiction =>
  JURISDICTIONS.find((j) => j.code === code) ?? JURISDICTIONS[JURISDICTIONS.length - 1];
