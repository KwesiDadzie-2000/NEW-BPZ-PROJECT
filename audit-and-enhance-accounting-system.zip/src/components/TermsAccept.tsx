"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, btn, Icon } from "./ui";

export function TermsAccept({ name, role }: { name: string; role: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function accept() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/security", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op: "accept_terms" }),
      });
      const data = await res.json();
      if (data.ok) {
        router.push("/");
        router.refresh();
      } else setError(data.error);
    } catch {
      setError("Could not record acceptance.");
    }
    setBusy(false);
  }

  return (
    <Card title="Terms of engagement" sub={`${name} · ${role} account`}>
      <div className="space-y-3 text-[13px] leading-relaxed text-mist-400">
        <p>
          Before this workspace is used on client engagements, please confirm the following operating
          terms. This record is written to the immutable audit log with your username and a timestamp.
        </p>
        <ol className="space-y-2">
          <li className="flex gap-2">
            <span className="font-bold text-gold-400">1.</span>
            <span><strong className="text-mist-200">Confidentiality.</strong> Client financial data accessed here is confidential and must not be disclosed outside the engagement team.</span>
          </li>
          <li className="flex gap-2">
            <span className="font-bold text-gold-400">2.</span>
            <span><strong className="text-mist-200">Data protection.</strong> Processing complies with Ghana&apos;s Data Protection Act, 2012 (Act 843). Personal data in payroll records is processed only for statutory payroll, tax and reporting purposes.</span>
          </li>
          <li className="flex gap-2">
            <span className="font-bold text-gold-400">3.</span>
            <span><strong className="text-mist-200">Accuracy of records.</strong> Postings made by you are your professional responsibility; the platform records who made each entry and when.</span>
          </li>
          <li className="flex gap-2">
            <span className="font-bold text-gold-400">4.</span>
            <span><strong className="text-mist-200">Statutory rates.</strong> Tax and payroll rates are configurable. The engagement owner must verify they match current legislation before filing.</span>
          </li>
          <li className="flex gap-2">
            <span className="font-bold text-gold-400">5.</span>
            <span><strong className="text-mist-200">Backups.</strong> Snapshots taken here support restore and client hand-over; server-side disaster recovery is operated at infrastructure level.</span>
          </li>
        </ol>
      </div>

      <div className="mt-5 flex items-center justify-between gap-3">
        <button
          className="text-xs font-semibold text-mist-500 hover:text-mist-300"
          onClick={() => {
            void fetch("/api/auth/logout", { method: "POST" }).then(() => {
              router.push("/login");
              router.refresh();
            });
          }}
        >
          Decline and sign out
        </button>
        <button className={btn.gold} onClick={accept} disabled={busy}>
          {busy ? "Recording…" : <><Icon name="check" size={15} /> Accept and continue</>}
        </button>
      </div>
      {error && <div className="mt-3 text-xs text-neg">{error}</div>}
    </Card>
  );
}
