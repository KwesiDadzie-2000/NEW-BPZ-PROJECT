"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { btn, cn } from "./ui";

export function RowAction({
  action,
  payload,
  label,
  tone = "default",
  user = "user",
}: {
  action: string;
  payload?: Record<string, unknown>;
  label: string;
  tone?: "default" | "gold";
  user?: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function fire() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, user, ...payload }),
      });
      const data = await res.json();
      if (data.ok) {
        router.refresh();
      } else {
        setError(data.error as string);
        window.setTimeout(() => setError(null), 5000);
      }
    } catch {
      setError("Network error.");
    }
    setBusy(false);
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <button
        className={cn(btn.tiny, tone === "gold" && "border-gold-400/40 text-gold-300 hover:border-gold-400/70")}
        disabled={busy}
        onClick={fire}
      >
        {busy ? (
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-mist-500/30 border-t-mist-300" />
        ) : (
          label
        )}
      </button>
      {error && <span className="max-w-[240px] text-right text-[12.5px] leading-snug text-neg">{error}</span>}
    </div>
  );
}
