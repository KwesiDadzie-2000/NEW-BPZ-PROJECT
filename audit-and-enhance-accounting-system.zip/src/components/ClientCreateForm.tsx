"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls, cn } from "./ui";

export function ClientCreateForm({
  sectors,
  serviceLines,
  jurisdictions,
}: {
  sectors: { value: string; label: string }[];
  serviceLines: { value: string; label: string }[];
  jurisdictions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [sector, setSector] = useState("services");
  const [jurisdiction, setJurisdiction] = useState("GH");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [picked, setPicked] = useState<string[]>(["bookkeeping", "payroll", "tax_compliance"]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [tempInfo, setTempInfo] = useState<{
    user: string;
    pass: string;
    portalUrl: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  function toggle(code: string) {
    setPicked((p) => (p.includes(code) ? p.filter((x) => x !== code) : [...p, code]));
  }

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);
    setTempInfo(null);
    try {
      const res = await fetch("/api/clients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: name,
          sector,
          jurisdiction,
          username,
          password,
          displayName,
          serviceLines: picked.join(","),
          feeModel: "Monthly service lines",
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccess(data.message);
        setTempInfo({
          user: data.credentials?.username ?? username,
          pass: data.credentials?.temporaryPassword ?? password,
          portalUrl: data.credentials?.portalUrl ?? data.loginLink ?? `${window.location.origin}/login`,
        });
        setCopied(false);
        setName("");
        setUsername("");
        setPassword("");
        setDisplayName("");
        router.refresh();
      } else {
        setError(data.error);
      }
    } catch {
      setError("Could not reach the service.");
    }
    setBusy(false);
  }

  return (
    <Card title="New Client Workspace" sub="Sector determines the tax context, chart focus and sector operations available in the workspace">
      <form onSubmit={create} className="grid grid-cols-2 gap-3">
        <Field label="Client / company name" className="col-span-2">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Golden Ore Mining Ltd" required minLength={2} />
        </Field>
        <Field label="Sector" className="col-span-2">
          <select className={inputCls} value={sector} onChange={(e) => setSector(e.target.value)}>
            {sectors.map((s) => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Login username" hint="3–30 chars">
          <input className={inputCls + " font-mono text-xs"} value={username} onChange={(e) => setUsername(e.target.value.toLowerCase())} required minLength={3} placeholder="clientlogin" />
        </Field>
        <Field
          label="Temporary password"
          hint="10+ characters, upper + lower case and a digit; reset required on first login"
        >
          <input
            type="password"
            className={inputCls}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={10}
          />
        </Field>
        <Field label="Full name (optional)" className="col-span-2">
          <input className={inputCls} value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="e.g. Akosua Darko (CFO)" />
        </Field>

        <div className="col-span-2">
          <span className="mb-1.5 block text-xs font-semibold text-mist-400">BPZ service lines (monthly billing)</span>
          <div className="flex flex-wrap gap-1.5">
            {serviceLines.map((s) => (
              <button
                key={s.value}
                type="button"
                onClick={() => toggle(s.value)}
                className={cn(
                  "rounded-md border px-2.5 py-1.5 text-[12.5px] font-semibold transition",
                  picked.includes(s.value) ? "border-gold-400/60 bg-gold-400/15 text-gold-300" : "border-ink-600 text-mist-500 hover:text-mist-300"
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="col-span-2 flex justify-end">
          <button className={btn.gold} disabled={busy}>
            {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="plus" size={15} />}
            {busy ? "Creating…" : "Create client & login"}
          </button>
        </div>

        {error && <div className="col-span-2 text-xs text-neg">{error}</div>}
        {success && (
          <div className="col-span-2 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2.5 text-xs leading-relaxed text-pos">
            <div className="font-bold">{success}</div>
            {tempInfo && (
              <div className="mt-2 space-y-2 text-mist-300">
                <div className="grid gap-1 rounded-lg border border-pos/25 bg-white/60 p-3 font-mono text-[12.5px]">
                  <div>
                    <span className="font-sans font-semibold text-mist-500">Portal: </span>
                    <a
                      href={tempInfo.portalUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="break-all font-semibold text-sd underline decoration-sd/40 underline-offset-2"
                    >
                      {tempInfo.portalUrl}
                    </a>
                  </div>
                  <div>
                    <span className="font-sans font-semibold text-mist-500">Username: </span>
                    <span className="font-bold text-gold-300">{tempInfo.user}</span>
                  </div>
                  <div>
                    <span className="font-sans font-semibold text-mist-500">Temporary password: </span>
                    <span className="font-bold text-gold-300">{tempInfo.pass}</span>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    className={btn.tiny}
                    onClick={async () => {
                      const text = [
                        "BPZ CONSULT client portal",
                        `Portal: ${tempInfo.portalUrl}`,
                        `Username: ${tempInfo.user}`,
                        `Temporary password: ${tempInfo.pass}`,
                        "You must set a new password on first login.",
                      ].join("\n");
                      await navigator.clipboard.writeText(text);
                      setCopied(true);
                    }}
                  >
                    <Icon name="doc" size={13} />
                    {copied ? "Access details copied" : "Copy access details"}
                  </button>
                  <span className="text-[12px] text-mist-500">
                    The client can only see their own workspace and must reset the password on first login.
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </form>
    </Card>
  );
}
