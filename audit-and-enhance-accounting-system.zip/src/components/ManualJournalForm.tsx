"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls, cn } from "./ui";
import { num } from "@/lib/format";

type Line = { account: string; cc: string; desc: string; amount: string; side: "dr" | "cr" };
const emptyLine = (): Line => ({ account: "", cc: "", desc: "", amount: "", side: "dr" });

const CATEGORIES = [
  { value: "SA", label: "Journal (FB50)" },
  { value: "OPEN", label: "Opening balance" },
  { value: "PREPAY", label: "Prepayment" },
  { value: "ADJ", label: "Adjustment" },
];

export function ManualJournalForm({
  accountOptions,
  ccOptions,
}: {
  accountOptions: { value: string; label: string }[];
  ccOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [lines, setLines] = useState<Line[]>([emptyLine(), emptyLine()]);
  const [category, setCategory] = useState("SA");
  const [reason, setReason] = useState("");
  const [reference, setReference] = useState("");
  const [period, setPeriod] = useState("");
  const [user, setUser] = useState("accountant");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const totals = useMemo(() => {
    let dr = 0;
    let cr = 0;
    for (const l of lines) {
      const a = Number(l.amount);
      if (Number.isFinite(a) && a > 0) {
        if (l.side === "dr") dr += a;
        else cr += a;
      }
    }
    return { dr: Math.round(dr * 100) / 100, cr: Math.round(cr * 100) / 100, diff: dr - cr };
  }, [lines]);

  const validLines = lines.filter((l) => l.account && Number(l.amount) > 0);
  const balanced = Math.abs(totals.diff) < 0.005;
  const needsReason = category === "ADJ" || category === "OPEN";
  const canPost = lines.length >= 2 && validLines.length === lines.length && balanced && (!needsReason || reason.trim().length > 0);

  const setLine = (idx: number, patch: Partial<Line>) => {
    setLines((ls) => ls.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
    setError(null);
  };

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canPost) return;
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await fetch("/api/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "manual_journal",
          user,
          reference: reference || reason,
          docCategory: category,
          reason,
          period: period || undefined,
          lines: lines.map((l) => ({
            account: l.account, cc: l.cc, desc: l.desc,
            dr: l.side === "dr" ? Number(l.amount) : 0,
            cr: l.side === "cr" ? Number(l.amount) : 0,
          })),
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccess(data.message);
        setLines([emptyLine(), emptyLine()]);
        setReason("");
        setReference("");
        router.refresh();
      } else setError(data.error);
    } catch {
      setError("Could not reach the posting service.");
    }
    setBusy(false);
  }

  return (
    <Card title="Manual Journal — Openings · Prepayments · Adjustments" sub="Free-entry with document category; openings and adjustments require a reason. The engine enforces balance and valid accounts.">
      <div className="space-y-3">
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Document category">
            <select className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Fiscal period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={period} onChange={(e) => setPeriod(e.target.value)} required />
          </Field>
          <Field label="Post as">
            <input className={inputCls + " font-mono text-xs"} value={user} onChange={(e) => setUser(e.target.value)} />
          </Field>
        </div>

        {needsReason && (
          <Field label={category === "OPEN" ? "Reason (e.g. FY opening balances)" : "Reason for adjustment"}>
            <input className={inputCls} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Mandatory — audited in the reference field" />
          </Field>
        )}
        <Field label="Reference (optional)">
          <input className={inputCls} value={reference} onChange={(e) => setReference(e.target.value)} placeholder="e.g. Month-end accrual" />
        </Field>

        <div className="hidden grid-cols-[2fr_1.1fr_1.6fr_1fr_auto_auto] gap-2 px-0.5 text-[12px] font-bold uppercase tracking-[0.14em] text-mist-600 sm:grid">
          <span>Account</span><span>Cost center</span><span>Description</span><span>Amount</span><span>Side</span><span />
        </div>

        {lines.map((l, i) => (
          <div key={i} className="grid grid-cols-2 gap-2 rounded-lg border border-ink-700/70 bg-ink-900/40 p-2 sm:grid-cols-[2fr_1.1fr_1.6fr_1fr_auto_auto] sm:border-0 sm:bg-transparent sm:p-0">
            <select className={inputCls + " text-[13px]"} value={l.account} onChange={(e) => setLine(i, { account: e.target.value })}>
              <option value="">— account —</option>
              {accountOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
            <select className={inputCls + " text-[13px]"} value={l.cc} onChange={(e) => setLine(i, { cc: e.target.value })}>
              <option value="">— cc —</option>
              {ccOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
            <input className={inputCls + " text-[13px]"} placeholder="Description" value={l.desc} onChange={(e) => setLine(i, { desc: e.target.value })} />
            <input type="number" min={0} step="0.01" className={inputCls + " text-right font-mono text-[13px]"} placeholder="0.00" value={l.amount} onChange={(e) => setLine(i, { amount: e.target.value })} />
            <div className="col-span-2 flex items-center gap-1 sm:col-span-1">
              {(["dr", "cr"] as const).map((s) => (
                <button key={s} type="button" onClick={() => setLine(i, { side: s })}
                  className={cn("flex-1 rounded-md border px-2.5 py-2 text-xs font-bold uppercase tracking-wider transition sm:flex-none",
                    l.side === s ? (s === "dr" ? "border-aa/50 bg-aa/15 text-aa" : "border-pos/50 bg-pos/15 text-pos") : "border-ink-600 text-mist-500 hover:text-mist-300")}
                  title={s === "dr" ? "Debit" : "Credit"}>
                  {s}
                </button>
              ))}
            </div>
            <button type="button" className="flex items-center justify-center rounded-md border border-transparent p-2 text-mist-600 transition hover:border-neg/30 hover:text-neg disabled:opacity-30" disabled={lines.length <= 2} onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))}>
              <Icon name="x" size={14} />
            </button>
          </div>
        ))}

        <button type="button" className="text-xs font-semibold text-mist-500 hover:text-gold-300" onClick={() => setLines((ls) => [...ls, emptyLine()])}>
          + Add line
        </button>

        <div className="flex flex-wrap items-end justify-between gap-4 border-t border-ink-700/70 pt-4">
          <div className="flex flex-wrap items-center gap-x-8 gap-y-2">
            <div>
              <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-600">Debits</div>
              <div className="font-mono text-lg tabular-nums text-aa">{num(totals.dr)}</div>
            </div>
            <div>
              <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-600">Credits</div>
              <div className="font-mono text-lg tabular-nums text-pos">{num(totals.cr)}</div>
            </div>
            <div className={cn("rounded-lg border px-3 py-2 text-xs font-semibold", balanced ? "border-pos/30 bg-pos/10 text-pos" : "border-neg/30 bg-neg/10 text-neg")}>
              {balanced ? "Balanced — ready to post" : `Out of balance by ${num(Math.abs(totals.diff))}`}
            </div>
          </div>
          <button type="submit" className={btn.gold} disabled={!canPost || busy} onClick={onSubmit}>
            {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="check" size={15} />}
            {busy ? "Posting…" : "Post document"}
          </button>
        </div>

        {error && (
          <div className="flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
            <Icon name="x" size={14} className="mt-px shrink-0" /><span>{error}</span>
          </div>
        )}
        {success && (
          <div className="flex items-start gap-2 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">
            <Icon name="check" size={14} className="mt-px shrink-0" /><span>{success}</span>
          </div>
        )}
      </div>
    </Card>
  );
}
