"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, cn, Badge, Stat, numCls, rowCls, tdCls, thCls } from "./ui";
import { num } from "@/lib/format";

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export type LoanRow = {
  id: number; code: string; lender: string; facilityType: string;
  principal: number; annualRate: number; termMonths: number;
  outstanding: number; currentPortion: number; nonCurrentPortion: number;
  nextPayment: number; debtService12m: number; effectiveRate: number; status: string;
};
type ScheduleRow = {
  id: number; seq: number; period: string; opening: string; interest: string;
  fee: string; principal: string; payment: string; closing: string; status: string; docNo: string;
};

export function LoansDesk({
  loans,
  portfolio,
  ccOptions,
  period,
}: {
  loans: LoanRow[];
  portfolio: { outstanding: number; current: number; nonCurrent: number; debtService12m: number };
  ccOptions: { value: string; label: string }[];
  period: string;
}) {
  const router = useRouter();
  const [selected, setSelected] = useState<number | null>(loans[0]?.id ?? null);
  const [schedule, setSchedule] = useState<ScheduleRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(loans.length === 0);

  async function run(payload: Record<string, unknown>) {
    setBusy(true); setError(null); setMsg(null);
    const d = await post(payload);
    setBusy(false);
    if (d.ok) { setMsg(d.message); router.refresh(); } else setError(d.error);
  }

  async function loadSchedule(id: number) {
    setSelected(id);
    const d = await post({ action: "loan.schedule", loanId: id });
    if (d.ok) setSchedule(d.rows);
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Borrowings outstanding" value={num(portfolio.outstanding)} tone="text-aa" />
        <Stat label="Current portion (12m)" value={num(portfolio.current)} sub="Shown in current liabilities" />
        <Stat label="Non-current portion" value={num(portfolio.nonCurrent)} sub="Shown in borrowings" />
        <Stat label="Debt service next 12m" value={num(portfolio.debtService12m)} sub="Principal + interest + fees" tone="text-neg" />
      </div>

      {msg && <div className="rounded-lg border border-pos/30 bg-pos/10 px-3 py-2.5 text-[12.5px] text-pos">{msg}</div>}
      {error && <div className="rounded-lg border border-neg/30 bg-neg/10 px-3 py-2.5 text-[12.5px] text-neg">{error}</div>}

      <Card
        title="Loan facilities"
        sub="Each facility carries its own full amortisation schedule, effective interest rate and covenant metrics"
        action={
          <button className={btn.gold} onClick={() => setShowNew(!showNew)}>
            {showNew ? "Close" : <><Icon name="plus" size={15} /> New facility</>}
          </button>
        }
      >
        {showNew && (
          <form
            className="mb-4 grid grid-cols-2 gap-3 rounded-lg border border-ink-700 bg-ink-900/40 p-3"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              run({
                action: "loan.drawdown",
                code: f.get("code"),
                lender: f.get("lender"),
                facilityType: f.get("facilityType"),
                principal: Number(f.get("principal")),
                annualRate: Number(f.get("annualRate")),
                termMonths: Number(f.get("termMonths")),
                startDate: f.get("startDate"),
                frequency: f.get("frequency"),
                timing: f.get("timing"),
                moratoriumMonths: Number(f.get("moratoriumMonths") || 0),
                arrangementFee: Number(f.get("arrangementFee") || 0),
                feeSpreadMonths: Number(f.get("feeSpreadMonths") || 0),
                cc: f.get("cc"),
                period,
              });
              setShowNew(false);
              e.currentTarget.reset();
            }}
          >
            <Field label="Loan code"><input name="code" className={inputCls} required placeholder="LN-2026-01" /></Field>
            <Field label="Lender"><input name="lender" className={inputCls} placeholder="Stanbic Bank Ghana" /></Field>
            <Field label="Facility type">
              <select name="facilityType" className={inputCls} defaultValue="amortising">
                <option value="amortising">Amortising — equal instalments</option>
                <option value="interest_only">Interest only — bullet principal</option>
                <option value="bullet">Bullet — interest capitalises to maturity</option>
              </select>
            </Field>
            <Field label="Principal (GHS)"><input name="principal" type="number" step="0.01" className={inputCls} required /></Field>
            <Field label="Interest rate % p.a."><input name="annualRate" type="number" step="0.0001" className={inputCls} required /></Field>
            <Field label="Term (months)"><input name="termMonths" type="number" min={1} className={inputCls} required defaultValue={60} /></Field>
            <Field label="First payment period"><input name="startDate" type="month" className={inputCls + " font-mono text-xs"} required /></Field>
            <Field label="Frequency">
              <select name="frequency" className={inputCls} defaultValue="monthly">
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="annually">Annually</option>
              </select>
            </Field>
            <Field label="Moratorium (months)" hint="Principal deferred; interest still accrues">
              <input name="moratoriumMonths" type="number" min={0} className={inputCls} defaultValue={0} />
            </Field>
            <Field label="Arrangement fee"><input name="arrangementFee" type="number" step="0.01" className={inputCls} /></Field>
            <Field label="Fee spread over (months)" hint="0 = over the full term"><input name="feeSpreadMonths" type="number" min={0} className={inputCls} /></Field>
            <Field label="Cost centre">
              <select name="cc" className={inputCls} defaultValue="">
                <option value="">— none —</option>
                {ccOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </Field>
            <div className="col-span-2 flex justify-end">
              <button className={btn.gold} disabled={busy}>Draw down &amp; build schedule</button>
            </div>
          </form>
        )}

        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px]">
            <thead>
              <tr className="border-b border-ink-700/70">
                <th className={thCls}>Code</th>
                <th className={thCls}>Lender</th>
                <th className={thCls}>Type</th>
                <th className={thCls + " text-right"}>Principal</th>
                <th className={thCls + " text-right"}>Rate %</th>
                <th className={thCls + " text-right"}>Outstanding</th>
                <th className={thCls + " text-right"}>Effective %</th>
                <th className={thCls + " text-right"}>Next payment</th>
                <th className={thCls + " text-right"}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loans.length === 0 && (
                <tr><td colSpan={9} className="px-3 py-6 text-center text-sm text-mist-500">No loan facilities recorded.</td></tr>
              )}
              {loans.map((l) => (
                <tr key={l.id} className={rowCls + (selected === l.id ? " bg-gold-400/5" : "")}>
                  <td className={tdCls}>
                    <button className="font-mono text-[12.5px] font-bold text-gold-300 hover:underline" onClick={() => loadSchedule(l.id)}>
                      {l.code}
                    </button>
                  </td>
                  <td className={tdCls}>{l.lender || "—"}</td>
                  <td className={tdCls}><Badge tone={l.facilityType === "amortising" ? "mm" : l.facilityType === "bullet" ? "amber" : "sd"}>{l.facilityType.replace("_", " ")}</Badge></td>
                  <td className={numCls}>{num(l.principal)}</td>
                  <td className={numCls}>{num(l.annualRate)}</td>
                  <td className={numCls + " font-semibold"}>{num(l.outstanding)}</td>
                  <td className={numCls + " text-neg"}>{num(l.effectiveRate)}</td>
                  <td className={numCls}>{num(l.nextPayment)}</td>
                  <td className={tdCls}>
                    <div className="flex justify-end gap-1">
                      <button className={btn.tiny} disabled={busy} onClick={() => run({ action: "loan.repay", loanId: l.id, period })}>
                        Pay instalment
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="border-t border-ink-700 px-4 py-2.5 text-[11.5px] leading-relaxed text-mist-500">
          Click a loan code to load its full schedule below. &quot;Pay instalment&quot; settles the next due payment —
          interest, fee and principal split — and posts it to the ledger.
        </p>
      </Card>

      {schedule.length > 0 && (
        <Card title={`Amortisation schedule (${schedule.length} periods)`} sub="Interest, fee and principal split per period — this is the schedule your lender provides" pad={false}>
          <div className="max-h-[520px] overflow-auto">
            <table className="w-full min-w-[900px]">
              <thead className="sticky top-0 bg-ink-850">
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>#</th>
                  <th className={thCls}>Period</th>
                  <th className={thCls + " text-right"}>Opening</th>
                  <th className={thCls + " text-right"}>Interest</th>
                  <th className={thCls + " text-right"}>Fee</th>
                  <th className={thCls + " text-right"}>Principal</th>
                  <th className={thCls + " text-right"}>Payment</th>
                  <th className={thCls + " text-right"}>Closing</th>
                  <th className={thCls}>Status</th>
                </tr>
              </thead>
              <tbody>
                {schedule.map((s) => (
                  <tr key={s.id} className={rowCls + (s.status === "paid" ? " opacity-60" : "")}>
                    <td className={tdCls}><span className="font-mono text-[12px]">{s.seq}</span></td>
                    <td className={tdCls}><span className="font-mono text-[11.5px]">{s.period}</span></td>
                    <td className={numCls}>{num(Number(s.opening))}</td>
                    <td className={numCls + " text-neg"}>{num(Number(s.interest))}</td>
                    <td className={numCls}>{Number(s.fee) > 0 ? num(Number(s.fee)) : "—"}</td>
                    <td className={numCls}>{num(Number(s.principal))}</td>
                    <td className={numCls + " font-semibold"}>{num(Number(s.payment))}</td>
                    <td className={numCls}>{num(Number(s.closing))}</td>
                    <td className={tdCls}>
                      <Badge tone={s.status === "paid" ? "green" : "slate"}>{s.status}</Badge>
                      {s.docNo && <div className="mt-0.5 font-mono text-[10px] text-mist-600">{s.docNo}</div>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
