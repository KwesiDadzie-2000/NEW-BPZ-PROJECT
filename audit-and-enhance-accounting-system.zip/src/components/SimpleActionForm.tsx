"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Field, btn, inputCls, cn } from "./ui";

export type SimpleField =
  | string
  | {
      label?: string;
      name?: string;
      defaultValue?: string;
      placeholder?: string;
      type?: "text" | "number" | "checkbox";
      required?: boolean;
      wide?: boolean;
      hint?: string;
    };

function norm(name: string, f: SimpleField) {
  if (typeof f === "string") {
    return { name, label: name, defaultValue: f, placeholder: "", type: "text" as const, required: false, wide: false, hint: "" };
  }
  return {
    name: f.name || name,
    label: f.label || name,
    defaultValue: f.defaultValue ?? "",
    placeholder: f.placeholder ?? "",
    type: f.type ?? "text",
    required: f.required ?? false,
    wide: f.wide ?? false,
    hint: f.hint ?? "",
  };
}

export function SimpleActionForm({
  action,
  label,
  fields = {},
  endpoint = "/api/actions",
  className,
  onResult,
}: {
  action: string;
  label: string;
  fields?: Record<string, SimpleField>;
  endpoint?: string;
  className?: string;
  onResult?: (data: Record<string, unknown>) => void;
}) {
  const router = useRouter();
  const specs = Object.entries(fields).map(([k, v]) => norm(k, v));
  const [values, setValues] = useState<Record<string, string>>(() => {
    const v: Record<string, string> = {};
    for (const s of specs) v[s.name] = s.defaultValue;
    return v;
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);
    const payload: Record<string, unknown> = { action };
    for (const s of specs) {
      const raw = values[s.name] ?? "";
      if (s.type === "checkbox") payload[s.name] = raw === "1" || raw === "true";
      else if (s.type === "number") payload[s.name] = raw === "" ? 0 : Number(raw);
      else if (raw === "true" || raw === "false") payload[s.name] = raw === "true";
      else payload[s.name] = raw;
    }
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccess((data.message as string) || "Saved.");
        // Preserve secrets display for API keys
        if (data.key) setSuccess(`API key created — copy now: ${data.key}`);
        if (data.secret && data.id) setSuccess(`Webhook #${data.id} secret: ${data.secret}`);
        onResult?.(data);
        router.refresh();
      } else {
        setError((data.error as string) || "Request failed");
      }
    } catch {
      setError("Could not reach the server.");
    }
    setBusy(false);
  }

  return (
    <form onSubmit={onSubmit} className={cn("grid grid-cols-2 gap-3", className)}>
      {specs.map((s) => (
        <Field key={s.name} label={s.label} className={s.wide ? "col-span-2" : undefined} hint={s.hint || undefined}>
          {s.type === "checkbox" ? (
            <label className="flex items-center gap-2 text-sm text-mist-200">
              <input
                type="checkbox"
                className="accent-gold-400"
                checked={values[s.name] === "1" || values[s.name] === "true"}
                onChange={(e) => setValues((v) => ({ ...v, [s.name]: e.target.checked ? "true" : "false" }))}
              />
              Enable
            </label>
          ) : (
            <input
              type={s.type === "number" ? "number" : "text"}
              className={inputCls}
              value={values[s.name] ?? ""}
              onChange={(e) => setValues((v) => ({ ...v, [s.name]: e.target.value }))}
              placeholder={s.placeholder}
              required={s.required}
              step={s.type === "number" ? "any" : undefined}
            />
          )}
        </Field>
      ))}
      <div className="col-span-2 flex flex-wrap items-center gap-3">
        <button type="submit" disabled={busy} className={btn.gold}>
          {busy ? "Working…" : label}
        </button>
        {success && <span className="text-sm text-emerald-400">{success}</span>}
        {error && <span className="text-sm text-rose-400">{error}</span>}
      </div>
    </form>
  );
}
