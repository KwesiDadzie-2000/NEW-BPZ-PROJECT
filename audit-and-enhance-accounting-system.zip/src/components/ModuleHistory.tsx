import Link from "next/link";
import { journalRows } from "@/lib/reports";
import { fmtDate, num } from "@/lib/format";
import { Card, EmptyState, tdCls, thCls, numCls, rowCls } from "./ui";

export async function ModuleHistory({
  clientId,
  module,
  title,
  sub,
  limit = 30,
}: {
  clientId: number;
  module: string;
  title: string;
  sub: string;
  limit?: number;
}) {
  const rows = await journalRows({ clientId, module, limit });

  return (
    <Card title={title} sub={sub} pad={false}>
      {rows.length === 0 ? (
        <div className="p-4">
          <EmptyState
            icon="journal"
            title="No postings from this module yet"
            body="Actions taken in this module will appear here — and in the Universal Journal."
          />
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-ink-700/70">
                <th className={thCls}>Doc</th>
                <th className={thCls}>Date</th>
                <th className={thCls}>Account</th>
                <th className={thCls}>Description</th>
                <th className={thCls}>CC</th>
                <th className={thCls}>BP</th>
                <th className={thCls + " text-right"}>Debit</th>
                <th className={thCls + " text-right"}>Credit</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className={rowCls}>
                  <td className={tdCls}>
                    <Link
                      href={`/universal-journal?doc=${r.docNo}`}
                      className="font-mono text-[12px] text-gold-300 hover:underline"
                    >
                      {r.docNo}
                    </Link>
                  </td>
                  <td className={tdCls + " text-[12.5px] text-mist-500"}>{fmtDate(r.postDate)}</td>
                  <td className={tdCls}>
                    <span className="font-mono text-[12.5px] text-mist-100">{r.account}</span>
                    <div className="mt-0.5 max-w-[180px] truncate text-[12.5px] text-mist-600">{r.accDesc}</div>
                  </td>
                  <td className={tdCls}>
                    <span className="block max-w-[240px] truncate text-[13px]">{r.description}</span>
                  </td>
                  <td className={tdCls}>
                    <span className="font-mono text-[12.5px] text-mist-500">{r.costCenter || "—"}</span>
                  </td>
                  <td className={tdCls}>
                    <span className="font-mono text-[12.5px] text-mist-500">{r.bp || "—"}</span>
                  </td>
                  <td className={numCls + " text-aa"}>{r.debit ? num(r.debit) : ""}</td>
                  <td className={numCls + " text-sd"}>{r.credit ? num(r.credit) : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
