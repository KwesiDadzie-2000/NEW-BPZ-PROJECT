"use client";

import { useState } from "react";
import { Card } from "./ui";
import { SimpleActionForm } from "./SimpleActionForm";

const TABS: [string, string, string][] = [
  ["ias37", "IAS 37", "Provisions & contingencies"],
  ["ias19", "IAS 19", "Employee benefits"],
  ["ias33", "IAS 33", "Earnings per share"],
  ["ias12", "IAS 12", "Deferred tax"],
  ["ifrs8", "IFRS 8", "Operating segments"],
  ["ifrs13", "IFRS 13", "Fair value hierarchy"],
  ["ias24", "IAS 24", "Related parties"],
  ["ias10", "IAS 10 / 29", "Events & hyperinflation"],
];

export function ExtendedStandardsDesk({ period }: { period: string }) {
  const [tab, setTab] = useState("ias37");

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {TABS.map(([id, label, note]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`rounded-lg border px-3 py-2 text-left text-sm transition ${
              tab === id ? "border-gold-400 bg-gold-400/10 text-gold-400" : "border-ink-600 text-mist-300 hover:border-mist-500"
            }`}
          >
            <div className="font-semibold">{label}</div>
            <div className="text-[11px] text-mist-500">{note}</div>
          </button>
        ))}
      </div>

      {tab === "ias37" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Recognise / disclose provision" sub="IAS 37 decision tree — probable → recognise; possible → contingent">
            <SimpleActionForm
              action="ias37.recognise"
              label="Assess & post"
              fields={{
                code: { label: "Code", placeholder: "PROV-01", required: true },
                title: { label: "Title", placeholder: "Legal claim", required: true },
                category: { label: "Category", defaultValue: "legal" },
                bestEstimate: { label: "Best estimate", type: "number", required: true },
                probability: { label: "Probability %", type: "number", defaultValue: "70" },
                discountRate: { label: "Discount rate %", type: "number", defaultValue: "0" },
                yearsToSettlement: { label: "Years to settlement", type: "number", defaultValue: "1" },
                contingent: { label: "Force contingent", defaultValue: "false" },
                contingentAsset: { label: "Contingent asset", defaultValue: "false" },
                obligatingEvent: { label: "Obligating event", wide: true },
                period: { label: "Period", defaultValue: period },
                notes: { label: "Notes", wide: true },
              }}
            />
          </Card>
          <Card title="Utilise / unwind" sub="Settlement against provision; finance cost on discounting">
            <SimpleActionForm
              action="ias37.utilise"
              label="Utilise provision"
              fields={{
                id: { label: "Provision id", type: "number", required: true },
                amount: { label: "Amount", type: "number", required: true },
                period: { label: "Period", defaultValue: period },
              }}
            />
            <div className="mt-4">
              <SimpleActionForm
                action="ias37.unwind"
                label="Unwind discount"
                fields={{
                  id: { label: "Provision id", type: "number", required: true },
                  period: { label: "Period", defaultValue: period },
                }}
              />
            </div>
            <div className="mt-4">
              <SimpleActionForm
                action="ias37.contingency"
                label="Disclose contingency"
                fields={{
                  title: { label: "Title", required: true },
                  kind: { label: "Kind (liability|asset)", defaultValue: "liability" },
                  likelihood: { label: "Likelihood", defaultValue: "possible" },
                  estimateLow: { label: "Estimate low", type: "number" },
                  estimateHigh: { label: "Estimate high", type: "number" },
                  description: { label: "Description", wide: true },
                  period: { label: "Period", defaultValue: period },
                }}
              />
            </div>
          </Card>
        </div>
      )}

      {tab === "ias19" && (
        <Card title="Defined benefit / gratuity plan" sub="Projected unit credit (simplified) with optional journal">
          <SimpleActionForm
            action="ias19.upsert_plan"
            label="Measure & save plan"
            fields={{
              code: { label: "Code", placeholder: "GRAT-01", required: true },
              name: { label: "Name", required: true },
              planType: { label: "Type", defaultValue: "gratuity" },
              members: { label: "Members", type: "number", defaultValue: "10" },
              averageSalary: { label: "Average salary", type: "number" },
              averageServiceYears: { label: "Avg service years", type: "number", defaultValue: "5" },
              salaryGrowth: { label: "Salary growth %", type: "number", defaultValue: "5" },
              discountRate: { label: "Discount rate %", type: "number", defaultValue: "10" },
              yearsToRetirement: { label: "Years to retirement", type: "number", defaultValue: "10" },
              planAssets: { label: "Plan assets", type: "number", defaultValue: "0" },
              postJournal: { label: "Post service cost journal (1/0)", defaultValue: "1" },
              period: { label: "Period", defaultValue: period },
              notes: { label: "Notes", wide: true },
            }}
          />
        </Card>
      )}

      {tab === "ias33" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="EPS computation" sub="Basic and diluted — anti-dilution rules applied">
            <SimpleActionForm
              action="ias33.eps"
              label="Compute EPS"
              fields={{
                period: { label: "Period", defaultValue: period },
                profitAttributable: { label: "Profit attributable", type: "number", required: true },
                preferenceDividends: { label: "Preference dividends", type: "number", defaultValue: "0" },
                weightedAvgShares: { label: "Weighted avg shares", type: "number", required: true },
                dilutiveShares: { label: "Dilutive potential shares", type: "number", defaultValue: "0" },
                discontinuedProfit: { label: "Discontinued profit", type: "number", defaultValue: "0" },
                notes: { label: "Notes", wide: true },
              }}
            />
          </Card>
          <Card title="Share capital register" sub="Feeds IAS 33 scope and equity notes">
            <SimpleActionForm
              action="ias33.share_capital"
              label="Save share capital"
              fields={{
                className: { label: "Class", defaultValue: "Ordinary" },
                parValue: { label: "Par value", type: "number", defaultValue: "1" },
                authorisedShares: { label: "Authorised shares", type: "number" },
                issuedShares: { label: "Issued shares", type: "number" },
                paidUpCapital: { label: "Paid-up capital", type: "number" },
                sharePremium: { label: "Share premium", type: "number", defaultValue: "0" },
                treasuryShares: { label: "Treasury shares", type: "number", defaultValue: "0" },
                period: { label: "Period", defaultValue: period },
              }}
            />
          </Card>
        </div>
      )}

      {tab === "ias12" && (
        <Card title="Deferred tax temporary difference" sub="Liability method — DTA / DTL from carrying vs tax base">
          <SimpleActionForm
            action="ias12.deferred_tax"
            label="Record temporary difference"
            fields={{
              description: { label: "Description", required: true, wide: true },
              origin: { label: "Origin (ppe|provisions|ecl|leases|tax_loss|other)", defaultValue: "ppe" },
              carryingAmount: { label: "Carrying amount", type: "number", required: true },
              taxBase: { label: "Tax base", type: "number", required: true },
              taxRate: { label: "Tax rate %", type: "number", defaultValue: "25" },
              throughOci: { label: "Through OCI (true/false)", defaultValue: "false" },
              period: { label: "Period", defaultValue: period },
              notes: { label: "Notes", wide: true },
            }}
          />
        </Card>
      )}

      {tab === "ifrs8" && (
        <Card title="Operating segment" sub="10% quantitative thresholds evaluated on save">
          <SimpleActionForm
            action="ifrs8.segment"
            label="Save segment"
            fields={{
              code: { label: "Code", required: true },
              name: { label: "Name", required: true },
              description: { label: "Description", wide: true },
              codm: { label: "CODM", defaultValue: "CEO" },
              costCenter: { label: "Cost center" },
              externalRevenue: { label: "External revenue", type: "number" },
              interSegmentRevenue: { label: "Inter-segment revenue", type: "number", defaultValue: "0" },
              segmentProfit: { label: "Segment profit", type: "number" },
              segmentAssets: { label: "Segment assets", type: "number" },
              segmentLiabilities: { label: "Segment liabilities", type: "number" },
              depreciation: { label: "Depreciation", type: "number", defaultValue: "0" },
              capitalExpenditure: { label: "Capex", type: "number", defaultValue: "0" },
              totalRevenue: { label: "Entity total revenue (for 10% test)", type: "number" },
              totalProfit: { label: "Entity total profit (for 10% test)", type: "number" },
              totalAssets: { label: "Entity total assets (for 10% test)", type: "number" },
              period: { label: "Period", defaultValue: period },
            }}
          />
        </Card>
      )}

      {tab === "ifrs13" && (
        <Card title="Fair value measurement" sub="Levels 1–3 hierarchy with unrealised gain/loss">
          <SimpleActionForm
            action="ifrs13.fair_value"
            label="Record FV measurement"
            fields={{
              code: { label: "Code", placeholder: "FV-01" },
              description: { label: "Description", required: true, wide: true },
              assetClass: { label: "Asset class", defaultValue: "financial" },
              level: { label: "Level (1|2|3)", type: "number", defaultValue: "2" },
              valuationTechnique: { label: "Technique (market|income|cost)", defaultValue: "market" },
              carryingAmount: { label: "Carrying amount", type: "number" },
              fairValue: { label: "Fair value", type: "number" },
              activeMarketQuoted: { label: "Active market quoted (true/false)", defaultValue: "false" },
              observableInputs: { label: "Observable inputs (true/false)", defaultValue: "true" },
              significantUnobservable: { label: "Significant unobservable (true/false)", defaultValue: "false" },
              period: { label: "Period", defaultValue: period },
              notes: { label: "Notes", wide: true },
            }}
          />
        </Card>
      )}

      {tab === "ias24" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Related party" sub="Parent, subsidiary, associate, key management, etc.">
            <SimpleActionForm
              action="ias24.party"
              label="Save related party"
              fields={{
                code: { label: "Code", required: true },
                name: { label: "Name", required: true },
                relationship: { label: "Relationship", defaultValue: "key_management" },
                bpNo: { label: "BP number" },
                controlPct: { label: "Control %", type: "number", defaultValue: "0" },
                nature: { label: "Nature", wide: true },
              }}
            />
          </Card>
          <Card title="Related-party transaction" sub="Amounts, outstanding balances, terms">
            <SimpleActionForm
              action="ias24.txn"
              label="Record transaction"
              fields={{
                relatedPartyId: { label: "Related party id", type: "number", required: true },
                nature: { label: "Nature", defaultValue: "sale" },
                description: { label: "Description", wide: true },
                amount: { label: "Amount", type: "number", required: true },
                outstanding: { label: "Outstanding", type: "number" },
                terms: { label: "Terms", defaultValue: "arm's length" },
                period: { label: "Period", defaultValue: period },
                docNo: { label: "Doc no" },
              }}
            />
          </Card>
        </div>
      )}

      {tab === "ias10" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Subsequent event (IAS 10)" sub="Adjusting vs non-adjusting">
            <SimpleActionForm
              action="ias10.event"
              label="Record event"
              fields={{
                title: { label: "Title", required: true },
                category: { label: "Category (adjusting|non_adjusting)", defaultValue: "non_adjusting" },
                eventDate: { label: "Event date", placeholder: "2026-03-15" },
                financialImpact: { label: "Financial impact", type: "number", defaultValue: "0" },
                description: { label: "Description", wide: true },
                adjustingEntryDocNo: { label: "Adjusting doc no" },
                period: { label: "Period", defaultValue: period },
              }}
            />
            <div className="mt-4">
              <SimpleActionForm
                action="ifrs7.risk"
                label="Add risk disclosure"
                fields={{
                  riskType: { label: "Risk type", defaultValue: "credit" },
                  title: { label: "Title", required: true },
                  exposure: { label: "Exposure", type: "number" },
                  mitigation: { label: "Mitigation", wide: true },
                  sensitivity: { label: "Sensitivity" },
                  body: { label: "Body", wide: true },
                  period: { label: "Period", defaultValue: period },
                }}
              />
            </div>
          </Card>
          <Card title="Hyperinflation factor (IAS 29)" sub="Only when functional currency is hyperinflationary">
            <SimpleActionForm
              action="ias29.factor"
              label="Set restatement factor"
              fields={{
                jurisdiction: { label: "Jurisdiction" },
                cpiIndex: { label: "CPI index", type: "number", defaultValue: "100" },
                baseCpi: { label: "Base CPI", type: "number", defaultValue: "100" },
                openingMonetaryNet: { label: "Opening monetary net", type: "number", defaultValue: "0" },
                closingMonetaryNet: { label: "Closing monetary net", type: "number", defaultValue: "0" },
                period: { label: "Period", defaultValue: period },
                notes: { label: "Notes", wide: true },
              }}
            />
          </Card>
        </div>
      )}
    </div>
  );
}
