"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls, cn, Badge } from "./ui";
import { num } from "@/lib/format";

type Emp = {
  id: number; code: string; name: string; position: string; department: string;
  email: string; phone: string; tin: string; ssnitNo: string; bankAccount: string;
  employmentType: string; jurisdiction: string; currency: string;
  basicSalary: number; allowances: number; hireDate: string; endDate: string; status: string;
};

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export function EmployeeManager({
  employees,
  jurisdictionOptions,
  ccOptions,
}: {
  employees: Emp[];
  jurisdictionOptions: { value: string; label: string }[];
  ccOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [tab, setTab] = useState<"add" | "list">("list");
  const [editing, setEditing] = useState<Emp | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");

  const filtered = employees.filter(
    (e) => !search || `${e.code} ${e.name} ${e.position} ${e.department}`.toLowerCase().includes(search.toLowerCase())
  );

  async function submitAdd(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setMsg(null);
    const fd = new FormData(e.currentTarget);
    const data = await post({ action: "add_employee", ...Object.fromEntries(fd.entries()) });
    setBusy(false);
    if (data.ok) {
      setMsg(data.message);
      (e.target as HTMLFormElement).reset();
      router.refresh();
    } else setError(data.error);
  }

  async function submitEdit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!editing) return;
    setBusy(true);
    setError(null);
    setMsg(null);
    const fd = new FormData(e.currentTarget);
    const data = await post({ action: "update_employee", employeeId: editing.id, ...Object.fromEntries(fd.entries()) });
    setBusy(false);
    if (data.ok) {
      setMsg(data.message);
      setEditing(null);
      router.refresh();
    } else setError(data.error);
  }

  async function terminate(emp: Emp) {
    setBusy(true);
    const data = await post({ action: "terminate_employee", employeeId: emp.id, endDate: new Date().toISOString().slice(0, 10) });
    setBusy(false);
    if (data.ok) { setMsg(data.message); router.refresh(); } else setError(data.error);
  }

  async function reinstate(emp: Emp) {
    setBusy(true);
    const data = await post({ action: "update_employee", employeeId: emp.id, status: "active", endDate: "" });
    setBusy(false);
    if (data.ok) { setMsg(`${emp.name} reinstated to active.`); router.refresh(); } else setError(data.error);
  }

  return (
    <Card
      title="Payroll Employee Master"
      sub="Add employees at any time — each carries their own jurisdiction, currency, salary and statutory identifiers. Editing a salary affects only future runs."
      action={
        <div className="flex gap-1.5">
          <button className={cn(btn.tiny, tab === "list" && "border-gold-400/50 text-gold-300")} onClick={() => setTab("list")}>Register ({employees.length})</button>
          <button className={cn(btn.tiny, tab === "add" && "border-gold-400/50 text-gold-300")} onClick={() => setTab("add")}>+ Add employee</button>
        </div>
      }
    >
      {msg && <div className="mb-3 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">{msg}</div>}
      {error && <div className="mb-3 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">{error}</div>}

      {tab === "add" && (
        <form onSubmit={submitAdd} className="grid grid-cols-2 gap-3">
          <Field label="Full name" className="col-span-2"><input name="name" className={inputCls} required /></Field>
          <Field label="Position / job title"><input name="position" className={inputCls} placeholder="e.g. Finance Manager" /></Field>
          <Field label="Department / cost center">
            <select name="department" className={inputCls} defaultValue="">
              <option value="">— none —</option>
              {ccOptions.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </Field>
          <Field label="Jurisdiction" hint="Determines the payroll statutory scheme">
            <select name="jurisdiction" className={inputCls} defaultValue="GH">
              {jurisdictionOptions.map((j) => <option key={j.value} value={j.value}>{j.label}</option>)}
            </select>
          </Field>
          <Field label="Employment type">
            <select name="employmentType" className={inputCls} defaultValue="permanent">
              <option value="permanent">Permanent</option>
              <option value="contract">Contract</option>
              <option value="intern">Intern / National service</option>
              <option value="consultant">Consultant (WHT)</option>
            </select>
          </Field>
          <Field label="Basic salary"><input name="basicSalary" type="number" step="0.01" min={0.01} className={inputCls} required /></Field>
          <Field label="Allowances"><input name="allowances" type="number" step="0.01" min={0} className={inputCls} defaultValue="0" /></Field>
          <Field label="Email"><input name="email" type="email" className={inputCls} /></Field>
          <Field label="Phone"><input name="phone" className={inputCls} /></Field>
          <Field label="TIN (tax number)"><input name="tin" className={inputCls + " font-mono text-xs"} /></Field>
          <Field label="Social security / pension no."><input name="ssnitNo" className={inputCls + " font-mono text-xs"} /></Field>
          <Field label="Bank account (for payslip)" className="col-span-2"><input name="bankAccount" className={inputCls + " font-mono text-xs"} /></Field>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy}>
              {busy ? "Adding…" : <><Icon name="plus" size={15} /> Add to payroll master</>}
            </button>
          </div>
        </form>
      )}

      {tab === "list" && (
        <>
          <input className={inputCls + " mb-3"} placeholder="Search name, code, position…" value={search} onChange={(e) => setSearch(e.target.value)} />
          <div className="max-h-[520px] space-y-2 overflow-y-auto">
            {filtered.length === 0 && <p className="py-6 text-center text-sm text-mist-500">No employees yet — add the first one.</p>}
            {filtered.map((e) => (
              <div key={e.id} className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="font-mono text-[12px] font-bold text-gold-300">{e.code}</span>
                  <span className="text-[13px] font-semibold text-mist-100">{e.name}</span>
                  <span className="text-[12.5px] text-mist-500">{e.position || "—"}</span>
                  <Badge tone={e.status === "active" ? "green" : e.status === "suspended" ? "amber" : "red"}>{e.status}</Badge>
                  <Badge tone="mm">{e.jurisdiction} · {e.currency}</Badge>
                  <span className="ml-auto font-mono text-[13px] tabular-nums text-mist-200">
                    {num(e.basicSalary)} <span className="text-[12px] text-mist-600">basic</span>
                  </span>
                </div>
                {editing?.id === e.id ? (
                  <form onSubmit={submitEdit} className="mt-3 grid grid-cols-2 gap-2 border-t border-ink-700 pt-3">
                    <input name="name" className={inputCls} defaultValue={e.name} required />
                    <input name="position" className={inputCls} defaultValue={e.position} placeholder="Position" />
                    <input name="basicSalary" type="number" step="0.01" className={inputCls} defaultValue={e.basicSalary} required />
                    <input name="allowances" type="number" step="0.01" className={inputCls} defaultValue={e.allowances} />
                    <select name="status" className={inputCls} defaultValue={e.status}>
                      <option value="active">active</option>
                      <option value="suspended">suspended</option>
                      <option value="left">left</option>
                    </select>
                    <select name="employmentType" className={inputCls} defaultValue={e.employmentType}>
                      <option value="permanent">permanent</option>
                      <option value="contract">contract</option>
                      <option value="intern">intern</option>
                      <option value="consultant">consultant</option>
                    </select>
                    <div className="col-span-2 flex gap-2">
                      <button className={btn.tiny} disabled={busy}>Save changes</button>
                      <button type="button" className={btn.tiny} onClick={() => setEditing(null)}>Cancel</button>
                    </div>
                  </form>
                ) : (
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <button className={btn.tiny} onClick={() => setEditing(e)}>Edit / salary change</button>
                    {e.status === "active" ? (
                      <button className={cn(btn.tiny, "hover:border-neg/40 hover:text-neg")} onClick={() => terminate(e)} disabled={busy}>Terminate</button>
                    ) : (
                      <button className={cn(btn.tiny, "border-pos/40 text-pos")} onClick={() => reinstate(e)} disabled={busy}>Reinstate</button>
                    )}
                    {e.tin && <span className="font-mono text-[12px] text-mist-600">TIN {e.tin}</span>}
                    {e.endDate && <span className="text-[12px] text-mist-600">left {e.endDate}</span>}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </Card>
  );
}
