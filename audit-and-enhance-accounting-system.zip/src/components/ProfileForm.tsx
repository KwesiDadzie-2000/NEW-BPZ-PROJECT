"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { btn, inputCls, Field } from "./ui";

export function ProfileForm({ name }: { name: string }) {
  const router = useRouter();
  const [value, setValue] = useState(name);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "profile", name: value }),
    });
    const data = await res.json();
    setBusy(false);
    setMsg(data.ok ? "Profile updated." : data.error);
    if (data.ok) router.refresh();
  }

  return (
    <form onSubmit={save} className="grid grid-cols-2 gap-3 md:grid-cols-4">
      <Field label="Display name" className="md:col-span-2">
        <input className={inputCls} value={value} onChange={(e) => setValue(e.target.value)} />
      </Field>
      <div className="col-span-2 flex items-end gap-3">
        <button className={btn.gold} disabled={busy}>
          {busy ? "Saving…" : "Save profile"}
        </button>
        {msg && <span className="text-xs text-mist-400">{msg}</span>}
      </div>
    </form>
  );
}
