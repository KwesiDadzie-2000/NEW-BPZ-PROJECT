"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { cn, Icon } from "./ui";
import { TextSizeControl } from "./TextSizeControl";
import { WORKSPACE_COOKIE } from "@/lib/cookie-names";

type NavItem = { href: string; label: string; icon: string; code?: string };
type NavGroup = { group: string; items: NavItem[] };

export type WorkspaceLite = { id: number; code: string; name: string };

const NAV: NavGroup[] = [
  { group: "Overview", items: [{ href: "/", label: "Dashboard", icon: "dashboard" }] },
  {
    group: "Operations",
    items: [
      { href: "/procurement", label: "Procurement", icon: "cart", code: "MM" },
      { href: "/sales", label: "Sales", icon: "tag", code: "SD" },
      { href: "/payroll", label: "Payroll Desk", icon: "users", code: "HR" },
      { href: "/payment-desk", label: "Payment Desk", icon: "card", code: "PMT" },
      { href: "/banking", label: "Banking & Reconciliation", icon: "building", code: "BANK" },
      { href: "/expenses", label: "Expenses & Statutory", icon: "shield", code: "EXP" },
      { href: "/inventory", label: "Inventory & Stock", icon: "box", code: "INV" },
      { href: "/assets", label: "Fixed Assets", icon: "truck", code: "AA" },
      { href: "/insurance", label: "Insurance & Claims", icon: "shield", code: "INS" },
      { href: "/projects", label: "Projects & Contracts", icon: "building", code: "IFRS15" },
      { href: "/standards", label: "IFRS 9 · 16 · 5 Desk", icon: "scale", code: "STD" },
      { href: "/disclosures", label: "Notes to Accounts", icon: "doc", code: "IAS1" },
      { href: "/group", label: "Group Consolidation", icon: "building", code: "IFRS10" },
      { href: "/loans", label: "Loan Facilities", icon: "card", code: "FIN" },
      { href: "/sector-ops", label: "Sector Operations", icon: "bolt", code: "SECT" },
    ],
  },
  {
    group: "Finance",
    items: [
      { href: "/universal-journal", label: "Universal Journal", icon: "journal", code: "ACDOCA" },
      { href: "/accounting", label: "Manual Journal", icon: "pen", code: "FI" },
      { href: "/budget", label: "Budgets & Scenarios", icon: "scale", code: "CO" },
      { href: "/month-end", label: "Month-End Close", icon: "check", code: "MCC" },
      { href: "/reports", label: "Reports (IFRS)", icon: "chart" },
      { href: "/disclosures", label: "Notes to Accounts", icon: "doc" },
      { href: "/compliance", label: "Tax & Filing Schedule", icon: "shield", code: "TAX" },
    ],
  },
  {
    group: "BPZ Services",
    items: [
      { href: "/advisory", label: "Advisory & Tax", icon: "doc", code: "AD" },
      { href: "/clients", label: "Clients", icon: "users", code: "MGT" },
    ],
  },
  {
    group: "Administration",
    items: [
      { href: "/admin", label: "Admin & Compliance", icon: "shield", code: "ADM" },
      { href: "/audit", label: "Audit Log", icon: "doc", code: "LOG" },
      { href: "/diagnostics", label: "Diagnostics", icon: "bolt", code: "ERR" },
      { href: "/assurance", label: "System Assurance", icon: "check", code: "ITGC" },
      { href: "/integrations", label: "SSO · API · SOC", icon: "shield", code: "ENT" },
      { href: "/data-protection", label: "Data Protection", icon: "database", code: "BAK" },
      { href: "/security", label: "My Security", icon: "shield", code: "SEC" },
      { href: "/migration", label: "Client Migration", icon: "download", code: "CSV" },
      { href: "/master-data", label: "Master Data", icon: "database" },
      { href: "/handbook", label: "User Handbook", icon: "book" },
    ],
  },
];

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-3 px-1 py-1">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gold-400 font-display text-[13px] font-extrabold tracking-tight text-brand-navy shadow-[0_0_24px_-6px_rgba(245,183,25,0.7)]">
        BPZ
      </span>
      <span className="min-w-0">
        <span className="block font-display text-[14px] font-extrabold leading-tight tracking-[0.04em] text-mist-100">
          BPZ CONSULT
        </span>
        <span className="block truncate text-[12px] font-semibold uppercase tracking-[0.16em] text-gold-400">
          Financial Experts
        </span>
      </span>
    </Link>
  );
}

export function Sidebar({
  docCount,
  lineCount,
  balanced,
  role,
  userName,
  workspaces,
  currentWs,
}: {
  docCount: number;
  lineCount: number;
  balanced: boolean;
  role: string;
  userName: string;
  workspaces: WorkspaceLite[];
  currentWs: WorkspaceLite;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [signingOut, setSigningOut] = useState(false);

  function switchWorkspace(id: number) {
    document.cookie = `${WORKSPACE_COOKIE}=${id}; path=/; max-age=31536000`;
    router.refresh();
  }

  async function signOut() {
    setSigningOut(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.push("/login");
      router.refresh();
    } finally {
      setSigningOut(false);
    }
  }

  return (
    <aside className="z-20 flex w-full shrink-0 flex-row items-center gap-2 overflow-x-auto border-b border-ink-700 bg-ink-900/95 px-3 py-2 md:sticky md:top-0 md:h-screen md:w-64 md:flex-col md:items-stretch md:overflow-y-auto md:overflow-x-hidden md:border-b-0 md:border-r md:px-4 md:py-5">
      <div className="mr-2 shrink-0 md:mb-4">
        <Brand />
      </div>

      <div className="hidden md:mb-5 md:block">
        <div className="rounded-lg border border-ink-700 bg-ink-850/80 px-3 py-2.5">
          <div className="text-[12px] font-bold uppercase tracking-[0.16em] text-mist-600">
            {role === "owner" ? "Workspace" : "Client workspace"}
          </div>
          {role === "owner" && workspaces.length > 1 ? (
            <select
              value={currentWs.id}
              onChange={(e) => switchWorkspace(Number(e.target.value))}
              className="mt-1.5 w-full cursor-pointer rounded-md border border-ink-600 bg-ink-950/70 px-2 py-1.5 text-xs font-semibold text-mist-100 outline-none transition focus:border-gold-400/60"
            >
              {workspaces.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.code} · {w.name}
                </option>
              ))}
            </select>
          ) : (
            <div className="mt-1.5 flex items-center justify-between gap-2">
              <span className="truncate text-xs font-semibold text-mist-200">{currentWs.name}</span>
              <span className="shrink-0 font-mono text-[12px] font-bold tracking-wider text-gold-300">{currentWs.code}</span>
            </div>
          )}
        </div>
      </div>

      <nav className="flex flex-1 flex-row gap-1 md:flex-none md:flex-col">
        {NAV.map((g) => (
          <div key={g.group} className="md:mb-4">
            <div className="hidden px-2.5 pb-1.5 text-[12px] font-bold uppercase tracking-[0.18em] text-mist-600 md:block">
              {g.group}
            </div>
            <div className="flex gap-1 md:flex-col">
              {g.items.map((it) => {
                const active = pathname === it.href;
                return (
                  <Link
                    key={it.href}
                    href={it.href}
                    className={cn(
                      "group relative flex shrink-0 items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] font-medium transition md:py-2.5",
                      active ? "bg-ink-800 text-mist-100" : "text-mist-500 hover:bg-ink-850 hover:text-mist-300"
                    )}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 hidden h-4 w-0.5 -translate-y-1/2 rounded-full bg-gold-400 md:block" />
                    )}
                    <Icon name={it.icon} size={16} className={cn(active ? "text-gold-400" : "text-mist-500 group-hover:text-mist-300")} />
                    <span className="whitespace-nowrap">{it.label}</span>
                    {it.code && (
                      <span className="ml-auto hidden rounded border border-ink-600 px-1 py-px font-mono text-[11.5px] font-bold tracking-wider text-mist-500 md:inline-block">
                        {it.code}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="hidden space-y-3 md:mt-auto md:block">
        <TextSizeControl />
        <div className="rounded-lg border border-ink-700 bg-ink-850/80 p-3">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-bold uppercase tracking-[0.16em] text-mist-500">
              Journal · {currentWs.code}
            </span>
            <span className={cn("h-2 w-2 rounded-full", balanced ? "bg-pos" : "bg-neg pulse-dot")} />
          </div>
          <div className="mt-1.5 font-mono text-xs tabular-nums text-mist-300">
            {lineCount.toLocaleString()} lines · {docCount.toLocaleString()} docs
          </div>
          <div className="mt-0.5 text-[12.5px] text-mist-500">
            {lineCount === 0 ? "No postings yet" : balanced ? "Books balanced" : "Out of balance"}
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 px-1">
          <div className="min-w-0">
            <div className="truncate text-xs font-semibold text-mist-300">{userName}</div>
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-600">{role}</div>
          </div>
          <button
            onClick={signOut}
            disabled={signingOut}
            className="rounded-md border border-ink-600 px-2.5 py-1.5 text-[12.5px] font-semibold text-mist-400 transition hover:border-neg/40 hover:text-neg disabled:opacity-40"
          >
            Sign out
          </button>
        </div>
      </div>
    </aside>
  );
}
