"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls } from "./ui";

export function ClientForm() {
  const router = useRouter();
  const [clientName, setClientName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await fetch("/api/clients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientName, username, password, displayName }),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccess(`${data.message} Login: ${username}`);
        setClientName("");
        setUsername("");
        setPassword("");
        setDisplayName("");
        router.refresh();
      } else {
        setError(data.error as string);
      }
    } catch {
      setError("Could not reach the service.");
    }
    setBusy(false);
  }

  return (
    <Card
      title="New Client"
      sub="Creates a client workspace plus a login for it. Independent books and document numbering."
    >
      <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3">
        <Field label="Client name" className="col-span-2">
          <input
            type="text"
            className={inputCls}
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            placeholder="e.g. Kumasi Widgets Ltd"
            required
          />
        </Field>
        <Field label="Login username" hint="3–30 chars: letters, numbers, dot, dash">
          <input
            type="text"
            className={inputCls + " font-mono text-xs"}
            value={username}
            onChange={(e) => setUsername(e.target.value.toLowerCase())}
            placeholder="kumasi"
            required
          />
        </Field>
        <Field label="Password" hint="At least 6 characters">
          <input
            type="password"
            className={inputCls}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
            minLength={6}
          />
        </Field>
        <Field label="Full name (optional)" className="col-span-2">
          <input
            type="text"
            className={inputCls}
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder="e.g. Kwame Asante"
          />
        </Field>
        <div className="col-span-2 flex justify-end">
          <button type="submit" className={btn.gold} disabled={busy}>
            {busy ? (
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" />
            ) : (
              <Icon name="plus" size={15} />
            )}
            {busy ? "Creating…" : "Create client"}
          </button>
        </div>
        {error && (
          <div className="col-span-2 flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
            <Icon name="x" size={14} className="mt-px shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="col-span-2 flex items-start gap-2 rounded-lg border border-sd/30 bg-sd/10 px-3 py-2 text-xs text-sd">
            <Icon name="check" size={14} className="mt-px shrink-0" />
            <span>{success}</span>
          </div>
        )}
      </form>
    </Card>
  );
}
