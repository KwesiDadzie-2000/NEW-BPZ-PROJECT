"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls, cn, Badge } from "./ui";
import { num } from "@/lib/format";

async function postJson(url: string, payload: Record<string, unknown>) {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

// ----------------------------------------------------------------
// Logins & roles manager (owner / firm staff)
// ----------------------------------------------------------------
export function UsersPanel({ initial }: { initial: { id: number; username: string; name: string; role: string; clientId: number | null; active: boolean; mustChangePassword: boolean }[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("accountant");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);
    const data = await postJson("/api/admin", { action: "add_user", name, username, password, role, mustChange: true });
    setBusy(false);
    if (data.ok) {
      setSuccess(data.message + " (temporary password must be reset on first login)");
      setName("");
      setUsername("");
      setPassword("");
      router.refresh();
    } else setError(data.error);
  }

  async function reissue(id: number) {
    const data = await postJson("/api/admin", { action: "reissue_temp", userId: id });
    if (data.ok) {
      setSuccess(data.message + " Sign-in link: open the site preview URL → /login");
      router.refresh();
    } else setError(data.error);
  }

  async function toggle(id: number, active: boolean) {
    await postJson("/api/admin", { action: "toggle_user", userId: id, active });
    router.refresh();
  }

  async function setRoleOf(id: number, r: string) {
    await postJson("/api/admin", { action: "set_role", userId: id, role: r });
    router.refresh();
  }

  return (
    <Card title="Logins & Roles" sub="Firm staff and client logins — reissue temporary passwords, restrict access, assign roles (owner / admin / accountant / viewer)">
      <form onSubmit={add} className="mb-4 grid grid-cols-2 gap-3">
        <Field label="Full name"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} required /></Field>
        <Field label="Username"><input className={inputCls + " font-mono text-xs"} value={username} onChange={(e) => setUsername(e.target.value.toLowerCase())} required minLength={3} /></Field>
        <Field label="Temporary password" hint="Must be reset on first login"><input type="password" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} /></Field>
        <Field label="Role">
          <select className={inputCls} value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="admin">Admin (full firm access)</option>
            <option value="accountant">Accountant (post & process)</option>
            <option value="viewer">Viewer (read-only — postings blocked)</option>
          </select>
        </Field>
        <div className="col-span-2 flex justify-end">
          <button className={btn.gold} disabled={busy}>{busy ? "Adding…" : "+ Add login"}</button>
        </div>
        {error && <div className="col-span-2 text-xs text-neg">{error}</div>}
        {success && <div className="col-span-2 text-xs text-pos">{success}</div>}
      </form>

      <div className="space-y-2">
        {initial.map((u) => (
          <div key={u.id} className="flex flex-wrap items-center gap-2.5 rounded-lg border border-ink-700/70 bg-ink-900/40 px-3 py-2">
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold text-mist-200">
                {u.name} <span className="ml-1 font-mono text-[12.5px] font-normal text-mist-500">@{u.username}</span>
              </div>
              <div className="mt-0.5 flex items-center gap-1.5">
                <Badge tone={u.role === "owner" ? "gold" : u.role === "admin" ? "fi" : u.role === "viewer" ? "slate" : "sd"}>{u.role}</Badge>
                {u.clientId === null ? <Badge tone="slate">Firm</Badge> : <Badge tone="mm">Client #{u.clientId}</Badge>}
                {u.mustChangePassword && <Badge tone="amber">Reset pending</Badge>}
              </div>
            </div>
            <select className="rounded-md border border-ink-600 bg-ink-950/60 px-2 py-1 text-[12.5px] text-mist-400" value={u.role} onChange={(e) => e.target.value && setRoleOf(u.id, e.target.value)}>
              <option value="admin">admin</option>
              <option value="accountant">accountant</option>
              <option value="viewer">viewer</option>
            </select>
            <button className={btn.tiny} onClick={() => reissue(u.id)}>Reissue temp</button>
            <button className={cn(btn.tiny, u.active ? "hover:border-neg/40 hover:text-neg" : "border-pos/40 text-pos")} onClick={() => toggle(u.id, !u.active)}>
              {u.active ? "Restrict" : "Restore"}
            </button>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ----------------------------------------------------------------
// Tax & rates administration (owner only)
// ----------------------------------------------------------------
export function RatesPanel({
  rates,
  bands,
  components,
}: {
  rates: { category: string; name: string; rate: number; notes: string }[];
  bands: { lower: number; upper: number | null; rate: number }[];
  components: { id: number; name: string; base: string; rate: number | null; side: string; active: boolean }[];
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [bandRows, setBandRows] = useState(bands.map((b) => ({ lower: String(b.lower), upper: b.upper === null ? "" : String(b.upper), rate: String(b.rate) })));

  const groups = [...new Set(rates.map((r) => r.category))];

  function saveGroup(g: string) {
    const rows = rates.filter((r) => r.category === g);
    if (!rows.length) return;
    setBusy(true);
    const data = postJson("/api/admin", { action: "save_rate", category: g, name: rows[0].name, rate: rows[0].rate });
    data.then(() => {
      setBusy(false);
      setSuccess(`Rate group ${g} saved — new rate applies to all future computations.`);
      router.refresh();
    });
  }
  void saveGroup;

  async function editRate(cat: string, name: string, rate: number) {
    setBusy(true);
    setError(null);
    setSuccess(null);
    const data = await postJson("/api/admin", { action: "save_rate", category: cat, name, rate });
    setBusy(false);
    if (data.ok) {
      setSuccess(`${name} updated to ${rate}% — applies to all future runs.`);
      router.refresh();
    } else setError(data.error);
  }

  async function saveBands() {
    setBusy(true);
    setError(null);
    setSuccess(null);
    const parsed = bandRows
      .filter((b) => b.lower !== "")
      .map((b) => ({ lower: Number(b.lower), upper: b.upper === "" ? null : Number(b.upper), rate: Number(b.rate) }));
    const data = await postJson("/api/admin", { action: "save_paye_bands", bands: parsed, effectiveFrom: "2026-09-01" });
    setBusy(false);
    if (data.ok) {
      setSuccess("PAYE schedule saved — every future payroll run uses these bands.");
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title="Tax, PAYE & Payroll Rates" sub="Owner-controlled statutory schedule — Ghana VAT 20% (no cascading), PAYE effective 1 Sep 2026, WHT resident & non-resident, SSNIT, NHIL. Edits apply to all future workspaces.">
      <div className="space-y-4">
        {groups.map((g) => (
          <div key={g} className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
            <div className="mb-2 text-[12.5px] font-bold uppercase tracking-[0.14em] text-gold-300">{g.replace("_", " ")}</div>
            <div className="space-y-1.5">
              {rates.filter((r) => r.category === g).map((r) => (
                <div key={r.category + r.name} className="flex items-center gap-3">
                  <span className="min-w-0 flex-1 truncate text-[13px] text-mist-300">{r.name}</span>
                  <input
                    type="number"
                    step="0.01"
                    className={inputCls + " w-24 text-right font-mono text-xs"}
                    defaultValue={r.rate}
                    onBlur={(e) => Number(e.target.value) !== r.rate && editRate(g, r.name, Number(e.target.value))}
                  />
                </div>
              ))}
            </div>
          </div>
        ))}

        <div className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
          <div className="mb-2 text-[12.5px] font-bold uppercase tracking-[0.14em] text-gold-300">PAYE bands (effective 1 Sep 2026 — editable)</div>
          <div className="space-y-1.5">
            <div className="grid grid-cols-3 gap-2 text-[12px] font-bold uppercase tracking-wider text-mist-600">
              <span>From (GHS)</span><span>To (blank = no cap)</span><span>Rate %</span>
            </div>
            {bandRows.map((b, i) => (
              <div key={i} className="grid grid-cols-3 gap-2">
                <input className={inputCls + " font-mono text-xs"} value={b.lower} onChange={(e) => setBandRows(bandRows.map((x, j) => (j === i ? { ...x, lower: e.target.value } : x)))} />
                <input className={inputCls + " font-mono text-xs"} value={b.upper} onChange={(e) => setBandRows(bandRows.map((x, j) => (j === i ? { ...x, upper: e.target.value } : x)))} />
                <input className={inputCls + " font-mono text-xs"} value={b.rate} onChange={(e) => setBandRows(bandRows.map((x, j) => (j === i ? { ...x, rate: e.target.value } : x)))} />
              </div>
            ))}
          </div>
          <div className="mt-3 flex justify-end">
            <button className={btn.gold} onClick={saveBands} disabled={busy}>{busy ? "Saving…" : "Save PAYE schedule"}</button>
          </div>
        </div>

        <div className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
          <div className="mb-2 text-[12.5px] font-bold uppercase tracking-[0.14em] text-gold-300">Payroll components (reference — engine uses named rates above)</div>
          <div className="space-y-1">
            {components.map((c) => (
              <div key={c.id} className="flex items-center gap-2 text-[12.5px] text-mist-400">
                <span className="flex-1">{c.name}</span>
                <Badge tone="slate">{c.base}</Badge>
                <span className="font-mono text-[12.5px]">{c.rate === null ? "bands" : `${num(c.rate)}%`}</span>
                <Badge tone={c.side === "employer" ? "amber" : "sd"}>{c.side}</Badge>
              </div>
            ))}
          </div>
        </div>

        {error && <div className="text-xs text-neg">{error}</div>}
        {success && <div className="text-xs text-pos">{success}</div>}
      </div>
    </Card>
  );
}

// ----------------------------------------------------------------
// Advisory engagement / workpaper editor
// ----------------------------------------------------------------
export function EngagementEditor({
  serviceLineOptions,
  template,
  checklist,
}: {
  serviceLineOptions: { value: string; label: string }[];
  template: string;
  checklist: { type: "quant" | "qual"; label: string }[];
}) {
  const router = useRouter();
  const [serviceLine, setServiceLine] = useState("");
  const [period, setPeriod] = useState("");
  const [status, setStatus] = useState("in_progress");
  const [quant, setQuant] = useState<Record<string, string>>({});
  const [qual, setQual] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function save() {
    setBusy(true);
    setError(null);
    setSuccess(null);
    const data = await postJson("/api/actions", {
      action: "save_engagement", serviceLine, template, period: period || undefined,
      status, quant, qual,
    });
    setBusy(false);
    if (data.ok) {
      setSuccess(data.message + " Workpapers appear in the engagement register.");
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title="Workpaper — Quantitative & Qualitative" sub={template || "Select a service line to load its BPZ work template"}>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Service line">
          <select className={inputCls} value={serviceLine} onChange={(e) => setServiceLine(e.target.value)}>
            <option value="">— select —</option>
            {serviceLineOptions.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Fiscal period">
          <input type="month" className={inputCls + " font-mono text-xs"} value={period} onChange={(e) => setPeriod(e.target.value)} />
        </Field>
        {checklist.filter((c) => c.type === "quant").map((c) => (
          <Field key={c.label} label={c.label} className="col-span-2">
            <input className={inputCls + " font-mono text-xs"} value={quant[c.label] ?? ""} onChange={(e) => setQuant({ ...quant, [c.label]: e.target.value })} placeholder="Figure (GHS)" />
          </Field>
        ))}
        {checklist.length > 0 && (
          <Field label="Qualitative notes (judgements, risks, references)" className="col-span-2">
            <textarea className={inputCls + " min-h-[110px] text-[13px]"} value={qual} onChange={(e) => setQual(e.target.value)} placeholder="Document assumptions, IAS/IFRS references, GRA positions, related-party review…" />
          </Field>
        )}
        <Field label="Status">
          <select className={inputCls} value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="in_progress">In progress</option>
            <option value="review">With reviewer</option>
            <option value="signed_off">Signed off</option>
          </select>
        </Field>
        <div className="flex items-end justify-end">
          <button className={btn.gold} onClick={save} disabled={busy}>
            {busy ? "Saving…" : "Save workpaper"}
          </button>
        </div>
        {error && <div className="col-span-2 text-xs text-neg">{error}</div>}
        {success && <div className="col-span-2 text-xs text-pos">{success}</div>}
      </div>
    </Card>
  );
}
