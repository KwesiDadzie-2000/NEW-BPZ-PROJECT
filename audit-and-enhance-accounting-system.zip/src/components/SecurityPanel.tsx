"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, Badge } from "./ui";

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/auth/security", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export function SecurityPanel({
  name,
  totpEnabled,
  role,
}: {
  name: string;
  totpEnabled: boolean;
  role: string;
}) {
  const router = useRouter();
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // 2FA enrolment
  const [secret, setSecret] = useState("");
  const [uri, setUri] = useState("");
  const [code, setCode] = useState("");
  // password change
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [totpForPw, setTotpForPw] = useState("");
  const [recCode, setRecCode] = useState("");
  const [showRec, setShowRec] = useState(false);

  async function begin2fa() {
    setBusy(true); setError(null); setMsg(null);
    const d = await post({ op: "2fa_begin" });
    setBusy(false);
    if (d.ok) { setSecret(d.secret); setUri(d.uri); } else setError(d.error);
  }

  async function confirm2fa() {
    setBusy(true); setError(null); setMsg(null);
    const d = await post({ op: "2fa_confirm", code });
    setBusy(false);
    if (d.ok) {
      setMsg(d.message); setSecret(""); setUri(""); setCode("");
      router.refresh();
    } else setError(d.error);
  }

  async function disable2fa() {
    setBusy(true); setError(null); setMsg(null);
    const d = await post({ op: "2fa_disable", code });
    setBusy(false);
    if (d.ok) { setMsg(d.message); setCode(""); router.refresh(); } else setError(d.error);
  }

  async function genRecovery() {
    setBusy(true); setError(null); setMsg(null);
    const d = await post({ op: "recovery_generate" });
    setBusy(false);
    if (d.ok) { setRecCode(d.recoveryCode); setShowRec(true); setMsg(d.message); router.refresh(); }
    else setError(d.error);
  }

  async function changePw(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null); setMsg(null);
    const d = await post({ op: "change_password", current: cur, next, totp: totpForPw });
    setBusy(false);
    if (d.ok) { setMsg(d.message); setCur(""); setNext(""); setTotpForPw(""); router.refresh(); } else setError(d.error);
  }

  return (
    <div className="space-y-4">
      {msg && <div className="rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">{msg}</div>}
      {error && <div className="rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">{error}</div>}

      <Card
        title="Two-factor authentication"
        sub="Time-based one-time passwords (TOTP) — works with Google Authenticator, Microsoft Authenticator, Authy or 1Password"
        action={<Badge tone={totpEnabled ? "green" : "amber"}>{totpEnabled ? "Enabled" : "Not enabled"}</Badge>}
      >
        {!totpEnabled && !secret && (
          <div className="space-y-3">
            <p className="text-[13px] leading-relaxed text-mist-500">
              Client financial data should never sit behind a single password. Enable a second factor — it takes
              under a minute and is enforced at sign-in for this account.
            </p>
            <button className={btn.gold} onClick={begin2fa} disabled={busy}>
              <Icon name="shield" size={15} /> Set up authenticator
            </button>
          </div>
        )}

        {!totpEnabled && secret && (
          <div className="space-y-3">
            <div className="rounded-lg border border-ink-700 bg-ink-900/60 p-3">
              <div className="text-[12.5px] font-bold uppercase tracking-wider text-mist-500">Step 1 — add the key</div>
              <p className="mt-1 text-[12.5px] leading-relaxed text-mist-400">
                In your authenticator app choose <strong>Add account → Enter a setup key</strong> and paste:
              </p>
              <div className="mt-2 break-all rounded-md bg-ink-950 px-3 py-2 font-mono text-[13px] font-bold tracking-widest text-gold-300">
                {secret}
              </div>
              <div className="mt-1 break-all font-mono text-[12px] text-mist-600">{uri}</div>
              <p className="mt-1.5 text-[12.5px] text-mist-600">
                Account: {name} · Issuer: BPZ CONSULT · SHA1 · 6 digits · 30-second period
              </p>
            </div>
            <Field label="Step 2 — enter the 6-digit code it shows">
              <input
                className={inputCls + " w-40 text-center font-mono text-lg tracking-[0.4em]"}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="000000"
                inputMode="numeric"
              />
            </Field>
            <div className="flex gap-2">
              <button className={btn.gold} onClick={confirm2fa} disabled={busy || code.length !== 6}>
                <Icon name="check" size={15} /> Confirm and enable
              </button>
              <button className={btn.ghost} onClick={() => { setSecret(""); setUri(""); }}>Cancel</button>
            </div>
          </div>
        )}

        {totpEnabled && (
          <div className="space-y-3">
            <p className="text-[13px] leading-relaxed text-mist-500">
              A code from your authenticator is required at every sign-in and to change your password.
              Save a recovery code — if you lose your phone it is the only way back into this account.
            </p>
            {showRec && recCode && (
              <div className="rounded-lg border border-gold-400/40 bg-gold-400/10 p-3">
                <div className="text-[12.5px] font-bold uppercase tracking-wider text-gold-300">Your one-time recovery code — copy it now</div>
                <div className="mt-1.5 break-all rounded-md bg-ink-950 px-3 py-2 font-mono text-[15px] font-bold tracking-widest text-gold-300">{recCode}</div>
                <p className="mt-1.5 text-[12.5px] text-mist-500">Shown once, never again. It restores access and resets 2FA for re-enrolment on a new device.</p>
              </div>
            )}
            {!showRec && (
              <button className={btn.ghost} onClick={genRecovery} disabled={busy}>
                <Icon name="download" size={15} /> Generate recovery code
              </button>
            )}
            <div className="flex flex-wrap items-end gap-3">
              <Field label="Current 6-digit code">
                <input
                  className={inputCls + " w-40 text-center font-mono text-lg tracking-[0.4em]"}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="000000"
                  inputMode="numeric"
                />
              </Field>
              <button className={btn.danger} onClick={disable2fa} disabled={busy || code.length !== 6}>
                Disable 2FA
              </button>
            </div>
          </div>
        )}
      </Card>

      <Card title="Change password" sub="Minimum 10 characters with an uppercase letter, a lowercase letter and a digit">
        <form onSubmit={changePw} className="grid grid-cols-2 gap-3">
          <Field label="Current password"><input type="password" className={inputCls} value={cur} onChange={(e) => setCur(e.target.value)} required /></Field>
          <Field label="New password"><input type="password" className={inputCls} value={next} onChange={(e) => setNext(e.target.value)} required minLength={10} /></Field>
          {totpEnabled && (
            <Field label="Authenticator code" className="col-span-2">
              <input className={inputCls + " w-40 text-center font-mono tracking-[0.3em]"} value={totpForPw} onChange={(e) => setTotpForPw(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="000000" inputMode="numeric" />
            </Field>
          )}
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy}>{busy ? "Updating…" : "Update password"}</button>
          </div>
        </form>
      </Card>
    </div>
  );
}
