"use client";

import { useEffect, useState } from "react";
import { cn } from "./ui";

const KEY = "bpz-textsize";
const OPTIONS = [
  { id: "default", label: "A", hint: "Standard text" },
  { id: "comfortable", label: "A+", hint: "Comfortable — larger" },
  { id: "large", label: "A++", hint: "Large — easiest to read" },
] as const;

/**
 * Low-vision support. Persists per device so each user gets their own setting
 * without needing an account preference.
 */
export function TextSizeControl() {
  const [size, setSize] = useState<string>("default");

  useEffect(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem(KEY) : null;
    if (saved) {
      setSize(saved);
      document.documentElement.setAttribute("data-textsize", saved);
    }
  }, []);

  function pick(id: string) {
    setSize(id);
    document.documentElement.setAttribute("data-textsize", id);
    try {
      window.localStorage.setItem(KEY, id);
    } catch {
      /* private browsing — still applies for this session */
    }
  }

  return (
    <div className="hidden md:block">
      <div className="rounded-lg border border-ink-700 bg-ink-850/80 px-3 py-2.5">
        <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-500">Text size</div>
        <div className="mt-2 flex gap-1.5">
          {OPTIONS.map((o) => (
            <button
              key={o.id}
              onClick={() => pick(o.id)}
              title={o.hint}
              aria-pressed={size === o.id}
              className={cn(
                "flex-1 rounded-md border py-1.5 font-display font-bold transition",
                o.id === "large" ? "text-[15px]" : o.id === "comfortable" ? "text-[14px]" : "text-[13px]",
                size === o.id
                  ? "border-gold-400 bg-gold-400 text-brand-navy"
                  : "border-ink-600 text-mist-300 hover:border-gold-400/50 hover:text-gold-300"
              )}
            >
              {o.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[12px] leading-snug text-mist-500">
          Choose the size that is comfortable for you. Saved on this device.
        </p>
      </div>
    </div>
  );
}
