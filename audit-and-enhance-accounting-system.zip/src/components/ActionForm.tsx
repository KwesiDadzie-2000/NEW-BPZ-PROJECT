"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls, cn } from "./ui";
import { num } from "@/lib/format";

export type FieldSpec = {
  name: string;
  label: string;
  type: "select" | "number" | "text";
  options?: { value: string; label: string }[];
  placeholder?: string;
  step?: string;
  min?: number;
  defaultValue?: string;
  wide?: boolean;
  hint?: string;
  required?: boolean;
};

type Props = {
  action: string;
  title: string;
  sub?: string;
  submitLabel: string;
  fields: FieldSpec[];
  userDefault?: string;
  totalFrom?: [string, string];
  periodField?: boolean;
  chargeable?: boolean;
  serviceLines?: { value: string; label: string }[];
  extraPayload?: Record<string, unknown>;
};

export function ActionForm({
  action,
  title,
  sub,
  submitLabel,
  fields,
  userDefault = "user",
  totalFrom,
  periodField = false,
  chargeable = false,
  serviceLines,
  extraPayload,
}: Props) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>(() => {
    const v: Record<string, string> = {};
    for (const f of fields) v[f.name] = f.defaultValue ?? "";
    v.__user = userDefault;
    return v;
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const set = (name: string, value: string) => {
    setValues((v) => ({ ...v, [name]: value }));
    setError(null);
  };

  const total = useMemo(() => {
    if (!totalFrom) return null;
    const a = Number(values[totalFrom[0]]);
    const b = Number(values[totalFrom[1]]);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
    return a * b;
  }, [values, totalFrom]);

  async function postJson(payload: Record<string, unknown>) {
    const res = await fetch("/api/actions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return res.json();
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);
    const payload: Record<string, unknown> = { action };
    for (const f of fields) payload[f.name] = values[f.name] ?? "";
    if (periodField) payload.period = values.__period || undefined;
    payload.user = values.__user || userDefault;
    if (extraPayload) Object.assign(payload, extraPayload);
    try {
      const data = await postJson(payload);
      if (data.ok) {
        let msg = data.message as string;
        if (chargeable && values.__charge && values.__serviceLine && Number(values.__fee) > 0) {
          const fee = await postJson({
            action: "charge_fee",
            serviceLine: values.__serviceLine,
            amount: Number(values.__fee),
            period: values.__period || undefined,
            user: values.__user,
          });
          if (fee.ok) msg += " " + (fee.message as string);
          else setError(fee.error as string);
        }
        setSuccess(msg);
        for (const f of fields) set(f.name, f.defaultValue ?? "");
        router.refresh();
      } else {
        setError(data.error as string);
      }
    } catch {
      setError("Could not reach the posting service.");
    }
    setBusy(false);
  }

  return (
    <Card title={title} sub={sub}>
      <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3">
        {fields.map((f) => (
          <Field key={f.name} label={f.label} className={f.wide ? "col-span-2" : undefined} hint={f.hint}>
            {f.type === "select" ? (
              <select className={inputCls} value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} required={f.required ?? true}>
                <option value="">— select —</option>
                {f.options?.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            ) : f.type === "number" ? (
              <input
                type="number"
                className={inputCls}
                value={values[f.name] ?? ""}
                onChange={(e) => set(f.name, e.target.value)}
                placeholder={f.placeholder}
                step={f.step ?? "0.01"}
                min={f.min ?? 0}
                required={f.required ?? true}
              />
            ) : (
              <input
                type="text"
                className={inputCls}
                value={values[f.name] ?? ""}
                onChange={(e) => set(f.name, e.target.value)}
                placeholder={f.placeholder}
                required={f.required ?? true}
              />
            )}
          </Field>
        ))}

        {periodField && (
          <Field label="Fiscal period" hint="YYYY-MM — e.g. 2026-07">
            <input
              type="month"
              className={inputCls + " font-mono text-xs"}
              value={values.__period ?? ""}
              onChange={(e) => set("__period", e.target.value)}
              required
            />
          </Field>
        )}

        <Field label="Post as (user)">
          <input type="text" className={inputCls + " font-mono text-xs"} value={values.__user ?? ""} onChange={(e) => set("__user", e.target.value)} required />
        </Field>

        {chargeable && (
          <>
            <div className="col-span-2 rounded-lg border border-gold-400/25 bg-gold-400/5 px-3 py-2.5">
              <label className="flex items-center gap-2 text-xs font-semibold text-gold-300">
                <input type="checkbox" checked={!!values.__charge} onChange={(e) => set("__charge", e.target.checked ? "1" : "")} className="accent-gold-400" />
                Charge to client (BPZ fee for this work)
              </label>
              {values.__charge && (
                <div className="mt-2 grid grid-cols-2 gap-3">
                  <Field label="Service line">
                    <select className={inputCls} value={values.__serviceLine ?? ""} onChange={(e) => set("__serviceLine", e.target.value)}>
                      <option value="">— select —</option>
                      {serviceLines?.map((o) => (
                        <option key={o.value} value={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Fee (GHS)">
                    <input type="number" min={0} step="0.01" className={inputCls} value={values.__fee ?? ""} onChange={(e) => set("__fee", e.target.value)} placeholder="0.00" />
                  </Field>
                </div>
              )}
            </div>
          </>
        )}

        <div className="col-span-2 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-mist-500">
            {totalFrom && total !== null ? (
              <span>
                Total: <span className="font-mono text-sm font-semibold text-gold-300">{num(total)}</span>
              </span>
            ) : (
              <span>Posts to this workspace&apos;s Universal Journal.</span>
            )}
          </div>
          <button type="submit" className={btn.gold} disabled={busy}>
            {busy ? (
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" />
            ) : (
              <Icon name="bolt" size={15} />
            )}
            {busy ? "Posting…" : submitLabel}
          </button>
        </div>

        {error && (
          <div className="col-span-2 flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
            <Icon name="x" size={14} className="mt-px shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="col-span-2 flex items-start gap-2 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">
            <Icon name="check" size={14} className="mt-px shrink-0" />
            <span>{success}</span>
          </div>
        )}
      </form>
    </Card>
  );
}
