"use client";

import { money } from "@/lib/format";

const PALETTE = ["#F5B719", "#34D399", "#5CC8E8", "#A78BFA", "#F0708C", "#8FA7CE", "#FF9F5A"];

/** Donut — revenue vs expense composition by module. */
export function DonutChart({
  data,
  total,
  label,
}: {
  data: { label: string; value: number }[];
  total: number;
  label: string;
}) {
  const size = 168;
  const r = 62;
  const c = 2 * Math.PI * r;
  const sum = data.reduce((s, d) => s + d.value, 0) || 1;
  let offset = 0;

  return (
    <div className="flex flex-wrap items-center gap-6">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0 -rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="18" />
        {data.map((d, i) => {
          const frac = d.value / sum;
          const dash = `${frac * c} ${c - frac * c}`;
          const el = (
            <circle
              key={d.label}
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke={PALETTE[i % PALETTE.length]}
              strokeWidth="18"
              strokeDasharray={dash}
              strokeDashoffset={-offset * c}
              strokeLinecap="butt"
            />
          );
          offset += frac;
          return el;
        })}
      </svg>
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-bold uppercase tracking-[0.14em] text-mist-500">{label}</div>
        <div className="mt-1 font-display text-2xl font-extrabold tabular-nums text-mist-100">{money(total)}</div>
        <ul className="mt-3 space-y-1.5">
          {data.map((d, i) => (
            <li key={d.label} className="flex items-center gap-2 text-[12.5px]">
              <span className="h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: PALETTE[i % PALETTE.length] }} />
              <span className="min-w-0 flex-1 truncate text-mist-400">{d.label}</span>
              <span className="font-mono text-[12.5px] tabular-nums text-mist-300">
                {Math.round((d.value / sum) * 100)}%
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/** Grouped bars — budget vs actual, or any two-series comparison. */
export function BarCompare({
  rows,
  aLabel,
  bLabel,
}: {
  rows: { label: string; a: number; b: number }[];
  aLabel: string;
  bLabel: string;
}) {
  const max = Math.max(...rows.flatMap((r) => [Math.abs(r.a), Math.abs(r.b)]), 1);
  return (
    <div>
      <div className="mb-3 flex items-center gap-4 text-[12.5px] font-semibold text-mist-500">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-gold-400" />{aLabel}</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-[#5CC8E8]" />{bLabel}</span>
      </div>
      <div className="space-y-2.5">
        {rows.map((r) => (
          <div key={r.label}>
            <div className="mb-1 flex items-center justify-between text-[12.5px]">
              <span className="truncate text-mist-400">{r.label}</span>
              <span className="font-mono tabular-nums text-mist-300">{money(r.b)}</span>
            </div>
            <div className="flex h-2 gap-0.5 overflow-hidden rounded-full bg-white/5">
              <div className="h-full rounded-l-full bg-gold-400" style={{ width: `${(Math.abs(r.a) / max) * 100}%` }} />
              <div className="h-full rounded-r-full bg-[#5CC8E8]" style={{ width: `${(Math.abs(r.b) / max) * 100}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
