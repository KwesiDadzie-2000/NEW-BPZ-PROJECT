"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { btn, Icon } from "./ui";

export function FeeButton({ clientId, feeMap }: { clientId: number; feeMap: Record<string, number> }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function generate() {
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await fetch("/api/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "generate_monthly_fees", forClientId: clientId, feeMap }),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccess(data.message);
        router.refresh();
      } else setError(data.error);
    } catch {
      setError("Could not reach the service.");
    }
    setBusy(false);
  }

  return (
    <div className="flex flex-wrap items-center gap-3">
      <button className={btn.gold} onClick={generate} disabled={busy}>
        {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="doc" size={15} />}
        {busy ? "Generating…" : "Generate this month's fees"}
      </button>
      {success && <span className="text-xs text-pos">{success}</span>}
      {error && <span className="text-xs text-neg">{error}</span>}
    </div>
  );
}
