import { db } from "@/db";
import {
  journalLines, accounts, partners, costCenters, materials, clients, users,
  invoices, assets, assetClasses, payrollRuns, bankAccounts, bankLines,
  feeInvoices, productionOrders, contracts, budgetScenarios, budgetLines,
  fiscalPeriods, taxRates, taxBands, purchaseOrders, salesOrders, stockMoves,
} from "@/db/schema";
import { employees } from "@/db/employees-schema";
import { eq, desc } from "drizzle-orm";
import { backupRuns } from "@/db/schema";
import { logActivity } from "./security";

export type Snapshot = {
  format: string;
  takenAt: string;
  scope: string;
  client?: { id: number; code: string; name: string; sector: string };
  counts: Record<string, number>;
  data: Record<string, unknown[]>;
};

/** Full restore-point snapshot of one workspace plus the shared reference data. */
export async function buildSnapshot(clientId: number, clientCode: string, clientName: string, sector: string): Promise<Snapshot> {
  const [
    jl, acc, bp, cc, mat, cli, usr, inv, ast, cls, pay, emp, bac, bal, fee, prd, con,
    bsc, bli, fp, tr, tb, po, so, stk,
  ] = await Promise.all([
    db.select().from(journalLines).where(eq(journalLines.clientId, clientId)),
    db.select().from(accounts),
    db.select().from(partners),
    db.select().from(costCenters),
    db.select().from(materials),
    db.select().from(clients),
    db.select().from(users),
    db.select().from(invoices).where(eq(invoices.clientId, clientId)),
    db.select().from(assets).where(eq(assets.clientId, clientId)),
    db.select().from(assetClasses),
    db.select().from(payrollRuns).where(eq(payrollRuns.clientId, clientId)),
    db.select().from(employees).where(eq(employees.clientId, clientId)),
    db.select().from(bankAccounts).where(eq(bankAccounts.clientId, clientId)),
    db.select().from(bankLines),
    db.select().from(feeInvoices).where(eq(feeInvoices.clientId, clientId)),
    db.select().from(productionOrders).where(eq(productionOrders.clientId, clientId)),
    db.select().from(contracts).where(eq(contracts.clientId, clientId)),
    db.select().from(budgetScenarios).where(eq(budgetScenarios.clientId, clientId)),
    db.select().from(budgetLines).where(eq(budgetLines.clientId, clientId)),
    db.select().from(fiscalPeriods).where(eq(fiscalPeriods.clientId, clientId)),
    db.select().from(taxRates),
    db.select().from(taxBands),
    db.select().from(purchaseOrders).where(eq(purchaseOrders.clientId, clientId)),
    db.select().from(salesOrders).where(eq(salesOrders.clientId, clientId)),
    db.select().from(stockMoves).where(eq(stockMoves.clientId, clientId)),
  ]);

  // Sessions and password hashes are deliberately excluded from snapshots.
  const safeUsers = usr.map((u) => ({
    id: u.id, username: u.username, name: u.name, role: u.role, clientId: u.clientId,
    active: u.active, totpEnabled: u.totpEnabled, createdAt: u.createdAt,
  }));

  const data: Record<string, unknown[]> = {
    journal_lines: jl, chart_of_accounts: acc, business_partners: bp, cost_centers: cc,
    materials: mat, workspaces: cli, users_no_secrets: safeUsers, invoices: inv,
    fixed_assets: ast, asset_classes: cls, payroll_runs: pay, employees: emp,
    bank_accounts: bac, bank_statement_lines: bal.filter((b) => bac.some((a) => a.id === b.accountId)),
    bpz_fees: fee, production_orders: prd, contracts: con, budget_scenarios: bsc,
    budget_lines: bli, fiscal_periods: fp, tax_rates: tr, tax_bands: tb,
    purchase_orders: po, sales_orders: so, stock_moves: stk,
  };

  const counts: Record<string, number> = {};
  for (const [k, v] of Object.entries(data)) counts[k] = v.length;

  return {
    format: "BPZ-CONSULT-SNAPSHOT/1.0",
    takenAt: new Date().toISOString(),
    scope: "workspace",
    client: { id: clientId, code: clientCode, name: clientName, sector },
    counts,
    data,
  };
}

export async function recordBackup(clientId: number, bytes: number, takenBy: string, scope = "workspace", docs = 0) {
  await db.insert(backupRuns).values({
    clientId, scope, kind: "manual", sizeBytes: bytes, docs, takenBy,
  });
  await logActivity({
    clientId, username: takenBy, action: "backup_taken", ok: true,
    detail: `Snapshot ${scope} — ${Math.round(bytes / 1024)} KB, ${docs} journal lines`,
  });
}

export async function listBackups(clientId: number | null, limit = 25) {
  const rows = clientId === null
    ? await db.select().from(backupRuns).orderBy(desc(backupRuns.id)).limit(limit)
    : await db.select().from(backupRuns).where(eq(backupRuns.clientId, clientId)).orderBy(desc(backupRuns.id)).limit(limit);
  return rows.map((r) => ({
    id: r.id, clientId: r.clientId, scope: r.scope, kind: r.kind,
    sizeBytes: r.sizeBytes, docs: r.docs, takenBy: r.takenBy, takenAt: r.takenAt.toISOString(),
  }));
}
