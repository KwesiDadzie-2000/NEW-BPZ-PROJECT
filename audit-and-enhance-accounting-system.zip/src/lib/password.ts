import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

export function hashPassword(pw: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(pw, salt, 64).toString("hex");
  return `scrypt:${salt}:${hash}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split(":");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const test = scryptSync(pw, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return expected.length === test.length && timingSafeEqual(test, expected);
  } catch {
    return false;
  }
}
