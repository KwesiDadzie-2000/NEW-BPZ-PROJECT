import { db } from "@/db";
import { loans, loanSchedules } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { postChecked, type JLine } from "./engine";
import { assertPeriodOpen, thisPeriod } from "./periods";
import { shiftPeriod } from "./periods";
import {
  buildLoanSchedule,
  effectiveInterestRate,
  loanCurrentSplit,
  loanMetrics,
  numberOfPeriods,
  type LoanTerms,
  type FacilityType,
  type Frequency,
} from "./loans";

const r2 = (n: number) => Math.round(n * 100) / 100;
const N = (v: unknown) => Number(v ?? 0);

export type LoanRow = typeof loans.$inferSelect;

export async function listLoans(clientId: number, status?: string) {
  const where = status
    ? and(eq(loans.clientId, clientId), eq(loans.status, status))
    : eq(loans.clientId, clientId);
  return db.select().from(loans).where(where).orderBy(desc(loans.id));
}

export async function getLoan(clientId: number, id: number) {
  return (
    await db.select().from(loans).where(and(eq(loans.clientId, clientId), eq(loans.id, id)))
  )[0];
}

function termsOf(row: LoanRow): LoanTerms {
  return {
    principal: Number(row.principal),
    annualRate: Number(row.annualRate),
    termMonths: row.termMonths,
    frequency: row.frequency as Frequency,
    facilityType: row.facilityType as FacilityType,
    moratoriumMonths: row.moratoriumMonths,
    arrangementFee: Number(row.arrangementFee),
    feeSpreadMonths: row.feeMonths,
  };
}

function periodForSequence(startDate: string, seq: number, f: Frequency): string {
  const base = startDate || thisPeriod();
  const step = f === "monthly" ? seq : f === "quarterly" ? (seq - 1) * 3 : (seq - 1) * 12;
  return shiftPeriod(base.slice(0, 7), step);
}

/** Drawdown + arrangement fee in a single balanced document. */
export async function drawdownLoan(
  clientId: number,
  input: {
    code: string;
    lender: string;
    facilityType: FacilityType;
    principal: number;
    annualRate: number;
    termMonths: number;
    startDate: string;
    frequency: Frequency;
    timing: "arrears" | "advance";
    moratoriumMonths: number;
    arrangementFee: number;
    feeSpreadMonths: number;
    drawdownAccount?: string;
    loanAccount?: string;
    interestAccount?: string;
    feeAccount?: string;
    cc?: string;
    period: string;
    user?: string;
    notes?: string;
  }
) {
  await assertPeriodOpen(clientId, input.period);
  if (!input.code.trim()) throw new Error("A loan reference code is required.");
  if (input.principal <= 0) throw new Error("Loan principal must be positive.");
  if (input.annualRate <= 0) throw new Error("The contractual interest rate must be positive.");
  if (input.termMonths <= 0) throw new Error("Loan term must be at least one month.");
  if (input.moratoriumMonths >= input.termMonths)
    throw new Error("The moratorium cannot cover the whole term — some principal must be repayable.");
  if ((input.arrangementFee ?? 0) < 0) throw new Error("Arrangement fee cannot be negative.");

  const loanAccount = input.loanAccount || "290000";
  const feeAccount = input.feeAccount || "576000";
  const drawAccount = input.drawdownAccount || "101000";

  const lines: JLine[] = [
    { account: drawAccount, desc: `Loan drawdown – ${input.code} ${input.lender}`, dr: input.principal },
  ];
  if ((input.arrangementFee ?? 0) > 0) {
    lines.push({
      account: feeAccount,
      cc: input.cc,
      desc: `Arrangement fee on ${input.code}`,
      dr: input.arrangementFee,
    });
    lines.push({
      account: drawAccount,
      desc: `Arrangement fee settled from proceeds – ${input.code}`,
      cr: input.arrangementFee,
    });
  }
  lines.push({ account: loanAccount, desc: `Borrowings – ${input.lender}`, cr: input.principal });

  const dr = r2(lines.reduce((s, l) => s + (l.dr ?? 0), 0));
  const cr = r2(lines.reduce((s, l) => s + (l.cr ?? 0), 0));
  if (Math.abs(dr - cr) > 0.005)
    throw new Error(`Drawdown does not balance (Dr ₵${dr.toFixed(2)} vs Cr ₵${cr.toFixed(2)}).`);

  const doc = await postChecked(clientId, {
    period: input.period,
    module: "FI",
    docType: "LOAN",
    user: input.user,
    reference: `${input.code} drawdown`,
    lines,
  });

  const row = await db
    .insert(loans)
    .values({
      clientId,
      code: input.code.trim(),
      lender: input.lender ?? "",
      facilityType: input.facilityType,
      principal: String(input.principal),
      annualRate: String(input.annualRate),
      termMonths: input.termMonths,
      startDate: input.startDate,
      frequency: input.frequency,
      timing: input.timing,
      moratoriumMonths: input.moratoriumMonths,
      arrangementFee: String(input.arrangementFee ?? 0),
      feeMonths: input.feeSpreadMonths || 0,
      drawdownAccount: drawAccount,
      loanAccount,
      interestAccount: input.interestAccount || "575000",
      feeAccount,
      currency: "GHS",
      cc: input.cc ?? "",
      outstanding: String(input.principal),
      notes: input.notes ?? "",
    })
    .returning({ id: loans.id, code: loans.code });

  const terms: LoanTerms = {
    principal: input.principal,
    annualRate: input.annualRate,
    termMonths: input.termMonths,
    frequency: input.frequency,
    facilityType: input.facilityType,
    moratoriumMonths: input.moratoriumMonths,
    arrangementFee: input.arrangementFee ?? 0,
    feeSpreadMonths: input.feeSpreadMonths || 0,
  };
  const schedule = buildLoanSchedule(terms);
  const totalPeriods = numberOfPeriods(input.termMonths, input.frequency);

  await db.insert(loanSchedules).values(
    schedule.rows.map((r) => ({
      clientId,
      loanId: row[0].id,
      seq: r.seq,
      period: periodForSequence(input.startDate, r.seq, input.frequency),
      opening: String(r.opening),
      interest: String(r.interest),
      fee: String(r.fee),
      principal: String(r.principal),
      payment: String(r.payment),
      closing: String(r.closing),
    }))
  );

  const metrics = loanMetrics(terms, input.principal);
  return {
    doc,
    id: row[0].id,
    code: row[0].code,
    instalment: schedule.instalment,
    periods: totalPeriods,
    effectiveRate: effectiveInterestRate(terms),
    debtService12m: metrics.debtService12m,
    message: `Loan ${row[0].code} drawn: ₵${input.principal.toFixed(2)} over ${input.termMonths} months → doc ${doc}. ${schedule.rows.length} scheduled payments, effective cost incl. fees ₵${schedule.effectiveCost.toFixed(2)}.`,
  };
}

/**
 * Repay the next scheduled instalment(s) — interest, fee and principal, with
 * the split posted to the ledger and the schedule marked paid.
 */
export async function repayLoan(
  clientId: number,
  input: { loanId: number; period: string; user?: string; amount?: number }
) {
  await assertPeriodOpen(clientId, input.period);
  const loan = await getLoan(clientId, input.loanId);
  if (!loan) throw new Error("Loan not found in this workspace.");
  if (loan.status !== "active") throw new Error(`Loan ${loan.code} is ${loan.status}.`);

  const pending = await db
    .select()
    .from(loanSchedules)
    .where(
      and(
        eq(loanSchedules.clientId, clientId),
        eq(loanSchedules.loanId, loan.id),
        eq(loanSchedules.status, "scheduled")
      )
    )
    .orderBy(loanSchedules.seq);
  if (!pending.length) throw new Error(`All scheduled payments on ${loan.code} are settled.`);

  // If the repayment period is given, only settle rows due on or before it.
  const due = input.period
    ? pending.filter((r) => r.period <= input.period)
    : [pending[0]];
  const rows = due.length ? due : [pending[0]];

  const interest = r2(rows.reduce((s, r) => s + Number(r.interest), 0));
  const fee = r2(rows.reduce((s, r) => s + Number(r.fee), 0));
  const principal = r2(rows.reduce((s, r) => s + Number(r.principal), 0));
  const payment = r2(rows.reduce((s, r) => s + Number(r.payment), 0));
  if (payment <= 0) throw new Error("Nothing is payable on the selected instalments.");

  const lines: JLine[] = [
    { account: loan.loanAccount, desc: `Principal repaid – ${loan.code}`, dr: principal },
    { account: loan.interestAccount, cc: loan.cc, desc: `Interest – ${loan.code}`, dr: interest },
  ];
  if (fee > 0) lines.push({ account: loan.feeAccount, cc: loan.cc, desc: `Facility fee – ${loan.code}`, dr: fee });
  lines.push({ account: loan.drawdownAccount, desc: `Instalment ${rows.map((r) => r.seq).join(",")} – ${loan.code}`, cr: payment });

  const doc = await postChecked(clientId, {
    period: input.period,
    module: "FI",
    docType: "LOAN",
    user: input.user,
    reference: `${loan.code} repayment (${rows.length} instalment${rows.length > 1 ? "s" : ""})`,
    lines,
  });

  await db
    .update(loanSchedules)
    .set({ status: "paid", docNo: doc })
    .where(
      and(
        eq(loanSchedules.clientId, clientId),
        eq(loanSchedules.loanId, loan.id),
        eq(loanSchedules.status, "scheduled"),
        sql`seq <= ${rows[rows.length - 1].seq}`
      )
    );

  const outstanding = r2(Number(loan.outstanding) - principal);
  await db
    .update(loans)
    .set({
      outstanding: String(Math.max(0, outstanding)),
      lastPeriod: input.period,
      status: outstanding <= 0.009 ? "settled" : "active",
    })
    .where(and(eq(loans.id, loan.id), eq(loans.clientId, clientId)));

  return {
    doc,
    interest,
    fee,
    principal,
    payment,
    outstanding,
    instalmentsSettled: rows.length,
    message: `${loan.code}: paid ₵${payment.toFixed(2)} (principal ₵${principal.toFixed(2)}, interest ₵${interest.toFixed(2)}${fee ? `, fee ₵${fee.toFixed(2)}` : ""}) → doc ${doc}. Outstanding now ₵${Math.max(0, outstanding).toFixed(2)}.`,
  };
}

import { sql } from "drizzle-orm";

/** Portfolio with balance-sheet split and covenant metrics. */
export async function loanPortfolio(clientId: number) {
  const all = await listLoans(clientId, "active");
  const rows = all.map(async (row) => {
    const terms = termsOf(row);
    const full = buildLoanSchedule(terms);
    const outstanding = Number(row.outstanding);
    const paid = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(loanSchedules)
      .where(
        and(
          eq(loanSchedules.clientId, clientId),
          eq(loanSchedules.loanId, row.id),
          eq(loanSchedules.status, "paid")
        )
      );
    const future = full.rows.slice(paid[0]?.n ?? 0);
    const split = loanCurrentSplit(future, outstanding);
    return {
      id: row.id,
      code: row.code,
      lender: row.lender,
      facilityType: row.facilityType,
      principal: Number(row.principal),
      annualRate: Number(row.annualRate),
      termMonths: row.termMonths,
      outstanding,
      currentPortion: split.currentPortion,
      nonCurrentPortion: split.nonCurrentPortion,
      nextPayment: future[0]?.payment ?? 0,
      debtService12m: loanMetrics(terms, outstanding).debtService12m,
      effectiveRate: effectiveInterestRate(terms),
    };
  });
  const resolved = await Promise.all(rows);
  return {
    rows: resolved,
    totals: {
      outstanding: r2(resolved.reduce((s, r) => s + r.outstanding, 0)),
      current: r2(resolved.reduce((s, r) => s + r.currentPortion, 0)),
      nonCurrent: r2(resolved.reduce((s, r) => s + r.nonCurrentPortion, 0)),
      debtService12m: r2(resolved.reduce((s, r) => s + r.debtService12m, 0)),
    },
  };
}

export async function listSchedule(clientId: number, loanId: number) {
  return db
    .select()
    .from(loanSchedules)
    .where(and(eq(loanSchedules.clientId, clientId), eq(loanSchedules.loanId, loanId)))
    .orderBy(loanSchedules.seq);
}

export { numberOfPeriods };
