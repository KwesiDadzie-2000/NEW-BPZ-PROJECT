import { db } from "@/db";
import {
  journalLines, accounts, clients, sessions, users, activityLog, invoices,
  fiscalPeriods, taxBands, taxRates, backupRuns,
} from "@/db/schema";
import { employees } from "@/db/employees-schema";
import { and, eq, sql, desc, lt } from "drizzle-orm";
import { PostingError, post } from "./posting";
import { computePaye, listPayeBands } from "./tax";
import { ensureSeed } from "./init";
import { verifyTotp, generateSecret, passwordProblem } from "./totp";
import { getRates } from "./fx";

export type Check = {
  id: string;
  area: string;
  name: string;
  status: "pass" | "fail" | "warn";
  detail: string;
  evidence?: string;
};

const r2 = (n: number) => Math.round(n * 100) / 100;

export async function runAssurance(): Promise<{ checks: Check[]; passed: number; failed: number; warned: number }> {
  await ensureSeed();
  const out: Check[] = [];
  const add = (c: Check) => out.push(c);

  // 1. Database connectivity
  try {
    await db.execute(sql`select 1`);
    add({ id: "db", area: "Platform", name: "Database connectivity", status: "pass", detail: "PostgreSQL reachable and responding." });
  } catch (e) {
    add({ id: "db", area: "Platform", name: "Database connectivity", status: "fail", detail: `Database unreachable: ${e instanceof Error ? e.message : "error"}` });
  }

  // 2. Double-entry integrity — every document in every workspace balances
  try {
    const bad = await db
      .select({ client: journalLines.clientId, doc: journalLines.docNo, dr: sql<number>`sum(${journalLines.debit})::float8`, cr: sql<number>`sum(${journalLines.credit})::float8` })
      .from(journalLines)
      .groupBy(journalLines.clientId, journalLines.docNo)
      .having(sql`abs(sum(${journalLines.debit}) - sum(${journalLines.credit})) > 0.005`);
    const docs = await db.select({ n: sql<number>`count(distinct (client_id, doc_no))::int` }).from(journalLines);
    add({
      id: "balance", area: "Accounting", name: "Double-entry integrity (Dr = Cr per document)",
      status: bad.length === 0 ? "pass" : "fail",
      detail: bad.length === 0 ? `All ${docs[0]?.n ?? 0} documents across all workspaces balance exactly.` : `${bad.length} unbalanced document(s) found.`,
      evidence: bad.slice(0, 3).map((b) => `${b.doc}: Dr ${b.dr.toFixed(2)} vs Cr ${b.cr.toFixed(2)}`).join(" · "),
    });
  } catch (e) {
    add({ id: "balance", area: "Accounting", name: "Double-entry integrity", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 3. Tenant isolation — no journal line exists outside a known workspace
  try {
    const ws = await db.select({ id: clients.id }).from(clients);
    const valid = new Set(ws.map((w) => w.id));
    const all = await db.select({ c: journalLines.clientId }).from(journalLines).groupBy(journalLines.clientId);
    const orphans = all.filter((a) => !valid.has(a.c));
    const userRows = await db.select({ username: users.username, clientId: users.clientId, role: users.role }).from(users);
    const cross = userRows.filter((u) => u.role === "client" && u.clientId === null);
    add({
      id: "isolation", area: "Security", name: "Client data isolation",
      status: orphans.length === 0 && cross.length === 0 ? "pass" : "fail",
      detail: orphans.length === 0 && cross.length === 0
        ? `${all.length} workspaces verified — every journal line belongs to a known client; no client user is unassigned.`
        : `${orphans.length} orphaned line set(s), ${cross.length} unassigned client login(s).`,
      evidence: `Workspaces: ${[...valid].join(", ")}`,
    });
  } catch (e) {
    add({ id: "isolation", area: "Security", name: "Client data isolation", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 4. Posting control — an unbalanced document must be refused, with no data left behind
  try {
    let refused = false;
    await db.transaction(async (tx) => {
      const probe = (await db.select({ id: clients.id }).from(clients).limit(1))[0];
      try {
        await post(tx as never, {
          clientId: probe.id, date: new Date().toISOString().slice(0, 10), period: new Date().toISOString().slice(0, 7),
          module: "FI", docType: "TEST",
          lines: [
            { account: "540000", desc: "assurance probe", dr: 100 },
            { account: "219000", desc: "assurance probe", cr: 90 },
          ],
        });
      } catch (err) {
        if (err instanceof PostingError) refused = true;
        else throw err;
      }
      throw new Error("ROLLBACK_PROBE");
    }).catch((e) => {
      if (e instanceof Error && e.message !== "ROLLBACK_PROBE") throw e;
    });
    const leftovers = await db.select({ n: sql<number>`count(*)::int` }).from(journalLines).where(eq(journalLines.docType, "TEST"));
    const clean = leftovers[0]?.n === 0;
    add({
      id: "posting", area: "Accounting", name: "Unbalanced posting control",
      status: refused && clean ? "pass" : "fail",
      detail: refused && clean
        ? "Unbalanced document refused by the posting engine; transaction rolled back leaving zero residue."
        : `Refused=${refused}, residue rows=${leftovers[0]?.n ?? 0}.`,
    });
  } catch (e) {
    add({ id: "posting", area: "Accounting", name: "Unbalanced posting control", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 5. PAYE engine — verify against the published Ghana band table
  try {
    const bands = await listPayeBands();
    const gross = 21000;
    const t1 = r2(gross * 0.055);
    const t2 = r2(Math.min(gross, 13000) * 0.05);
    const taxable = gross - t1 - t2;
    const got = computePaye(taxable, bands, 0);
    const expected = 2209.13;
    add({
      id: "paye", area: "Payroll", name: "Ghana PAYE computation accuracy",
      status: Math.abs(got - expected) < 0.02 ? "pass" : "fail",
      detail: Math.abs(got - expected) < 0.02
        ? `Gross ₵21,000 → taxable ₵${taxable.toFixed(2)} → PAYE ₵${got.toFixed(2)} matches the published schedule.`
        : `PAYE returned ₵${got.toFixed(2)}, expected ₵${expected.toFixed(2)}.`,
      evidence: `${bands.length} PAYE bands loaded (eff. ${bands[0]?.effectiveFrom ?? "n/a"}).`,
    });
  } catch (e) {
    add({ id: "paye", area: "Payroll", name: "Ghana PAYE computation accuracy", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 6. TOTP engine — prove the second factor verifies and rejects
  try {
    const secret = generateSecret();
    const { hotpForTest } = await import("./totp-selftest");
    const good = hotpForTest(secret, Math.floor(Date.now() / 30_000));
    const okGood = verifyTotp(secret, good);
    const okBad = verifyTotp(secret, "000000");
    const policyOk = passwordProblem("weak") !== null && passwordProblem("Str0ngPassphrase2026") === null;
    add({
      id: "auth", area: "Security", name: "Two-factor & password policy engine",
      status: okGood && !okBad && policyOk ? "pass" : "fail",
      detail: okGood && !okBad && policyOk
        ? "TOTP verifies a valid code, rejects an invalid one; password policy accepts strong and rejects weak."
        : `TOTP valid=${okGood}, invalid rejected=${!okBad}, policy=${policyOk}.`,
    });
  } catch (e) {
    add({ id: "auth", area: "Security", name: "Two-factor & password policy engine", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 7. Session hygiene — expired and abandoned sessions
  try {
    const now = new Date();
    const stale = await db.select({ n: sql<number>`count(*)::int` }).from(sessions).where(lt(sessions.expiresAt, now));
    const pending = await db.select({ n: sql<number>`count(*)::int` }).from(sessions).where(and(eq(sessions.pending, true), lt(sessions.expiresAt, now)));
    const total = await db.select({ n: sql<number>`count(*)::int` }).from(sessions);
    add({
      id: "sessions", area: "Security", name: "Session hygiene",
      status: (stale[0]?.n ?? 0) <= 5 ? "pass" : "warn",
      detail: `${total[0]?.n ?? 0} session(s) on record, ${stale[0]?.n ?? 0} expired, ${pending[0]?.n ?? 0} abandoned mid-2FA. Expired sessions grant no access.`,
    });
  } catch (e) {
    add({ id: "sessions", area: "Security", name: "Session hygiene", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 8. Audit trail is capturing evidence
  try {
    const n = await db.select({ c: sql<number>`count(*)::int` }).from(activityLog);
    const last = await db.select({ at: activityLog.at, action: activityLog.action }).from(activityLog).orderBy(desc(activityLog.id)).limit(1);
    const ageH = last[0] ? (Date.now() - last[0].at.getTime()) / 3_600_000 : 999;
    add({
      id: "audit", area: "Compliance", name: "Immutable audit trail capturing",
      status: (n[0]?.c ?? 0) > 0 && ageH < 720 ? "pass" : "warn",
      detail: `${n[0]?.c ?? 0} event(s) retained. Most recent: ${last[0]?.action ?? "none"}${last[0] ? `, ${ageH.toFixed(1)}h ago` : ""}.`,
    });
  } catch (e) {
    add({ id: "audit", area: "Compliance", name: "Immutable audit trail capturing", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 9. Statutory rate completeness
  try {
    const cats = await db.select({ c: taxRates.category, n: sql<number>`count(*)::int` }).from(taxRates).groupBy(taxRates.category);
    const bands = await db.select({ n: sql<number>`count(*)::int` }).from(taxBands);
    const needCat = ["VAT", "CIT", "WHT_RES", "WHT_NR", "SSNIT", "NHIL"];
    const missing = needCat.filter((c) => !cats.some((x) => x.c === c));
    add({
      id: "rates", area: "Compliance", name: "Statutory rate tables present",
      status: missing.length === 0 && (bands[0]?.n ?? 0) >= 5 ? "pass" : "warn",
      detail: missing.length === 0
        ? `${cats.reduce((s, c) => s + c.n, 0)} rates across ${cats.length} categories, ${bands[0]?.n ?? 0} PAYE bands — all owner-editable with effective dates.`
        : `Missing categories: ${missing.join(", ")}.`,
    });
  } catch (e) {
    add({ id: "rates", area: "Compliance", name: "Statutory rate tables present", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 10. FX rate freshness (IAS 21 evidence)
  try {
    const rates = await getRates();
    const nonBase = rates.filter((r) => r.code !== "GHS");
    const stalest = nonBase.reduce((m, r) => {
      const t = r.updatedAt ? new Date(r.updatedAt).getTime() : 0;
      return Math.max(m, t);
    }, 0);
    const days = stalest ? (Date.now() - stalest) / 86_400_000 : 999;
    add({
      id: "fx", area: "Accounting", name: "Currency rates available for revaluation",
      status: nonBase.length > 0 && days < 8 ? "pass" : days < 30 ? "warn" : "fail",
      detail: `${nonBase.length} foreign currencies configured. Oldest rate is ${days === 999 ? "never refreshed" : `${days.toFixed(1)} day(s) old`}.`,
    });
  } catch (e) {
    add({ id: "fx", area: "Accounting", name: "Currency rates available", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 11. Fiscal period control
  try {
    const closed = await db.select({ n: sql<number>`count(*)::int` }).from(fiscalPeriods).where(eq(fiscalPeriods.status, "closed"));
    const lines = await db.select({ n: sql<number>`count(*)::int` }).from(journalLines).where(sql`period !~ '^[0-9]{4}-[0-9]{2}$'`);
    add({
      id: "periods", area: "Accounting", name: "Fiscal period control",
      status: (lines[0]?.n ?? 0) === 0 ? "pass" : "fail",
      detail: (lines[0]?.n ?? 0) === 0
        ? `Every journal line carries a valid YYYY-MM period. ${closed[0]?.n ?? 0} period(s) currently closed and locked against posting.`
        : `${lines[0]?.n ?? 0} line(s) have an invalid period value.`,
    });
  } catch (e) {
    add({ id: "periods", area: "Accounting", name: "Fiscal period control", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 12. Data protection — backup recency
  try {
    const last = await db.select().from(backupRuns).orderBy(desc(backupRuns.id)).limit(1);
    const hours = last[0] ? (Date.now() - last[0].takenAt.getTime()) / 3_600_000 : 999;
    add({
      id: "backup", area: "Compliance", name: "Backup / data protection",
      status: hours <= 24 ? "pass" : hours <= 168 ? "warn" : "fail",
      detail: last[0]
        ? `Most recent snapshot taken ${hours.toFixed(1)} hour(s) ago (${last[0].scope}, ${Math.round((last[0].sizeBytes || 0) / 1024)} KB).`
        : "No snapshot has been taken yet. Download one from Data Protection.",
    });
  } catch (e) {
    add({ id: "backup", area: "Compliance", name: "Backup / data protection", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 13. Chart of accounts completeness
  try {
    const n = await db.select({ c: sql<number>`count(*)::int` }).from(accounts);
    const types = await db.select({ t: accounts.type, c: sql<number>`count(*)::int` }).from(accounts).groupBy(accounts.type);
    const have = new Set(types.map((t) => t.t));
    const need = ["Asset", "Liability", "Equity", "Revenue", "Expense"];
    const missing = need.filter((t) => !have.has(t));
    add({
      id: "coa", area: "Accounting", name: "Chart of accounts completeness",
      status: missing.length === 0 && (n[0]?.c ?? 0) >= 60 ? "pass" : "warn",
      detail: missing.length === 0
        ? `${n[0]?.c ?? 0} accounts covering all five IFRS statement categories.`
        : `Missing statement categories: ${missing.join(", ")}.`,
    });
  } catch (e) {
    add({ id: "coa", area: "Accounting", name: "Chart of accounts completeness", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 14. Invoice integrity — paid + partial must never exceed total
  try {
    const bad = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(invoices)
      .where(sql`paid < -0.005 OR (paid - total > 0.005 AND total > 0)`);
    add({
      id: "invoices", area: "Accounting", name: "Receivable / payable integrity",
      status: (bad[0]?.n ?? 0) === 0 ? "pass" : "fail",
      detail: (bad[0]?.n ?? 0) === 0
        ? "No invoice is over-settled or carries a negative balance."
        : `${bad[0]?.n ?? 0} invoice(s) violate settlement limits.`,
    });
  } catch (e) {
    add({ id: "invoices", area: "Accounting", name: "Receivable / payable integrity", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  // 15. Employee master integrity
  try {
    const bad = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(employees)
      .where(sql`basic_salary <= 0 OR status NOT IN ('active','suspended','left')`);
    const total = await db.select({ n: sql<number>`count(*)::int` }).from(employees);
    add({
      id: "employees", area: "Payroll", name: "Employee master integrity",
      status: (bad[0]?.n ?? 0) === 0 ? "pass" : "fail",
      detail: (bad[0]?.n ?? 0) === 0
        ? `${total[0]?.n ?? 0} employee record(s) valid — no zero salaries or invalid statuses.`
        : `${bad[0]?.n ?? 0} invalid employee record(s).`,
    });
  } catch (e) {
    add({ id: "employees", area: "Payroll", name: "Employee master integrity", status: "fail", detail: e instanceof Error ? e.message : "check error" });
  }

  const passed = out.filter((c) => c.status === "pass").length;
  const failed = out.filter((c) => c.status === "fail").length;
  const warned = out.filter((c) => c.status === "warn").length;
  return { checks: out, passed, failed, warned };
}
