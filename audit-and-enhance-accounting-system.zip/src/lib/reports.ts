import { db } from "@/db";
import {
  journalLines,
  accounts,
  partners,
  costCenters,
  materials,
  purchaseOrders,
  salesOrders,
  stockMoves,
  budgetLines,
} from "@/db/schema";
import { and, eq, sql, desc, ne, inArray } from "drizzle-orm";
import { ensureSeed } from "./init";

type MoneyCol = (typeof journalLines)["debit" | "credit"];
const sumExpr = (col: MoneyCol) => sql<number>`coalesce(sum(${col}), 0)::float8`;

function pc(clientId: number, from?: string, to?: string) {
  return and(
    eq(journalLines.clientId, clientId),
    from ? sql`${journalLines.period} >= ${from}` : undefined,
    to ? sql`${journalLines.period} <= ${to}` : undefined
  );
}

// ------------------------------------------------------------
// TRIAL BALANCE
// ------------------------------------------------------------

export type TbRow = { account: string; description: string; type: string; dr: number; cr: number; bal: number };

export async function trialBalance(clientId: number, from?: string, to?: string): Promise<{
  rows: TbRow[]; totalDr: number; totalCr: number; balanced: boolean;
}> {
  await ensureSeed();
  const raw = await db
    .select({
      account: journalLines.account,
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(pc(clientId, from, to))
    .groupBy(journalLines.account);
  const accs = await db.select().from(accounts);
  const map = new Map(accs.map((a) => [a.accountNo, a]));
  const rows: TbRow[] = raw
    .map((r) => ({
      account: r.account,
      description: map.get(r.account)?.description ?? "(unknown)",
      type: map.get(r.account)?.type ?? "—",
      dr: r.dr,
      cr: r.cr,
      bal: r.dr - r.cr,
    }))
    .sort((a, b) => a.account.localeCompare(b.account));
  const totalDr = rows.reduce((s, r) => s + r.dr, 0);
  const totalCr = rows.reduce((s, r) => s + r.cr, 0);
  return { rows, totalDr, totalCr, balanced: Math.abs(totalDr - totalCr) < 0.01 };
}

/** Opening balance of an account before a period range. */
async function openingBal(clientId: number, acc: string, from?: string): Promise<number> {
  const rows = await db
    .select({
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(
      from
        ? and(eq(journalLines.clientId, clientId), eq(journalLines.account, acc), sql`${journalLines.period} < ${from}`)
        : and(eq(journalLines.clientId, clientId), eq(journalLines.account, acc))
    );
  const r = rows[0];
  return (r?.dr ?? 0) - (r?.cr ?? 0);
}

async function closeBal(clientId: number, acc: string, from?: string, to?: string): Promise<number> {
  const rows = await db
    .select({
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.account, acc), from ? sql`${journalLines.period} >= ${from}` : undefined, to ? sql`${journalLines.period} <= ${to}` : undefined));
  const r = rows[0];
  return (r?.dr ?? 0) - (r?.cr ?? 0);
}

const bal = (rows: TbRow[], acc: string) => rows.find((r) => r.account === acc)?.bal ?? 0;

// ------------------------------------------------------------
// ACTIVITY
// ------------------------------------------------------------

export async function byModule(clientId: number, from?: string, to?: string) {
  await ensureSeed();
  return db
    .select({
      module: journalLines.module,
      docs: sql<number>`count(distinct ${journalLines.docNo})::float8`,
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(pc(clientId, from, to))
    .groupBy(journalLines.module)
    .orderBy(sql`coalesce(sum(${journalLines.debit}), 0) desc`);
}

export async function byCostCenter(clientId: number, from?: string, to?: string) {
  await ensureSeed();
  const raw = await db
    .select({
      cc: journalLines.costCenter,
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(and(pc(clientId, from, to)!, ne(journalLines.costCenter, "")))
    .groupBy(journalLines.costCenter)
    .orderBy(desc(journalLines.costCenter));
  const ccs = await db.select().from(costCenters);
  const map = new Map(ccs.map((c) => [c.ccCode, c.ccName]));
  return raw.map((r) => ({ cc: r.cc, name: map.get(r.cc) ?? r.cc, dr: r.dr, cr: r.cr }));
}

// ------------------------------------------------------------
// P&L / BALANCE SHEET
// ------------------------------------------------------------

export async function pnl(clientId: number, from?: string, to?: string) {
  const { rows } = await trialBalance(clientId, from, to);
  const revenue = rows.filter((r) => r.type === "Revenue").map((r) => ({ ...r, amount: r.bal < 0 ? -r.bal : r.bal }));
  const expense = rows.filter((r) => r.type === "Expense").map((r) => ({ ...r, amount: r.bal }));
  const totalRev = revenue.reduce((s, r) => s + r.amount, 0);
  const totalExp = expense.reduce((s, r) => s + r.amount, 0);
  return { revenue, expense, totalRev, totalExp, net: totalRev - totalExp };
}

export async function balanceSheet(clientId: number, from?: string, to?: string) {
  const { rows } = await trialBalance(clientId, from, to);
  const assets = rows.filter((r) => r.type === "Asset");
  const liab = rows.filter((r) => r.type === "Liability");
  const equity = rows.filter((r) => r.type === "Equity");
  const tAssets = assets.reduce((s, r) => s + r.bal, 0);
  const tLiab = liab.reduce((s, r) => s + r.bal, 0);
  const tEquity = equity.reduce((s, r) => s + r.bal, 0);
  const net = tAssets + tLiab - tEquity;
  const grand = rows.reduce((s, r) => s + r.bal, 0);
  return {
    assets, liab, equity, tAssets, tLiab, tEquity, net,
    tLiabEq: -tLiab + tEquity,
    tLiabEqNet: -tLiab + tEquity + net,
    balanced: Math.abs(grand) < 0.01,
  };
}

// ------------------------------------------------------------
// CASH FLOW (IAS 7 – indirect method)
// ------------------------------------------------------------

const CASH_ACCOUNTS = ["100000", "101000", "102000", "103000", "104000", "105000"];
const TAX_PAYABLES = ["205000", "206000", "207000", "208000", "209000", "211000", "215000", "216000", "217000", "218000"];
const ASSET_ACCOUNTS = ["130000", "131000", "132000", "133000", "134000", "135000", "136000", "137000", "138000", "138500", "140000", "140500"];

export async function cashFlow(clientId: number, from?: string, to?: string) {
  const { net } = await pnl(clientId, from, to);
  const dep = await closeBal(clientId, "550000", from, to);
  const fxGain = await closeBal(clientId, "491000", from, to);
  const fxLoss = await closeBal(clientId, "580000", from, to);
  const fxNet = fxGain - fxLoss;

  const arOpen = await openingBal(clientId, "110000", from);
  const arClose = await closeBal(clientId, "110000", from, to);
  const dAr = arClose - arOpen;

  const invAcc = ["120000", "121000", "122000", "123000", "124000"];
  const invOpen = (await Promise.all(invAcc.map((a) => openingBal(clientId, a, from)))).reduce((s, v) => s + v, 0);
  const invClose = (await Promise.all(invAcc.map((a) => closeBal(clientId, a, from, to)))).reduce((s, v) => s + v, 0);
  const dInv = invClose - invOpen;

  const prepayOpen = await openingBal(clientId, "141000", from);
  const prepayClose = await closeBal(clientId, "141000", from, to);
  const dPrepay = prepayClose - prepayOpen;

  const apAcc = ["200000", "201000", "202000"];
  const apOpen = (await Promise.all(apAcc.map((a) => openingBal(clientId, a, from)))).reduce((s, v) => s + v, 0);
  const apClose = (await Promise.all(apAcc.map((a) => closeBal(clientId, a, from, to)))).reduce((s, v) => s + v, 0);
  const dAp = apClose - apOpen;

  const payOpen = (await Promise.all(TAX_PAYABLES.map((a) => openingBal(clientId, a, from)))).reduce((s, v) => s + v, 0);
  const payClose = (await Promise.all(TAX_PAYABLES.map((a) => closeBal(clientId, a, from, to)))).reduce((s, v) => s + v, 0);
  const dPay = payClose - payOpen;

  const taxesPaid = (
    await db
      .select({ t: sumExpr(journalLines.credit) })
      .from(journalLines)
      .where(and(eq(journalLines.clientId, clientId), inArray(journalLines.account, TAX_PAYABLES), from ? sql`${journalLines.period} >= ${from}` : undefined, to ? sql`${journalLines.period} <= ${to}` : undefined))
  )[0]?.t ?? 0;

  const investingDr = (
    await db
      .select({ t: sumExpr(journalLines.debit) })
      .from(journalLines)
      .where(and(eq(journalLines.clientId, clientId), inArray(journalLines.account, ASSET_ACCOUNTS), from ? sql`${journalLines.period} >= ${from}` : undefined, to ? sql`${journalLines.period} <= ${to}` : undefined))
  )[0]?.t ?? 0;

  const loanAcc = ["220000", "290000", "291000"];
  const loanOpen = (await Promise.all(loanAcc.map((a) => openingBal(clientId, a, from)))).reduce((s, v) => s + v, 0);
  const loanClose = (await Promise.all(loanAcc.map((a) => closeBal(clientId, a, from, to)))).reduce((s, v) => s + v, 0);
  const dLoan = loanClose - loanOpen;
  const capital = (await closeBal(clientId, "300000", from, to)) + (await closeBal(clientId, "310000", from, to));

  const operatingLines = [
    { label: "Net income", v: net },
    { label: "Add back: depreciation & amortisation", v: dep },
    { label: "(Increase) / decrease in trade receivables", v: -dAr },
    { label: "(Increase) / decrease in inventories", v: -dInv },
    { label: "(Increase) / decrease in prepayments", v: -dPrepay },
    { label: "Increase / (decrease) in trade payables", v: dAp },
    { label: "Increase / (decrease) in wages & tax payables", v: dPay },
    { label: "Taxes paid", v: -taxesPaid },
    { label: "Net foreign exchange (gain) / loss", v: fxNet },
  ];
  const operating = operatingLines.reduce((s, l) => s + l.v, 0);
  const investingLines = [
    { label: "Purchase of non-current assets", v: -investingDr },
    { label: "Total cash used in investing activities", v: -investingDr },
  ];
  const financingLines = [
    { label: "Drawdown / (repayment) of borrowings", v: -dLoan },
    { label: "Share capital issued", v: capital },
    { label: "Total cash from financing activities", v: -dLoan + capital },
  ];
  const change = operating + -investingDr + -dLoan + capital;

  const cashOpen = (await Promise.all(CASH_ACCOUNTS.map((a) => openingBal(clientId, a, from)))).reduce((s, v) => s + v, 0);
  const cashCloseParts = await Promise.all(
    CASH_ACCOUNTS.map(async (a) => (await openingBal(clientId, a, from)) + (await closeBal(clientId, a, from, to)))
  );
  const cashClose = cashCloseParts.reduce((s, v) => s + v, 0);

  return {
    net, dep, fxNet, taxesPaid,
    operatingLines, operating,
    investingLines,
    financingLines,
    change,
    cashOpen,
    cashClose,
    changeActual: cashClose - cashOpen,
  };
}

// ------------------------------------------------------------
// STATEMENT OF CHANGES IN EQUITY
// ------------------------------------------------------------

export async function statementOfChangesInEquity(clientId: number, from?: string, to?: string) {
  const { rows } = await trialBalance(clientId, from, to);
  const equityRows = rows.filter((r) => r.type === "Equity");
  const { net } = await pnl(clientId, from, to);
  const opening: Record<string, number> = {};
  for (const r of equityRows) opening[r.account] = await openingBal(clientId, r.account, from);
  return {
    rows: equityRows.map((r) => ({
      account: r.account,
      description: r.description,
      opening: opening[r.account] ?? 0,
      movement: r.bal,
      closing: (opening[r.account] ?? 0) + r.bal,
    })),
    net,
  };
}

// ------------------------------------------------------------
// AGING (AP / AR)
// ------------------------------------------------------------

const BUCKETS = [
  { label: "Current", min: 0, max: 0 },
  { label: "1–30 days", min: 1, max: 30 },
  { label: "31–60 days", min: 31, max: 60 },
  { label: "61–90 days", min: 61, max: 90 },
  { label: "> 90 days", min: 91, max: 100000 },
];

export async function aging(clientId: number, direction: "AP" | "AR") {
  const accs = direction === "AP" ? ["200000", "201000", "202000"] : ["110000"];
  const rows = await db
    .select({
      bp: journalLines.bp,
      postDate: journalLines.postDate,
      dr: sql<number>`(${journalLines.debit})::float8`,
      cr: sql<number>`(${journalLines.credit})::float8`,
    })
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), inArray(journalLines.account, accs), ne(journalLines.bp, "")))
    .orderBy(journalLines.postDate, journalLines.id);
  const todayTs = Date.now();
  const byBp = new Map<string, { buckets: number[]; total: number }>();
  for (const r of rows) {
    const move = direction === "AP" ? r.cr - r.dr : r.dr - r.cr;
    if (move === 0) continue;
    const ageDays = Math.floor((todayTs - new Date(r.postDate).getTime()) / 86400000);
    let idx = BUCKETS.findIndex((b) => ageDays >= b.min && ageDays <= b.max);
    if (idx === -1) idx = direction === "AP" ? 0 : ageDays <= 0 ? 0 : BUCKETS.length - 1;
    // AP credits (we owe) age; AP debits (payments) reduce the oldest bucket — approximate at current
    const e = byBp.get(r.bp) ?? { buckets: Array(5).fill(0), total: 0 };
    e.buckets[idx] += move;
    e.total += move;
    byBp.set(r.bp, e);
  }
  const bps = await db.select().from(partners);
  const name = new Map(bps.map((b) => [b.bpNo, b.name]));
  return [...byBp.entries()]
    .map(([bp, v]) => ({
      bp, name: name.get(bp) ?? bp,
      buckets: v.buckets.map((x) => Math.round(x * 100) / 100),
      total: Math.round(v.total * 100) / 100,
    }))
    .filter((x) => Math.abs(x.total) > 0.005)
    .sort((a, b) => Math.abs(b.total) - Math.abs(a.total));
}

// ------------------------------------------------------------
// JOURNAL
// ------------------------------------------------------------

export type JRow = {
  id: number; docNo: string; period: string; postDate: string; module: string; docType: string;
  account: string; accDesc: string; bp: string; costCenter: string; material: string;
  description: string; debit: number; credit: number; createdBy: string; reference: string;
};

const J_SELECT = {
  id: journalLines.id,
  docNo: journalLines.docNo,
  period: journalLines.period,
  postDate: journalLines.postDate,
  module: journalLines.module,
  docType: journalLines.docType,
  account: journalLines.account,
  bp: journalLines.bp,
  costCenter: journalLines.costCenter,
  material: journalLines.material,
  description: journalLines.description,
  debit: sql<number>`(${journalLines.debit})::float8`,
  credit: sql<number>`(${journalLines.credit})::float8`,
  createdBy: journalLines.createdBy,
  reference: journalLines.reference,
};

export async function journalRows(filter: {
  clientId: number; from?: string; to?: string; search?: string; module?: string; account?: string; doc?: string; limit?: number; offset?: number;
}): Promise<JRow[]> {
  await ensureSeed();
  const cond = and(
    pc(filter.clientId, filter.from, filter.to)!,
    filter.doc ? eq(journalLines.docNo, filter.doc) : undefined,
    filter.module ? eq(journalLines.module, filter.module) : undefined,
    filter.account ? eq(journalLines.account, filter.account) : undefined,
    filter.search
      ? sql`(${journalLines.docNo} like ${"%" + filter.search + "%"} or ${journalLines.account} like ${"%" + filter.search + "%"} or ${journalLines.bp} like ${"%" + filter.search + "%"} or ${journalLines.description} like ${"%" + filter.search + "%"} or ${journalLines.reference} like ${"%" + filter.search + "%"})`
      : undefined
  );
  const rows = await db
    .select(J_SELECT)
    .from(journalLines)
    .where(cond)
    .orderBy(desc(journalLines.id))
    .limit(filter.limit ?? 500)
    .offset(filter.offset ?? 0);
  const accs = await db.select().from(accounts);
  const map = new Map(accs.map((a) => [a.accountNo, a.description]));
  return rows.map((r) => ({ ...r, accDesc: map.get(r.account) ?? "" }));
}

export async function journalTotals(clientId: number, from?: string, to?: string) {
  const rows = await db
    .select({
      lineCount: sql<number>`count(*)::float8`,
      docCount: sql<number>`count(distinct ${journalLines.docNo})::float8`,
      docsToday: sql<number>`count(distinct ${journalLines.docNo}) filter (where ${journalLines.postDate} = ${new Date().toISOString().slice(0, 10)})::float8`,
      totalDr: sumExpr(journalLines.debit),
      totalCr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(pc(clientId, from, to)!);
  return rows[0] ?? { lineCount: 0, docCount: 0, docsToday: 0, totalDr: 0, totalCr: 0 };
}

export async function documentLines(clientId: number, docNo: string) {
  const rows = await db
    .select(J_SELECT)
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)))
    .orderBy(journalLines.id);
  const accs = await db.select().from(accounts);
  const map = new Map(accs.map((a) => [a.accountNo, a.description]));
  const lines: JRow[] = rows.map((r) => ({ ...r, accDesc: map.get(r.account) ?? "" }));
  const dr = lines.reduce((s, l) => s + l.debit, 0);
  const cr = lines.reduce((s, l) => s + l.credit, 0);
  return { lines, dr, cr, balanced: Math.abs(dr - cr) < 0.01 };
}

// ------------------------------------------------------------
// BP LEDGER
// ------------------------------------------------------------

export async function bpActivity(clientId: number, from?: string, to?: string) {
  const rows = await db
    .select({
      bp: journalLines.bp,
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(and(pc(clientId, from, to)!, ne(journalLines.bp, "")))
    .groupBy(journalLines.bp);
  const all = await db.select().from(partners).where(eq(partners.clientId, clientId));
  const map = new Map(all.map((p) => [p.bpNo, p]));
  return rows
    .map((r) => ({
      bp: r.bp,
      name: map.get(r.bp)?.name ?? r.bp,
      type: map.get(r.bp)?.type ?? "—",
      dr: r.dr, cr: r.cr, bal: r.dr - r.cr,
    }))
    .sort((a, b) => a.bp.localeCompare(b.bp));
}

export async function bpLedger(clientId: number, bp: string, from?: string, to?: string) {
  const rows = await db
    .select({
      id: journalLines.id, docNo: journalLines.docNo, postDate: journalLines.postDate,
      period: journalLines.period, module: journalLines.module, description: journalLines.description,
      debit: sql<number>`(${journalLines.debit})::float8`,
      credit: sql<number>`(${journalLines.credit})::float8`,
    })
    .from(journalLines)
    .where(and(pc(clientId, from, to)!, eq(journalLines.bp, bp)))
    .orderBy(journalLines.id);
  let run = 0;
  const lines = rows.map((r) => {
    run += r.debit - r.credit;
    return { ...r, running: run };
  });
  return { lines, total: run };
}

// ------------------------------------------------------------
// STOCK VALUATION
// ------------------------------------------------------------

export async function stockValuation(clientId: number, from?: string, to?: string) {
  const INV = ["120000", "121000", "122000", "123000", "124000"];
  const rows = await db
    .select({
      material: journalLines.material,
      dr: sumExpr(journalLines.debit),
      cr: sumExpr(journalLines.credit),
    })
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), inArray(journalLines.account, INV), ne(journalLines.material, ""), from ? sql`${journalLines.period} >= ${from}` : undefined, to ? sql`${journalLines.period} <= ${to}` : undefined))
    .groupBy(journalLines.material);
  const moves = await db
    .select({
      material: stockMoves.material,
      qin: sql<number>`coalesce(sum(${stockMoves.qtyIn}), 0)::float8`,
      qout: sql<number>`coalesce(sum(${stockMoves.qtyOut}), 0)::float8`,
    })
    .from(stockMoves)
    .where(eq(stockMoves.clientId, clientId))
    .groupBy(stockMoves.material);
  const qMap = new Map(moves.map((m) => [m.material, m]));
  const mats = await db.select().from(materials);
  const mMap = new Map(mats.map((m) => [m.materialNo, m]));
  return rows
    .map((r) => {
      const q = qMap.get(r.material);
      const qty = (q?.qin ?? 0) - (q?.qout ?? 0);
      const value = r.dr - r.cr;
      return {
        material: r.material,
        description: mMap.get(r.material)?.description ?? r.material,
        type: mMap.get(r.material)?.type ?? "—",
        qty,
        value,
        stdPrice: mMap.get(r.material) ? Number(mMap.get(r.material)?.stdPrice) : 0,
      };
    })
    .sort((a, b) => a.material.localeCompare(b.material));
}

// ------------------------------------------------------------
// BUDGET VARIANCE
// ------------------------------------------------------------

export async function budgetVariance(clientId: number, scenarioId: number, from?: string, to?: string) {
  const lines = await db
    .select()
    .from(budgetLines)
    .where(and(eq(budgetLines.clientId, clientId), eq(budgetLines.scenarioId, scenarioId)));
  const { rows } = await trialBalance(clientId, from, to);
  const accMap = new Map(rows.map((r) => [r.account, r]));
  return lines
    .map((l) => {
      const a = accMap.get(l.account);
      const actual = a ? (a.type === "Revenue" ? -a.bal : a.bal) : 0;
      const budget = Number(l.amount);
      return {
        account: l.account,
        description: a?.description ?? l.account,
        type: a?.type ?? "—",
        budget,
        actual,
        variance: budget - actual,
        note: l.note,
      };
    })
    .sort((x, y) => x.account.localeCompare(y.account));
}

// ------------------------------------------------------------
// DASHBOARD
// ------------------------------------------------------------

export async function dashboardData(clientId: number) {
  const totals = await journalTotals(clientId);
  const { rows: tb } = await trialBalance(clientId);
  const mod = await byModule(clientId);
  const cc = await byCostCenter(clientId);
  const recent = (await journalRows({ clientId, limit: 10 })).slice(0, 10);
  const bank = CASH_ACCOUNTS.reduce((s, a) => s + bal(tb, a), 0);
  const rev = tb.filter((r) => r.type === "Revenue").reduce((s, r) => s + (r.bal < 0 ? -r.bal : r.bal), 0);
  const exp = tb.filter((r) => r.type === "Expense").reduce((s, r) => s + r.bal, 0);
  return {
    // Sign convention: liabilities and revenue carry CREDIT balances, so they are
    // negated here to display as natural positive amounts on the dashboard.
    totals, bank, ar: bal(tb, "110000"),
    ap: -bal(tb, "200000"),
    grir: -(bal(tb, "211000") + bal(tb, "210000")),
    salPayable: -bal(tb, "220000") - bal(tb, "205000"),
    rev, exp, net: rev - exp, mod, cc, recent,
  };
}

// ------------------------------------------------------------
// MASTER DATA + ORDER BOOKS
// ------------------------------------------------------------

export async function masterData(clientId: number) {
  await ensureSeed();
  const [accs, bps, ccs, mats] = await Promise.all([
    db.select().from(accounts).orderBy(accounts.accountNo),
    db.select().from(partners).where(eq(partners.clientId, clientId)).orderBy(partners.bpNo),
    db.select().from(costCenters).orderBy(costCenters.ccCode),
    db.select().from(materials).orderBy(materials.materialNo),
  ]);
  return { accs, bps, ccs, mats };
}

export async function orderBooks(clientId: number) {
  const [pos, sos] = await Promise.all([
    db.select().from(purchaseOrders).where(eq(purchaseOrders.clientId, clientId)).orderBy(desc(purchaseOrders.id)).limit(100),
    db.select().from(salesOrders).where(eq(salesOrders.clientId, clientId)).orderBy(desc(salesOrders.id)).limit(100),
  ]);
  const bps = await db.select().from(partners).where(eq(partners.clientId, clientId));
  return { pos, sos, bpName: new Map(bps.map((b) => [b.bpNo, b.name])) };
}

// ------------------------------------------------------------
// VAT RETURN (Ghana VAT Act — output less recoverable input)
// ------------------------------------------------------------

export async function vatReturn(clientId: number, from?: string, to?: string) {
  const { rows } = await trialBalance(clientId, from, to);
  const find = (a: string) => rows.find((r) => r.account === a);
  const output = -(find("211000")?.bal ?? 0); // credit balance = payable
  const input = find("112000")?.bal ?? 0; // debit balance = recoverable
  const netPayable = output - input;
  // Standard-rated sales base = output VAT / 20%
  const salesBase = output / 0.2;
  const purchasesBase = input / 0.2;
  return {
    output, input, netPayable, salesBase, purchasesBase,
    rate: 20,
    flat: rows.filter((r) => r.account === "211000" || r.account === "112000").map((r) => ({
      account: r.account, description: r.description, dr: r.dr, cr: r.cr, bal: r.bal,
    })),
  };
}

// ------------------------------------------------------------
// WITHHOLDING TAX SCHEDULE — what was deducted and what to remit
// ------------------------------------------------------------

export async function whtSchedule(clientId: number, from?: string, to?: string) {
  // 209000 Withholding tax payable: credit = deducted from suppliers
  const { rows } = await trialBalance(clientId, from, to);
  const payable = -(rows.find((r) => r.account === "209000")?.bal ?? 0);

  // Group WHT by partner for the certificate listing
  const lines = await db
    .select({
      bp: journalLines.bp,
      description: journalLines.description,
      dr: sql<number>`coalesce(sum(${journalLines.debit}),0)::float8`,
      cr: sql<number>`coalesce(sum(${journalLines.credit}),0)::float8`,
    })
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.account, "209000"), from ? sql`${journalLines.period} >= ${from}` : undefined, to ? sql`${journalLines.period} <= ${to}` : undefined))
    .groupBy(journalLines.bp, journalLines.description);

  const bps = await db.select().from(partners).where(eq(partners.clientId, clientId));
  const nm = new Map(bps.map((b) => [b.bpNo, b.name]));

  return {
    payable,
    byPartner: lines
      .filter((l) => l.cr > 0)
      .map((l) => ({
        bp: l.bp || "—",
        name: nm.get(l.bp ?? "") ?? (l.bp || "Unassigned"),
        deducted: l.cr,
        detail: l.description,
      }))
      .sort((a, b) => b.deducted - a.deducted),
  };
}

// ------------------------------------------------------------
// COMPLIANCE CALENDAR — statutory filings and their due dates
// ------------------------------------------------------------

export type FilingItem = {
  tax: string;
  what: string;
  due: string;
  basis: string;
  authority: string;
  status: "due" | "overdue" | "upcoming";
  amount: number | null;
};

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

export async function complianceCalendar(clientId: number, period: string) {
  const [y, m] = period.split("-").map(Number);
  const label = `${MONTHS[(m || 1) - 1]} ${y}`;
  const [vat, wht, { rows: tb }] = await Promise.all([
    vatReturn(clientId, period, period),
    whtSchedule(clientId, period, period),
    trialBalance(clientId, period, period),
  ]);
  const paye = -(tb.find((r) => r.account === "207000")?.bal ?? 0);
  const ssnit = -(tb.find((r) => r.account === "206000")?.bal ?? 0);
  const nhil = -(tb.find((r) => r.account === "208000")?.bal ?? 0);

  const now = new Date();
  const dueDate = new Date(Date.UTC(y, (m || 1) - 1 + 1, 0)); // end of following month
  const overdue = now > dueDate;

  const items: FilingItem[] = [
    { tax: "VAT", what: `VAT return for ${label} (output ₵${vat.output.toFixed(2)} less input ₵${vat.input.toFixed(2)})`, due: "Last working day of the following month", basis: `Net VAT payable ₵${vat.netPayable.toFixed(2)}`, authority: "GRA Domestic Tax Revenue Division", status: overdue ? "overdue" : "due", amount: vat.netPayable },
    { tax: "PAYE", what: `PAYE on employment income for ${label}`, due: "15th of the following month", basis: `PAYE deducted ₵${paye.toFixed(2)}`, authority: "GRA Domestic Tax Revenue Division", status: overdue ? "overdue" : "due", amount: paye },
    { tax: "WHT", what: `Withholding tax deducted from suppliers/contracts in ${label}`, due: "15th of the following month", basis: `WHT deducted ₵${wht.payable.toFixed(2)}`, authority: "GRA Domestic Tax Revenue Division", status: overdue ? "overdue" : "due", amount: wht.payable },
    { tax: "SSNIT", what: `Social security contributions (Tier 1 & 2) for ${label}`, due: "14th of the following month", basis: `Employee + employer ₵${ssnit.toFixed(2)}`, authority: "SSNIT", status: overdue ? "overdue" : "due", amount: ssnit },
    { tax: "NHIL", what: `National Health Insurance Levy (payroll) for ${label}`, due: "15th of the following month", basis: `Levy ₵${nhil.toFixed(2)}`, authority: "NHIA / GRA", status: overdue ? "overdue" : "due", amount: nhil },
    { tax: "CIT", what: `Corporate income tax — quarterly instalment`, due: "End of the quarter following the period", basis: `Apply the sector CIT rate to taxable income`, authority: "GRA", status: "upcoming", amount: null },
  ];
  return { period, items, vat, wht, paye, ssnit, nhil };
}
