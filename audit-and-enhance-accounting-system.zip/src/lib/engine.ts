import { db } from "@/db";
import {
  journalLines,
  materials,
  payOverrides,
  payrollRuns,
  invoices,
  assets,
  assetClasses,
  stockMoves,
  feeInvoices,
  contractCertificates,
  contracts,
} from "@/db/schema";
import { and, eq, ne, sql } from "drizzle-orm";
import { PostingError, post, type JLine } from "./posting";

export type { JLine } from "./posting";
import { getRate, getRates } from "./fx";
import { listPayeBands, rateValue, computePaye } from "./tax";
import { settlementStatus, withholdingBase } from "./accounting-rules";
import { assertPeriodOpen, thisPeriod } from "./periods";
import { partners } from "@/db/schema";
import { employees } from "@/db/employees-schema";
import { listEmployees, type Employee } from "./employees";

const r2 = (n: number) => Math.round(n * 100) / 100;

function rows<T>(v: T[]): T[] {
  return v;
}

// ------------------------------------------------------------
// Period-aware posting wrapper (enforces closed periods)
// ------------------------------------------------------------

export async function postChecked(
  clientId: number,
  p: { period: string; module: string; docType: string; lines: JLine[]; user?: string; reference?: string }
): Promise<string> {
  await assertPeriodOpen(clientId, p.period);
  return post(db as never, {
    clientId,
    date: new Date().toISOString().slice(0, 10),
    period: p.period,
    module: p.module,
    docType: p.docType,
    lines: p.lines,
    user: p.user,
    reference: p.reference,
  });
}

// ------------------------------------------------------------
// Reversal — mirrors every line of a document, with a reason
// ------------------------------------------------------------

export async function reverseDocument(clientId: number, docNo: string, reason: string, period: string, user?: string) {
  if (!reason?.trim()) throw new PostingError("A reason is required for every reversal.");
  const rows = await db
    .select()
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)));
  if (!rows.length) throw new PostingError(`Document ${docNo} not found in this workspace.`);
  if (rows[0].docType === "REV")
    throw new PostingError("A reversal document cannot itself be reversed. Reverse the original correction instead.");

  const priorReversal = await db
    .select({ docNo: journalLines.docNo })
    .from(journalLines)
    .where(
      and(
        eq(journalLines.clientId, clientId),
        eq(journalLines.docType, "REV"),
        sql`${journalLines.reference} like ${`REV of ${docNo} —%`}`
      )
    )
    .limit(1);
  if (priorReversal.length)
    throw new PostingError(
      `Document ${docNo} was already reversed by ${priorReversal[0].docNo}. A second reversal would duplicate the correction.`
    );

  // Never cancel an issued invoice/certificate while money has been allocated
  // to it. Reverse its receipts first, then reverse the source document.
  const sourceInvoice = (
    await db
      .select()
      .from(invoices)
      .where(and(eq(invoices.clientId, clientId), eq(invoices.docNo, docNo)))
  )[0];
  if (sourceInvoice && Number(sourceInvoice.paid) > 0.009)
    throw new PostingError(
      `${sourceInvoice.no} has ₵${Number(sourceInvoice.paid).toFixed(2)} settled against it. Reverse the payment/receipt document first.`
    );

  const lines: JLine[] = rows.map((l) => ({
    account: l.account,
    bp: l.bp,
    cc: l.costCenter,
    material: l.material,
    desc: `REVERSAL – ${l.description}`,
    dr: Number(l.credit) || undefined,
    cr: Number(l.debit) || undefined,
  }));
  const doc = await postChecked(clientId, {
    period,
    module: rows[0].module,
    docType: "REV",
    user,
    reference: `REV of ${docNo} — ${reason.trim()}`,
    lines,
  });

  // The journal is now mirrored, but the business documents must follow or the
  // payable stays settled and the bill vanishes from the payment desk.
  await reinstateInvoiceOnReversal(clientId, docNo);

  return { doc, message: `Document ${docNo} reversed → ${doc}. Reason: ${reason.trim()}` };
}

/**
 * When a payment (or receipt) document is reversed, the invoice it settled must
 * be un-settled so the liability returns and the bill reappears for payment.
 * Matches the payment back to its invoice via the reference, which is always
 * the invoice number.
 */
async function reinstateInvoiceOnReversal(clientId: number, reversedDocNo: string) {
  const original = await db
    .select()
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, reversedDocNo)));
  if (!original.length) return;
  const reference = original[0]?.reference ?? "";
  const docType = original[0]?.docType;

  // ---- PAYROLL RUN: the run must be un-posted so net pay is not payable twice ----
  if (docType === "PY") {
    const runs = await db
      .select()
      .from(payrollRuns)
      .where(and(eq(payrollRuns.clientId, clientId), eq(payrollRuns.docNo, reversedDocNo)));
    let run = runs[0];
    if (!run) {
      // Legacy rows may store a different doc; fall back to matching the
      // employee code carried in the run reference.
      const empCode = reference.split("–")[1]?.trim().split(" ")[0] ?? "";
      if (empCode) {
        const alt = await db
          .select()
          .from(payrollRuns)
          .where(and(eq(payrollRuns.clientId, clientId), eq(payrollRuns.bpNo, empCode)));
        run = alt[0];
      }
    }
    if (run) await db.delete(payrollRuns).where(eq(payrollRuns.id, run.id));
    return;
  }

  // ---- DEPRECIATION RUN: restore each asset's accumulated depreciation and NBV.
  // The run's reference carries "Name amount" pairs, so we can unwind precisely
  // regardless of how many assets were in the run. ----
  if (docType === "AF") {
    const perAsset: { name: string; amount: number }[] = [];
    const detail = reference.split(":")[1] ?? "";
    for (const part of detail.split("·")) {
      const m = part.trim().match(/^(.*?)\s+([\d,]+\.\d{2})$/);
      if (m) perAsset.push({ name: m[1].trim(), amount: Number(m[2].replace(/,/g, "")) });
    }
    for (const p of perAsset) {
      const a = (
        await db
          .select()
          .from(assets)
          .where(and(eq(assets.clientId, clientId), eq(assets.name, p.name)))
      )[0];
      if (!a) continue;
      const accum = Math.max(0, r2(Number(a.accumDep) - p.amount));
      await db
        .update(assets)
        .set({ accumDep: String(accum), nbv: String(r2(Number(a.cost) - accum)) })
        .where(eq(assets.id, a.id));
    }
    return;
  }

  // ---- INVOICE / PAYMENT / RECEIPT: un-settle the invoice ----
  const inv = (
    await db
      .select()
      .from(invoices)
      .where(and(eq(invoices.clientId, clientId), eq(invoices.docNo, reversedDocNo)))
  )[0];

  // Case A: the reversed document IS the invoice/certificate issuance. It is
  // cancelled (not reopened for payment). If it was an IPC, restore the
  // contract's billed and retention totals so the next certificate is correct.
  if (inv) {
    await db
      .update(invoices)
      .set({ status: "cancelled", paid: "0" })
      .where(eq(invoices.id, inv.id));

    const certificate = (
      await db
        .select()
        .from(contractCertificates)
        .where(
          and(
            eq(contractCertificates.clientId, clientId),
            eq(contractCertificates.certNo, inv.no)
          )
        )
    )[0];
    if (certificate) {
      await db
        .update(contractCertificates)
        .set({ status: "cancelled", paid: "0" })
        .where(eq(contractCertificates.id, certificate.id));
      const contract = (
        await db
          .select()
          .from(contracts)
          .where(
            and(
              eq(contracts.clientId, clientId),
              eq(contracts.id, certificate.contractId)
            )
          )
      )[0];
      if (contract) {
        await db
          .update(contracts)
          .set({
            billed: String(
              Math.max(0, r2(Number(contract.billed) - Number(certificate.grossValue)))
            ),
            retentionHeld: String(
              Math.max(
                0,
                r2(Number(contract.retentionHeld) - Number(certificate.retention))
              )
            ),
          })
          .where(eq(contracts.id, contract.id));
      }
    }
    return;
  }

  // Case B: it was a payment or receipt against an invoice.
  const number = reference.split(" ")[0];
  if (!number) return;
  const target = (
    await db
      .select()
      .from(invoices)
      .where(and(eq(invoices.clientId, clientId), eq(invoices.no, number)))
  )[0];
  if (!target) return;

  const settled = await db
    .select({
      amt: sql<number>`coalesce(sum(${journalLines.debit} - ${journalLines.credit}),0)::float8`,
    })
    .from(journalLines)
    .where(
      and(
        eq(journalLines.clientId, clientId),
        sql`(${journalLines.account} IN ('200000','110000'))`,
        eq(journalLines.docNo, reversedDocNo),
        ne(journalLines.bp, "")
      )
    );
  const reversedAmount = r2(Math.abs(settled[0]?.amt ?? 0));
  const newPaid = Math.max(0, r2(Number(target.paid) - reversedAmount));
  const restoredStatus = newPaid <= 0.009 ? "open" : "partial";
  await db
    .update(invoices)
    .set({ paid: String(newPaid), status: restoredStatus })
    .where(eq(invoices.id, target.id));

  const certificate = (
    await db
      .select()
      .from(contractCertificates)
      .where(
        and(
          eq(contractCertificates.clientId, clientId),
          eq(contractCertificates.certNo, target.no)
        )
      )
  )[0];
  if (certificate) {
    await db
      .update(contractCertificates)
      .set({ paid: String(newPaid), status: restoredStatus })
      .where(eq(contractCertificates.id, certificate.id));
  }
}

// ------------------------------------------------------------
// FIXED ASSETS — registry + depreciation run (SL / declining)
// ------------------------------------------------------------

const CLASS_ACCOUNT: Record<string, string> = {
  "GEN-BLDG": "131000", "GEN-PLANT": "132000", "GEN-VEH": "133000", "GEN-IT": "134000",
  "GEN-FURN": "135000", "GEN-CIP": "136000", "GEN-INTANG": "140000",
  "MIN-EQ": "137000", "MIN-RIGHTS": "140500", "OIL-WELL": "138000", "OIL-EXPLO": "138500",
  "CON-PLANT": "132000", "FIN-LOAN": "111000", "ENE-GEN": "138000",
};

export async function addAsset(clientId: number, input: {
  name: string; classCode: string; cost: number; inService: string; cc?: string; period?: string; user?: string;
}) {
  const { name, classCode, cost } = input;
  const period = input.period ?? thisPeriod();
  if (!name || !classCode) throw new PostingError("Asset name and class are required.");
  if (!Number.isFinite(cost) || cost <= 0) throw new PostingError("Cost must be positive.");
  const cls = (await db.select().from(assetClasses).where(eq(assetClasses.code, classCode)))[0];
  if (!cls) throw new PostingError(`Asset class ${classCode} not found.`);
  const acc = CLASS_ACCOUNT[classCode] ?? "133000";
  const doc = await postChecked(clientId, {
    period, module: "FI-AA", docType: "AA", user: input.user, reference: classCode,
    lines: [
      { account: acc, cc: input.cc, desc: `Asset acquisition – ${name}`, dr: cost },
      { account: "101000", desc: `Bank payment – ${name}`, cr: cost },
    ],
  });
  await db.insert(assets).values({
    clientId, name, classCode, cost: String(cost), accumDep: "0", nbv: String(cost),
    inService: input.inService, cc: input.cc ?? "", active: true, docNo: doc,
  });
  return { doc, message: `Asset "${name}" capitalised at cost → doc ${doc}.` };
}

export type DepResult = { doc: string; perAsset: { name: string; class: string; amount: number }[]; total: number };

export async function runDepreciation(clientId: number, period: string, user?: string): Promise<DepResult> {
  const assetRows = await db.select().from(assets).where(and(eq(assets.clientId, clientId), eq(assets.active, true)));
  const classes = new Map(
    (await db.select().from(assetClasses)).map((c) => [c.code, { rate: Number(c.rate), method: c.method }])
  );
  const perAsset: DepResult["perAsset"] = [];
  for (const a of assetRows) {
    const cls = classes.get(a.classCode);
    const rate = cls?.rate ?? 0;
    if (rate <= 0) continue;
    const cost = Number(a.cost);
    const nbv = Number(a.nbv);
    if (nbv <= 0.005) continue;
    const monthDep = cls?.method === "db" ? r2(nbv * (rate / 100) / 12) : r2(cost * (rate / 100) / 12);
    const dep = Math.min(monthDep, nbv);
    if (dep <= 0.005) continue;
    perAsset.push({ name: a.name, class: a.classCode, amount: dep });
  }
  const total = r2(perAsset.reduce((s, x) => s + x.amount, 0));
  if (total <= 0) throw new PostingError("Nothing to depreciate — no depreciable assets with NBV > 0.");

  const doc = await postChecked(clientId, {
    period, module: "FI-AA", docType: "AF", user,
    reference: `Depreciation ${period}: ${perAsset.map((a) => `${a.name} ${a.amount.toFixed(2)}`).join(" · ")}`,
    lines: [
      { account: "550000", desc: `Depreciation run ${period}`, dr: total },
      { account: "139000", desc: "Accumulated depreciation", cr: total },
    ],
  });
  const byName = new Map(perAsset.map((p) => [p.name, p.amount]));
  for (const a of assetRows) {
    const dep = byName.get(a.name);
    if (dep) {
      const accum = r2(Number(a.accumDep) + dep);
      await db.update(assets).set({ accumDep: String(accum), nbv: String(r2(Number(a.nbv) - dep)) }).where(eq(assets.id, a.id));
    }
  }
  return { doc, perAsset, total };
}

// ------------------------------------------------------------
// PAYROLL — Ghana statutory engine (PAYE bands, SSNIT, NHIL, housing)
// ------------------------------------------------------------

export async function employeeBasic(clientId: number, bpNo: string): Promise<number> {
  const row = (
    await db.select().from(payOverrides).where(and(eq(payOverrides.clientId, clientId), eq(payOverrides.bpNo, bpNo)))
  ).sort((a, b) => b.period.localeCompare(a.period))[0];
  return row ? Number(row.basic) : 8000;
}

export async function ensurePartner(clientId: number, code: string, name: string, type: "Employee" | "Vendor" | "Customer") {
  const existing = await db
    .select({ bpNo: partners.bpNo })
    .from(partners)
    .where(and(eq(partners.bpNo, code), eq(partners.clientId, clientId)));
  if (!existing.length) {
    await db
      .insert(partners)
      .values({ bpNo: code, clientId, name, type })
      .onConflictDoNothing({ target: [partners.bpNo, partners.clientId] });
  }
}

export type PayComputation = {
  gross: number; taxable: number; incomeTax: number; pension: number; otherDeductions: number;
  employerCost: number; net: number; breakdown: { label: string; amount: number }[];
};

/** Jurisdiction-aware payroll computation. Ghana uses the full statutory scheme. */
export async function computePay(input: {
  jurisdiction: string; basic: number; allowance: number;
}): Promise<PayComputation> {
  const basic = r2(input.basic);
  const allowance = r2(input.allowance);
  const gross = r2(basic + allowance);
  const breakdown: { label: string; amount: number }[] = [];
  const isGhana = input.jurisdiction === "GH";

  let incomeTax = 0;
  let pension = 0;
  let otherDeductions = 0;
  let employerCost = 0;
  let taxable = gross;

  if (isGhana) {
    const [ssnitT1, ssnitT2, ssnitER, nhilR, housingR] = await Promise.all([
      rateValue("SSNIT", "Employee Tier 1", 5.5),
      rateValue("SSNIT", "Employee Tier 2 (capped)", 5),
      rateValue("SSNIT", "Employer Tier 2 (capped)", 13),
      rateValue("NHIL", "Employee 2.5%", 2.5),
      rateValue("HOUSING", "Housing on basic", 5),
    ]);
    const cap = await rateValue("SSNIT", "Tier 2 cap (GHS)", 13000);
    const relief = await rateValue("PAYE", "Personal relief (GHS)", 0);

    const t1 = r2(gross * (ssnitT1 / 100));
    const t2 = r2(Math.min(gross, cap) * (ssnitT2 / 100));
    const nhil = r2(gross * (nhilR / 100));
    const housing = r2(basic * (housingR / 100));
    const bands = (await listPayeBands()).sort((x, y) => x.lower - y.lower);
    taxable = Math.max(0, gross - t1 - t2);
    incomeTax = computePaye(taxable, bands, relief);
    pension = r2(t1 + t2);
    otherDeductions = r2(nhil + housing);
    employerCost = r2(Math.min(gross, cap) * (ssnitER / 100));
    breakdown.push(
      { label: "SSNIT Tier 1 (employee)", amount: t1 },
      { label: "SSNIT Tier 2 (employee)", amount: t2 },
      { label: "NHIL 2.5%", amount: nhil },
      { label: "Housing (on basic)", amount: housing },
      { label: "PAYE (progressive bands)", amount: incomeTax },
    );
  } else {
    // Generic scheme: progressive bands for the jurisdiction, else a flat rate.
    const bands = await listPayeBands(`${input.jurisdiction}`);
    if (bands.length) {
      taxable = gross;
      incomeTax = computePaye(taxable, bands.sort((x, y) => x.lower - y.lower), 0);
      breakdown.push({ label: `Income tax (${input.jurisdiction} progressive bands)`, amount: incomeTax });
    } else {
      const flat = await rateValue("PAYROLL", `Flat income tax (${input.jurisdiction})`, 0);
      taxable = gross;
      incomeTax = r2(gross * (flat / 100));
      breakdown.push({ label: `Income tax @ ${flat}% (${input.jurisdiction} flat)`, amount: incomeTax });
    }
    const pensionEmp = await rateValue("PAYROLL", `Pension employee (${input.jurisdiction})`, 0);
    const pensionEr = await rateValue("PAYROLL", `Pension employer (${input.jurisdiction})`, 0);
    pension = r2(gross * (pensionEmp / 100));
    const otherRate = await rateValue("PAYROLL", `Other statutory deductions (${input.jurisdiction})`, 0);
    otherDeductions = r2(gross * (otherRate / 100));
    employerCost = r2(gross * (pensionEr / 100));
    if (pension > 0) breakdown.push({ label: "Pension / social security (employee)", amount: pension });
    if (otherDeductions > 0) breakdown.push({ label: "Other statutory deductions", amount: otherDeductions });
  }

  const net = r2(gross - incomeTax - pension - otherDeductions);
  return { gross, taxable, incomeTax, pension, otherDeductions, employerCost, net, breakdown };
}

/** Run payroll for one employee (from the employee master). */
export async function runPayroll(clientId: number, input: {
  employeeId?: number; code?: string; period: string;
  basic?: number; allowance?: number; cc?: string; user?: string;
}) {
  const period = input.period;
  let emp: Employee | undefined;
  if (input.employeeId) {
    const r = (await db.select().from(employees).where(and(eq(employees.id, input.employeeId), eq(employees.clientId, clientId))))[0];
    if (!r) throw new PostingError("Employee not found in this workspace.");
    emp = { ...r, basicSalary: Number(r.basicSalary), allowances: Number(r.allowances) };
  } else if (input.code) {
    const r = (await db.select().from(employees).where(and(eq(employees.code, input.code), eq(employees.clientId, clientId))))[0];
    if (!r) throw new PostingError(`Employee ${input.code} is not in the employee master. Add them first.`);
    emp = { ...r, basicSalary: Number(r.basicSalary), allowances: Number(r.allowances) };
  } else {
    throw new PostingError("Select an employee.");
  }
  if (emp.status !== "active") throw new PostingError(`${emp.name} is ${emp.status} — payroll cannot run. Reinstated employees must be set back to active.`);

  const basic = r2(input.basic ?? emp.basicSalary);
  const allowance = r2(input.allowance ?? emp.allowances);
  if (basic <= 0) throw new PostingError("Basic salary must be positive.");
  await ensurePartner(clientId, emp.code, emp.name, "Employee");

  const c = await computePay({ jurisdiction: emp.jurisdiction, basic, allowance });
  if (c.net < 0) throw new PostingError(`Deductions exceed gross for ${emp.name}.`);
  if (c.gross <= 0) throw new PostingError("Gross pay is zero.");

  const doc = await postChecked(clientId, {
    period, module: "HR", docType: "PY", user: input.user,
    reference: `Payroll ${period} – ${emp.code} ${emp.name} (${emp.jurisdiction})`,
    lines: [
      { account: "510000", bp: emp.code, cc: input.cc || emp.department, desc: `Salaries & wages – ${emp.name}`, dr: c.gross },
      ...(c.employerCost > 0 ? [{ account: "511000", bp: emp.code, desc: "Employer statutory contribution", dr: c.employerCost }] : []),
      { account: "205000", bp: emp.code, desc: `Net pay – ${emp.name}`, cr: c.net },
      ...(c.pension > 0 ? [{ account: "206000", bp: emp.code, desc: "Pension / social security payable", cr: c.pension }] : []),
      ...(c.incomeTax > 0 ? [{ account: "207000", bp: emp.code, desc: "PAYE / income tax payable", cr: c.incomeTax }] : []),
      ...(c.otherDeductions > 0 ? [{ account: "208000", bp: emp.code, desc: "Other statutory payables", cr: c.otherDeductions }] : []),
      ...(c.employerCost > 0 ? [{ account: "229000", bp: emp.code, desc: "Employer contribution payable", cr: c.employerCost }] : []),
    ],
  });

  await db
    .insert(payOverrides)
    .values({ clientId, bpNo: emp.code, period, basic: String(basic), allowance: String(allowance), note: emp.name })
    .onConflictDoUpdate({
      target: [payOverrides.clientId, payOverrides.bpNo, payOverrides.period],
      set: { basic: String(basic), allowance: String(allowance) },
    });
  await db.insert(payrollRuns).values({
    clientId, period, bpNo: emp.code, basic: String(basic), allowance: String(allowance), gross: String(c.gross),
    paye: String(c.incomeTax), ssnitT1: String(c.pension), ssnitT2: "0", nhil: String(c.otherDeductions),
    housing: "0", otherDed: "0", net: String(c.net), employerCost: String(c.employerCost), docNo: doc,
  });
  return { doc, employee: emp, ...c };
}

/** Batch payroll — every active employee for a period. */
export async function runBatchPayroll(clientId: number, input: { period: string; user?: string }) {
  const staff = await listEmployees(clientId, false);
  if (!staff.length) throw new PostingError("No active employees in this workspace. Add employees to the payroll master first.");
  const results: { code: string; name: string; net: number; doc: string }[] = [];
  const skipped: string[] = [];
  for (const e of staff) {
    try {
      const r = await runPayroll(clientId, { employeeId: e.id, period: input.period, user: input.user });
      results.push({ code: e.code, name: e.name, net: r.net, doc: r.doc });
    } catch (err) {
      skipped.push(`${e.code}: ${err instanceof Error ? err.message : "failed"}`);
    }
  }
  if (!results.length) throw new PostingError(`No payroll posted. ${skipped.join(" · ")}`);
  const totalNet = r2(results.reduce((s, x) => s + x.net, 0));
  return {
    count: results.length,
    totalNet,
    skipped,
    message: `Batch payroll ${input.period}: ${results.length} employee(s) paid, net ${totalNet.toFixed(2)}${skipped.length ? ` · skipped ${skipped.length}` : ""}.`,
  };
}

// Back-compat wrapper for the legacy Ghana direct-entry form.
export async function runPayrollGhana(clientId: number, input: {
  bpNo: string; period: string; basic: number; allowance: number; cc?: string; user?: string;
}) {
  const basic = r2(input.basic ?? 0);
  const allowance = r2(input.allowance ?? 0);
  if (basic <= 0) throw new PostingError("Basic salary must be positive.");
  const gross = r2(basic + allowance);
  await ensurePartner(clientId, input.bpNo, input.bpNo, "Employee");

  const [ssnitT1Rate, ssnitT2Rate, ssnitERate, nhilRate, housingRate] = await Promise.all([
    rateValue("SSNIT", "Employee Tier 1", 5.5),
    rateValue("SSNIT", "Employee Tier 2 (capped)", 5),
    rateValue("SSNIT", "Employer Tier 2 (capped)", 13),
    rateValue("NHIL", "Employee 2.5%", 2.5),
    rateValue("HOUSING", "Housing on basic", 5),
  ]);
  const ssnitCap = await rateValue("SSNIT", "Tier 2 cap (GHS)", 13000);
  const payeRelief = await rateValue("PAYE", "Personal relief (GHS)", 0);
  const { bpNo, period, cc } = input;

  const ssnitT1 = r2(gross * (ssnitT1Rate / 100));
  const ssnitT2 = r2(Math.min(gross, ssnitCap) * (ssnitT2Rate / 100));
  const nhil = r2(gross * (nhilRate / 100));
  const housing = r2(basic * (housingRate / 100));

  const bands = (await listPayeBands("PAYE")).sort((x, y) => x.lower - y.lower);
  const payeBase = Math.max(0, gross - ssnitT1 - ssnitT2);
  const payeAmt = computePaye(payeBase, bands, payeRelief);

  const employeeTotal = r2(ssnitT1 + ssnitT2 + nhil + housing + payeAmt);
  const net = r2(gross - employeeTotal);
  if (net < 0) throw new PostingError(`Deductions (₵${employeeTotal.toFixed(2)}) exceed gross (₵${gross.toFixed(2)}).`);
  const employer = r2(Math.min(gross, ssnitCap) * (ssnitERate / 100));

  const doc = await postChecked(clientId, {
    period, module: "HR", docType: "PY", user: input.user, reference: `Payroll ${period} – ${bpNo}`,
    lines: [
      { account: "510000", bp: bpNo, cc, desc: `Salaries & wages – ${bpNo}`, dr: gross },
      { account: "511000", desc: "SSNIT employer contribution", dr: employer },
      { account: "205000", bp: bpNo, desc: `Net pay – ${bpNo}`, cr: net },
      { account: "206000", bp: bpNo, desc: "SSNIT payable (employee T1+T2)", cr: r2(ssnitT1 + ssnitT2) },
      { account: "207000", bp: bpNo, desc: "PAYE payable", cr: payeAmt },
      { account: "208000", bp: bpNo, desc: "NHIL payable", cr: nhil },
      { account: "229000", bp: bpNo, desc: "Housing payable", cr: housing },
      { account: "229000", desc: "SSNIT employer payable", cr: employer },
    ],
  });

  await db
    .insert(payOverrides)
    .values({ clientId, bpNo, period, basic: String(basic), allowance: String(allowance), note: "Latest salary" })
    .onConflictDoUpdate({
      target: [payOverrides.clientId, payOverrides.bpNo, payOverrides.period],
      set: { basic: String(basic), allowance: String(allowance) },
    });
  await db.insert(payrollRuns).values({
    clientId, period, bpNo, basic: String(basic), allowance: String(allowance), gross: String(gross),
    paye: String(payeAmt), ssnitT1: String(ssnitT1), ssnitT2: String(ssnitT2), nhil: String(nhil),
    housing: String(housing), otherDed: "0", net: String(net), employerCost: String(employer), docNo: doc,
  });
  return { doc, gross, paye: payeAmt, ssnit: r2(ssnitT1 + ssnitT2), nhil, housing, net, employer };
}

// ------------------------------------------------------------
// PAYMENT DESK — partial/full payments with WHT + FX gain/loss
// ------------------------------------------------------------

export async function payInvoice(clientId: number, input: {
  invoiceId: number; amount: number; rateNow: number; whtName?: string; period: string; user?: string;
}) {
  const inv = (await db.select().from(invoices).where(eq(invoices.id, input.invoiceId)))[0];
  if (!inv || inv.clientId !== clientId) throw new PostingError("Invoice not found in this workspace.");
  if (inv.docType !== "invoice") throw new PostingError(`Only invoices can be paid (this is a ${inv.docType}).`);
  if (inv.status === "paid" || inv.status === "cancelled") throw new PostingError("Invoice is already settled.");
  const total = Number(inv.total);
  const paid = Number(inv.paid);
  const balance = r2(total - paid);
  if (!Number.isFinite(input.amount) || input.amount <= 0) throw new PostingError("Payment amount must be positive.");
  if (input.amount > balance + 0.009) throw new PostingError(`Payment exceeds outstanding balance (₵${balance.toFixed(2)}).`);

  const amount = r2(input.amount);
  const isSales = inv.direction === "sales";
  const lines: JLine[] = [];
  let wht = 0;

  if (isSales) {
    lines.push({ account: "101000", desc: `Receipt ${inv.no} – ${inv.bp}`, dr: amount });
    lines.push({ account: "110000", bp: inv.bp, desc: `Settle ${inv.no}`, cr: amount });
    if (inv.currency !== "GHS") {
      const rateAt = Number(inv.rate) || 1;
      const fxBalance = amount / rateAt;
      const delta = r2(fxBalance * (input.rateNow - rateAt));
      if (Math.abs(delta) >= 0.005) {
        if (delta > 0) {
          lines.push({ account: "110000", bp: inv.bp, desc: `FX revalue on receipt ${inv.no}`, dr: delta }, { account: "491000", bp: inv.bp, desc: `FX gain ${inv.no}`, cr: delta });
        } else {
          lines.push({ account: "110000", bp: inv.bp, desc: `FX revalue on receipt ${inv.no}`, cr: -delta }, { account: "580000", bp: inv.bp, desc: `FX loss ${inv.no}`, dr: -delta });
        }
      }
    }
  } else {
    if (input.whtName) {
      const rate = await rateValue("WHT_RES", input.whtName, 0);
      const base = withholdingBase(amount, Number(inv.subtotal), total);
      wht = r2(base * (rate / 100));
    }
    const netBank = r2(amount - wht);
    lines.push({ account: "200000", bp: inv.bp, desc: `Pay ${inv.no}`, dr: amount });
    lines.push({ account: "101000", desc: `Bank payment ${inv.no}`, cr: netBank });
    if (wht > 0) lines.push({ account: "209000", bp: inv.bp, desc: `WHT – ${input.whtName}`, cr: wht });
    if (inv.currency !== "GHS") {
      const rateAt = Number(inv.rate) || 1;
      const fxBalance = amount / rateAt;
      const delta = r2(fxBalance * (input.rateNow - rateAt));
      if (Math.abs(delta) >= 0.005) {
        if (delta > 0) {
          lines.push({ account: "580000", bp: inv.bp, desc: `FX loss ${inv.no} (cedis weaker)`, dr: delta }, { account: "200000", bp: inv.bp, desc: `FX revalue ${inv.no}`, cr: delta });
        } else {
          lines.push({ account: "491000", bp: inv.bp, desc: `FX gain ${inv.no} (cedis stronger)`, cr: -delta }, { account: "200000", bp: inv.bp, desc: `FX revalue ${inv.no}`, dr: -delta });
        }
      }
    }
  }

  const doc = await postChecked(clientId, {
    period: input.period,
    module: isSales ? "SD" : "MM",
    docType: isSales ? "DZ" : "PMT",
    user: input.user,
    reference: `${inv.no} (${amount >= balance - 0.009 ? "full" : "partial"} payment${inv.currency !== "GHS" ? ` @ ${input.rateNow} ${inv.currency}` : ""})`,
    lines,
  });
  const newPaid = r2(paid + amount);
  const newStatus = settlementStatus(total, newPaid);
  await db
    .update(invoices)
    .set({
      paid: String(newPaid),
      // Compare cumulative settlement with the INVOICE TOTAL, not with the
      // balance that existed before this payment. The old test could mark a
      // second partial payment as fully paid while a balance remained.
      status: newStatus,
      rate: inv.currency !== "GHS" ? String(input.rateNow) : inv.rate,
    })
    .where(eq(invoices.id, inv.id));

  // IPCs use the invoice subledger for controlled collection. Keep the
  // certificate schedule synchronised with the same partial/full status.
  const certificate = (
    await db
      .select()
      .from(contractCertificates)
      .where(
        and(
          eq(contractCertificates.clientId, clientId),
          eq(contractCertificates.certNo, inv.no)
        )
      )
  )[0];
  if (certificate) {
    await db
      .update(contractCertificates)
      .set({ paid: String(newPaid), status: newStatus })
      .where(eq(contractCertificates.id, certificate.id));
  }

  return { doc, wht, message: `${isSales ? "Received" : "Paid"} ₵${amount.toFixed(2)} on ${inv.no} → doc ${doc}${wht > 0 ? ` (WHT ₵${wht.toFixed(2)})` : ""}.` };
}

// ------------------------------------------------------------
// INVENTORY — stock movements + valuation support
// ------------------------------------------------------------

export async function stockMovement(clientId: number, input: {
  material: string; qtyIn: number; qtyOut: number; amountIn: number; amountOut: number; period: string; ref?: string; user?: string;
}) {
  const { material, period } = input;
  const qtyIn = r2(input.qtyIn ?? 0);
  const qtyOut = r2(input.qtyOut ?? 0);
  if (qtyIn <= 0 && qtyOut <= 0) throw new PostingError("Record a quantity in or out.");
  const mat = (await db.select().from(materials).where(eq(materials.materialNo, material)))[0];
  if (!mat) throw new PostingError(`Material ${material} not found.`);
  const amountIn = qtyIn > 0 ? r2(input.amountIn || qtyIn * Number(mat.stdPrice)) : 0;
  const amountOut = qtyOut > 0 ? r2(input.amountOut || qtyOut * Number(mat.stdPrice)) : 0;
  const acc = mat.type === "Raw Material" ? "120000" : mat.type === "Finished Good" ? "121000" : "124000";
  const ref = input.ref ?? "Manual stock adjustment";

  if (qtyIn > 0) {
    await postChecked(clientId, {
      period, module: "INV", docType: "STK", user: input.user, reference: ref,
      lines: [
        { account: acc, material, desc: `Stock in – ${material}`, dr: amountIn },
        { account: "200000", desc: `Stock receipt payable – ${material}`, cr: amountIn },
      ],
    });
  }
  if (qtyOut > 0) {
    await postChecked(clientId, {
      period, module: "INV", docType: "STK", user: input.user, reference: ref,
      lines: [
        { account: "592000", material, desc: `Stock issue/write-off – ${material}`, dr: amountOut },
        { account: acc, material, desc: `Stock out – ${material}`, cr: amountOut },
      ],
    });
  }
  await db.insert(stockMoves).values({
    clientId, material, moveDate: new Date().toISOString().slice(0, 10), period,
    qtyIn: String(qtyIn), qtyOut: String(qtyOut), amountIn: String(amountIn), amountOut: String(amountOut), ref,
  });
  return { message: `Stock movement recorded for ${material}.` };
}

// ------------------------------------------------------------
// FX REVALUATION (IAS 21) — open multi-currency invoices
// ------------------------------------------------------------

export async function revaluateFx(clientId: number, period: string, user?: string) {
  const rows = await db.select().from(invoices).where(eq(invoices.clientId, clientId));
  const openInv = rows.filter(
    (i) => (i.status === "open" || i.status === "partial") && i.docType === "invoice" && i.currency !== "GHS"
  );
  if (!openInv.length) throw new PostingError("No open multi-currency invoices to revalue.");
  const rates = new Map((await getRates()).map((r) => [r.code, r.rateGhs]));
  const lines: JLine[] = [];
  let changed = 0;
  for (const inv of openInv) {
    const rateAt = Number(inv.rate) || 1;
    const rateNow = rates.get(inv.currency) ?? rateAt;
    const balance = r2(Number(inv.total) - Number(inv.paid));
    if (Math.abs(rateNow - rateAt) < 0.00001 || balance === 0) continue;
    const delta = r2((balance / rateAt) * (rateNow - rateAt));
    if (Math.abs(delta) < 0.005) continue;
    changed++;
    if (inv.direction === "sales") {
      if (delta > 0) lines.push({ account: "110000", bp: inv.bp, desc: `FX revalue ${inv.no} (cedis weaker)`, dr: delta }, { account: "491000", bp: inv.bp, desc: `FX gain ${inv.no}`, cr: delta });
      else lines.push({ account: "110000", bp: inv.bp, desc: `FX revalue ${inv.no} (cedis stronger)`, cr: -delta }, { account: "580000", bp: inv.bp, desc: `FX loss ${inv.no}`, dr: -delta });
    } else {
      if (delta > 0) lines.push({ account: "580000", bp: inv.bp, desc: `FX loss ${inv.no} (cedis weaker)`, dr: delta }, { account: "200000", bp: inv.bp, desc: `FX revalue ${inv.no}`, cr: delta });
      else lines.push({ account: "491000", bp: inv.bp, desc: `FX gain ${inv.no}`, cr: -delta }, { account: "200000", bp: inv.bp, desc: `FX revalue ${inv.no}`, dr: -delta });
    }
    await db.update(invoices).set({ rate: String(rateNow) }).where(eq(invoices.id, inv.id));
  }
  if (!changed) throw new PostingError("No FX movement to record (rates unchanged since last revaluation).");
  const doc = await postChecked(clientId, {
    period, module: "FI", docType: "FX", user,
    reference: `IAS 21 revaluation ${period} — ${changed} invoice(s)`,
    lines,
  });
  return { doc, count: changed, message: `FX revaluation posted for ${changed} invoice(s) → doc ${doc}.` };
}

// ------------------------------------------------------------
// BPZ FEE CHARGING — "charge to client" on any owner posting
// ------------------------------------------------------------

export async function chargeClientFee(clientId: number, input: { serviceLine: string; amount: number; period: string; user?: string }) {
  const { serviceLine, amount, period } = input;
  if (!serviceLine || !Number.isFinite(amount) || amount <= 0)
    throw new PostingError("Select a service line and a positive fee amount.");
  await db.insert(feeInvoices).values({ clientId, serviceLine, period, amount: String(amount), status: "open" });
  return { message: `₵${amount.toFixed(2)} charged to client for ${serviceLine} (${period}). Collect from Fees & Billing.` };
}

export async function collectFee(clientId: number, feeId: number, period: string, user?: string) {
  const fee = (await db.select().from(feeInvoices).where(eq(feeInvoices.id, feeId)))[0];
  if (!fee || fee.clientId !== clientId) throw new PostingError("Fee invoice not found.");
  if (fee.status === "paid") throw new PostingError("Fee already collected.");
  const doc = await postChecked(clientId, {
    period, module: "FI", docType: "FEE", user, reference: `BPZ fee ${fee.serviceLine} ${fee.period}`,
    lines: [
      { account: "101000", desc: `BPZ fee received – ${fee.serviceLine}`, dr: Number(fee.amount) },
      { account: "410000", desc: `BPZ professional fee – ${fee.serviceLine}`, cr: Number(fee.amount) },
    ],
  });
  await db.update(feeInvoices).set({ status: "paid", docNo: doc }).where(eq(feeInvoices.id, feeId));
  return { doc, message: `Fee collected → doc ${doc}.` };
}
