/** Pure accounting rules — no database access, covered by regression tests. */

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/** Invoice settlement status from cumulative paid amount. */
export function settlementStatus(
  total: number,
  paid: number
): "open" | "partial" | "paid" {
  const t = round2(total);
  const p = round2(paid);
  if (p <= 0.009) return "open";
  if (p >= t - 0.009) return "paid";
  return "partial";
}

/** IFRS 15 net contract position and cumulative performance. */
export function contractPosition(input: {
  transactionPrice: number;
  pctComplete: number;
  actualCostToDate: number;
  billedToDate: number;
  advancesReceived: number;
}) {
  const pct = Math.max(0, Math.min(100, input.pctComplete));
  const revenueToDate = round2((input.transactionPrice * pct) / 100);
  const actualCostToDate = round2(input.actualCostToDate);
  const cumulativeProfit = round2(revenueToDate - actualCostToDate);
  const netPosition = round2(
    revenueToDate - input.billedToDate - input.advancesReceived
  );
  return {
    revenueToDate,
    actualCostToDate,
    cumulativeProfit,
    contractAsset: round2(Math.max(0, netPosition)),
    contractLiability: round2(Math.max(0, -netPosition)),
  };
}

/**
 * Allocation when a certificate is raised: use the existing contract asset
 * first; any billing above it becomes a contract liability (overbilling).
 */
export function certificateAllocation(gross: number, availableAsset: number) {
  const g = round2(Math.max(0, gross));
  const assetBilled = round2(Math.min(g, Math.max(0, availableAsset)));
  return {
    assetBilled,
    overBilling: round2(g - assetBilled),
  };
}

/** Full expected loss on an onerous contract — recognised immediately. */
export function onerousLoss(transactionPrice: number, estimatedCost: number) {
  return round2(Math.max(0, estimatedCost - transactionPrice));
}

/**
 * WHT base for a full or partial payment. Recoverable VAT is excluded, so a
 * partial settlement takes the same net/gross proportion as the invoice.
 */
export function withholdingBase(
  paymentAmount: number,
  invoiceSubtotal: number,
  invoiceTotal: number
) {
  if (invoiceTotal <= 0) return round2(paymentAmount);
  return round2(paymentAmount * (invoiceSubtotal / invoiceTotal));
}
