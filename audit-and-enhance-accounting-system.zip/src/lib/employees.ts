import { db } from "@/db";
import { employees, jurisdictions } from "@/db/employees-schema";
import { and, asc, eq } from "drizzle-orm";
import { PostingError } from "./posting";
import { jurisdictionByCode, JURISDICTIONS } from "@/data/jurisdictions";

const r2 = (n: number) => Math.round(n * 100) / 100;

export type Employee = {
  id: number; clientId: number; code: string; name: string; position: string; department: string;
  email: string; phone: string; tin: string; ssnitNo: string; bankAccount: string;
  employmentType: string; jurisdiction: string; currency: string;
  basicSalary: number; allowances: number; hireDate: string; endDate: string; status: string;
};

function toEmployee(r: typeof employees.$inferSelect): Employee {
  return {
    id: r.id, clientId: r.clientId, code: r.code, name: r.name, position: r.position,
    department: r.department, email: r.email, phone: r.phone, tin: r.tin, ssnitNo: r.ssnitNo,
    bankAccount: r.bankAccount, employmentType: r.employmentType, jurisdiction: r.jurisdiction,
    currency: r.currency, basicSalary: Number(r.basicSalary), allowances: Number(r.allowances),
    hireDate: r.hireDate, endDate: r.endDate, status: r.status,
  };
}

export async function listEmployees(clientId: number, includeInactive = true): Promise<Employee[]> {
  const rows = includeInactive
    ? await db.select().from(employees).where(eq(employees.clientId, clientId)).orderBy(asc(employees.code))
    : await db.select().from(employees).where(and(eq(employees.clientId, clientId), eq(employees.status, "active"))).orderBy(asc(employees.code));
  return rows.map(toEmployee);
}

export async function addEmployee(clientId: number, input: Record<string, unknown>): Promise<Employee> {
  const s = (k: string, d = "") => (typeof input[k] === "string" ? (input[k] as string).trim() : d);
  const n = (k: string) => (Number.isFinite(Number(input[k])) ? Number(input[k]) : 0);

  const name = s("name");
  if (!name) throw new PostingError("Employee name is required.");
  const basic = n("basicSalary");
  if (basic <= 0) throw new PostingError("Basic salary must be greater than zero.");
  const jur = jurisdictionByCode(s("jurisdiction", "GH"));

  const existing = await db.select({ code: employees.code }).from(employees).where(eq(employees.clientId, clientId));
  const nextNum = existing.reduce((m, e) => {
    const v = Number(e.code.replace(/\D/g, ""));
    return Number.isFinite(v) ? Math.max(m, v) : m;
  }, 0) + 1;
  const code = s("code") || `EMP-${String(nextNum).padStart(3, "0")}`;

  const dup = existing.find((e) => e.code === code);
  if (dup) throw new PostingError(`Employee code ${code} already exists in this workspace.`);

  const created = await db
    .insert(employees)
    .values({
      clientId, code, name,
      position: s("position"), department: s("department"), email: s("email"), phone: s("phone"),
      tin: s("tin"), ssnitNo: s("ssnitNo"), bankAccount: s("bankAccount"),
      employmentType: s("employmentType", "permanent"),
      jurisdiction: jur.code,
      currency: s("currency") || jur.currency,
      basicSalary: basic.toFixed(2), allowances: n("allowances").toFixed(2),
      hireDate: s("hireDate") || new Date().toISOString().slice(0, 10),
      status: "active",
    })
    .returning();
  return toEmployee(created[0]);
}

export async function updateEmployee(clientId: number, id: number, input: Record<string, unknown>): Promise<Employee> {
  const row = (await db.select().from(employees).where(and(eq(employees.id, id), eq(employees.clientId, clientId))))[0];
  if (!row) throw new PostingError("Employee not found in this workspace.");
  const s = (k: string, prev: string) => (typeof input[k] === "string" ? (input[k] as string).trim() : prev);
  const n = (k: string, prev: number) => (input[k] === undefined || input[k] === "" ? prev : Number(input[k]));

  const basic = n("basicSalary", Number(row.basicSalary));
  if (basic <= 0) throw new PostingError("Basic salary must be greater than zero.");

  const updated = await db
    .update(employees)
    .set({
      name: s("name", row.name), position: s("position", row.position), department: s("department", row.department),
      email: s("email", row.email), phone: s("phone", row.phone), tin: s("tin", row.tin),
      ssnitNo: s("ssnitNo", row.ssnitNo), bankAccount: s("bankAccount", row.bankAccount),
      employmentType: s("employmentType", row.employmentType),
      currency: s("currency", row.currency),
      basicSalary: basic.toFixed(2),
      allowances: n("allowances", Number(row.allowances)).toFixed(2),
      status: s("status", row.status),
      endDate: s("endDate", row.endDate),
    })
    .where(eq(employees.id, id))
    .returning();
  return toEmployee(updated[0]);
}

/** Terminate: keeps history, blocks future payroll runs. */
export async function terminateEmployee(clientId: number, id: number, endDate: string): Promise<Employee> {
  const row = (await db.select().from(employees).where(and(eq(employees.id, id), eq(employees.clientId, clientId))))[0];
  if (!row) throw new PostingError("Employee not found in this workspace.");
  const updated = await db
    .update(employees)
    .set({ status: "left", endDate: endDate || new Date().toISOString().slice(0, 10) })
    .where(eq(employees.id, id))
    .returning();
  return toEmployee(updated[0]);
}

// ------------------------------------------------------------
// Jurisdiction seeding
// ------------------------------------------------------------

export async function ensureJurisdictions() {
  for (const j of JURISDICTIONS) {
    await db
      .insert(jurisdictions)
      .values({
        code: j.code, name: j.name, currency: j.currency, vatName: j.vatName,
        vatRate: String(j.vatRate), citRate: String(j.citRate),
        payrollScheme: j.payrollScheme, notes: j.notes,
      })
      .onConflictDoNothing({ target: jurisdictions.code });
  }
}

export async function listJurisdictions() {
  const rows = await db.select().from(jurisdictions).orderBy(asc(jurisdictions.code));
  return rows.map((r) => ({
    code: r.code, name: r.name, currency: r.currency, vatName: r.vatName,
    vatRate: Number(r.vatRate), citRate: Number(r.citRate), payrollScheme: r.payrollScheme, notes: r.notes,
  }));
}

export { r2 };
