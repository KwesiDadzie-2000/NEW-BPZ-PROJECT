import { db } from "@/db";
import { impairmentTests, heldForSale, accounts, journalLines } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { postChecked, type JLine } from "./engine";
import { assertPeriodOpen } from "./periods";
import {
  valueInUse,
  recoverableAmount,
  impairmentLoss,
  impairmentReversal,
  allocateCguImpairment,
  assessHeldForSale,
  disposalGainLoss,
} from "./standards";

const r2 = (n: number) => Math.round(n * 100) / 100;

/* =====================================================================
   IAS 36 — IMPAIRMENT
   ===================================================================== */

export async function runImpairmentTest(
  clientId: number,
  input: {
    period: string;
    unitName: string;
    unitType?: "cgu" | "asset";
    carryingAmount: number;
    fairValueLessCosts: number;
    cashFlows: number[];
    terminalValue?: number;
    discountRate: number;
    notes?: string;
    user?: string;
    post?: boolean;
  }
) {
  await assertPeriodOpen(clientId, input.period);
  if (!input.unitName.trim()) throw new Error("Name the asset or cash-generating unit.");
  if (input.carryingAmount <= 0) throw new Error("Carrying amount must be positive.");
  if (input.discountRate <= 0) throw new Error("A pre-tax discount rate is required for value in use.");
  if (!input.cashFlows.length) throw new Error("Provide at least one period of forecast cash flows for value in use.");
  if (input.fairValueLessCosts <= 0 && input.cashFlows.every((c) => c <= 0))
    throw new Error("Provide either fair value less costs of disposal or forecast cash flows.");

  // Both measures are always computed so the higher one is selected objectively.
  const viu = valueInUse({
    cashFlows: input.cashFlows.map((c) => Math.max(0, c)),
    discountRate: input.discountRate,
    terminalValue: input.terminalValue ?? 0,
  });
  const recovery = recoverableAmount(input.fairValueLessCosts, viu.valueInUse);
  const carrying = r2(input.carryingAmount);
  const loss = impairmentLoss(carrying, recovery.recoverableAmount);

  // Prior charges set the reversal ceiling (IAS 36.117) — goodwill cannot reverse.
  const priorCharges = r2(
    (
      await db
        .select({
          total: sql<number>`coalesce(sum(${impairmentTests.impairmentLoss}),0)::float8`,
        })
        .from(impairmentTests)
        .where(and(eq(impairmentTests.clientId, clientId), eq(impairmentTests.unitName, input.unitName.trim())))
    )[0]?.total ?? 0
  );
  const reversal = loss === 0 ? impairmentReversal({
    currentCarryingAmount: carrying,
    priorImpairmentCharges: priorCharges,
    recoverable: recovery.recoverableAmount,
  }).reversal : 0;

  let doc = "";
  if (input.post !== false && (loss > 0 || reversal > 0)) {
    const lines: JLine[] = loss > 0
      ? [
          { account: "509800", cc: "CC-ADM", desc: `Impairment loss – ${input.unitName}`, dr: loss },
          { account: "139000", desc: `Accumulated impairment – ${input.unitName}`, cr: loss },
        ]
      : [
          { account: "139000", desc: `Reverse impairment – ${input.unitName}`, dr: reversal },
          { account: "494000", cc: "CC-ADM", desc: `Impairment reversal – ${input.unitName}`, cr: reversal },
        ];
    doc = await postChecked(clientId, {
      period: input.period,
      module: "FA",
      docType: "IMP",
      user: input.user,
      reference: `IAS 36 impairment test – ${input.unitName} (${input.period})`,
      lines,
    });
  }

  await db.insert(impairmentTests).values({
    clientId,
    period: input.period,
    unitName: input.unitName.trim(),
    unitType: input.unitType ?? "cgu",
    carryingAmount: String(carrying),
    fairValueLessCosts: String(r2(input.fairValueLessCosts)),
    cashFlows: String(r2(input.cashFlows.reduce((s, c) => s + c, 0))),
    terminalValue: String(r2(input.terminalValue ?? 0)),
    discountRate: String(input.discountRate),
    horizonYears: input.cashFlows.length,
    valueInUse: String(viu.valueInUse),
    recoverableAmount: String(recovery.recoverableAmount),
    impairmentLoss: String(loss),
    reversalAvailable: String(reversal),
    docNo: doc,
    notes: input.notes ?? "",
    createdBy: input.user ?? "",
  });

  return {
    doc,
    unitName: input.unitName,
    carryingAmount: carrying,
    valueInUse: viu.valueInUse,
    valueInUseRows: viu.rows,
    fairValueLessCosts: r2(input.fairValueLessCosts),
    recoverableAmount: recovery.recoverableAmount,
    basis: recovery.basis,
    impairmentLoss: loss,
    reversal,
    priorCharges,
    message:
      loss > 0
        ? `${input.unitName}: carrying ₵${carrying.toFixed(2)} exceeds recoverable ₵${recovery.recoverableAmount.toFixed(2)} (${recovery.basis}) — impairment of ₵${loss.toFixed(2)}${doc ? ` → doc ${doc}` : ""}.`
        : reversal > 0
          ? `${input.unitName}: no further impairment; prior charge reversed by ₵${reversal.toFixed(2)} → doc ${doc}.`
          : `${input.unitName}: carrying amount is recoverable — no impairment required.`,
  };
}

/** Allocate a CGU loss across its assets with IAS 36.104 floors. */
export async function allocateCguLoss(
  clientId: number,
  input: {
    period: string;
    unitName: string;
    assets: { name: string; carryingAmount: number; floor: number }[];
    totalLoss: number;
    user?: string;
    post?: boolean;
  }
) {
  await assertPeriodOpen(clientId, input.period);
  if (!input.assets.length) throw new Error("List the assets inside the cash-generating unit.");
  if (input.totalLoss <= 0) throw new Error("The CGU impairment loss must be positive.");

  const allocation = allocateCguImpairment(
    input.assets.map((a) => ({
      name: a.name,
      carryingAmount: a.carryingAmount,
      floor: a.floor ?? 0,
    })),
    input.totalLoss
  );
  const allocatedTotal = r2(allocation.reduce((s, a) => s + a.allocated, 0));

  let doc = "";
  if (input.post !== false && allocatedTotal > 0) {
    const lines: JLine[] = [];
    for (const a of allocation) {
      if (a.allocated <= 0) continue;
      lines.push({ account: "509800", cc: "CC-ADM", desc: `CGU impairment – ${a.name}`, dr: a.allocated });
      lines.push({ account: "139000", desc: `Accumulated impairment – ${a.name}`, cr: a.allocated });
    }
    doc = await postChecked(clientId, {
      period: input.period,
      module: "FA",
      docType: "IMP",
      user: input.user,
      reference: `IAS 36 CGU allocation – ${input.unitName}`,
      lines,
    });
  }

  return {
    doc,
    allocation,
    allocatedTotal,
    unallocated: r2(input.totalLoss - allocatedTotal),
    message: `Impairment of ₵${input.totalLoss.toFixed(2)} allocated across ${allocation.length} asset(s). Unallocated because of recoverable-amount floors: ₵${(input.totalLoss - allocatedTotal).toFixed(2)}.`,
  };
}

export async function listImpairmentTests(clientId: number, period?: string) {
  const where = period
    ? and(eq(impairmentTests.clientId, clientId), eq(impairmentTests.period, period))
    : eq(impairmentTests.clientId, clientId);
  return db.select().from(impairmentTests).where(where).orderBy(desc(impairmentTests.id)).limit(200);
}

/* =====================================================================
   IFRS 5 — HELD FOR SALE & DISCONTINUED OPERATIONS
   ===================================================================== */

export async function classifyHeldForSale(
  clientId: number,
  input: {
    period: string;
    assetCode: string;
    description: string;
    originalCost: number;
    accumulatedDepreciation: number;
    fairValue: number;
    costsToSell: number;
    committedToPlan: boolean;
    activeMarketing: boolean;
    expectedSaleMonths: number;
    discontinuedOperation: boolean;
    expectedSaleDate?: string;
    user?: string;
    post?: boolean;
  }
) {
  await assertPeriodOpen(clientId, input.period);
  const carrying = r2(Math.max(0, input.originalCost - Math.max(0, input.accumulatedDepreciation)));
  if (carrying <= 0) throw new Error("Carrying amount must be positive — check cost and accumulated depreciation.");

  const assessment = assessHeldForSale({
    carryingAmount: carrying,
    fairValue: input.fairValue,
    costsToSell: input.costsToSell,
    committedToPlan: input.committedToPlan,
    activeMarketing: input.activeMarketing,
    expectedSaleMonths: input.expectedSaleMonths,
    discontinuedOperation: input.discontinuedOperation,
  });

  if (!assessment.qualifies)
    throw new Error(
      `IFRS 5.7 criteria not met: ${assessment.reasons.join("; ")}. The asset stays in property, plant and equipment and continues to depreciate.`
    );

  let doc = "";
  if (input.post !== false && assessment.writeDown > 0) {
    doc = await postChecked(clientId, {
      period: input.period,
      module: "FA",
      docType: "HFS",
      user: input.user,
      reference: `${input.assetCode} reclassified held for sale`,
      lines: [
        { account: "295500", desc: `Assets held for sale – ${input.description}`, dr: assessment.measuredAmount },
        { account: "139000", desc: `Accumulated depreciation transferred – ${input.description}`, dr: r2(Math.max(0, input.accumulatedDepreciation)) },
        ...(assessment.writeDown > 0
          ? [{ account: "509900", cc: "CC-ADM", desc: `Write-down to fair value less costs to sell`, dr: assessment.writeDown }]
          : []),
        { account: "130000", desc: `Cost transferred out of PPE – ${input.description}`, cr: r2(Math.max(0, input.originalCost)) },
      ],
    });
  }

  await db.insert(heldForSale).values({
    clientId,
    period: input.period,
    assetCode: input.assetCode,
    description: input.description,
    originalCost: String(r2(input.originalCost)),
    accumulatedDepreciation: String(r2(Math.max(0, input.accumulatedDepreciation))),
    carryingAmount: String(carrying),
    fairValueLessCosts: String(r2(Math.max(0, input.fairValue - Math.max(0, input.costsToSell)))),
    writeDown: String(assessment.writeDown),
    discontinuedOperation: input.discontinuedOperation,
    expectedSaleDate: input.expectedSaleDate ?? "",
    docNo: doc,
    createdBy: input.user ?? "",
  });

  return {
    doc,
    ...assessment,
    carryingAmount: carrying,
    fairValueLessCosts: r2(Math.max(0, input.fairValue - Math.max(0, input.costsToSell))),
    message: assessment.qualifies
      ? `${input.assetCode} reclassified as held for sale at ₵${assessment.measuredAmount.toFixed(2)}${assessment.writeDown > 0 ? ` (write-down ₵${assessment.writeDown.toFixed(2)})` : ""}. Depreciation has ceased.${doc ? ` → doc ${doc}` : ""} ${assessment.presentation}.`
      : assessment.reasons.join("; "),
  };
}

/** Complete the sale of an asset held for sale. */
export async function completeHeldForSaleDisposal(
  clientId: number,
  input: {
    id: number;
    proceeds: number;
    costsToSell: number;
    period: string;
    user?: string;
  }
) {
  await assertPeriodOpen(clientId, input.period);
  const row = (
    await db.select().from(heldForSale).where(and(eq(heldForSale.clientId, clientId), eq(heldForSale.id, input.id)))
  )[0];
  if (!row) throw new Error("Held-for-sale record not found in this workspace.");
  if (row.status !== "held_for_sale") throw new Error("This asset has already been disposed of.");

  const result = disposalGainLoss({
    proceeds: input.proceeds,
    costsToSell: input.costsToSell,
    heldForSaleCarryingAmount: Number(row.carryingAmount),
  });

  const doc = await postChecked(clientId, {
    period: input.period,
    module: "FA",
    docType: "HFS",
    user: input.user,
    reference: `${row.assetCode} disposal completed`,
    lines: [
      { account: "101000", desc: `Proceeds – ${row.description}`, dr: r2(input.proceeds) },
      ...(result.loss > 0
        ? [{ account: "509900", cc: "CC-ADM", desc: `Loss on disposal – ${row.description}`, dr: result.loss }]
        : []),
      ...(result.gain > 0
        ? [{ account: "495000", cc: "CC-ADM", desc: `Gain on disposal – ${row.description}`, cr: result.gain }]
        : []),
      { account: "295500", desc: `De-recognise held for sale – ${row.description}`, cr: Number(row.carryingAmount) },
    ],
  });

  await db
    .update(heldForSale)
    .set({ status: "disposed" })
    .where(and(eq(heldForSale.id, row.id), eq(heldForSale.clientId, clientId)));

  return {
    doc,
    ...result,
    message: `${row.assetCode} sold for ₵${input.proceeds.toFixed(2)} — ${result.gain > 0 ? `gain ₵${result.gain.toFixed(2)}` : `loss ₵${result.loss.toFixed(2)}`} → doc ${doc}.`,
  };
}

export async function listHeldForSale(clientId: number) {
  return db
    .select()
    .from(heldForSale)
    .where(eq(heldForSale.clientId, clientId))
    .orderBy(desc(heldForSale.id))
    .limit(200);
}

/** Balance-sheet disclosure lines for the standards desks. */
export async function standardsBalances(clientId: number) {
  const balanceOf = async (accountNo: string) => {
    const r = (
      await db
        .select({
          bal: sql<number>`coalesce(sum(${journalLines.debit} - ${journalLines.credit}),0)::float8`,
        })
        .from(journalLines)
        .where(and(eq(journalLines.clientId, clientId), eq(journalLines.account, accountNo)))
    )[0]?.bal ?? 0;
    return r2(r);
  };
  return {
    eclAllowance: r2(-(await balanceOf("114000"))),
    eclCharge: await balanceOf("509000"),
    eclReversal: -(await balanceOf("509500")),
    rouAssets: await balanceOf("115000"),
    rouAccumulatedDep: -(await balanceOf("115500")),
    leaseLiability: -(await balanceOf("294000")),
    rouDepreciation: await balanceOf("534000"),
    leaseInterest: await balanceOf("536000"),
    impairmentLoss: await balanceOf("509800"),
    impairmentReversal: -(await balanceOf("494000")),
    heldForSale: await balanceOf("295500"),
    onerousProvision: -(await balanceOf("293000")),
  };
}
