/**
 * Enterprise SSO — OIDC / SAML / SCIM configuration & login bootstrap.
 * Big Four buyers mandate federated identity; password-only is a hard RFP fail.
 */
import { createHash, randomBytes } from "crypto";
import { db } from "@/db";
import { ssoProviders, ssoIdentities, users, sessions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { hashPassword } from "./password";
import { PostingError } from "./posting";
import { ensureSeed } from "./init";

const enc = (s: string) => Buffer.from(s, "utf8").toString("base64url");
const dec = (s: string) => Buffer.from(s, "base64url").toString("utf8");

export type SsoPublic = {
  id: number;
  name: string;
  protocol: string;
  enabled: boolean;
  issuer: string;
  authorizationUrl: string;
  allowedDomains: string;
  defaultRole: string;
  hasClientSecret: boolean;
  hasSamlCert: boolean;
  scimEndpoint: string;
};

export async function listSsoProviders(): Promise<SsoPublic[]> {
  await ensureSeed();
  const rows = await db.select().from(ssoProviders).orderBy(ssoProviders.id);
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    protocol: r.protocol,
    enabled: r.enabled,
    issuer: r.issuer,
    authorizationUrl: r.authorizationUrl,
    allowedDomains: r.allowedDomains,
    defaultRole: r.defaultRole,
    hasClientSecret: !!r.clientSecretEnc,
    hasSamlCert: !!r.samlCert,
    scimEndpoint: r.scimEndpoint,
  }));
}

export async function upsertSsoProvider(input: {
  id?: number;
  name: string;
  protocol: "oidc" | "saml" | "scim";
  enabled?: boolean;
  issuer?: string;
  clientId?: string;
  clientSecret?: string;
  authorizationUrl?: string;
  tokenUrl?: string;
  userInfoUrl?: string;
  jwksUrl?: string;
  samlEntryPoint?: string;
  samlCert?: string;
  scimEndpoint?: string;
  scimToken?: string;
  defaultRole?: string;
  allowedDomains?: string;
}) {
  if (!input.name) throw new PostingError("SSO provider name is required.");
  if (!["oidc", "saml", "scim"].includes(input.protocol))
    throw new PostingError("Protocol must be oidc, saml or scim.");

  const values = {
    name: input.name,
    protocol: input.protocol,
    enabled: input.enabled ?? false,
    issuer: input.issuer ?? "",
    clientId: input.clientId ?? "",
    clientSecretEnc: input.clientSecret ? enc(input.clientSecret) : undefined,
    authorizationUrl: input.authorizationUrl ?? "",
    tokenUrl: input.tokenUrl ?? "",
    userInfoUrl: input.userInfoUrl ?? "",
    jwksUrl: input.jwksUrl ?? "",
    samlEntryPoint: input.samlEntryPoint ?? "",
    samlCert: input.samlCert ?? "",
    scimEndpoint: input.scimEndpoint ?? "",
    scimTokenEnc: input.scimToken ? enc(input.scimToken) : undefined,
    defaultRole: input.defaultRole ?? "viewer",
    allowedDomains: input.allowedDomains ?? "",
    updatedAt: new Date(),
  };

  if (input.id) {
    const patch: Record<string, unknown> = { ...values };
    if (!input.clientSecret) delete patch.clientSecretEnc;
    if (!input.scimToken) delete patch.scimTokenEnc;
    await db.update(ssoProviders).set(patch).where(eq(ssoProviders.id, input.id));
    return { id: input.id };
  }

  const rows = await db
    .insert(ssoProviders)
    .values({
      ...values,
      clientSecretEnc: values.clientSecretEnc ?? "",
      scimTokenEnc: values.scimTokenEnc ?? "",
    })
    .returning({ id: ssoProviders.id });
  return { id: rows[0].id };
}

/** Build the IdP redirect URL (authorization code flow for OIDC; SSO POST for SAML). */
export function buildSsoRedirect(
  provider: {
    protocol: string;
    authorizationUrl: string;
    samlEntryPoint: string;
    clientId: string;
    issuer: string;
  },
  opts: { redirectUri: string; state: string }
): { url: string; method: "GET" | "POST"; relayState?: string } {
  if (provider.protocol === "saml") {
    const entry = provider.samlEntryPoint || provider.authorizationUrl;
    if (!entry) throw new PostingError("SAML entry point is not configured.");
    return { url: entry, method: "GET", relayState: opts.state };
  }
  // OIDC
  const base = provider.authorizationUrl;
  if (!base) throw new PostingError("OIDC authorization URL is not configured.");
  const u = new URL(base);
  u.searchParams.set("response_type", "code");
  u.searchParams.set("client_id", provider.clientId);
  u.searchParams.set("redirect_uri", opts.redirectUri);
  u.searchParams.set("scope", "openid profile email");
  u.searchParams.set("state", opts.state);
  if (provider.issuer) u.searchParams.set("nonce", randomBytes(12).toString("hex"));
  return { url: u.toString(), method: "GET" };
}

/**
 * Federated login bootstrap — used after IdP callback validates the assertion.
 * Creates the local user on first login (JIT provisioning) if domain is allowed.
 */
export async function federatedLogin(input: {
  providerId: number;
  subject: string;
  email: string;
  name?: string;
  ip?: string;
}): Promise<{ sessionId: string; userId: number; created: boolean }> {
  const provider = (await db.select().from(ssoProviders).where(eq(ssoProviders.id, input.providerId)))[0];
  if (!provider || !provider.enabled) throw new PostingError("SSO provider is disabled or missing.");

  if (provider.allowedDomains) {
    const domains = provider.allowedDomains.split(",").map((d) => d.trim().toLowerCase()).filter(Boolean);
    const emailDomain = (input.email.split("@")[1] ?? "").toLowerCase();
    if (domains.length && !domains.includes(emailDomain)) {
      throw new PostingError(`Email domain ${emailDomain} is not allowed for this SSO provider.`);
    }
  }

  // Existing link?
  let link = (
    await db
      .select()
      .from(ssoIdentities)
      .where(and(eq(ssoIdentities.providerId, input.providerId), eq(ssoIdentities.subject, input.subject)))
  )[0];

  let userId = link?.userId;
  let created = false;

  if (!userId) {
    // Match by username = email local-part or full email
    const uname = input.email.toLowerCase();
    let user = (await db.select().from(users).where(eq(users.username, uname)))[0];
    if (!user) {
      const rows = await db
        .insert(users)
        .values({
          username: uname,
          passwordHash: hashPassword(randomBytes(24).toString("hex")), // unusable local password
          name: input.name || input.email,
          role: provider.defaultRole || "viewer",
          active: true,
          acceptedTermsAt: new Date(),
          mustChangePassword: false,
          usesBootstrapPassword: false,
        })
        .returning();
      user = rows[0];
      created = true;
    }
    userId = user.id;
    await db.insert(ssoIdentities).values({
      providerId: input.providerId,
      userId,
      subject: input.subject,
      email: input.email,
      lastLoginAt: new Date(),
    });
  } else {
    await db
      .update(ssoIdentities)
      .set({ lastLoginAt: new Date(), email: input.email })
      .where(eq(ssoIdentities.id, link!.id));
  }

  const sessionId = randomBytes(24).toString("hex");
  const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({
    id: sessionId,
    userId: userId!,
    expiresAt: expires,
    pending: false,
    ip: input.ip ?? "",
  });

  return { sessionId, userId: userId!, created };
}

/** SCIM bearer token check for provisioning endpoint. */
export async function verifyScimToken(providerId: number, bearer: string): Promise<boolean> {
  const provider = (await db.select().from(ssoProviders).where(eq(ssoProviders.id, providerId)))[0];
  if (!provider || !provider.enabled || provider.protocol !== "scim") return false;
  if (!provider.scimTokenEnc) return false;
  try {
    return dec(provider.scimTokenEnc) === bearer;
  } catch {
    return false;
  }
}

export function newSsoState(): string {
  return randomBytes(16).toString("hex");
}
