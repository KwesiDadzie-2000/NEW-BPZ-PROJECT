import { db } from "@/db";
import { journalLines, financialInstruments, eclAssessments, eclProvisionMatrix, accounts } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { postChecked } from "./engine";
import { assertPeriodOpen } from "./periods";
import {
  computeEcl,
  determineStage,
  interestRevenueBase,
  lgdNetOfCollateral,
  provisionMatrixEcl,
  eclMovement,
  type EclStage,
} from "./standards";

const r2 = (n: number) => Math.round(n * 100) / 100;

export type InstrumentRow = typeof financialInstruments.$inferSelect;

export const CATEGORIES: { code: string; label: string; note: string }[] = [
  {
    code: "amortised_cost",
    label: "Amortised cost",
    note: "Business model is hold to collect contractual cash flows, and those cash flows are solely payments of principal and interest (IFRS 9.4.2). Interest revenue on gross carrying amount.",
  },
  {
    code: "fvoci",
    label: "Fair value through other comprehensive income",
    note: "Hold to collect and sell business model (IFRS 9.4.3). Debt instruments only. ECL is recognised in profit or loss; fair value movements go to OCI.",
  },
  {
    code: "fvtpl",
    label: "Fair value through profit or loss",
    note: "Residual category, held for trading, or fair value option (IFRS 9.4.4 / 6.7). ECL is not separately recognised — it is within fair value.",
  },
];

export async function listInstruments(clientId: number, status?: string) {
  const where = status
    ? and(eq(financialInstruments.clientId, clientId), eq(financialInstruments.status, status))
    : eq(financialInstruments.clientId, clientId);
  return db.select().from(financialInstruments).where(where).orderBy(desc(financialInstruments.id));
}

export async function getInstrument(clientId: number, id: number) {
  return (
    await db
      .select()
      .from(financialInstruments)
      .where(and(eq(financialInstruments.clientId, clientId), eq(financialInstruments.id, id)))
  )[0];
}

export async function addInstrument(
  clientId: number,
  input: {
    code: string;
    name: string;
    category: string;
    instrumentType: string;
    counterparty?: string;
    principal: number;
    effectiveRate: number;
    issueDate?: string;
    maturityDate?: string;
    collateralValue?: number;
    creditGrade?: string;
    currency?: string;
    notes?: string;
    user?: string;
  }
) {
  if (!input.code.trim()) throw new Error("Instrument code is required.");
  if (!input.name.trim()) throw new Error("Instrument name is required.");
  if (!CATEGORIES.some((c) => c.code === input.category))
    throw new Error("Unknown IFRS 9 classification category.");
  if (input.principal <= 0) throw new Error("Principal or fair value must be positive.");
  if (input.effectiveRate < 0) throw new Error("The effective interest rate cannot be negative.");

  // FVTPL carries impairment inside fair value — a separate ECL model is not applied.
  if (input.category === "fvtpl" && (input.collateralValue ?? 0) > 0)
    throw new Error("Collateral detail is not relevant to FVTPL assets; fair value already reflects credit risk.");

  const row = await db
    .insert(financialInstruments)
    .values({
      clientId,
      code: input.code.trim(),
      name: input.name.trim(),
      category: input.category,
      instrumentType: input.instrumentType,
      counterparty: input.counterparty ?? "",
      principal: String(input.principal),
      effectiveRate: String(input.effectiveRate),
      issueDate: input.issueDate ?? "",
      maturityDate: input.maturityDate ?? "",
      carryingAmount: String(input.principal),
      eclAllowance: "0",
      stage: 1,
      collateralValue: String(input.collateralValue ?? 0),
      creditGrade: input.creditGrade ?? "",
      currency: input.currency ?? "GHS",
      notes: input.notes ?? "",
    })
    .returning({ id: financialInstruments.id, code: financialInstruments.code });

  return { id: row[0].id, code: row[0].code, message: `Financial instrument ${row[0].code} added at amortised cost ₵${input.principal.toFixed(2)}.` };
}

export async function ensureProvisionMatrix(clientId: number) {
  const existing = await db
    .select()
    .from(eclProvisionMatrix)
    .where(eq(eclProvisionMatrix.clientId, clientId));
  if (existing.length) return existing;
  const seed = [
    { bucket: "current", label: "Not yet due", pd: 0.5 },
    { bucket: "1_30", label: "1 – 30 days past due", pd: 2 },
    { bucket: "31_60", label: "31 – 60 days past due", pd: 10 },
    { bucket: "61_90", label: "61 – 90 days past due", pd: 25 },
    { bucket: "90_plus", label: "More than 90 days past due", pd: 75 },
  ];
  const rows = await db
    .insert(eclProvisionMatrix)
    .values(seed.map((s) => ({ clientId, bucket: s.bucket, label: s.label, pd: String(s.pd) })))
    .returning();
  return rows;
}

export async function updateProvisionMatrix(
  clientId: number,
  rows: { bucket: string; pd: number }[]
) {
  for (const row of rows) {
    if (row.pd < 0 || row.pd > 100) throw new Error("Provision-matrix PD must be between 0% and 100%.");
    await db
      .update(eclProvisionMatrix)
      .set({ pd: String(row.pd) })
      .where(and(eq(eclProvisionMatrix.clientId, clientId), eq(eclProvisionMatrix.bucket, row.bucket)));
  }
  return { message: "Provision matrix updated for all future ECL runs." };
}

/** ECL on trade receivables using the simplified lifetime approach + aging. */
export async function assessTradeReceivableEcl(
  clientId: number,
  params: { period: string; user?: string; post?: boolean }
) {
  await assertPeriodOpen(clientId, params.period);
  const matrix = await ensureProvisionMatrix(clientId);
  const pdByBucket = new Map(matrix.map((m) => [m.bucket, Number(m.pd)]));

  // The aging report supplies exposure per bucket; the matrix supplies PD.
  const { aging } = await import("./reports");
  const agingRows = await aging(clientId, "AR");
  const bucketKeys = ["current", "1_30", "31_60", "61_90", "90_plus"];
  const bucketTotals = new Map<string, number>(bucketKeys.map((k) => [k, 0]));
  for (const partner of agingRows) {
    partner.buckets.forEach((amount: number, index: number) => {
      const key = bucketKeys[index] ?? "90_plus";
      bucketTotals.set(key, r2((bucketTotals.get(key) ?? 0) + Math.max(0, amount)));
    });
  }

  const exposureRows = Array.from(bucketTotals.entries()).map(([bucket, amount]) => ({
    bucket,
    amount,
    pd: pdByBucket.get(bucket) ?? 0,
  }));
  const matrixResult = provisionMatrixEcl(exposureRows);
  const totalExposure = r2(exposureRows.reduce((s, x) => s + x.amount, 0));

  const allowanceAccount = "114000";
  const priorBalance = r2(
    (
      await db
        .select({
          bal: sql<number>`coalesce(sum(${journalLines.credit} - ${journalLines.debit}),0)::float8`,
        })
        .from(journalLines)
        .where(and(eq(journalLines.clientId, clientId), eq(journalLines.account, allowanceAccount)))
    )[0]?.bal ?? 0
  );

  const required = matrixResult.total;
  const movement = r2(required - priorBalance);

  let doc = "";
  if (params.post !== false && Math.abs(movement) >= 0.005) {
    const lines = [
      movement > 0
        ? { account: "509000", cc: "CC-ADM", desc: `ECL charge on trade receivables – ${params.period}`, dr: movement }
        : { account: "110000", desc: `Release of ECL on trade receivables – ${params.period}`, dr: Math.abs(movement) },
      movement > 0
        ? { account: allowanceAccount, desc: `Increase expected credit loss allowance – ${params.period}`, cr: movement }
        : { account: "509500", cc: "CC-ADM", desc: `Reversal of expected credit loss – ${params.period}`, cr: Math.abs(movement) },
    ];
    doc = await postChecked(clientId, {
      period: params.period,
      module: "FI",
      docType: "ECL",
      user: params.user,
      reference: `IFRS 9 ECL on trade receivables – ${params.period}`,
      lines,
    });
  }

  await db
    .delete(eclAssessments)
    .where(and(eq(eclAssessments.clientId, clientId), eq(eclAssessments.period, params.period)));
  if (matrixResult.rows.some((r) => r.provision > 0)) {
    await db.insert(eclAssessments).values(
      matrixResult.rows
        .filter((r) => r.provision > 0)
        .map((r) => ({
          clientId,
          period: params.period,
          instrumentId: 0,
          stage: 2 as EclStage,
          exposure: String(r.amount),
          pd: String(r.pd),
          lgd: "100",
          ecl: String(r.provision),
          discountRate: "0",
          horizonMonths: 12,
          movement: String(r.provision),
          docNo: doc,
          notes: `Trade receivable provision matrix – ${r.bucket}`,
          createdBy: params.user ?? "",
        }))
    );
  }

  const movementSchedule = eclMovement(
    priorBalance,
    Math.max(0, movement),
    Math.abs(Math.min(0, movement)),
    0,
    0
  );
  return {
    doc,
    totalExposure,
    requiredAllowance: required,
    priorBalance,
    movement,
    rows: matrixResult.rows,
    movementSchedule,
    message:
      Math.abs(movement) < 0.005
        ? `ECL allowance of ₵${required.toFixed(2)} is already adequate — no journal required.`
        : `ECL allowance moved to ₵${required.toFixed(2)} (${movement > 0 ? "charge" : "release"} of ₵${Math.abs(movement).toFixed(2)})${doc ? ` → doc ${doc}` : ""}.`,
  };
}

/** ECL run for a single financial instrument, with staging and journal posting. */
export async function assessInstrumentEcl(
  clientId: number,
  input: {
    instrumentId: number;
    period: string;
    daysPastDue?: number;
    pdNow?: number;
    forwardLookingAdjustment?: number;
    user?: string;
    post?: boolean;
  }
) {
  await assertPeriodOpen(clientId, input.period);
  const inst = await getInstrument(clientId, input.instrumentId);
  if (!inst) throw new Error("Financial instrument not found in this workspace.");
  if (inst.status !== "active") throw new Error(`Instrument ${inst.code} is ${inst.status}.`);
  if (inst.category === "fvtpl")
    throw new Error("FVTPL assets carry credit risk inside fair value — run ECL only on amortised cost or FVOCI instruments.");

  const pdAtOrigination = Number(inst.effectiveRate) * 12 || 1;
  const stageInfo = determineStage({
    daysPastDue: input.daysPastDue ?? 0,
    pdNow: input.pdNow ?? pdAtOrigination * 2,
    pdAtOrigination,
  });

  const lgd = lgdNetOfCollateral({
    lgdGross: stageInfo.stage === 3 ? 100 : 45,
    exposure: Number(inst.carryingAmount),
    collateralValue: Number(inst.collateralValue),
  });

  const horizon = stageInfo.lifetime ? 12 : 12;
  const result = computeEcl({
    exposure: Number(inst.carryingAmount),
    pd: Math.min(100, (input.pdNow ?? pdAtOrigination * 2) + (input.forwardLookingAdjustment ?? 0)),
    lgd,
    discountRate: Number(inst.effectiveRate),
    horizonMonths: horizon,
  });

  const priorAllowance = Number(inst.eclAllowance);
  const movement = r2(result.ecl - priorAllowance);

  let doc = "";
  if (input.post !== false && Math.abs(movement) >= 0.005) {
    const lines = [
      movement > 0
        ? { account: "509000", cc: "CC-ADM", desc: `ECL charge – ${inst.code} (Stage ${stageInfo.stage})`, dr: movement }
        : { account: inst.instrumentType.includes("receivable") || inst.instrumentType.includes("loan") ? "110000" : "149000", desc: `Release of ECL – ${inst.code}`, dr: Math.abs(movement) },
      movement > 0
        ? { account: allowanceAccountFor(inst.instrumentType), desc: `ECL allowance – ${inst.code}`, cr: movement }
        : { account: "509500", cc: "CC-ADM", desc: `Reversal of ECL – ${inst.code}`, cr: Math.abs(movement) },
    ];
    doc = await postChecked(clientId, {
      period: input.period,
      module: "FI",
      docType: "ECL",
      user: input.user,
      reference: `IFRS 9 ECL ${inst.code} – Stage ${stageInfo.stage}`,
      lines,
    });
  }

  await db
    .update(financialInstruments)
    .set({
      stage: stageInfo.stage,
      eclAllowance: String(result.ecl),
      stage2Since: stageInfo.stage >= 2 && Number(inst.stage) < 2 ? new Date().toISOString().slice(0, 10) : inst.stage2Since,
      lastEclPeriod: input.period,
    })
    .where(and(eq(financialInstruments.id, inst.id), eq(financialInstruments.clientId, clientId)));

  await db.insert(eclAssessments).values({
    clientId,
    period: input.period,
    instrumentId: inst.id,
    stage: stageInfo.stage,
    exposure: String(Number(inst.carryingAmount)),
    pd: String(Math.min(100, (input.pdNow ?? pdAtOrigination * 2) + (input.forwardLookingAdjustment ?? 0))),
    lgd: String(lgd),
    ecl: String(result.ecl),
    discountRate: inst.effectiveRate,
    horizonMonths: horizon,
    movement: String(movement),
    docNo: doc,
    notes: stageInfo.reason,
    createdBy: input.user ?? "",
  });

  const interest = interestRevenueBase({
    stage: stageInfo.stage,
    grossCarryingAmount: Number(inst.carryingAmount),
    eclAllowance: result.ecl,
    effectiveRate: Number(inst.effectiveRate),
  });

  return {
    doc,
    code: inst.code,
    stage: stageInfo.stage,
    reason: stageInfo.reason,
    exposure: Number(inst.carryingAmount),
    lgd,
    ecl: result.ecl,
    priorAllowance,
    movement,
    interestRevenue: interest,
    message: `${inst.code} → Stage ${stageInfo.stage}. ECL ₵${result.ecl.toFixed(2)} (movement ₵${movement.toFixed(2)})${doc ? ` → doc ${doc}` : ""}. ${stageInfo.reason}. Interest revenue now accrues on the ${stageInfo.stage === 3 ? "net" : "gross"} carrying amount.`,
  };
}

function allowanceAccountFor(instrumentType: string) {
  if (instrumentType === "trade_receivable") return "114000";
  if (instrumentType === "loan_receivable") return "114500";
  return "114600";
}

/** Portfolio ECL summary for the IFRS 9.35H movement disclosure. */
export async function eclPortfolio(clientId: number) {
  const instruments = await listInstruments(clientId, "active");
  const totals = {
    grossAmortisedCost: 0,
    grossFvoci: 0,
    grossFvtpl: 0,
    allowance: 0,
    stage1: 0,
    stage2: 0,
    stage3: 0,
    netCarrying: 0,
  };
  for (const i of instruments) {
    const gross = Number(i.carryingAmount);
    const allowance = Number(i.eclAllowance);
    if (i.category === "amortised_cost") totals.grossAmortisedCost = r2(totals.grossAmortisedCost + gross);
    if (i.category === "fvoci") totals.grossFvoci = r2(totals.grossFvoci + gross);
    if (i.category === "fvtpl") totals.grossFvtpl = r2(totals.grossFvtpl + gross);
    totals.allowance = r2(totals.allowance + allowance);
    if (i.stage === 1) totals.stage1 = r2(totals.stage1 + gross);
    if (i.stage === 2) totals.stage2 = r2(totals.stage2 + gross);
    if (i.stage === 3) totals.stage3 = r2(totals.stage3 + gross);
  }
  totals.netCarrying = r2(
    totals.grossAmortisedCost + totals.grossFvoci + totals.grossFvtpl - totals.allowance
  );
  return { instruments, totals };
}

export async function listEclAssessments(clientId: number, period?: string) {
  const where = period
    ? and(eq(eclAssessments.clientId, clientId), eq(eclAssessments.period, period))
    : eq(eclAssessments.clientId, clientId);
  return db.select().from(eclAssessments).where(where).orderBy(desc(eclAssessments.id)).limit(200);
}
