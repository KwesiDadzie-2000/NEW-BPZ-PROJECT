/**
 * Persistence + journal posting for extended standards desks.
 */
import { db } from "@/db";
import {
  provisions,
  employeeBenefitPlans,
  epsComputations,
  deferredTaxItems,
  fairValueMeasurements,
  operatingSegments,
  relatedParties,
  relatedPartyTxns,
  subsequentEvents,
  contingencies,
  riskDisclosures,
  shareCapital,
  hyperinflationFactors,
  disclosureNotes,
} from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";
import { PostingError } from "./posting";
import { postChecked } from "./engine";
import { thisPeriod } from "./periods";
import {
  assessProvision,
  provisionUnwinding,
  provisionMovement,
  definedBenefitObligation,
  netDefinedBenefitLiability,
  computeEps,
  deferredTax,
  restatementFactor,
  monetaryGainLoss,
  classifyFairValueLevel,
  unrealisedGainLoss,
  isReportableSegment,
} from "./standards-extended";

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const str = (v: unknown, d = "") => (v === undefined || v === null ? d : String(v).trim() || d);
const num = (v: unknown, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

/* -------------------- IAS 37 -------------------- */

export async function listProvisions(clientId: number) {
  return db.select().from(provisions).where(eq(provisions.clientId, clientId)).orderBy(desc(provisions.createdAt));
}

export async function recogniseProvision(
  clientId: number,
  input: Record<string, unknown>,
  user = "SYSTEM"
) {
  const code = str(input.code);
  const title = str(input.title);
  if (!code || !title) throw new PostingError("Provision code and title are required.");
  const bestEstimate = num(input.bestEstimate);
  const probability = num(input.probability, 70);
  const discountRate = num(input.discountRate);
  const years = num(input.yearsToSettlement, 1);
  const contingent = Boolean(input.contingent);
  const contingentAsset = Boolean(input.contingentAsset);
  const period = str(input.period, thisPeriod());

  const assessment = assessProvision({
    bestEstimate,
    minEstimate: num(input.minEstimate),
    maxEstimate: num(input.maxEstimate),
    probability,
    discountRate,
    yearsToSettlement: years,
    contingent,
    contingentAsset,
  });

  let docNo = "";
  let status = "contingent";
  let carrying = 0;

  if (assessment.decision === "recognise") {
    status = "recognised";
    carrying = assessment.presentValue;
    const account = str(input.account, "293000");
    const expenseAccount = str(input.expenseAccount, "584000");
    docNo = await postChecked(clientId, {
      period,
      module: "IAS37",
      docType: "PROV",
      user,
      reference: code,
      lines: [
        { account: expenseAccount, desc: `Provision ${code} — ${title}`, dr: carrying },
        { account, desc: `Provision ${code} — ${title}`, cr: carrying },
      ],
    });
  } else if (assessment.decision === "recognise_asset") {
    status = "recognised";
    carrying = assessment.presentValue;
    docNo = await postChecked(clientId, {
      period,
      module: "IAS37",
      docType: "PROV",
      user,
      reference: code,
      lines: [
        { account: str(input.account, "141000"), desc: `Contingent asset ${code}`, dr: carrying },
        { account: str(input.expenseAccount, "490000"), desc: `Contingent asset ${code}`, cr: carrying },
      ],
    });
  } else if (assessment.decision === "contingent_liability" || assessment.decision === "contingent_asset_disclose") {
    status = "contingent";
    carrying = 0;
  } else {
    status = "silent";
    carrying = 0;
  }

  const rows = await db
    .insert(provisions)
    .values({
      clientId,
      code,
      title,
      category: str(input.category, "legal"),
      recognitionDate: str(input.recognitionDate, new Date().toISOString().slice(0, 10)),
      bestEstimate: String(bestEstimate),
      minEstimate: String(num(input.minEstimate)),
      maxEstimate: String(num(input.maxEstimate)),
      probability: String(probability),
      discountRate: String(discountRate),
      yearsToSettlement: String(years),
      presentValue: String(assessment.presentValue),
      carryingAmount: String(carrying),
      added: String(carrying),
      contingent: contingent || assessment.decision.includes("contingent"),
      contingentAsset,
      obligatingEvent: str(input.obligatingEvent),
      expectedOutflow: str(input.expectedOutflow),
      account: str(input.account, "293000"),
      expenseAccount: str(input.expenseAccount, "584000"),
      period,
      docNo,
      status,
      notes: `${assessment.reason}${str(input.notes) ? " — " + str(input.notes) : ""}`,
      createdBy: user,
    })
    .returning();

  return { provision: rows[0], assessment, docNo };
}

export async function utiliseProvision(
  clientId: number,
  id: number,
  amount: number,
  period: string,
  user = "SYSTEM"
) {
  const row = (await db.select().from(provisions).where(and(eq(provisions.id, id), eq(provisions.clientId, clientId))))[0];
  if (!row) throw new PostingError("Provision not found.");
  if (row.status !== "recognised") throw new PostingError("Only recognised provisions can be utilised.");
  const amt = r2(Math.min(Math.max(0, amount), Number(row.carryingAmount)));
  if (amt <= 0) throw new PostingError("Utilisation amount must be positive.");
  const docNo = await postChecked(clientId, {
    period,
    module: "IAS37",
    docType: "PROV",
    user,
    reference: row.code,
    lines: [
      { account: row.account, desc: `Utilise provision ${row.code}`, dr: amt },
      { account: "101000", desc: `Settle provision ${row.code}`, cr: amt },
    ],
  });
  const carrying = r2(Number(row.carryingAmount) - amt);
  await db
    .update(provisions)
    .set({
      utilised: String(r2(Number(row.utilised) + amt)),
      carryingAmount: String(carrying),
      status: carrying <= 0.009 ? "settled" : row.status,
      docNo: row.docNo ? `${row.docNo},${docNo}` : docNo,
    })
    .where(eq(provisions.id, id));
  return { docNo, carrying };
}

export async function unwindProvision(clientId: number, id: number, period: string, user = "SYSTEM") {
  const row = (await db.select().from(provisions).where(and(eq(provisions.id, id), eq(provisions.clientId, clientId))))[0];
  if (!row || row.status !== "recognised") throw new PostingError("Recognised provision required.");
  const interest = provisionUnwinding(Number(row.carryingAmount), Number(row.discountRate));
  if (interest <= 0) return { docNo: "", interest: 0 };
  const docNo = await postChecked(clientId, {
    period,
    module: "IAS37",
    docType: "PROV",
    user,
    reference: row.code,
    lines: [
      { account: "575000", desc: `Unwinding ${row.code}`, dr: interest },
      { account: row.account, desc: `Unwinding ${row.code}`, cr: interest },
    ],
  });
  await db
    .update(provisions)
    .set({
      unwindingInterest: String(r2(Number(row.unwindingInterest) + interest)),
      carryingAmount: String(r2(Number(row.carryingAmount) + interest)),
    })
    .where(eq(provisions.id, id));
  return { docNo, interest };
}

/* -------------------- IAS 19 -------------------- */

export async function listBenefitPlans(clientId: number) {
  return db.select().from(employeeBenefitPlans).where(eq(employeeBenefitPlans.clientId, clientId));
}

export async function upsertBenefitPlan(clientId: number, input: Record<string, unknown>, user = "SYSTEM") {
  const code = str(input.code);
  const name = str(input.name);
  if (!code || !name) throw new PostingError("Plan code and name required.");
  const period = str(input.period, thisPeriod());
  const calc = definedBenefitObligation({
    members: num(input.members),
    averageSalary: num(input.averageSalary),
    averageServiceYears: num(input.averageServiceYears),
    salaryGrowth: num(input.salaryGrowth, 5),
    discountRate: num(input.discountRate, 10),
    yearsToRetirement: num(input.yearsToRetirement, 10),
    benefitFormulaYears: num(input.benefitFormulaYears, 1 / 12),
  });
  const planAssets = num(input.planAssets);
  const net = netDefinedBenefitLiability({ dbo: calc.dbo, planAssets });

  let docNo = "";
  if (num(input.postJournal) === 1 && calc.currentServiceCost > 0) {
    const service = calc.currentServiceCost;
    const interest = calc.interestCost;
    const lines = [
      { account: "540000", desc: `IAS 19 service cost ${code}`, dr: service },
      { account: "299000", desc: `IAS 19 DBO ${code}`, cr: service },
    ];
    if (interest > 0) {
      lines.push({ account: "575000", desc: `IAS 19 net interest ${code}`, dr: interest });
      lines.push({ account: "299000", desc: `IAS 19 DBO interest ${code}`, cr: interest });
    }
    docNo = await postChecked(clientId, {
      period,
      module: "IAS19",
      docType: "BEN",
      user,
      reference: code,
      lines,
    });
  }

  const existing = (
    await db
      .select()
      .from(employeeBenefitPlans)
      .where(and(eq(employeeBenefitPlans.clientId, clientId), eq(employeeBenefitPlans.code, code)))
  )[0];

  const values = {
    name,
    planType: str(input.planType, "defined_benefit"),
    currency: str(input.currency, "GHS"),
    discountRate: String(num(input.discountRate, 10)),
    salaryGrowth: String(num(input.salaryGrowth, 5)),
    inflationRate: String(num(input.inflationRate)),
    members: num(input.members),
    averageServiceYears: String(num(input.averageServiceYears)),
    averageSalary: String(num(input.averageSalary)),
    definedBenefitObligation: String(calc.dbo),
    planAssets: String(planAssets),
    netLiability: String(net.net),
    currentServiceCost: String(calc.currentServiceCost),
    netInterest: String(calc.interestCost),
    actuarialGainLoss: String(num(input.actuarialGainLoss)),
    contributions: String(num(input.contributions)),
    benefitsPaid: String(num(input.benefitsPaid)),
    period,
    docNo: docNo || existing?.docNo || "",
    status: "active",
    notes: str(input.notes),
  };

  if (existing) {
    await db.update(employeeBenefitPlans).set(values).where(eq(employeeBenefitPlans.id, existing.id));
    return { id: existing.id, calc, net, docNo };
  }
  const rows = await db
    .insert(employeeBenefitPlans)
    .values({ clientId, code, ...values })
    .returning();
  return { id: rows[0].id, calc, net, docNo };
}

/* -------------------- IAS 33 -------------------- */

export async function computeAndStoreEps(clientId: number, input: Record<string, unknown>, user = "SYSTEM") {
  const period = str(input.period, thisPeriod());
  const result = computeEps({
    profitAttributable: num(input.profitAttributable),
    preferenceDividends: num(input.preferenceDividends),
    weightedAvgShares: num(input.weightedAvgShares),
    dilutiveShares: num(input.dilutiveShares),
    discontinuedProfit: num(input.discontinuedProfit),
  });
  if (result.basicDenominator <= 0) throw new PostingError("Weighted average shares must be > 0.");

  await db.delete(epsComputations).where(and(eq(epsComputations.clientId, clientId), eq(epsComputations.period, period)));
  const rows = await db
    .insert(epsComputations)
    .values({
      clientId,
      period,
      profitAttributable: String(num(input.profitAttributable)),
      preferenceDividends: String(num(input.preferenceDividends)),
      weightedAvgShares: String(num(input.weightedAvgShares)),
      dilutiveShares: String(num(input.dilutiveShares)),
      basicEps: String(result.basicEps),
      dilutedEps: String(result.dilutedEps),
      discontinuedProfit: String(num(input.discontinuedProfit)),
      continuingBasicEps: String(result.continuingBasicEps),
      notes: str(input.notes),
      createdBy: user,
    })
    .returning();
  return { row: rows[0], result };
}

export async function upsertShareCapital(clientId: number, input: Record<string, unknown>) {
  const rows = await db
    .insert(shareCapital)
    .values({
      clientId,
      className: str(input.className, "Ordinary"),
      parValue: String(num(input.parValue, 1)),
      authorisedShares: String(num(input.authorisedShares)),
      issuedShares: String(num(input.issuedShares)),
      paidUpCapital: String(num(input.paidUpCapital)),
      sharePremium: String(num(input.sharePremium)),
      treasuryShares: String(num(input.treasuryShares)),
      period: str(input.period, thisPeriod()),
    })
    .returning();
  return rows[0];
}

/* -------------------- IAS 12 -------------------- */

export async function addDeferredTaxItem(clientId: number, input: Record<string, unknown>) {
  const period = str(input.period, thisPeriod());
  const calc = deferredTax({
    carryingAmount: num(input.carryingAmount),
    taxBase: num(input.taxBase),
    taxRate: num(input.taxRate, 25),
  });
  const rows = await db
    .insert(deferredTaxItems)
    .values({
      clientId,
      period,
      description: str(input.description, "Temporary difference"),
      origin: str(input.origin, "ppe"),
      carryingAmount: String(num(input.carryingAmount)),
      taxBase: String(num(input.taxBase)),
      temporaryDifference: String(calc.difference),
      taxRate: String(num(input.taxRate, 25)),
      deferredTaxAsset: String(calc.dta),
      deferredTaxLiability: String(calc.dtl),
      throughOci: Boolean(input.throughOci),
      notes: str(input.notes),
    })
    .returning();
  return { row: rows[0], calc };
}

/* -------------------- IFRS 13 -------------------- */

export async function addFairValueMeasurement(clientId: number, input: Record<string, unknown>) {
  const levelInfo = classifyFairValueLevel({
    activeMarketQuoted: Boolean(input.activeMarketQuoted),
    observableInputs: Boolean(input.observableInputs ?? true),
    significantUnobservable: Boolean(input.significantUnobservable),
  });
  const level = num(input.level, levelInfo.level) as 1 | 2 | 3;
  const carrying = num(input.carryingAmount);
  const fv = num(input.fairValue, carrying);
  const rows = await db
    .insert(fairValueMeasurements)
    .values({
      clientId,
      code: str(input.code, `FV-${Date.now().toString(36).slice(-4).toUpperCase()}`),
      description: str(input.description, "Fair value item"),
      assetClass: str(input.assetClass, "financial"),
      level,
      valuationTechnique: str(input.valuationTechnique, "market"),
      observableInputs: str(input.observableInputsText, levelInfo.rationale),
      unobservableInputs: str(input.unobservableInputs),
      carryingAmount: String(carrying),
      fairValue: String(fv),
      unrealisedGainLoss: String(unrealisedGainLoss(carrying, fv)),
      period: str(input.period, thisPeriod()),
      recurring: input.recurring === false || input.recurring === "false" ? false : true,
      notes: str(input.notes),
    })
    .returning();
  return rows[0];
}

/* -------------------- IFRS 8 -------------------- */

export async function upsertSegment(clientId: number, input: Record<string, unknown>) {
  const code = str(input.code);
  const name = str(input.name);
  if (!code || !name) throw new PostingError("Segment code and name required.");
  const existing = (
    await db
      .select()
      .from(operatingSegments)
      .where(and(eq(operatingSegments.clientId, clientId), eq(operatingSegments.code, code)))
  )[0];
  const values = {
    name,
    description: str(input.description),
    chiefOperatingDecisionMaker: str(input.codm, "CEO"),
    costCenter: str(input.costCenter),
    externalRevenue: String(num(input.externalRevenue)),
    interSegmentRevenue: String(num(input.interSegmentRevenue)),
    segmentProfit: String(num(input.segmentProfit)),
    segmentAssets: String(num(input.segmentAssets)),
    segmentLiabilities: String(num(input.segmentLiabilities)),
    depreciation: String(num(input.depreciation)),
    capitalExpenditure: String(num(input.capitalExpenditure)),
    period: str(input.period, thisPeriod()),
    active: true,
  };
  const reportable = isReportableSegment({
    segmentRevenue: num(input.externalRevenue) + num(input.interSegmentRevenue),
    totalRevenue: num(input.totalRevenue, num(input.externalRevenue) + num(input.interSegmentRevenue)),
    segmentProfitAbs: Math.abs(num(input.segmentProfit)),
    totalProfitAbs: Math.abs(num(input.totalProfit, num(input.segmentProfit))),
    segmentAssets: num(input.segmentAssets),
    totalAssets: num(input.totalAssets, num(input.segmentAssets)),
  });
  if (existing) {
    await db.update(operatingSegments).set(values).where(eq(operatingSegments.id, existing.id));
    return { id: existing.id, reportable };
  }
  const rows = await db.insert(operatingSegments).values({ clientId, code, ...values }).returning();
  return { id: rows[0].id, reportable };
}

/* -------------------- IAS 24 -------------------- */

export async function upsertRelatedParty(clientId: number, input: Record<string, unknown>) {
  const code = str(input.code);
  const name = str(input.name);
  if (!code || !name) throw new PostingError("Related party code and name required.");
  const existing = (
    await db
      .select()
      .from(relatedParties)
      .where(and(eq(relatedParties.clientId, clientId), eq(relatedParties.code, code)))
  )[0];
  const values = {
    name,
    relationship: str(input.relationship, "other"),
    bpNo: str(input.bpNo),
    controlPct: String(num(input.controlPct)),
    nature: str(input.nature),
    active: true,
  };
  if (existing) {
    await db.update(relatedParties).set(values).where(eq(relatedParties.id, existing.id));
    return existing.id;
  }
  const rows = await db.insert(relatedParties).values({ clientId, code, ...values }).returning();
  return rows[0].id;
}

export async function addRelatedPartyTxn(clientId: number, input: Record<string, unknown>, user = "SYSTEM") {
  const relatedPartyId = num(input.relatedPartyId);
  if (!relatedPartyId) throw new PostingError("Select a related party.");
  const rows = await db
    .insert(relatedPartyTxns)
    .values({
      clientId,
      relatedPartyId,
      period: str(input.period, thisPeriod()),
      txnDate: str(input.txnDate, new Date().toISOString().slice(0, 10)),
      nature: str(input.nature, "sale"),
      description: str(input.description),
      amount: String(num(input.amount)),
      outstanding: String(num(input.outstanding, num(input.amount))),
      terms: str(input.terms, "arm's length"),
      docNo: str(input.docNo),
      createdBy: user,
    })
    .returning();
  return rows[0];
}

/* -------------------- IAS 10 / contingencies / risk / IAS 29 -------------------- */

export async function addSubsequentEvent(clientId: number, input: Record<string, unknown>, user = "SYSTEM") {
  const rows = await db
    .insert(subsequentEvents)
    .values({
      clientId,
      period: str(input.period, thisPeriod()),
      eventDate: str(input.eventDate, new Date().toISOString().slice(0, 10)),
      category: str(input.category, "non_adjusting"),
      title: str(input.title, "Subsequent event"),
      description: str(input.description),
      financialImpact: String(num(input.financialImpact)),
      adjustingEntryDocNo: str(input.adjustingEntryDocNo),
      createdBy: user,
    })
    .returning();
  return rows[0];
}

export async function addContingency(clientId: number, input: Record<string, unknown>, user = "SYSTEM") {
  const rows = await db
    .insert(contingencies)
    .values({
      clientId,
      period: str(input.period, thisPeriod()),
      title: str(input.title, "Contingency"),
      kind: str(input.kind, "liability"),
      likelihood: str(input.likelihood, "possible"),
      estimateLow: String(num(input.estimateLow)),
      estimateHigh: String(num(input.estimateHigh)),
      description: str(input.description),
      createdBy: user,
    })
    .returning();
  return rows[0];
}

export async function addRiskDisclosure(clientId: number, input: Record<string, unknown>) {
  const rows = await db
    .insert(riskDisclosures)
    .values({
      clientId,
      period: str(input.period, thisPeriod()),
      riskType: str(input.riskType, "credit"),
      title: str(input.title, "Risk"),
      exposure: String(num(input.exposure)),
      mitigation: str(input.mitigation),
      sensitivity: str(input.sensitivity),
      body: str(input.body),
    })
    .returning();
  return rows[0];
}

export async function setHyperinflationFactor(clientId: number, input: Record<string, unknown>) {
  const period = str(input.period, thisPeriod());
  const factor = restatementFactor(num(input.cpiIndex, 100), num(input.baseCpi, 100));
  const gainLoss = monetaryGainLoss({
    openingMonetaryNet: num(input.openingMonetaryNet),
    closingMonetaryNet: num(input.closingMonetaryNet),
    factor,
  });
  await db.delete(hyperinflationFactors).where(and(eq(hyperinflationFactors.clientId, clientId), eq(hyperinflationFactors.period, period)));
  const rows = await db
    .insert(hyperinflationFactors)
    .values({
      clientId,
      jurisdiction: str(input.jurisdiction),
      period,
      cpiIndex: String(num(input.cpiIndex, 100)),
      baseCpi: String(num(input.baseCpi, 100)),
      restatementFactor: String(factor),
      monetaryGainLoss: String(gainLoss),
      notes: str(input.notes),
    })
    .returning();
  return { row: rows[0], factor, gainLoss };
}

export async function listDisclosureNotes(clientId: number, period: string) {
  return db
    .select()
    .from(disclosureNotes)
    .where(and(eq(disclosureNotes.clientId, clientId), eq(disclosureNotes.period, period)))
    .orderBy(disclosureNotes.sortOrder);
}

export { provisionMovement, assessProvision };
