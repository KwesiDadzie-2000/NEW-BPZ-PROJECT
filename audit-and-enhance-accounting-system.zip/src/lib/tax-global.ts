/**
 * Multi-jurisdiction tax engine — US/UK/EU/NG/KE/ZA/AE + Ghana.
 * Extends the Ghana-first tax.ts with CIT, VAT, WHT and payroll per jurisdiction.
 */
import { db } from "@/db";
import { taxRates, taxBands } from "@/db/schema";
import { jurisdictions } from "@/db/employees-schema";
import { and, eq, asc } from "drizzle-orm";
import { computePaye, listPayeBands, type PayeBand } from "./tax";
import { jurisdictionByCode } from "@/data/jurisdictions";
import { PostingError } from "./posting";

const r2 = (n: number) => Math.round(n * 100) / 100;

/** Seed progressive PAYE/income-tax bands for major jurisdictions (owner-editable). */
export const GLOBAL_PAYE_BANDS: Record<string, { lower: number; upper: number | null; rate: number }[]> = {
  // Ghana already in tax.ts — kept for completeness
  "PAYE": [
    { lower: 0, upper: 3500, rate: 5 },
    { lower: 3500, upper: 13000, rate: 10 },
    { lower: 13000, upper: 25000, rate: 17.5 },
    { lower: 25000, upper: 37000, rate: 25 },
    { lower: 37000, upper: 57000, rate: 30 },
    { lower: 57000, upper: null, rate: 35 },
  ],
  "PAYE:NG": [
    { lower: 0, upper: 300000, rate: 7 },
    { lower: 300000, upper: 600000, rate: 11 },
    { lower: 600000, upper: 1100000, rate: 15 },
    { lower: 1100000, upper: 1600000, rate: 19 },
    { lower: 1600000, upper: 3200000, rate: 21 },
    { lower: 3200000, upper: null, rate: 24 },
  ],
  "PAYE:KE": [
    { lower: 0, upper: 288000, rate: 10 },
    { lower: 288000, upper: 388000, rate: 25 },
    { lower: 388000, upper: 6000000, rate: 30 },
    { lower: 6000000, upper: 9600000, rate: 32.5 },
    { lower: 9600000, upper: null, rate: 35 },
  ],
  "PAYE:ZA": [
    { lower: 0, upper: 237100, rate: 18 },
    { lower: 237100, upper: 370500, rate: 26 },
    { lower: 370500, upper: 512800, rate: 31 },
    { lower: 512800, upper: 673000, rate: 36 },
    { lower: 673000, upper: 857900, rate: 39 },
    { lower: 857900, upper: 1817000, rate: 41 },
    { lower: 1817000, upper: null, rate: 45 },
  ],
  "PAYE:GB": [
    { lower: 0, upper: 12570, rate: 0 }, // personal allowance simplified
    { lower: 12570, upper: 50270, rate: 20 },
    { lower: 50270, upper: 125140, rate: 40 },
    { lower: 125140, upper: null, rate: 45 },
  ],
  "PAYE:US": [
    // Federal single filer 2026-ish brackets (illustrative; owner-editable)
    { lower: 0, upper: 11925, rate: 10 },
    { lower: 11925, upper: 48475, rate: 12 },
    { lower: 48475, upper: 103350, rate: 22 },
    { lower: 103350, upper: 197300, rate: 24 },
    { lower: 197300, upper: 250525, rate: 32 },
    { lower: 250525, upper: 626350, rate: 35 },
    { lower: 626350, upper: null, rate: 37 },
  ],
  "PAYE:EU": [
    { lower: 0, upper: 15000, rate: 10 },
    { lower: 15000, upper: 40000, rate: 25 },
    { lower: 40000, upper: 80000, rate: 35 },
    { lower: 80000, upper: null, rate: 42 },
  ],
  "PAYE:AE": [
    // UAE — no personal income tax
    { lower: 0, upper: null, rate: 0 },
  ],
};

export const GLOBAL_STATUTORY: {
  code: string;
  items: { category: string; name: string; rate: number; notes: string }[];
}[] = [
  {
    code: "NG",
    items: [
      { category: "VAT", name: "Nigeria VAT", rate: 7.5, notes: "FIRS VAT 7.5%" },
      { category: "CIT", name: "Nigeria CIT", rate: 30, notes: "CITA company income tax" },
      { category: "WHT_RES", name: "Nigeria WHT services", rate: 10, notes: "WHT on services" },
      { category: "WHT_RES", name: "Nigeria WHT dividends", rate: 10, notes: "WHT on dividends" },
      { category: "SSNIT", name: "Nigeria pension employee", rate: 8, notes: "Pension Reform Act employee" },
      { category: "SSNIT", name: "Nigeria pension employer", rate: 10, notes: "Pension Reform Act employer" },
      { category: "NHIL", name: "Nigeria NHF", rate: 2.5, notes: "National Housing Fund" },
    ],
  },
  {
    code: "KE",
    items: [
      { category: "VAT", name: "Kenya VAT", rate: 16, notes: "KRA VAT 16%" },
      { category: "CIT", name: "Kenya CIT", rate: 30, notes: "Corporate tax 30%" },
      { category: "WHT_RES", name: "Kenya WHT professional", rate: 5, notes: "WHT on professional fees" },
      { category: "SSNIT", name: "Kenya NSSF employee", rate: 6, notes: "NSSF tier contributions (simplified)" },
      { category: "SSNIT", name: "Kenya NSSF employer", rate: 6, notes: "NSSF employer" },
      { category: "NHIL", name: "Kenya SHIF", rate: 2.75, notes: "Social Health Insurance Fund" },
    ],
  },
  {
    code: "ZA",
    items: [
      { category: "VAT", name: "South Africa VAT", rate: 15, notes: "SARS VAT 15%" },
      { category: "CIT", name: "South Africa CIT", rate: 27, notes: "Corporate tax 27%" },
      { category: "WHT_RES", name: "SA dividends tax", rate: 20, notes: "Dividends tax 20%" },
      { category: "SSNIT", name: "SA UIF employee", rate: 1, notes: "Unemployment Insurance Fund" },
      { category: "SSNIT", name: "SA UIF employer", rate: 1, notes: "UIF employer" },
      { category: "NHIL", name: "SA SDL", rate: 1, notes: "Skills Development Levy" },
    ],
  },
  {
    code: "GB",
    items: [
      { category: "VAT", name: "UK VAT standard", rate: 20, notes: "HMRC VAT 20%" },
      { category: "CIT", name: "UK Corporation Tax", rate: 25, notes: "Main rate 25%" },
      { category: "WHT_RES", name: "UK PAYE coding", rate: 0, notes: "Operated via RTI — use PAYE:GB bands" },
      { category: "SSNIT", name: "UK NI employee", rate: 8, notes: "Primary Class 1 NI (simplified)" },
      { category: "SSNIT", name: "UK NI employer", rate: 13.8, notes: "Secondary Class 1 NI" },
      { category: "SSNIT", name: "UK auto-enrol employee", rate: 5, notes: "Auto-enrolment minimum employee" },
      { category: "SSNIT", name: "UK auto-enrol employer", rate: 3, notes: "Auto-enrolment minimum employer" },
    ],
  },
  {
    code: "US",
    items: [
      { category: "VAT", name: "US sales tax (avg placeholder)", rate: 0, notes: "State-level — configure per nexus" },
      { category: "CIT", name: "US federal CIT", rate: 21, notes: "IRC federal corporate 21%" },
      { category: "SSNIT", name: "US FICA SS employee", rate: 6.2, notes: "Social Security employee" },
      { category: "SSNIT", name: "US FICA Medicare employee", rate: 1.45, notes: "Medicare employee" },
      { category: "SSNIT", name: "US FICA SS employer", rate: 6.2, notes: "Social Security employer" },
      { category: "SSNIT", name: "US FICA Medicare employer", rate: 1.45, notes: "Medicare employer" },
      { category: "SSNIT", name: "US FUTA employer", rate: 0.6, notes: "FUTA net typical rate" },
    ],
  },
  {
    code: "EU",
    items: [
      { category: "VAT", name: "EU VAT standard (placeholder)", rate: 20, notes: "Varies by member state — override in Admin" },
      { category: "CIT", name: "EU CIT average placeholder", rate: 24, notes: "Configure per member state" },
      { category: "SSNIT", name: "EU social employee placeholder", rate: 10, notes: "Configure per member state" },
      { category: "SSNIT", name: "EU social employer placeholder", rate: 15, notes: "Configure per member state" },
    ],
  },
  {
    code: "AE",
    items: [
      { category: "VAT", name: "UAE VAT", rate: 5, notes: "FTA VAT 5%" },
      { category: "CIT", name: "UAE Corporate Tax", rate: 9, notes: "CT 9% above threshold" },
      { category: "SSNIT", name: "UAE EOS gratuity accrual", rate: 0, notes: "End-of-service gratuity — use IAS 19 desk" },
    ],
  },
];

export async function seedGlobalTax() {
  for (const [taxCode, bands] of Object.entries(GLOBAL_PAYE_BANDS)) {
    if (taxCode === "PAYE") continue; // Ghana seeded in init
    const existing = await db.select().from(taxBands).where(eq(taxBands.tax, taxCode)).limit(1);
    if (existing.length) continue;
    await db.insert(taxBands).values(
      bands.map((b) => ({
        tax: taxCode,
        lower: String(b.lower),
        upper: b.upper === null ? null : String(b.upper),
        rate: String(b.rate),
        effectiveFrom: "2026-01-01",
      }))
    );
  }

  for (const block of GLOBAL_STATUTORY) {
    for (const item of block.items) {
      const existing = await db
        .select()
        .from(taxRates)
        .where(and(eq(taxRates.category, item.category), eq(taxRates.name, item.name)))
        .limit(1);
      if (existing.length) continue;
      await db.insert(taxRates).values({
        category: item.category,
        name: item.name,
        rate: String(item.rate),
        effectiveFrom: "2026-01-01",
        notes: item.notes,
      });
    }
  }
}

export async function computePayeForJurisdiction(
  taxable: number,
  jurisdictionCode: string
): Promise<{ paye: number; bands: PayeBand[]; taxCode: string }> {
  const code = (jurisdictionCode || "GH").toUpperCase();
  const taxCode = code === "GH" ? "PAYE" : `PAYE:${code}`;
  let bands = await listPayeBands(taxCode);
  if (!bands.length && taxCode !== "PAYE") {
    bands = await listPayeBands("PAYE");
  }
  return { paye: computePaye(taxable, bands), bands, taxCode };
}

export async function vatRateForJurisdiction(code: string): Promise<{ name: string; rate: number }> {
  const j = jurisdictionByCode(code);
  // Prefer DB rate if seeded
  const rows = await db.select().from(taxRates).where(eq(taxRates.category, "VAT"));
  const hit = rows.find((r) => r.name.toLowerCase().includes(j.name.split(" ")[0].toLowerCase()));
  return { name: hit?.name ?? j.vatName, rate: hit ? Number(hit.rate) : j.vatRate };
}

export async function citRateForJurisdiction(code: string): Promise<number> {
  const j = jurisdictionByCode(code);
  const rows = await db.select().from(taxRates).where(eq(taxRates.category, "CIT"));
  const hit = rows.find((r) => r.name.toLowerCase().includes(j.name.split(" ")[0].toLowerCase()));
  return hit ? Number(hit.rate) : j.citRate;
}

export async function listJurisdictionProfiles() {
  return db.select().from(jurisdictions).orderBy(asc(jurisdictions.name));
}

export function validateJurisdictionCode(code: string) {
  const j = jurisdictionByCode(code);
  if (!j) throw new PostingError(`Unknown jurisdiction ${code}`);
  return j;
}
