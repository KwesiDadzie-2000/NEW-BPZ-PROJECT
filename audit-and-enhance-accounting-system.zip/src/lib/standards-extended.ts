/**
 * Extended financial-reporting standards — pure computation layer.
 *   IAS 37  — Provisions, contingent liabilities & contingent assets
 *   IAS 19  — Employee benefits (defined benefit / gratuity)
 *   IAS 33  — Earnings per share
 *   IAS 12  — Deferred tax
 *   IAS 29  — Hyperinflation restatement
 *   IFRS 8  — Operating segment aggregation helpers
 *   IFRS 13 — Fair value hierarchy helpers
 */
export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
export const round6 = (n: number) => Math.round((n + Number.EPSILON) * 1e6) / 1e6;

/* =====================================================================
   IAS 37 — PROVISIONS
   ===================================================================== */

export type ProvisionInput = {
  bestEstimate: number;
  minEstimate?: number;
  maxEstimate?: number;
  probability: number; // 0-100
  discountRate: number; // % p.a.
  yearsToSettlement: number;
  contingent?: boolean;
  contingentAsset?: boolean;
};

/**
 * Recognition decision tree (IAS 37.14 / .23 / .27–.35):
 *  - Probable (>50%) + reliable estimate → recognise provision
 *  - Possible (not probable, not remote) → disclose contingent liability
 *  - Remote → neither recognise nor disclose (usually)
 *  - Contingent asset: disclose when probable; recognise when virtually certain
 */
export function assessProvision(input: ProvisionInput): {
  decision: "recognise" | "contingent_liability" | "contingent_asset_disclose" | "recognise_asset" | "silent";
  presentValue: number;
  undiscounted: number;
  reason: string;
} {
  const p = Math.min(100, Math.max(0, input.probability));
  const best = Math.max(0, input.bestEstimate);
  const years = Math.max(0, input.yearsToSettlement);
  const r = input.discountRate / 100;
  const pv = years > 0 && r > 0 ? round2(best / Math.pow(1 + r, years)) : round2(best);

  if (input.contingentAsset) {
    if (p >= 95) {
      return {
        decision: "recognise_asset",
        presentValue: pv,
        undiscounted: best,
        reason: "Inflow virtually certain — recognise contingent asset (IAS 37.33).",
      };
    }
    if (p > 50) {
      return {
        decision: "contingent_asset_disclose",
        presentValue: pv,
        undiscounted: best,
        reason: "Inflow probable but not virtually certain — disclose contingent asset (IAS 37.34).",
      };
    }
    return {
      decision: "silent",
      presentValue: 0,
      undiscounted: best,
      reason: "Inflow not probable — contingent asset is not disclosed (IAS 37.35).",
    };
  }

  if (input.contingent || p <= 50) {
    if (p <= 10) {
      return {
        decision: "silent",
        presentValue: 0,
        undiscounted: best,
        reason: "Outflow remote — no recognition or disclosure required (IAS 37.28).",
      };
    }
    return {
      decision: "contingent_liability",
      presentValue: pv,
      undiscounted: best,
      reason: "Outflow possible but not probable — disclose contingent liability (IAS 37.28 / .86).",
    };
  }

  // Probable → provision
  return {
    decision: "recognise",
    presentValue: pv,
    undiscounted: best,
    reason:
      years > 0 && r > 0
        ? `Present obligation probable; recognised at discounted best estimate (IAS 37.36–.47). PV factor ${(1 / Math.pow(1 + r, years)).toFixed(4)}.`
        : "Present obligation probable; recognised at best estimate (IAS 37.36).",
  };
}

/** Mid-point of a range when no best estimate is more likely (IAS 37.39). */
export function rangeMidpoint(min: number, max: number): number {
  return round2((Math.max(0, min) + Math.max(0, max)) / 2);
}

/** Unwinding of discount for a provision (finance cost). */
export function provisionUnwinding(carryingAmount: number, discountRate: number): number {
  return round2(Math.max(0, carryingAmount) * (Math.max(0, discountRate) / 100));
}

/** Movement schedule for disclosure. */
export function provisionMovement(input: {
  opening: number;
  added: number;
  utilised: number;
  reversed: number;
  unwinding: number;
}): { closing: number; lines: { label: string; amount: number }[] } {
  const closing = round2(
    Math.max(0, input.opening) + input.added - input.utilised - input.reversed + input.unwinding
  );
  return {
    closing,
    lines: [
      { label: "Opening carrying amount", amount: round2(input.opening) },
      { label: "Additional provisions", amount: round2(input.added) },
      { label: "Amounts utilised", amount: round2(-Math.abs(input.utilised)) },
      { label: "Unused amounts reversed", amount: round2(-Math.abs(input.reversed)) },
      { label: "Unwinding of discount", amount: round2(input.unwinding) },
      { label: "Closing carrying amount", amount: closing },
    ],
  };
}

/* =====================================================================
   IAS 19 — EMPLOYEE BENEFITS (simplified PUC)
   ===================================================================== */

export function definedBenefitObligation(input: {
  members: number;
  averageSalary: number;
  averageServiceYears: number;
  salaryGrowth: number; // %
  discountRate: number; // %
  yearsToRetirement?: number;
  benefitFormulaYears?: number; // e.g. 1 month per year of service → 1/12
}): {
  dbo: number;
  currentServiceCost: number;
  interestCost: number;
  projectedSalary: number;
} {
  const members = Math.max(0, input.members);
  const salary = Math.max(0, input.averageSalary);
  const service = Math.max(0, input.averageServiceYears);
  const g = input.salaryGrowth / 100;
  const r = input.discountRate / 100;
  const years = Math.max(0, input.yearsToRetirement ?? 10);
  const formula = input.benefitFormulaYears ?? 1 / 12; // gratuity: 1 month per year

  const projectedSalary = round2(salary * Math.pow(1 + g, years));
  // Simplified projected unit credit: DBO = members × projectedSalary × service × formula × discount
  const lumpAtRetirement = members * projectedSalary * service * formula;
  const dbo = years > 0 && r > 0 ? round2(lumpAtRetirement / Math.pow(1 + r, years)) : round2(lumpAtRetirement);
  const currentServiceCost =
    years > 0 && r > 0
      ? round2((members * projectedSalary * formula) / Math.pow(1 + r, years))
      : round2(members * projectedSalary * formula);
  const interestCost = round2(dbo * r);

  return { dbo, currentServiceCost, interestCost, projectedSalary };
}

export function netDefinedBenefitLiability(input: {
  dbo: number;
  planAssets: number;
}): { net: number; surplus: number; deficit: number } {
  const net = round2(input.dbo - Math.max(0, input.planAssets));
  return { net, surplus: net < 0 ? Math.abs(net) : 0, deficit: net > 0 ? net : 0 };
}

/* =====================================================================
   IAS 33 — EARNINGS PER SHARE
   ===================================================================== */

export function computeEps(input: {
  profitAttributable: number;
  preferenceDividends?: number;
  weightedAvgShares: number;
  dilutiveShares?: number;
  discontinuedProfit?: number;
}): {
  basicEps: number;
  dilutedEps: number;
  continuingBasicEps: number;
  numerator: number;
  basicDenominator: number;
  dilutedDenominator: number;
} {
  const pref = Math.max(0, input.preferenceDividends ?? 0);
  const numerator = round2(input.profitAttributable - pref);
  const basicDen = Math.max(0, input.weightedAvgShares);
  const dilutive = Math.max(0, input.dilutiveShares ?? 0);
  const dilutedDen = basicDen + dilutive;
  const basicEps = basicDen > 0 ? round6(numerator / basicDen) : 0;
  // Anti-dilution: diluted EPS cannot increase loss-per-share or decrease profit-per-share wrongly
  let dilutedEps = dilutedDen > 0 ? round6(numerator / dilutedDen) : basicEps;
  if (numerator >= 0 && dilutedEps > basicEps) dilutedEps = basicEps; // anti-dilutive instruments ignored
  if (numerator < 0 && dilutedEps < basicEps) dilutedEps = basicEps;

  const disc = input.discontinuedProfit ?? 0;
  const continuingNum = round2(numerator - disc);
  const continuingBasicEps = basicDen > 0 ? round6(continuingNum / basicDen) : 0;

  return {
    basicEps,
    dilutedEps,
    continuingBasicEps,
    numerator,
    basicDenominator: basicDen,
    dilutedDenominator: dilutedDen,
  };
}

/** Weighted average shares for a simple issue mid-period. */
export function weightedAverageShares(
  events: { date: string; shares: number; weightMonths: number }[]
): number {
  const totalMonths = events.reduce((s, e) => s + Math.max(0, e.weightMonths), 0) || 12;
  const weighted = events.reduce((s, e) => s + Math.max(0, e.shares) * Math.max(0, e.weightMonths), 0);
  return round2(weighted / totalMonths);
}

/* =====================================================================
   IAS 12 — DEFERRED TAX
   ===================================================================== */

export function temporaryDifference(input: {
  carryingAmount: number;
  taxBase: number;
}): { difference: number; taxable: boolean; deductible: boolean } {
  const difference = round2(input.carryingAmount - input.taxBase);
  return {
    difference,
    taxable: difference > 0, // will reverse as taxable amounts → DTL
    deductible: difference < 0, // will reverse as deductible amounts → DTA
  };
}

export function deferredTax(input: {
  carryingAmount: number;
  taxBase: number;
  taxRate: number; // %
}): { difference: number; dta: number; dtl: number } {
  const { difference, taxable, deductible } = temporaryDifference(input);
  const rate = Math.max(0, input.taxRate) / 100;
  const tax = round2(Math.abs(difference) * rate);
  return {
    difference,
    dta: deductible ? tax : 0,
    dtl: taxable ? tax : 0,
  };
}

/* =====================================================================
   IAS 29 — HYPERINFLATION
   ===================================================================== */

export function restatementFactor(cpiIndex: number, baseCpi: number): number {
  const base = baseCpi > 0 ? baseCpi : 100;
  const cpi = cpiIndex > 0 ? cpiIndex : base;
  return Math.round((cpi / base) * 1e8) / 1e8;
}

export function restateNonMonetary(amount: number, factor: number): number {
  return round2(Math.max(0, amount) * Math.max(0, factor));
}

/**
 * Gain/loss on net monetary position:
 * monetary assets - monetary liabilities, restated movement approx.
 */
export function monetaryGainLoss(input: {
  openingMonetaryNet: number;
  closingMonetaryNet: number;
  factor: number;
}): number {
  // Simplified: holding net monetary liabilities in hyperinflation produces a gain
  const restatedOpening = round2(input.openingMonetaryNet * input.factor);
  return round2(restatedOpening - input.closingMonetaryNet);
}

/* =====================================================================
   IFRS 8 — SEGMENTS
   ===================================================================== */

export function isReportableSegment(input: {
  segmentRevenue: number;
  totalRevenue: number;
  segmentProfitAbs: number;
  totalProfitAbs: number;
  segmentAssets: number;
  totalAssets: number;
}): { reportable: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const revTest = input.totalRevenue > 0 && input.segmentRevenue / input.totalRevenue >= 0.1;
  const profitTest = input.totalProfitAbs > 0 && input.segmentProfitAbs / input.totalProfitAbs >= 0.1;
  const assetTest = input.totalAssets > 0 && input.segmentAssets / input.totalAssets >= 0.1;
  if (revTest) reasons.push("≥10% of combined revenue (IFRS 8.13(a))");
  if (profitTest) reasons.push("≥10% of combined profit/loss absolute (IFRS 8.13(b))");
  if (assetTest) reasons.push("≥10% of combined assets (IFRS 8.13(c))");
  return { reportable: reasons.length > 0, reasons };
}

/* =====================================================================
   IFRS 13 — FAIR VALUE HIERARCHY
   ===================================================================== */

export function classifyFairValueLevel(input: {
  activeMarketQuoted: boolean;
  observableInputs: boolean;
  significantUnobservable: boolean;
}): { level: 1 | 2 | 3; rationale: string } {
  if (input.activeMarketQuoted && !input.significantUnobservable) {
    return { level: 1, rationale: "Quoted prices in active markets for identical assets/liabilities (IFRS 13.76)." };
  }
  if (input.significantUnobservable) {
    return { level: 3, rationale: "Significant unobservable inputs (IFRS 13.86)." };
  }
  if (input.observableInputs) {
    return { level: 2, rationale: "Inputs other than quoted prices that are observable (IFRS 13.81)." };
  }
  return { level: 3, rationale: "Default to Level 3 when inputs are not observable." };
}

export function unrealisedGainLoss(carryingAmount: number, fairValue: number): number {
  return round2(fairValue - carryingAmount);
}
