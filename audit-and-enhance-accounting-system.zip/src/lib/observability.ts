/**
 * Error tracking and structured logging.
 *
 * The platform deliberately has no third-party SDK in the request path, so it
 * works on any host without configuration. Errors are logged as structured JSON
 * on the server — which is what Sentry, Datadog, Logtail or a platform's own
 * log drain ingest — and the most recent failures are retained in the database
 * so they can be viewed in the app instead of disappearing into a console.
 *
 * To switch on Sentry later: install the SDK, call captureException from the
 * `report` function below, and remove nothing else.
 */

import { db } from "@/db";
import { errorLog } from "@/db/schema";
import { desc } from "drizzle-orm";

type Level = "error" | "warn" | "info";

export type ErrorContext = {
  clientId?: number | null;
  workspace?: string;
  username?: string;
  action?: string;
  route?: string;
  detail?: string;
};

const REDACT = ["password", "passwordhash", "totpsecret", "recoveryhash", "token", "secret"];

function scrub(ctx: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(ctx)) {
    out[REDACT.some((r) => k.toLowerCase().includes(r)) ? "[redacted]" : k] = v;
  }
  return out;
}

/** Structured server-side log line — machine-parsable by any log drain. */
export function logEvent(level: Level, message: string, ctx: ErrorContext = {}, err?: unknown) {
  const payload = {
    ts: new Date().toISOString(),
    level,
    service: "bpz-platform",
    message,
    ...scrub(ctx as Record<string, unknown>),
    error:
      err instanceof Error
        ? { name: err.name, message: err.message, stack: err.stack?.split("\n").slice(0, 6).join(" | ") }
        : err !== undefined
          ? String(err)
          : undefined,
  };
  const line = JSON.stringify(payload);
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

/** Record an error: logged structurally AND retained for the in-app viewer. */
export async function report(message: string, ctx: ErrorContext = {}, err?: unknown) {
  logEvent("error", message, ctx, err);
  try {
    await db.insert(errorLog).values({
      clientId: ctx.clientId ?? null,
      workspace: ctx.workspace ?? "",
      username: ctx.username ?? "",
      action: (ctx.action ?? "").slice(0, 80),
      route: (ctx.route ?? "").slice(0, 120),
      message: message.slice(0, 400),
      stack: err instanceof Error ? (err.stack ?? "").slice(0, 2000) : String(err ?? "").slice(0, 2000),
    });
  } catch (e) {
    // Never let error recording itself break a request.
    console.error(JSON.stringify({ ts: new Date().toISOString(), level: "error", message: "error_log insert failed", cause: e instanceof Error ? e.message : e }));
  }
}

/** Most recent retained errors, for the in-app diagnostics viewer. */
export async function recentErrors(limit = 50) {
  const rows = await db.select().from(errorLog).orderBy(desc(errorLog.id)).limit(limit);
  return rows.map((r) => ({
    id: r.id,
    clientId: r.clientId,
    workspace: r.workspace,
    username: r.username,
    action: r.action,
    route: r.route,
    message: r.message,
    stack: r.stack,
    at: r.at.toISOString(),
  }));
}

export async function clearErrors() {
  await db.delete(errorLog);
}
