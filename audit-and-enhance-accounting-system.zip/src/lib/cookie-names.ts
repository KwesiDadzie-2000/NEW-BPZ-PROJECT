/** Cookie names — shared by server and client code (no server imports here). */
export const SESSION_COOKIE = "lc_session";
export const WORKSPACE_COOKIE = "lc_ws";
