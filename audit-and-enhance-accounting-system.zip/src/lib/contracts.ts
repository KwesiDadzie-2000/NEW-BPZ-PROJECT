import { db } from "@/db";
import { contracts, contractCertificates, contractCosts, journalLines, partners, invoices } from "@/db/schema";
import { and, eq, desc, sql } from "drizzle-orm";
import { contractVariations } from "@/db/contract-variation-schema";
import { PostingError, post, type JLine } from "./posting";
import { postChecked } from "./engine";
import { assertPeriodOpen, thisPeriod, periodLabel } from "./periods";
import { upsertPartner } from "./posting";
import {
  contractPosition,
  certificateAllocation,
  onerousLoss,
} from "./accounting-rules";

const r2 = (n: number) => Math.round(n * 100) / 100;

export type Method = "cost_to_cost" | "input_survey" | "output_milestone" | "straight_line";

export const METHODS: { code: Method; label: string; note: string }[] = [
  {
    code: "cost_to_cost",
    label: "Cost-to-cost (input method)",
    note: "IFRS 15 default. % complete = costs incurred ÷ total estimated cost. Best where costs track effort reliably.",
  },
  {
    code: "input_survey",
    label: "Surveyor / input measurement",
    note: "Percentage certified by a professional surveyor or engineer. Common in construction and civil works.",
  },
  {
    code: "output_milestone",
    label: "Output / milestones achieved",
    note: "Recognise on delivered milestones. Suits IT implementations, consulting phases, plant fabrication.",
  },
  {
    code: "straight_line",
    label: "Straight line over contract term",
    note: "Even recognition across the contract months. Only where the customer consumes the benefit evenly.",
  },
];

export type ContractRow = {
  id: number;
  no: string;
  title: string;
  counterparty: string;
  sector: string;
  startDate: string;
  endDate: string;
  method: Method;
  totalValue: number;
  estimatedCost: number;
  costToDate: number;
  recognisedRevenue: number;
  recognisedCost: number;
  billed: number;
  retentionPct: number;
  retentionHeld: number;
  retentionReleased: number;
  advances: number;
  cc: string;
  status: string;
  pctComplete: number;
  /** IFRS 15 computed figures */
  revenueToDate: number;
  costOfRevenueToDate: number;
  cumulativeProfit: number;
  expectedProfit: number;
  marginPct: number;
  contractAsset: number;
  contractLiability: number;
  unbilledRevenue: number;
  progressThisPeriod: number;
  isLossMaking: boolean;
  lossProvision: number;
  monthsElapsed: number;
  monthsTotal: number;
};

function pctCompleteFor(
  method: string,
  costToDate: number,
  estimatedCost: number,
  surveyedPct: number,
  milestonesDone: number,
  milestonesTotal: number,
  startDate: string,
  endDate: string
): number {
  let p = 0;
  if (method === "cost_to_cost") {
    p = estimatedCost > 0 ? (costToDate / estimatedCost) * 100 : 0;
  } else if (method === "input_survey") {
    p = surveyedPct;
  } else if (method === "output_milestone") {
    p = milestonesTotal > 0 ? (milestonesDone / milestonesTotal) * 100 : 0;
  } else {
    const start = Date.parse(startDate || "");
    const end = Date.parse(endDate || "");
    if (Number.isFinite(start) && Number.isFinite(end) && end > start) {
      const now = Date.now();
      p = ((now - start) / (end - start)) * 100;
    }
  }
  return Math.max(0, Math.min(100, r2(p)));
}

function monthsBetween(a: string, b: string): number {
  const pa = a.split("-").map(Number);
  const pb = b.split("-").map(Number);
  if (!pa[0] || !pb[0]) return 0;
  return (pb[0] - pa[0]) * 12 + (pb[1] ?? 1) - (pa[1] ?? 1);
}

function decorate(r: typeof contracts.$inferSelect): ContractRow {
  const totalValue = Number(r.totalValue);
  const estimatedCost = Number(r.estimatedCost) || totalValue * 0.85;
  const costToDate = Number(r.costToDate);
  const billed = Number(r.billed);
  const advances = Number(r.advances);
  const retentionHeld = Number(r.retentionHeld);
  const recognisedRevenue = Number(r.recognisedRevenue);
  const recognisedCost = Number(r.recognisedCost);

  const pctComplete = pctCompleteFor(
    r.method,
    costToDate,
    estimatedCost,
    Number(r.pctComplete),
    0,
    0,
    r.startDate,
    r.endDate
  );

  const position = contractPosition({
    transactionPrice: totalValue,
    pctComplete,
    actualCostToDate: costToDate,
    billedToDate: billed,
    advancesReceived: advances,
  });
  const { revenueToDate, cumulativeProfit, contractAsset, contractLiability } =
    position;
  const costOfRevenueToDate = position.actualCostToDate;
  const expectedProfit = r2(totalValue - estimatedCost);
  const marginPct = totalValue > 0 ? r2((expectedProfit / totalValue) * 100) : 0;

  const isLossMaking = estimatedCost > totalValue;
  const lossProvision = isLossMaking
    ? onerousLoss(totalValue, estimatedCost)
    : Number(r.lossProvision);
  const unbilledRevenue = contractAsset;

  const nowPeriod = thisPeriod();
  const monthsElapsed = Math.max(0, monthsBetween(r.startDate || "", nowPeriod));
  const monthsTotal = Math.max(1, monthsBetween(r.startDate || "", r.endDate || ""));

  return {
    id: r.id,
    no: r.no,
    title: r.title || r.no,
    counterparty: r.counterparty,
    sector: r.sector,
    startDate: r.startDate,
    endDate: r.endDate,
    method: r.method as Method,
    totalValue,
    estimatedCost,
    costToDate,
    recognisedRevenue,
    recognisedCost,
    billed,
    retentionPct: Number(r.retentionPct),
    retentionHeld,
    retentionReleased: Number(r.retentionReleased),
    advances,
    cc: r.cc,
    status: r.status,
    pctComplete,
    revenueToDate,
    costOfRevenueToDate,
    cumulativeProfit,
    expectedProfit,
    marginPct,
    contractAsset,
    contractLiability,
    unbilledRevenue,
    progressThisPeriod: r2(revenueToDate - recognisedRevenue),
    isLossMaking,
    lossProvision,
    monthsElapsed,
    monthsTotal,
  };
}

export async function listContracts(clientId: number, status?: string): Promise<ContractRow[]> {
  const rows = status
    ? await db.select().from(contracts).where(and(eq(contracts.clientId, clientId), eq(contracts.status, status))).orderBy(desc(contracts.id))
    : await db.select().from(contracts).where(eq(contracts.clientId, clientId)).orderBy(desc(contracts.id));
  return rows.map(decorate);
}

export async function getContract(clientId: number, id: number): Promise<ContractRow | undefined> {
  const r = (await db.select().from(contracts).where(and(eq(contracts.clientId, clientId), eq(contracts.id, id))))[0];
  return r ? decorate(r) : undefined;
}

/** Create a contract and record any advance received. */
export async function createContract(
  clientId: number,
  input: {
    title: string; counterparty: string; totalValue: number; estimatedCost: number;
    method: Method; startDate: string; endDate: string; cc?: string;
    retentionPct: number; currency?: string; sector?: string; advance?: number;
    user?: string;
  }
) {
  const { title, counterparty, totalValue, estimatedCost, method } = input;
  if (!title) throw new PostingError("Give the contract a title.");
  if (!counterparty) throw new PostingError("Select the customer.");
  if (totalValue <= 0) throw new PostingError("Contract value must be positive.");
  if (estimatedCost <= 0) throw new PostingError("Estimated cost is required — IFRS 15 needs it to measure progress.");
  if ((input.retentionPct ?? 0) < 0 || (input.retentionPct ?? 0) > 50)
    throw new PostingError("Retention must be between 0% and 50%.");
  if ((input.advance ?? 0) < 0 || (input.advance ?? 0) > totalValue)
    throw new PostingError("The mobilisation advance cannot exceed the contract value.");
  if (!METHODS.some((m) => m.code === method)) throw new PostingError("Choose a recognition method.");
  if (input.startDate && input.endDate && input.endDate <= input.startDate)
    throw new PostingError("The contract end date must be after the start date.");

  const customer = (
    await db
      .select()
      .from(partners)
      .where(
        and(
          eq(partners.clientId, clientId),
          eq(partners.bpNo, counterparty),
          eq(partners.type, "Customer")
        )
      )
  )[0];
  if (!customer)
    throw new PostingError(
      `Customer "${counterparty}" is not in this workspace. Add it under Master Data first.`
    );

  const postPeriod = (input.startDate || thisPeriod()).slice(0, 7);
  if ((input.advance ?? 0) > 0 || estimatedCost > totalValue)
    await assertPeriodOpen(clientId, postPeriod);

  const created = await db.transaction(async (tx) => {
    // The serial ID drives the display number. Count-based numbering races
    // under concurrent users.
    const pendingNo = `PENDING-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const inserted = await tx
      .insert(contracts)
      .values({
        clientId,
        no: pendingNo,
        title,
        counterparty,
        sector: input.sector ?? "construction",
        startDate: input.startDate,
        endDate: input.endDate,
        method,
        totalValue: String(totalValue),
        estimatedCost: String(estimatedCost),
        retentionPct: String(input.retentionPct ?? 0),
        retentionHeld: "0",
        advances: String(input.advance ?? 0),
        currency: input.currency ?? "GHS",
        cc: input.cc ?? "",
        status: "active",
        pctComplete: "0",
        costToDate: "0",
        recognisedRevenue: "0",
        recognisedCost: "0",
        billed: "0",
        lossProvision: String(onerousLoss(totalValue, estimatedCost)),
      })
      .returning({ id: contracts.id });

    const no = `CNT-${String(inserted[0].id).padStart(4, "0")}`;
    await tx.update(contracts).set({ no }).where(eq(contracts.id, inserted[0].id));

    const expectedLoss = onerousLoss(totalValue, estimatedCost);
    if (expectedLoss > 0) {
      await post(tx as never, {
        clientId,
        date: new Date().toISOString().slice(0, 10),
        period: postPeriod,
        module: "SD",
        docType: "CON",
        user: input.user,
        reference: `${no} onerous contract provision`,
        lines: [
          {
            account: "508000",
            cc: input.cc,
            desc: `Onerous contract loss – ${title}`,
            dr: expectedLoss,
          },
          {
            account: "293000",
            desc: `Provision for onerous contract – ${no}`,
            cr: expectedLoss,
          },
        ],
      });
    }

    if (input.advance && input.advance > 0) {
      await post(tx as never, {
        clientId,
        date: new Date().toISOString().slice(0, 10),
        period: postPeriod,
        module: "SD",
        docType: "CON",
        user: input.user,
        reference: `${no} mobilisation advance`,
        lines: [
          {
            account: "101000",
            bp: counterparty,
            desc: `Advance received – ${title}`,
            dr: input.advance,
          },
          {
            account: "222000",
            bp: counterparty,
            desc: `Contract liability – advance on ${no}`,
            cr: input.advance,
          },
        ],
      });
    }

    return { id: inserted[0].id, no };
  });

  return {
    id: created.id,
    no: created.no,
    message: `Contract ${created.no} opened — ${title}. Recognition: ${METHODS.find((m) => m.code === method)?.label}.`,
  };
}

/** Record costs incurred on a contract. Drives cost-to-cost progress. */
export async function recordContractCost(
  clientId: number,
  input: {
    contractId: number;
    amount: number;
    account?: string;
    vendor?: string;
    vat?: boolean;
    description?: string;
    period: string;
    user?: string;
  }
) {
  const c = await getContract(clientId, input.contractId);
  if (!c) throw new PostingError("Contract not found in this workspace.");
  if (c.status !== "active") throw new PostingError(`Contract ${c.no} is ${c.status}.`);
  const amount = r2(input.amount);
  if (amount <= 0) throw new PostingError("Enter a positive cost amount.");

  const account = input.account || "505000";
  let vendorName = "accrued cost";
  if (input.vendor) {
    const vendor = (
      await db
        .select()
        .from(partners)
        .where(
          and(
            eq(partners.clientId, clientId),
            eq(partners.bpNo, input.vendor),
            eq(partners.type, "Vendor")
          )
        )
    )[0];
    if (!vendor)
      throw new PostingError(
        `Supplier "${input.vendor}" is not in this workspace. Add it under Master Data first.`
      );
    vendorName = vendor.name;
  }

  const vat = input.vendor && input.vat ? r2(amount * 0.2) : 0;
  const grossPayable = r2(amount + vat);

  await assertPeriodOpen(clientId, input.period);
  const doc = await db.transaction(async (tx) => {
    const costLines: JLine[] = [
      {
        account,
        cc: c.cc,
        desc: `Contract cost – ${c.title}: ${input.description || "cost incurred"}`,
        dr: amount,
      },
    ];
    if (vat > 0) {
      costLines.push({
        account: "112000",
        bp: input.vendor,
        desc: `Recoverable input VAT – ${c.no}`,
        dr: vat,
      });
    }
    costLines.push({
      account: input.vendor ? "200000" : "219000",
      bp: input.vendor,
      desc: input.vendor
        ? `Payable to ${vendorName} – ${input.description || c.no}`
        : `Accrued contract cost – ${input.description || c.no}`,
      cr: grossPayable,
    });

    const journalDoc = await post(tx as never, {
      clientId,
      date: new Date().toISOString().slice(0, 10),
      period: input.period,
      module: "SD",
      docType: "CON",
      user: input.user,
      reference: `${c.no} · ${input.description || "contract cost"}`,
      lines: costLines,
    });

    const costRow = await tx
      .insert(contractCosts)
      .values({
        clientId,
        contractId: c.id,
        period: input.period,
        account,
        vendor: input.vendor ?? "",
        description: input.description ?? "",
        amount: String(amount),
        docNo: journalDoc,
        createdBy: input.user ?? "",
      })
      .returning({ id: contractCosts.id });

    if (input.vendor) {
      // Open AP item, available immediately at the Payment Desk. The invoice
      // points to the SAME journal document, so there is no duplicate posting.
      await tx.insert(invoices).values({
        clientId,
        direction: "purchase",
        docType: "invoice",
        no: `${c.no}-COST${String(costRow[0].id).padStart(4, "0")}`,
        bp: input.vendor,
        currency: "GHS",
        rate: "1",
        subtotal: String(amount),
        vat: String(vat),
        total: String(grossPayable),
        status: "open",
        period: input.period,
        docNo: journalDoc,
        note: `Project cost – ${c.title}: ${input.description || "cost incurred"}`,
        paid: "0",
        expenseCategory: "service",
      });
    }

    // Atomic increment survives concurrent site-cost postings.
    await tx
      .update(contracts)
      .set({ costToDate: sql`${contracts.costToDate} + ${amount}` })
      .where(and(eq(contracts.id, c.id), eq(contracts.clientId, clientId)));

    return journalDoc;
  });

  const updated = await getContract(clientId, c.id);
  return {
    doc,
    pctComplete: updated?.pctComplete ?? 0,
    message: `Cost ₵${amount.toFixed(2)} recorded on ${c.no} → doc ${doc}. Progress now ${updated?.pctComplete.toFixed(1)}%.`,
  };
}

/** Post the IFRS 15 period-end recognition entry for a contract. */
export async function recogniseRevenue(
  clientId: number,
  input: { contractId: number; period: string; user?: string; forcePct?: number }
) {
  const c = await getContract(clientId, input.contractId);
  if (!c) throw new PostingError("Contract not found in this workspace.");
  if (c.status !== "active") throw new PostingError(`Contract ${c.no} is ${c.status}.`);
  await assertPeriodOpen(clientId, input.period);

  // Allow a surveyor-certified override where the method is input measurement.
  let pct = c.pctComplete;
  if (input.forcePct !== undefined && input.forcePct !== null) {
    if (input.forcePct < 0 || input.forcePct > 100)
      throw new PostingError("Percentage complete must be 0–100.");
    pct = r2(input.forcePct);
  }

  // IFRS 15: cumulative revenue from the selected measure of progress.
  // Costs are actual costs incurred and were already charged to P&L when
  // recorded; recognition must never create estimated/fictitious costs.
  const revenueToDate = r2((c.totalValue * pct) / 100);
  const actualCostToDate = r2(c.costToDate);
  const revenueThisPeriod = r2(revenueToDate - c.recognisedRevenue);
  const costThisPeriod = r2(actualCostToDate - c.recognisedCost);

  if (Math.abs(revenueThisPeriod) < 0.005 && Math.abs(costThisPeriod) < 0.005)
    throw new PostingError(`No new revenue to recognise on ${c.no} — progress is unchanged at ${pct.toFixed(1)}%.`);

  const lines: JLine[] = [];
  const priorNetPosition = r2(c.recognisedRevenue - c.billed - c.advances);
  const priorContractAsset = Math.max(0, priorNetPosition);
  const priorContractLiability = Math.max(0, -priorNetPosition);

  if (revenueThisPeriod > 0) {
    // Performance first releases advances/over-billings (contract liability),
    // then creates an unbilled contract asset for any remaining performance.
    const liabilityRelease = r2(Math.min(revenueThisPeriod, priorContractLiability));
    const assetIncrease = r2(revenueThisPeriod - liabilityRelease);
    if (liabilityRelease > 0) {
      lines.push({
        account: "222000",
        bp: c.counterparty,
        cc: c.cc,
        desc: `Release contract liability – ${c.no}`,
        dr: liabilityRelease,
      });
    }
    if (assetIncrease > 0) {
      lines.push({
        account: "143000",
        bp: c.counterparty,
        cc: c.cc,
        desc: `Contract asset – unbilled performance (${periodLabel(input.period)}, ${pct.toFixed(1)}%)`,
        dr: assetIncrease,
      });
    }
    lines.push({
      account: "440000",
      bp: c.counterparty,
      cc: c.cc,
      desc: `Revenue recognised over time – ${c.no}`,
      cr: revenueThisPeriod,
    });
  } else if (revenueThisPeriod < 0) {
    // A downward estimate/progress revision reverses prior revenue. Reduce the
    // existing contract asset first; any excess becomes a contract liability.
    const reduction = Math.abs(revenueThisPeriod);
    const assetReduction = r2(Math.min(reduction, priorContractAsset));
    const liabilityIncrease = r2(reduction - assetReduction);
    lines.push({
      account: "440000",
      bp: c.counterparty,
      cc: c.cc,
      desc: `Revenue estimate revision – ${c.no}`,
      dr: reduction,
    });
    if (assetReduction > 0) {
      lines.push({
        account: "143000",
        bp: c.counterparty,
        cc: c.cc,
        desc: `Reduce contract asset – ${c.no}`,
        cr: assetReduction,
      });
    }
    if (liabilityIncrease > 0) {
      lines.push({
        account: "222000",
        bp: c.counterparty,
        cc: c.cc,
        desc: `Increase contract liability – ${c.no}`,
        cr: liabilityIncrease,
      });
    }
  }

  // Reserve the new cumulative state with an optimistic lock before posting.
  // If another user recognised this contract from the same starting values,
  // only one update succeeds; the other receives a clear retry message instead
  // of duplicating revenue.
  const reserved = await db
    .update(contracts)
    .set({
      recognisedRevenue: String(revenueToDate),
      recognisedCost: String(actualCostToDate),
      pctComplete: String(pct),
    })
    .where(
      and(
        eq(contracts.id, c.id),
        eq(contracts.clientId, clientId),
        eq(contracts.recognisedRevenue, String(c.recognisedRevenue)),
        eq(contracts.recognisedCost, String(c.recognisedCost))
      )
    )
    .returning({ id: contracts.id });
  if (!reserved.length)
    throw new PostingError(
      `${c.no} changed while you were working. Reload it and run recognition again.`
    );

  // Costs were expensed when incurred, so the recognition journal contains
  // revenue / contract-position lines only.
  let doc = "";
  try {
    if (lines.length > 0) {
      doc = await postChecked(clientId, {
        period: input.period,
        module: "SD",
        docType: "RV",
        user: input.user,
        reference: `IFRS 15 recognition ${c.no} – ${pct.toFixed(1)}% complete`,
        lines,
      });
    }
  } catch (error) {
    // Release the reservation if posting failed.
    await db
      .update(contracts)
      .set({
        recognisedRevenue: String(c.recognisedRevenue),
        recognisedCost: String(c.recognisedCost),
        pctComplete: String(c.pctComplete),
      })
      .where(
        and(
          eq(contracts.id, c.id),
          eq(contracts.recognisedRevenue, String(revenueToDate)),
          eq(contracts.recognisedCost, String(actualCostToDate))
        )
      );
    throw error;
  }

  const profit = r2(revenueThisPeriod - costThisPeriod);
  const netPosition = r2(revenueToDate - c.billed - c.advances);
  return {
    doc,
    revenueThisPeriod,
    costThisPeriod,
    profit,
    pctComplete: pct,
    contractAsset: r2(Math.max(0, netPosition)),
    contractLiability: r2(Math.max(0, -netPosition)),
    message: `${c.no}: revenue ₵${revenueThisPeriod.toFixed(2)} recognised (${pct.toFixed(1)}% complete)${doc ? ` → doc ${doc}` : ""}. Actual contract cost added since the prior run: ₵${costThisPeriod.toFixed(2)}. Period contract margin: ₵${profit.toFixed(2)}.`,
  };
}

/** Raise an interim payment certificate against work certified to date. */
export async function raiseCertificate(
  clientId: number,
  input: { contractId: number; period: string; grossValue?: number; surveyedPct?: number; user?: string }
) {
  const c = await getContract(clientId, input.contractId);
  if (!c) throw new PostingError("Contract not found in this workspace.");
  if (c.status !== "active") throw new PostingError(`Contract ${c.no} is ${c.status}.`);
  await assertPeriodOpen(clientId, input.period);

  const pct = input.surveyedPct !== undefined && input.surveyedPct > 0 ? r2(input.surveyedPct) : c.pctComplete;
  const valueCertified = r2((c.totalValue * pct) / 100);
  const previouslyCertified = c.billed;
  const gross = input.grossValue && input.grossValue > 0 ? r2(input.grossValue) : r2(valueCertified - previouslyCertified);
  if (gross <= 0) throw new PostingError(`No new value to certify on ${c.no} — ${pct.toFixed(1)}% complete equals ₵${valueCertified.toFixed(2)} already certified.`);
  if (previouslyCertified + gross > c.totalValue + 0.009)
    throw new PostingError(
      `Certificate would exceed the contract value by ₵${(previouslyCertified + gross - c.totalValue).toFixed(2)}. Record an approved variation before certifying it.`
    );

  const retention = r2((gross * c.retentionPct) / 100);
  const net = r2(gross - retention);
  // Reserve a database sequence value first. This is concurrency-safe even if
  // two quantity surveyors issue certificates at the same instant.
  const seqResult = await db.execute<{ id: number }>(
    sql`select nextval('contract_certificates_id_seq')::int as id`
  );
  const certificateId = Number(seqResult.rows[0]?.id);
  const certNo = `${c.no}-IPC${String(certificateId).padStart(4, "0")}`;

  const result = await db.transaction(async (tx) => {
    // Reserve cumulative totals atomically. The optimistic lock stops two
    // simultaneous certificates from overwriting each other.
    const reservation = await tx
      .update(contracts)
      .set({
        billed: sql`${contracts.billed} + ${gross}`,
        retentionHeld: sql`${contracts.retentionHeld} + ${retention}`,
        pctComplete: String(pct),
      })
      .where(
        and(
          eq(contracts.id, c.id),
          eq(contracts.clientId, clientId),
          eq(contracts.billed, String(c.billed)),
          sql`${contracts.billed} + ${gross} <= ${contracts.totalValue}`
        )
      )
      .returning({ id: contracts.id });
    if (!reservation.length)
      throw new PostingError(
        `${c.no} changed while this certificate was being prepared, or the contract value would be exceeded. Reload and try again.`
      );

    const preCertificateNet = r2(
      c.recognisedRevenue - c.billed - c.advances
    );
    const availableContractAsset = Math.max(0, preCertificateNet);
    const { assetBilled, overBilling } = certificateAllocation(
      gross,
      availableContractAsset
    );
    const billingLines: JLine[] = [
      {
        account: "110000",
        bp: c.counterparty,
        desc: `Interim certificate ${certNo} – ${c.title}`,
        dr: gross,
      },
    ];
    if (assetBilled > 0) {
      billingLines.push({
        account: "143000",
        bp: c.counterparty,
        cc: c.cc,
        desc: `Contract asset billed – ${c.no}`,
        cr: assetBilled,
      });
    }
    if (overBilling > 0) {
      billingLines.push({
        account: "222000",
        bp: c.counterparty,
        cc: c.cc,
        desc: `Contract liability – overbilling on ${c.no}`,
        cr: overBilling,
      });
    }
    if (retention > 0) {
      billingLines.push({
        account: "116000",
        bp: c.counterparty,
        desc: `Retention held – ${certNo}`,
        dr: retention,
      });
      billingLines.push({
        account: "110000",
        bp: c.counterparty,
        desc: `Retention reclassified from receivable – ${certNo}`,
        cr: retention,
      });
    }

    const doc = await post(tx as never, {
      clientId,
      date: new Date().toISOString().slice(0, 10),
      period: input.period,
      module: "SD",
      docType: "RV",
      user: input.user,
      reference: `${certNo} (retention ${c.retentionPct}%)`,
      lines: billingLines,
    });

    await tx.insert(contractCertificates).values({
      id: certificateId,
      clientId,
      contractId: c.id,
      certNo,
      period: input.period,
      certDate: new Date().toISOString().slice(0, 10),
      grossValue: String(gross),
      retention: String(retention),
      netPayable: String(net),
      cumulativePct: String(pct),
      docNo: doc,
      status: "open",
      createdBy: input.user ?? "",
    });

    const invoiceRow = await tx
      .insert(invoices)
      .values({
        clientId,
        direction: "sales",
        docType: "invoice",
        no: certNo,
        bp: c.counterparty,
        currency: "GHS",
        rate: "1",
        subtotal: String(net),
        vat: "0",
        total: String(net),
        status: "open",
        period: input.period,
        docNo: doc,
        note: `Interim payment certificate – ${c.title}; retention ₵${retention.toFixed(2)}`,
        paid: "0",
        expenseCategory: "service",
      })
      .returning({ id: invoices.id });

    return { doc, invoiceId: invoiceRow[0].id, assetBilled, overBilling };
  });

  return {
    doc: result.doc,
    invoiceId: result.invoiceId,
    certNo,
    gross,
    retention,
    net,
    assetBilled: result.assetBilled,
    overBilling: result.overBilling,
    message: `${certNo} raised: gross ₵${gross.toFixed(2)}, retention ₵${retention.toFixed(2)} (${c.retentionPct}%), net ₵${net.toFixed(2)} → doc ${result.doc}. Receivable now due from ${c.counterparty}.`,
  };
}

export async function reviseContract(
  clientId: number,
  input: {
    contractId: number;
    newValue: number;
    newEstimatedCost: number;
    period: string;
    description: string;
    approvedBy: string;
    user?: string;
  }
) {
  const c = await getContract(clientId, input.contractId);
  if (!c) throw new PostingError("Contract not found in this workspace.");
  if (c.status !== "active") throw new PostingError(`Contract ${c.no} is ${c.status}.`);
  if (input.newValue <= 0 || input.newEstimatedCost <= 0)
    throw new PostingError("Revised contract value and estimated cost must be positive.");
  if (!input.description.trim())
    throw new PostingError("Explain the approved variation or estimate revision.");
  if (!input.approvedBy.trim())
    throw new PostingError("Record who approved this revision.");
  await assertPeriodOpen(clientId, input.period);

  const oldProvision = onerousLoss(c.totalValue, c.estimatedCost);
  const newProvision = onerousLoss(input.newValue, input.newEstimatedCost);
  const provisionDelta = r2(newProvision - oldProvision);

  return db.transaction(async (tx) => {
    let doc = "";
    if (Math.abs(provisionDelta) >= 0.005) {
      const lines: JLine[] =
        provisionDelta > 0
          ? [
              {
                account: "508000",
                cc: c.cc,
                desc: `Increase onerous contract loss – ${c.no}`,
                dr: provisionDelta,
              },
              {
                account: "293000",
                desc: `Increase onerous provision – ${c.no}`,
                cr: provisionDelta,
              },
            ]
          : [
              {
                account: "293000",
                desc: `Release onerous provision – ${c.no}`,
                dr: Math.abs(provisionDelta),
              },
              {
                account: "493000",
                cc: c.cc,
                desc: `Reversal of onerous provision – ${c.no}`,
                cr: Math.abs(provisionDelta),
              },
            ];
      doc = await post(tx as never, {
        clientId,
        date: new Date().toISOString().slice(0, 10),
        period: input.period,
        module: "SD",
        docType: "CON",
        user: input.user,
        reference: `${c.no} revision – ${input.description}`,
        lines,
      });
    }

    await tx.insert(contractVariations).values({
      clientId,
      contractId: c.id,
      period: input.period,
      kind: input.newValue !== c.totalValue ? "variation" : "estimate_revision",
      oldValue: String(c.totalValue),
      newValue: String(input.newValue),
      oldEstimatedCost: String(c.estimatedCost),
      newEstimatedCost: String(input.newEstimatedCost),
      description: input.description,
      approvedBy: input.approvedBy,
    });

    await tx
      .update(contracts)
      .set({
        totalValue: String(input.newValue),
        estimatedCost: String(input.newEstimatedCost),
        lossProvision: String(newProvision),
      })
      .where(and(eq(contracts.id, c.id), eq(contracts.clientId, clientId)));

    return {
      doc,
      provisionDelta,
      message: `${c.no} revised: value ₵${input.newValue.toFixed(2)}, estimated cost ₵${input.newEstimatedCost.toFixed(2)}. ${provisionDelta > 0 ? `Onerous provision increased by ₵${provisionDelta.toFixed(2)}.` : provisionDelta < 0 ? `Provision released by ₵${Math.abs(provisionDelta).toFixed(2)}.` : "No provision adjustment."}`,
    };
  });
}

export async function releaseRetention(
  clientId: number,
  input: {
    contractId: number;
    amount?: number;
    period: string;
    user?: string;
  }
) {
  const c = await getContract(clientId, input.contractId);
  if (!c) throw new PostingError("Contract not found in this workspace.");
  await assertPeriodOpen(clientId, input.period);
  const outstanding = r2(c.retentionHeld - c.retentionReleased);
  const amount = r2(input.amount && input.amount > 0 ? input.amount : outstanding);
  if (amount <= 0) throw new PostingError(`No retention remains to release on ${c.no}.`);
  if (amount > outstanding + 0.009)
    throw new PostingError(
      `Release exceeds outstanding retention (₵${outstanding.toFixed(2)}).`
    );

  return db.transaction(async (tx) => {
    const seqResult = await tx.execute<{ id: number }>(
      sql`select nextval('invoices_id_seq')::int as id`
    );
    const invoiceId = Number(seqResult.rows[0]?.id);
    const no = `${c.no}-RET${String(invoiceId).padStart(4, "0")}`;
    const doc = await post(tx as never, {
      clientId,
      date: new Date().toISOString().slice(0, 10),
      period: input.period,
      module: "SD",
      docType: "RV",
      user: input.user,
      reference: `${no} retention release`,
      lines: [
        {
          account: "110000",
          bp: c.counterparty,
          desc: `Retention now due – ${c.no}`,
          dr: amount,
        },
        {
          account: "116000",
          bp: c.counterparty,
          desc: `Release retention receivable – ${c.no}`,
          cr: amount,
        },
      ],
    });

    await tx.insert(invoices).values({
      id: invoiceId,
      clientId,
      direction: "sales",
      docType: "invoice",
      no,
      bp: c.counterparty,
      currency: "GHS",
      rate: "1",
      subtotal: String(amount),
      vat: "0",
      total: String(amount),
      status: "open",
      period: input.period,
      docNo: doc,
      note: `Retention release – ${c.title}`,
      paid: "0",
      expenseCategory: "service",
    });

    await tx
      .update(contracts)
      .set({ retentionReleased: sql`${contracts.retentionReleased} + ${amount}` })
      .where(and(eq(contracts.id, c.id), eq(contracts.clientId, clientId)));

    return {
      doc,
      invoiceId,
      no,
      amount,
      message: `Retention ₵${amount.toFixed(2)} released on ${c.no} as ${no}. It is now available for receipt at the Payment Desk.`,
    };
  });
}

export async function listVariations(clientId: number, contractId?: number) {
  const where = contractId
    ? and(
        eq(contractVariations.clientId, clientId),
        eq(contractVariations.contractId, contractId)
      )
    : eq(contractVariations.clientId, clientId);
  return db
    .select()
    .from(contractVariations)
    .where(where)
    .orderBy(desc(contractVariations.id))
    .limit(200);
}

export async function listCertificates(clientId: number, contractId?: number) {
  const where = contractId
    ? and(eq(contractCertificates.clientId, clientId), eq(contractCertificates.contractId, contractId))
    : eq(contractCertificates.clientId, clientId);
  return db.select().from(contractCertificates).where(where).orderBy(desc(contractCertificates.id)).limit(200);
}

export async function listContractCosts(clientId: number, contractId: number) {
  return db
    .select()
    .from(contractCosts)
    .where(and(eq(contractCosts.clientId, clientId), eq(contractCosts.contractId, contractId)))
    .orderBy(desc(contractCosts.id))
    .limit(200);
}

/** Portfolio view — the IFRS 15 disclosure schedule across all contracts. */
export async function contractPortfolio(clientId: number) {
  const all = await listContracts(clientId);
  const active = all.filter((c) => c.status === "active");
  return {
    all,
    active,
    totals: {
      value: r2(active.reduce((s, c) => s + c.totalValue, 0)),
      revenue: r2(active.reduce((s, c) => s + c.revenueToDate, 0)),
      cost: r2(active.reduce((s, c) => s + c.costToDate, 0)),
      contractAssets: r2(active.reduce((s, c) => s + c.contractAsset, 0)),
      contractLiabilities: r2(active.reduce((s, c) => s + c.contractLiability, 0)),
      retention: r2(active.reduce((s, c) => s + c.retentionHeld, 0)),
      expectedProfit: r2(active.reduce((s, c) => s + c.expectedProfit, 0)),
      lossProvision: r2(all.reduce((s, c) => s + (c.isLossMaking ? c.lossProvision : 0), 0)),
    },
    lossMaking: all.filter((c) => c.isLossMaking),
  };
}

/** Record the receipt of a certified amount (from the payment desk). */
export async function receiveCertificatePayment(
  clientId: number,
  input: { certificateId: number; amount: number; period: string; user?: string }
) {
  const cert = (
    await db
      .select()
      .from(contractCertificates)
      .where(and(eq(contractCertificates.clientId, clientId), eq(contractCertificates.id, input.certificateId)))
  )[0];
  if (!cert) throw new PostingError("Certificate not found in this workspace.");
  if (cert.status === "paid") throw new PostingError("This certificate is already fully settled.");
  const balance = r2(Number(cert.netPayable) - Number(cert.paid));
  const amount = r2(input.amount) || balance;
  if (amount <= 0) throw new PostingError("Nothing to receive.");
  if (amount > balance + 0.009) throw new PostingError(`Amount exceeds the outstanding certificate balance (₵${balance.toFixed(2)}).`);
  const c = await getContract(clientId, cert.contractId);

  const doc = await postChecked(clientId, {
    period: input.period,
    module: "SD",
    docType: "DZ",
    user: input.user,
    reference: `${cert.certNo} receipt`,
    lines: [
      { account: "101000", desc: `Certificate receipt – ${cert.certNo}`, dr: amount },
      { account: "110000", bp: c?.counterparty, desc: `Settle ${cert.certNo}`, cr: amount },
    ],
  });

  const newPaid = r2(Number(cert.paid) + amount);
  await db
    .update(contractCertificates)
    .set({ paid: String(newPaid), status: newPaid >= Number(cert.netPayable) - 0.009 ? "paid" : "partial" })
    .where(eq(contractCertificates.id, cert.id));

  return { doc, message: `₵${amount.toFixed(2)} received on ${cert.certNo} → doc ${doc}.` };
}
