import { db } from "@/db";
import { fiscalPeriods, journalLines } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { PostingError } from "./posting";

export const thisPeriod = (): string => new Date().toISOString().slice(0, 7);

/** Unlimited fiscal periods — simple YYYY-MM strings. */
export function shiftPeriod(period: string, delta: number): string {
  const [y, m] = period.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}

export function periodLabel(period: string): string {
  const [y, m] = period.split("-").map(Number);
  const names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${names[(m ?? 1) - 1] ?? m} ${y}`;
}

export async function periodStatus(clientId: number, period: string): Promise<"open" | "closed"> {
  const rows = await db
    .select()
    .from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, clientId), eq(fiscalPeriods.period, period)));
  return rows[0]?.status === "closed" ? "closed" : "open";
}

export async function assertPeriodOpen(clientId: number, period: string) {
  const status = await periodStatus(clientId, period);
  if (status === "closed")
    throw new PostingError(
      `Period ${periodLabel(period)} is closed for this workspace. Reopen it from Month-End Close before posting.`
    );
}

export async function closePeriod(clientId: number, period: string, user: string) {
  const lines = await db
    .select({ n: journalLines.id })
    .from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.period, period)));
  const count = lines.length;
  await db
    .insert(fiscalPeriods)
    .values({ clientId, period, status: "closed", closedBy: user, closedAt: new Date() })
    .onConflictDoUpdate({
      target: [fiscalPeriods.clientId, fiscalPeriods.period],
      set: { status: "closed", closedBy: user, closedAt: new Date() },
    });
  return { count };
}

export async function openPeriod(clientId: number, period: string, user: string) {
  await db
    .insert(fiscalPeriods)
    .values({ clientId, period, status: "open", closedBy: user, closedAt: null })
    .onConflictDoUpdate({
      target: [fiscalPeriods.clientId, fiscalPeriods.period],
      set: { status: "open", closedBy: user, closedAt: null },
    });
}

export async function listClosedPeriods(clientId: number) {
  const rows = await db
    .select()
    .from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, clientId), eq(fiscalPeriods.status, "closed")))
    .orderBy(fiscalPeriods.period);
  return rows;
}
