/**
 * IAS 1 Notes to the Financial Statements — full disclosure pack.
 * Generates audit-ready notes from live Universal Journal + standards desks.
 * Notes that do not apply say so honestly rather than printing empty tables.
 */
import { db } from "@/db";
import {
  accounts,
  assets,
  leases,
  financialInstruments,
  eclAssessments,
  impairmentTests,
  heldForSale,
  loans,
  contracts,
  invoices,
  partners,
  journalLines,
  disclosureNotes,
  accountingPolicies,
  operatingSegments,
  relatedParties,
  relatedPartyTxns,
  provisions,
  employeeBenefitPlans,
  fairValueMeasurements,
  epsComputations,
  deferredTaxItems,
  subsequentEvents,
  contingencies,
  riskDisclosures,
  shareCapital,
  hyperinflationFactors,
  payrollRuns,
  clients,
} from "@/db/schema";
import { and, eq, sql, desc, asc } from "drizzle-orm";
import { trialBalance, pnl, balanceSheet, cashFlow, aging } from "./reports";
import { ensureSeed } from "./init";

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const money = (n: number) =>
  r2(n).toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export type NoteBlock = {
  key: string;
  title: string;
  standardRef: string;
  applicable: boolean;
  notApplicableReason?: string;
  body: string;
  tables?: { headers: string[]; rows: (string | number)[][] }[];
  sortOrder: number;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sumExpr = (col: any) => sql<number>`coalesce(sum(${col}), 0)::float8`;

async function accBal(clientId: number, acc: string, from?: string, to?: string) {
  const rows = await db
    .select({ dr: sumExpr(journalLines.debit), cr: sumExpr(journalLines.credit) })
    .from(journalLines)
    .where(
      and(
        eq(journalLines.clientId, clientId),
        eq(journalLines.account, acc),
        from ? sql`${journalLines.period} >= ${from}` : undefined,
        to ? sql`${journalLines.period} <= ${to}` : undefined
      )
    );
  return (rows[0]?.dr ?? 0) - (rows[0]?.cr ?? 0);
}

async function typeBals(clientId: number, type: string, from?: string, to?: string) {
  const { rows } = await trialBalance(clientId, from, to);
  return rows.filter((r) => r.type === type);
}

/** Default significant accounting policies (IAS 1 / IAS 8). */
export const DEFAULT_POLICIES: { key: string; title: string; standardRef: string; body: string; sortOrder: number }[] = [
  {
    key: "basis",
    title: "Basis of preparation",
    standardRef: "IAS 1 / IAS 8",
    sortOrder: 1,
    body:
      "These financial statements have been prepared in accordance with IFRS Accounting Standards as issued by the IASB. The historical cost convention is applied except for financial instruments measured at fair value, biological assets (where applicable), and assets held for sale. The going-concern basis has been adopted. Functional and presentation currency is the Ghana Cedi (GHS) unless a different base currency is configured for the reporting entity. Comparative figures are restated only where required by IAS 8.",
  },
  {
    key: "revenue",
    title: "Revenue recognition",
    standardRef: "IFRS 15",
    sortOrder: 2,
    body:
      "Revenue is recognised when control of goods or services transfers to the customer, at the transaction price allocated to each performance obligation. Long-term construction and service contracts use an over-time method (cost-to-cost or certified output) when the customer simultaneously receives and consumes benefits. Contract assets (unbilled work) and contract liabilities (advances / deferred revenue) are presented separately. Variable consideration is constrained to amounts highly probable not to reverse.",
  },
  {
    key: "ppe",
    title: "Property, plant and equipment",
    standardRef: "IAS 16",
    sortOrder: 3,
    body:
      "PPE is stated at cost less accumulated depreciation and impairment. Depreciation is charged on a straight-line basis over useful lives defined by asset class. Land is not depreciated. Residual values and useful lives are reviewed annually. Subsequent expenditure is capitalised only when future economic benefits are probable and cost can be measured reliably.",
  },
  {
    key: "intangibles",
    title: "Intangible assets",
    standardRef: "IAS 38",
    sortOrder: 4,
    body:
      "Acquired intangibles are capitalised at cost and amortised over their useful lives. Internally generated goodwill is not recognised. Development costs are capitalised only when IAS 38.57 criteria are met; otherwise they are expensed as incurred. Indefinite-life intangibles are tested annually for impairment.",
  },
  {
    key: "leases",
    title: "Leases",
    standardRef: "IFRS 16",
    sortOrder: 5,
    body:
      "At commencement the Group recognises a right-of-use asset and a lease liability equal to the present value of unpaid lease payments, discounted at the incremental borrowing rate (or rate implicit in the lease when readily determinable). ROU assets are depreciated over the shorter of lease term and useful life. Short-term leases (≤12 months) and low-value assets (≤USD 5,000 when new) are expensed on a straight-line basis.",
  },
  {
    key: "inventories",
    title: "Inventories",
    standardRef: "IAS 2",
    sortOrder: 6,
    body:
      "Inventories are measured at the lower of cost and net realisable value. Cost is determined on a weighted-average basis and includes direct materials, direct labour and a systematic allocation of production overheads. NRV is estimated selling price less costs of completion and sale. Write-downs are reversed when NRV recovers.",
  },
  {
    key: "fi",
    title: "Financial instruments",
    standardRef: "IFRS 9 / IFRS 7 / IFRS 13",
    sortOrder: 7,
    body:
      "Financial assets are classified as amortised cost, FVOCI or FVTPL based on the business model and SPPI test. Expected credit losses are recognised on a forward-looking basis using a three-stage model for instruments and a provision matrix for trade receivables. Fair value measurements are categorised within the IFRS 13 hierarchy (Levels 1–3).",
  },
  {
    key: "ecl",
    title: "Impairment of financial assets",
    standardRef: "IFRS 9",
    sortOrder: 8,
    body:
      "The Group applies the simplified approach for trade receivables (lifetime ECL) and the general approach for loans and other instruments (12-month or lifetime ECL depending on significant increase in credit risk). PD × LGD × EAD is discounted at the original effective interest rate. Collateral is reflected in LGD.",
  },
  {
    key: "impairment",
    title: "Impairment of non-financial assets",
    standardRef: "IAS 36",
    sortOrder: 9,
    body:
      "Assets are tested for impairment when indicators exist; CGUs containing goodwill are tested annually. Recoverable amount is the higher of fair value less costs of disposal and value in use (discounted cash flows). Impairments of CGUs are allocated first to goodwill, then pro-rata to other assets. Reversals (except goodwill) are recognised when recoverable amount increases.",
  },
  {
    key: "provisions",
    title: "Provisions, contingent liabilities and contingent assets",
    standardRef: "IAS 37",
    sortOrder: 10,
    body:
      "A provision is recognised when there is a present legal or constructive obligation from a past event, an outflow is probable, and the amount can be estimated reliably. Provisions are measured at the best estimate of expenditure required, discounted where material. Contingent liabilities are disclosed unless the possibility of outflow is remote. Contingent assets are disclosed when inflow is probable and recognised only when virtually certain.",
  },
  {
    key: "employee_benefits",
    title: "Employee benefits",
    standardRef: "IAS 19",
    sortOrder: 11,
    body:
      "Short-term benefits are expensed as the related service is provided. Defined contribution plans (including statutory SSNIT) are expensed when contributions are due. Defined benefit obligations are measured using the projected unit credit method; remeasurements are recognised in OCI. Termination benefits are recognised at the earlier of when the Group can no longer withdraw the offer and when related restructuring costs are recognised.",
  },
  {
    key: "tax",
    title: "Income taxes",
    standardRef: "IAS 12",
    sortOrder: 12,
    body:
      "Current tax is the expected tax payable on taxable profit using rates enacted or substantively enacted at the reporting date. Deferred tax is recognised on temporary differences between carrying amounts and tax bases, using the liability method. Deferred tax assets are recognised to the extent that taxable profit will be available. Tax is recognised in profit or loss except to the extent it relates to items in OCI or equity.",
  },
  {
    key: "fx",
    title: "Foreign currency",
    standardRef: "IAS 21",
    sortOrder: 13,
    body:
      "Transactions in foreign currencies are translated at the spot rate on the transaction date. Monetary assets and liabilities are retranslated at the closing rate; exchange differences are recognised in profit or loss. Non-monetary items measured at historical cost remain at the historical rate. The results and financial position of foreign operations are translated into the presentation currency with exchange differences taken to OCI (CTA).",
  },
  {
    key: "hfs",
    title: "Non-current assets held for sale and discontinued operations",
    standardRef: "IFRS 5",
    sortOrder: 14,
    body:
      "Non-current assets (or disposal groups) are classified as held for sale when their carrying amount will be recovered principally through a sale transaction rather than continuing use. They are measured at the lower of carrying amount and fair value less costs to sell; depreciation ceases on classification. Discontinued operations are presented as a single post-tax amount in the statement of profit or loss.",
  },
  {
    key: "eps_policy",
    title: "Earnings per share",
    standardRef: "IAS 33",
    sortOrder: 15,
    body:
      "Basic EPS is calculated by dividing profit attributable to ordinary equity holders by the weighted average number of ordinary shares outstanding. Diluted EPS adjusts for the effects of all dilutive potential ordinary shares. EPS is presented for continuing and discontinued operations.",
  },
  {
    key: "segments_policy",
    title: "Operating segments",
    standardRef: "IFRS 8",
    sortOrder: 16,
    body:
      "Segment information is reported consistently with internal reports provided to the chief operating decision maker. Reportable segments are operating segments that exceed quantitative thresholds, or that management believes are useful to users. Inter-segment transactions are measured on the basis used internally.",
  },
  {
    key: "related_policy",
    title: "Related parties",
    standardRef: "IAS 24",
    sortOrder: 17,
    body:
      "Related-party relationships, transactions and outstanding balances (including commitments) are disclosed. Key management personnel compensation is disclosed in total and by category. Terms that differ from arm's-length are highlighted.",
  },
  {
    key: "borrowings",
    title: "Borrowings and borrowing costs",
    standardRef: "IFRS 9 / IAS 23",
    sortOrder: 18,
    body:
      "Borrowings are initially recognised at fair value net of transaction costs and subsequently at amortised cost using the effective interest method. Borrowing costs directly attributable to the acquisition, construction or production of a qualifying asset are capitalised; other borrowing costs are expensed.",
  },
  {
    key: "investment_property",
    title: "Investment property",
    standardRef: "IAS 40",
    sortOrder: 19,
    body:
      "Investment property is property held to earn rentals or for capital appreciation. The Group elects the cost model (cost less depreciation and impairment) unless fair value is elected in the entity policy pack. Fair value, when disclosed, is measured under IFRS 13.",
  },
  {
    key: "hyperinflation",
    title: "Hyperinflationary economies",
    standardRef: "IAS 29",
    sortOrder: 20,
    body:
      "When the functional currency is that of a hyperinflationary economy, the financial statements are restated in terms of the measuring unit current at the reporting date using a general price index. The gain or loss on the net monetary position is included in profit or loss. Comparative amounts are also restated.",
  },
];

/** Build the full Notes to Accounts pack for a workspace + period. */
export async function buildNotesToAccounts(
  clientId: number,
  from?: string,
  to?: string
): Promise<{ periodLabel: string; notes: NoteBlock[]; policies: typeof DEFAULT_POLICIES }> {
  await ensureSeed();
  const periodLabel = from && to ? (from === to ? from : `${from} to ${to}`) : to || from || "YTD";
  const periodKey = to || from || new Date().toISOString().slice(0, 7);

  const client = (await db.select().from(clients).where(eq(clients.id, clientId)))[0];
  const { rows: tb } = await trialBalance(clientId, from, to);
  const pl = await pnl(clientId, from, to);
  const bs = await balanceSheet(clientId, from, to);
  const cf = await cashFlow(clientId, from, to);

  const assetRows = await db.select().from(assets).where(eq(assets.clientId, clientId));
  const leaseRows = await db.select().from(leases).where(and(eq(leases.clientId, clientId), eq(leases.status, "active")));
  const fiRows = await db.select().from(financialInstruments).where(eq(financialInstruments.clientId, clientId));
  const eclRows = await db
    .select()
    .from(eclAssessments)
    .where(eq(eclAssessments.clientId, clientId))
    .orderBy(desc(eclAssessments.createdAt));
  const impRows = await db.select().from(impairmentTests).where(eq(impairmentTests.clientId, clientId));
  const hfsRows = await db.select().from(heldForSale).where(eq(heldForSale.clientId, clientId));
  const loanRows = await db.select().from(loans).where(eq(loans.clientId, clientId));
  const contractRows = await db.select().from(contracts).where(eq(contracts.clientId, clientId));
  const segRows = await db.select().from(operatingSegments).where(and(eq(operatingSegments.clientId, clientId), eq(operatingSegments.active, true)));
  const rpRows = await db.select().from(relatedParties).where(and(eq(relatedParties.clientId, clientId), eq(relatedParties.active, true)));
  const rptRows = await db.select().from(relatedPartyTxns).where(eq(relatedPartyTxns.clientId, clientId));
  const provRows = await db.select().from(provisions).where(eq(provisions.clientId, clientId));
  const ebpRows = await db.select().from(employeeBenefitPlans).where(eq(employeeBenefitPlans.clientId, clientId));
  const fvRows = await db.select().from(fairValueMeasurements).where(eq(fairValueMeasurements.clientId, clientId));
  const epsRows = await db.select().from(epsComputations).where(eq(epsComputations.clientId, clientId));
  const dtRows = await db.select().from(deferredTaxItems).where(eq(deferredTaxItems.clientId, clientId));
  const seRows = await db.select().from(subsequentEvents).where(eq(subsequentEvents.clientId, clientId));
  const contRows = await db.select().from(contingencies).where(eq(contingencies.clientId, clientId));
  const riskRows = await db.select().from(riskDisclosures).where(eq(riskDisclosures.clientId, clientId));
  const scRows = await db.select().from(shareCapital).where(eq(shareCapital.clientId, clientId));
  const hypRows = await db.select().from(hyperinflationFactors).where(eq(hyperinflationFactors.clientId, clientId));
  const payRows = await db.select().from(payrollRuns).where(eq(payrollRuns.clientId, clientId));
  const arAging = await aging(clientId, "AR");
  const apAging = await aging(clientId, "AP");

  // inventory balances
  const invAccs = ["120000", "121000", "122000", "123000", "124000"];
  const invDetail = await Promise.all(
    invAccs.map(async (a) => {
      const acc = (await db.select().from(accounts).where(eq(accounts.accountNo, a)))[0];
      const bal = await accBal(clientId, a, from, to);
      return { account: a, description: acc?.description ?? a, bal };
    })
  );
  const invTotal = invDetail.reduce((s, r) => s + r.bal, 0);

  // PPE movement
  const ppeCost = assetRows.reduce((s, a) => s + Number(a.cost), 0);
  const ppeAccum = assetRows.reduce((s, a) => s + Number(a.accumDep), 0);
  const ppeNbv = assetRows.reduce((s, a) => s + Number(a.nbv), 0);

  const notes: NoteBlock[] = [];

  // 1. Basis of preparation
  notes.push({
    key: "basis",
    title: "1. Basis of preparation",
    standardRef: "IAS 1",
    applicable: true,
    sortOrder: 1,
    body: `These financial statements of ${client?.name ?? "the Entity"} have been prepared in accordance with IFRS Accounting Standards. Presentation currency: ${client?.baseCurrency ?? "GHS"}. Sector profile: ${client?.sector ?? "general"}. Reporting period: ${periodLabel}. The statements comprise the statement of financial position, statement of profit or loss and other comprehensive income, statement of changes in equity, statement of cash flows and notes. Materiality is assessed quantitatively and qualitatively per IAS 1 and IAS 8.`,
  });

  // 2. Significant accounting policies
  notes.push({
    key: "policies",
    title: "2. Significant accounting policies",
    standardRef: "IAS 1 / IAS 8",
    applicable: true,
    sortOrder: 2,
    body: "The principal accounting policies applied are set out below and have been applied consistently unless otherwise stated. Full policy text is maintained in the Accounting Policies register and exported with this pack.",
    tables: [
      {
        headers: ["Policy", "Standard"],
        rows: DEFAULT_POLICIES.map((p) => [p.title, p.standardRef]),
      },
    ],
  });

  // 3. PPE movement
  if (assetRows.length === 0) {
    notes.push({
      key: "ppe",
      title: "3. Property, plant and equipment",
      standardRef: "IAS 16",
      applicable: false,
      notApplicableReason: "No PPE items are registered in the fixed-asset module for this entity/period.",
      sortOrder: 3,
      body: "Not applicable — the entity holds no property, plant and equipment at the reporting date.",
    });
  } else {
    notes.push({
      key: "ppe",
      title: "3. Property, plant and equipment",
      standardRef: "IAS 16",
      applicable: true,
      sortOrder: 3,
      body: `PPE is carried at cost less accumulated depreciation and impairment. Total cost ${money(ppeCost)}; accumulated depreciation ${money(ppeAccum)}; net book value ${money(ppeNbv)}.`,
      tables: [
        {
          headers: ["Asset", "Class", "Cost", "Accum. dep.", "NBV", "In service", "Active"],
          rows: assetRows.map((a) => [
            a.name,
            a.classCode,
            money(Number(a.cost)),
            money(Number(a.accumDep)),
            money(Number(a.nbv)),
            a.inService,
            a.active ? "Yes" : "No",
          ]),
        },
      ],
    });
  }

  // 4. Intangibles
  const intangBal = await accBal(clientId, "140000", from, to);
  notes.push({
    key: "intangibles",
    title: "4. Intangible assets",
    standardRef: "IAS 38",
    applicable: Math.abs(intangBal) > 0.01,
    notApplicableReason: Math.abs(intangBal) < 0.01 ? "No intangible asset balances in the Universal Journal." : undefined,
    sortOrder: 4,
    body:
      Math.abs(intangBal) > 0.01
        ? `Intangible assets carrying amount ${money(Math.abs(intangBal))}. Amortisation is recognised within operating expenses.`
        : "Not applicable — no intangible assets recognised.",
  });

  // 5. ROU & lease liabilities
  if (leaseRows.length === 0) {
    notes.push({
      key: "leases",
      title: "5. Right-of-use assets and lease liabilities",
      standardRef: "IFRS 16",
      applicable: false,
      notApplicableReason: "No active leases on the IFRS 16 desk.",
      sortOrder: 5,
      body: "Not applicable — the entity has no leases requiring recognition under IFRS 16. Short-term and low-value exemptions, if used, are expensed in profit or loss.",
    });
  } else {
    const rou = leaseRows.reduce((s, l) => s + Number(l.rouAsset) - Number(l.accumulatedDepreciation), 0);
    const liab = leaseRows.reduce((s, l) => s + Number(l.leaseLiability), 0);
    notes.push({
      key: "leases",
      title: "5. Right-of-use assets and lease liabilities",
      standardRef: "IFRS 16",
      applicable: true,
      sortOrder: 5,
      body: `Aggregate ROU carrying amount ${money(rou)}; aggregate lease liability ${money(liab)}. Maturity analysis and depreciation by class are maintained on the IFRS 16 desk.`,
      tables: [
        {
          headers: ["Code", "Description", "Lessor", "Term (m)", "Payment", "Discount %", "ROU", "Accum dep", "Liability"],
          rows: leaseRows.map((l) => [
            l.code,
            l.description,
            l.lessor,
            l.termMonths,
            money(Number(l.payment)),
            Number(l.discountRate),
            money(Number(l.rouAsset)),
            money(Number(l.accumulatedDepreciation)),
            money(Number(l.leaseLiability)),
          ]),
        },
      ],
    });
  }

  // 6. Investment property
  const ipBal = await accBal(clientId, "138500", from, to);
  notes.push({
    key: "investment_property",
    title: "6. Investment property",
    standardRef: "IAS 40",
    applicable: Math.abs(ipBal) > 0.01,
    notApplicableReason: Math.abs(ipBal) < 0.01 ? "No investment property balances." : undefined,
    sortOrder: 6,
    body:
      Math.abs(ipBal) > 0.01
        ? `Investment property carrying amount ${money(Math.abs(ipBal))} (cost model unless fair-value election is recorded on the IFRS 13 desk).`
        : "Not applicable — the entity does not hold investment property.",
  });

  // 7. Inventories
  if (Math.abs(invTotal) < 0.01) {
    notes.push({
      key: "inventories",
      title: "7. Inventories",
      standardRef: "IAS 2",
      applicable: false,
      notApplicableReason: "No inventory balances in the Universal Journal.",
      sortOrder: 7,
      body: "Not applicable — the entity holds no inventories at the reporting date.",
    });
  } else {
    notes.push({
      key: "inventories",
      title: "7. Inventories",
      standardRef: "IAS 2",
      applicable: true,
      sortOrder: 7,
      body: `Inventories are measured at the lower of cost and NRV. Total carrying amount ${money(invTotal)}.`,
      tables: [
        {
          headers: ["Account", "Description", "Carrying amount"],
          rows: invDetail.filter((r) => Math.abs(r.bal) > 0.01).map((r) => [r.account, r.description, money(r.bal)]),
        },
      ],
    });
  }

  // 8. Receivables & ECL
  const arBal = await accBal(clientId, "110000", from, to);
  const eclAllow = fiRows.reduce((s, f) => s + Number(f.eclAllowance), 0);
  notes.push({
    key: "receivables_ecl",
    title: "8. Trade and other receivables & expected credit losses",
    standardRef: "IFRS 9 / IFRS 7",
    applicable: Math.abs(arBal) > 0.01 || fiRows.length > 0 || eclRows.length > 0,
    notApplicableReason:
      Math.abs(arBal) < 0.01 && fiRows.length === 0
        ? "No trade receivables or financial instruments requiring ECL."
        : undefined,
    sortOrder: 8,
    body:
      Math.abs(arBal) > 0.01 || fiRows.length > 0
        ? `Gross trade receivables ${money(Math.max(0, arBal))}. Lifetime ECL / stage allowances ${money(eclAllow)}. Aging and stage movements are shown below.`
        : "Not applicable.",
    tables: [
      {
        headers: ["BP", "Name", "Total", "B0", "B1", "B2", "B3", "B4"],
        rows: Array.isArray(arAging)
          ? (arAging as { bp: string; name: string; total: number; buckets: number[] }[]).slice(0, 20).map((b) => [
              b.bp,
              b.name,
              money(Number(b.total)),
              ...(b.buckets || []).map((x) => money(Number(x))),
            ])
          : [["—", "No AR aging", "0", "0", "0", "0", "0", "0"]],
      },
      fiRows.length
        ? {
            headers: ["Instrument", "Category", "Stage", "Carrying amount", "ECL allowance"],
            rows: fiRows.map((f) => [
              f.code,
              f.category,
              f.stage,
              money(Number(f.carryingAmount)),
              money(Number(f.eclAllowance)),
            ]),
          }
        : { headers: ["Note"], rows: [["No IFRS 9 instruments on register"]] },
    ],
  });

  // 9. Financial instrument classification & FV
  if (fiRows.length === 0 && fvRows.length === 0) {
    notes.push({
      key: "fi_class",
      title: "9. Financial instrument classification & fair value",
      standardRef: "IFRS 9 / IFRS 13",
      applicable: false,
      notApplicableReason: "No financial instruments or fair-value measurements registered.",
      sortOrder: 9,
      body: "Not applicable — beyond routine trade receivables/payables measured at amortised cost, no additional financial instruments are held.",
    });
  } else {
    notes.push({
      key: "fi_class",
      title: "9. Financial instrument classification & fair value",
      standardRef: "IFRS 9 / IFRS 13",
      applicable: true,
      sortOrder: 9,
      body: "Classification follows the business-model and SPPI tests. Fair value hierarchy disclosures follow IFRS 13.",
      tables: [
        fiRows.length
          ? {
              headers: ["Code", "Name", "Category", "Type", "Principal", "EIR %", "Carrying", "Stage"],
              rows: fiRows.map((f) => [
                f.code,
                f.name,
                f.category,
                f.instrumentType,
                money(Number(f.principal)),
                Number(f.effectiveRate),
                money(Number(f.carryingAmount)),
                f.stage,
              ]),
            }
          : { headers: ["—"], rows: [["No instruments"]] },
        fvRows.length
          ? {
              headers: ["Code", "Description", "Level", "Technique", "Carrying", "Fair value", "Unrealised"],
              rows: fvRows.map((f) => [
                f.code,
                f.description,
                f.level,
                f.valuationTechnique,
                money(Number(f.carryingAmount)),
                money(Number(f.fairValue)),
                money(Number(f.unrealisedGainLoss)),
              ]),
            }
          : { headers: ["IFRS 13"], rows: [["No Level 1–3 measurements recorded this period"]] },
      ],
    });
  }

  // 10. Loans & borrowings
  if (loanRows.length === 0) {
    notes.push({
      key: "loans",
      title: "10. Loans and borrowings",
      standardRef: "IFRS 9 / IFRS 7",
      applicable: false,
      notApplicableReason: "No loan facilities on the loans desk.",
      sortOrder: 10,
      body: "Not applicable — the entity has no interest-bearing borrowings at the reporting date.",
    });
  } else {
    notes.push({
      key: "loans",
      title: "10. Loans and borrowings",
      standardRef: "IFRS 9 / IFRS 7",
      applicable: true,
      sortOrder: 10,
      body: "Borrowings are measured at amortised cost using the effective interest method. Schedules are maintained per facility.",
      tables: [
        {
          headers: ["Code", "Lender", "Type", "Principal", "Rate %", "Term (m)", "Outstanding", "Status"],
          rows: loanRows.map((l) => [
            l.code,
            l.lender,
            l.facilityType,
            money(Number(l.principal)),
            Number(l.annualRate),
            l.termMonths,
            money(Number(l.outstanding)),
            l.status,
          ]),
        },
      ],
    });
  }

  // 11. Contract balances (IFRS 15)
  if (contractRows.length === 0) {
    notes.push({
      key: "contracts",
      title: "11. Contract balances",
      standardRef: "IFRS 15",
      applicable: false,
      notApplicableReason: "No long-term contracts on the projects desk.",
      sortOrder: 11,
      body: "Not applicable — revenue is recognised at a point in time for standard sales; no material contract assets/liabilities.",
    });
  } else {
    notes.push({
      key: "contracts",
      title: "11. Contract balances",
      standardRef: "IFRS 15",
      applicable: true,
      sortOrder: 11,
      body: "Contract assets represent unbilled performance; contract liabilities represent advances and deferred revenue. Retention is presented within contract assets/liabilities as appropriate.",
      tables: [
        {
          headers: [
            "Contract",
            "Method",
            "Total value",
            "% complete",
            "Revenue recognised",
            "Cost recognised",
            "Billed",
            "Retention held",
            "Status",
          ],
          rows: contractRows.map((c) => [
            c.no,
            c.method,
            money(Number(c.totalValue)),
            Number(c.pctComplete),
            money(Number(c.recognisedRevenue)),
            money(Number(c.recognisedCost)),
            money(Number(c.billed)),
            money(Number(c.retentionHeld)),
            c.status,
          ]),
        },
      ],
    });
  }

  // 12. Revenue disaggregation
  notes.push({
    key: "revenue_disagg",
    title: "12. Revenue disaggregation",
    standardRef: "IFRS 15.114",
    applicable: pl.totalRev > 0.01,
    notApplicableReason: pl.totalRev <= 0.01 ? "No revenue recognised in the period." : undefined,
    sortOrder: 12,
    body:
      pl.totalRev > 0.01
        ? `Total revenue ${money(pl.totalRev)}. Disaggregation by account follows the chart of accounts mapping to performance obligations / sectors.`
        : "Not applicable — no revenue in the period.",
    tables: [
      {
        headers: ["Account", "Description", "Amount"],
        rows: pl.revenue.map((r) => [r.account, r.description, money(r.amount)]),
      },
    ],
  });

  // 13. Operating segments IFRS 8
  if (segRows.length === 0) {
    notes.push({
      key: "segments",
      title: "13. Operating segments",
      standardRef: "IFRS 8",
      applicable: false,
      notApplicableReason:
        "No operating segments have been defined. The entity operates as a single reportable segment; the CODM reviews entity-wide results.",
      sortOrder: 13,
      body: "Not applicable as a multi-segment report — the entity is managed as one operating segment. Entity-wide disclosures of revenue by product/service are given in note 12.",
    });
  } else {
    notes.push({
      key: "segments",
      title: "13. Operating segments",
      standardRef: "IFRS 8",
      applicable: true,
      sortOrder: 13,
      body: "Segment information is based on internal reports reviewed by the chief operating decision maker.",
      tables: [
        {
          headers: [
            "Code",
            "Name",
            "External revenue",
            "Inter-segment",
            "Profit",
            "Assets",
            "Liabilities",
            "Depreciation",
            "Capex",
          ],
          rows: segRows.map((s) => [
            s.code,
            s.name,
            money(Number(s.externalRevenue)),
            money(Number(s.interSegmentRevenue)),
            money(Number(s.segmentProfit)),
            money(Number(s.segmentAssets)),
            money(Number(s.segmentLiabilities)),
            money(Number(s.depreciation)),
            money(Number(s.capitalExpenditure)),
          ]),
        },
      ],
    });
  }

  // 14. Related parties IAS 24
  if (rpRows.length === 0 && rptRows.length === 0) {
    notes.push({
      key: "related_parties",
      title: "14. Related parties",
      standardRef: "IAS 24",
      applicable: false,
      notApplicableReason: "No related parties or related-party transactions have been registered.",
      sortOrder: 14,
      body: "Not applicable — management has identified no related-party relationships requiring disclosure under IAS 24 for this period. Key management compensation, if any, is included in payroll note.",
    });
  } else {
    notes.push({
      key: "related_parties",
      title: "14. Related parties",
      standardRef: "IAS 24",
      applicable: true,
      sortOrder: 14,
      body: "Related-party relationships and transactions are disclosed below. Terms are arm's length unless otherwise stated.",
      tables: [
        rpRows.length
          ? {
              headers: ["Code", "Name", "Relationship", "Control %", "Nature"],
              rows: rpRows.map((r) => [r.code, r.name, r.relationship, Number(r.controlPct), r.nature]),
            }
          : { headers: ["—"], rows: [["No parties on register"]] },
        rptRows.length
          ? {
              headers: ["Period", "Nature", "Description", "Amount", "Outstanding", "Terms"],
              rows: rptRows.map((t) => [
                t.period,
                t.nature,
                t.description,
                money(Number(t.amount)),
                money(Number(t.outstanding)),
                t.terms,
              ]),
            }
          : { headers: ["Transactions"], rows: [["No related-party transactions in period"]] },
      ],
    });
  }

  // 15. Employee benefits IAS 19
  const payeTotal = payRows.reduce((s, p) => s + Number(p.paye), 0);
  const ssnitTotal = payRows.reduce((s, p) => s + Number(p.ssnitT1) + Number(p.ssnitT2), 0);
  if (ebpRows.length === 0 && payRows.length === 0) {
    notes.push({
      key: "employee_benefits",
      title: "15. Employee benefits",
      standardRef: "IAS 19",
      applicable: false,
      notApplicableReason: "No payroll runs or defined-benefit plans recorded.",
      sortOrder: 15,
      body: "Not applicable — the entity has no employees on the payroll desk and no defined-benefit plans for the period.",
    });
  } else {
    notes.push({
      key: "employee_benefits",
      title: "15. Employee benefits",
      standardRef: "IAS 19",
      applicable: true,
      sortOrder: 15,
      body: `Short-term benefits are expensed as incurred. Statutory defined-contribution (SSNIT) expense ${money(ssnitTotal)}; PAYE withheld ${money(payeTotal)}. Defined-benefit / long-service plans are measured under the projected unit credit method where applicable.`,
      tables: [
        ebpRows.length
          ? {
              headers: ["Code", "Name", "Type", "DBO", "Plan assets", "Net liability", "Service cost", "Net interest"],
              rows: ebpRows.map((e) => [
                e.code,
                e.name,
                e.planType,
                money(Number(e.definedBenefitObligation)),
                money(Number(e.planAssets)),
                money(Number(e.netLiability)),
                money(Number(e.currentServiceCost)),
                money(Number(e.netInterest)),
              ]),
            }
          : {
              headers: ["Statutory payroll"],
              rows: [
                ["PAYE withheld", money(payeTotal)],
                ["SSNIT (employee tiers)", money(ssnitTotal)],
                ["Payroll runs", String(payRows.length)],
              ],
            },
      ],
    });
  }

  // 16. Provisions IAS 37
  if (provRows.length === 0) {
    notes.push({
      key: "provisions",
      title: "16. Provisions",
      standardRef: "IAS 37",
      applicable: false,
      notApplicableReason: "No provisions recognised on the IAS 37 register.",
      sortOrder: 16,
      body: "Not applicable — management has identified no present obligations requiring provision at the reporting date.",
    });
  } else {
    notes.push({
      key: "provisions",
      title: "16. Provisions",
      standardRef: "IAS 37",
      applicable: true,
      sortOrder: 16,
      body: "Provisions represent best estimates of expenditure required to settle present obligations, discounted where the time value of money is material. Movement for the period is shown below.",
      tables: [
        {
          headers: [
            "Code",
            "Title",
            "Category",
            "Opening/Best est.",
            "Added",
            "Utilised",
            "Reversed",
            "Unwinding",
            "Carrying",
            "Status",
          ],
          rows: provRows.map((p) => [
            p.code,
            p.title,
            p.category,
            money(Number(p.bestEstimate)),
            money(Number(p.added)),
            money(Number(p.utilised)),
            money(Number(p.reversed)),
            money(Number(p.unwindingInterest)),
            money(Number(p.carryingAmount)),
            p.status,
          ]),
        },
      ],
    });
  }

  // 17. Deferred tax IAS 12
  if (dtRows.length === 0) {
    notes.push({
      key: "deferred_tax",
      title: "17. Deferred tax",
      standardRef: "IAS 12",
      applicable: false,
      notApplicableReason: "No temporary differences have been scheduled on the deferred-tax register.",
      sortOrder: 17,
      body: "Not applicable / not yet scheduled — deferred tax will be recognised when temporary differences between carrying amounts and tax bases are identified. Current tax is recognised within the tax expense accounts.",
    });
  } else {
    const dta = dtRows.reduce((s, d) => s + Number(d.deferredTaxAsset), 0);
    const dtl = dtRows.reduce((s, d) => s + Number(d.deferredTaxLiability), 0);
    notes.push({
      key: "deferred_tax",
      title: "17. Deferred tax",
      standardRef: "IAS 12",
      applicable: true,
      sortOrder: 17,
      body: `Deferred tax assets ${money(dta)}; deferred tax liabilities ${money(dtl)}; net ${money(dta - dtl)}.`,
      tables: [
        {
          headers: ["Description", "Origin", "Carrying", "Tax base", "Temporary diff.", "Rate %", "DTA", "DTL", "OCI?"],
          rows: dtRows.map((d) => [
            d.description,
            d.origin,
            money(Number(d.carryingAmount)),
            money(Number(d.taxBase)),
            money(Number(d.temporaryDifference)),
            Number(d.taxRate),
            money(Number(d.deferredTaxAsset)),
            money(Number(d.deferredTaxLiability)),
            d.throughOci ? "Yes" : "No",
          ]),
        },
      ],
    });
  }

  // 18. Held for sale IFRS 5
  if (hfsRows.length === 0) {
    notes.push({
      key: "held_for_sale",
      title: "18. Non-current assets held for sale",
      standardRef: "IFRS 5",
      applicable: false,
      notApplicableReason: "No assets classified as held for sale.",
      sortOrder: 18,
      body: "Not applicable — no disposal groups or non-current assets met the IFRS 5 held-for-sale criteria during the period.",
    });
  } else {
    notes.push({
      key: "held_for_sale",
      title: "18. Non-current assets held for sale & discontinued operations",
      standardRef: "IFRS 5",
      applicable: true,
      sortOrder: 18,
      body: "Assets held for sale are measured at the lower of carrying amount and fair value less costs to sell. Depreciation ceases on classification.",
      tables: [
        {
          headers: ["Asset", "Description", "Carrying", "FV less costs", "Write-down", "Discontinued?", "Status"],
          rows: hfsRows.map((h) => [
            h.assetCode,
            h.description,
            money(Number(h.carryingAmount)),
            money(Number(h.fairValueLessCosts)),
            money(Number(h.writeDown)),
            h.discontinuedOperation ? "Yes" : "No",
            h.status,
          ]),
        },
      ],
    });
  }

  // 19. EPS IAS 33
  if (epsRows.length === 0 && scRows.length === 0) {
    notes.push({
      key: "eps",
      title: "19. Earnings per share",
      standardRef: "IAS 33",
      applicable: false,
      notApplicableReason:
        "EPS is presented only when the entity has ordinary shares publicly traded or is in the process of filing with a securities commission. No share capital / EPS computation registered.",
      sortOrder: 19,
      body: "Not applicable — the entity is not within the scope of IAS 33 (no publicly traded ordinary shares). Profit for the period is reported in the statement of profit or loss.",
    });
  } else {
    const latest = epsRows[0];
    notes.push({
      key: "eps",
      title: "19. Earnings per share",
      standardRef: "IAS 33",
      applicable: true,
      sortOrder: 19,
      body: latest
        ? `Basic EPS ${Number(latest.basicEps).toFixed(4)}; diluted EPS ${Number(latest.dilutedEps).toFixed(4)}. Profit attributable ${money(Number(latest.profitAttributable))}; weighted average shares ${Number(latest.weightedAvgShares).toLocaleString()}.`
        : "Share capital registered; run the EPS computation on the Standards desk to populate basic and diluted EPS.",
      tables: [
        latest
          ? {
              headers: ["Period", "Profit attrib.", "Pref. div.", "WASO", "Dilutive", "Basic EPS", "Diluted EPS"],
              rows: epsRows.map((e) => [
                e.period,
                money(Number(e.profitAttributable)),
                money(Number(e.preferenceDividends)),
                Number(e.weightedAvgShares),
                Number(e.dilutiveShares),
                Number(e.basicEps).toFixed(6),
                Number(e.dilutedEps).toFixed(6),
              ]),
            }
          : {
              headers: ["Class", "Par", "Authorised", "Issued", "Paid-up", "Premium"],
              rows: scRows.map((s) => [
                s.className,
                money(Number(s.parValue)),
                Number(s.authorisedShares),
                Number(s.issuedShares),
                money(Number(s.paidUpCapital)),
                money(Number(s.sharePremium)),
              ]),
            },
      ],
    });
  }

  // 20. Capital & financial risk IFRS 7
  if (riskRows.length === 0) {
    notes.push({
      key: "risk",
      title: "20. Capital and financial risk management",
      standardRef: "IFRS 7 / IAS 1",
      applicable: true,
      sortOrder: 20,
      body: `The entity's capital comprises share capital and retained earnings (see statement of changes in equity). Financial risks — credit, liquidity, market (FX and interest) — are monitored by management. Trade receivables credit risk is managed through the IFRS 9 ECL model. Liquidity is managed via cash flow forecasting and banking facilities. Market risk arises primarily from FX exposures on foreign-currency monetary items (IAS 21) and interest on borrowings. No formal hedge accounting (IFRS 9) has been designated unless recorded on the instruments desk.`,
    });
  } else {
    notes.push({
      key: "risk",
      title: "20. Capital and financial risk management",
      standardRef: "IFRS 7 / IAS 1",
      applicable: true,
      sortOrder: 20,
      body: "Quantitative risk exposures and mitigations are tabulated below.",
      tables: [
        {
          headers: ["Risk", "Title", "Exposure", "Mitigation", "Sensitivity"],
          rows: riskRows.map((r) => [
            r.riskType,
            r.title,
            money(Number(r.exposure)),
            r.mitigation,
            r.sensitivity,
          ]),
        },
      ],
    });
  }

  // 21. Contingencies
  if (contRows.length === 0 && provRows.filter((p) => p.contingent).length === 0) {
    notes.push({
      key: "contingencies",
      title: "21. Contingencies",
      standardRef: "IAS 37",
      applicable: false,
      notApplicableReason: "No contingent liabilities or contingent assets identified.",
      sortOrder: 21,
      body: "Not applicable — management is not aware of contingent liabilities or contingent assets that require disclosure under IAS 37.",
    });
  } else {
    notes.push({
      key: "contingencies",
      title: "21. Contingent liabilities and contingent assets",
      standardRef: "IAS 37",
      applicable: true,
      sortOrder: 21,
      body: "Contingent items are disclosed where outflow/inflow is possible but not probable, or cannot be measured reliably.",
      tables: [
        contRows.length
          ? {
              headers: ["Title", "Kind", "Likelihood", "Low", "High", "Description"],
              rows: contRows.map((c) => [
                c.title,
                c.kind,
                c.likelihood,
                money(Number(c.estimateLow)),
                money(Number(c.estimateHigh)),
                c.description,
              ]),
            }
          : {
              headers: ["From provisions register (contingent flag)"],
              rows: provRows
                .filter((p) => p.contingent)
                .map((p) => [p.code, p.title, money(Number(p.bestEstimate)), p.notes]),
            },
      ],
    });
  }

  // 22. Events after reporting period IAS 10
  if (seRows.length === 0) {
    notes.push({
      key: "subsequent_events",
      title: "22. Events after the reporting period",
      standardRef: "IAS 10",
      applicable: true,
      sortOrder: 22,
      body: "Management has evaluated events through the date of authorisation of these financial statements. No adjusting or non-adjusting events requiring disclosure under IAS 10 have been identified. If material subsequent events arise they will be recorded on the subsequent-events register and either adjusted (if conditions existed at period-end) or disclosed.",
    });
  } else {
    notes.push({
      key: "subsequent_events",
      title: "22. Events after the reporting period",
      standardRef: "IAS 10",
      applicable: true,
      sortOrder: 22,
      body: "The following events occurred after the reporting date and before authorisation for issue.",
      tables: [
        {
          headers: ["Date", "Category", "Title", "Impact", "Adjusting doc", "Description"],
          rows: seRows.map((e) => [
            e.eventDate,
            e.category,
            e.title,
            money(Number(e.financialImpact)),
            e.adjustingEntryDocNo || "—",
            e.description,
          ]),
        },
      ],
    });
  }

  // 23. Impairment IAS 36 (extra)
  if (impRows.length > 0) {
    notes.push({
      key: "impairment",
      title: "23. Impairment of non-financial assets",
      standardRef: "IAS 36",
      applicable: true,
      sortOrder: 23,
      body: "CGU and asset-level impairment tests performed during the period.",
      tables: [
        {
          headers: ["Period", "Unit", "Carrying", "VIU", "Recoverable", "Loss", "Reversal available"],
          rows: impRows.map((i) => [
            i.period,
            i.unitName,
            money(Number(i.carryingAmount)),
            money(Number(i.valueInUse)),
            money(Number(i.recoverableAmount)),
            money(Number(i.impairmentLoss)),
            money(Number(i.reversalAvailable)),
          ]),
        },
      ],
    });
  } else {
    notes.push({
      key: "impairment",
      title: "23. Impairment of non-financial assets",
      standardRef: "IAS 36",
      applicable: false,
      notApplicableReason: "No IAS 36 impairment tests were performed this period.",
      sortOrder: 23,
      body: "Not applicable — no impairment indicators were identified and no CGU tests were required this period.",
    });
  }

  // 24. Hyperinflation IAS 29
  if (hypRows.length === 0) {
    notes.push({
      key: "hyperinflation",
      title: "24. Hyperinflationary restatement",
      standardRef: "IAS 29",
      applicable: false,
      notApplicableReason: "Functional currency is not that of a hyperinflationary economy.",
      sortOrder: 24,
      body: "Not applicable — the functional currency is not hyperinflationary as defined by IAS 29; no restatement factors have been applied.",
    });
  } else {
    notes.push({
      key: "hyperinflation",
      title: "24. Hyperinflationary restatement",
      standardRef: "IAS 29",
      applicable: true,
      sortOrder: 24,
      body: "Financial statements have been restated into the measuring unit current at the reporting date.",
      tables: [
        {
          headers: ["Period", "Jurisdiction", "CPI", "Base CPI", "Factor", "Monetary G/(L)"],
          rows: hypRows.map((h) => [
            h.period,
            h.jurisdiction,
            Number(h.cpiIndex),
            Number(h.baseCpi),
            Number(h.restatementFactor),
            money(Number(h.monetaryGainLoss)),
          ]),
        },
      ],
    });
  }

  // Persist auto-generated note flags for audit trail
  for (const n of notes) {
    await db
      .insert(disclosureNotes)
      .values({
        clientId,
        period: periodKey,
        noteKey: n.key,
        title: n.title,
        standardRef: n.standardRef,
        applicable: n.applicable,
        notApplicableReason: n.notApplicableReason ?? "",
        body: n.body,
        sortOrder: n.sortOrder,
        autoGenerated: true,
        updatedBy: "system",
      })
      .onConflictDoNothing();
  }

  // Ensure default policies exist
  for (const p of DEFAULT_POLICIES) {
    await db
      .insert(accountingPolicies)
      .values({
        clientId,
        policyKey: p.key,
        title: p.title,
        standardRef: p.standardRef,
        body: p.body,
        active: true,
        sortOrder: p.sortOrder,
      })
      .onConflictDoNothing();
  }

  return { periodLabel, notes: notes.sort((a, b) => a.sortOrder - b.sortOrder), policies: DEFAULT_POLICIES };
}

/** Plain-text / markdown rendering of the notes pack. */
export function renderNotesMarkdown(pack: Awaited<ReturnType<typeof buildNotesToAccounts>>): string {
  const lines: string[] = [`# Notes to the Financial Statements`, `Period: ${pack.periodLabel}`, ``];
  for (const n of pack.notes) {
    lines.push(`## ${n.title}`);
    lines.push(`*${n.standardRef}*`);
    if (!n.applicable) {
      lines.push(`**Not applicable.** ${n.notApplicableReason ?? ""}`);
    }
    lines.push(n.body);
    if (n.tables) {
      for (const t of n.tables) {
        lines.push("");
        lines.push(`| ${t.headers.join(" | ")} |`);
        lines.push(`| ${t.headers.map(() => "---").join(" | ")} |`);
        for (const row of t.rows) {
          lines.push(`| ${row.map((c) => String(c)).join(" | ")} |`);
        }
      }
    }
    lines.push("");
  }
  lines.push(`## Significant accounting policies (detail)`);
  for (const p of pack.policies) {
    lines.push(`### ${p.title} (${p.standardRef})`);
    lines.push(p.body);
    lines.push("");
  }
  return lines.join("\n");
}
