import { db } from "@/db";
import {
  accounts,
  partners,
  costCenters,
  materials,
  meta,
  clients,
  users,
  currencies,
  taxRates,
  taxBands,
  payComponents,
  assetClasses,
  workTemplates,
  bankAccounts,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "./password";
import { CHART_OF_ACCOUNTS, ASSET_CLASSES, WORK_TEMPLATES } from "@/data/sectors";
import { seedGlobalTax } from "./tax-global";

/** Business Partners (Vendors + Customers + Employees) — Ghana market. */
const PARTNERS: [string, string, string][] = [
  ["V001", "Enterprise Insurance Co.", "Vendor"],
  ["V002", "Auto Garage Ltd", "Vendor"],
  ["V003", "Office Supplies Ghana", "Vendor"],
  ["V004", "SteelMasters Ltd (Raw Materials)", "Vendor"],
  ["V005", "Cedi Freight & Haulage", "Vendor"],
  ["V006", "Accra Utilities & Power", "Vendor"],
  ["V007", "Takoradi Drilling Services (O&G)", "Vendor"],
  ["V008", "Obuasi Mining Equipment Co.", "Vendor"],
  ["C001", "Customer A Ltd", "Customer"],
  ["C002", "Customer B Inc", "Customer"],
  ["C003", "West Africa Traders", "Customer"],
  ["C004", "Golden Coast Exports (USD)", "Customer"],
  ["E001", "John Mensah", "Employee"],
  ["E002", "Ama Owusu", "Employee"],
  ["E003", "Kofi Boateng", "Employee"],
];

const COST_CENTERS: [string, string][] = [
  ["CC-ADM", "Administration"],
  ["CC-SLS", "Sales"],
  ["CC-OPS", "Operations"],
  ["CC-HR", "Human Resources"],
  ["CC-PRC", "Procurement"],
  ["CC-IT", "IT"],
  ["CC-PRD", "Production"],
  ["CC-CNT", "Projects / Contracts"],
];

const MATERIALS: [string, string, string, number][] = [
  ["MAT-001", "Steel Rods", "Raw Material", 50],
  ["MAT-002", "Office Paper (Ream)", "Consumable", 30],
  ["MAT-003", "Finished Widget", "Finished Good", 200],
  ["MAT-004", "Cement Bags (WIP input)", "Raw Material", 18],
  ["MAT-005", "Spare Parts", "Consumable", 500],
];

const TAX_SEED: [string, string, number, string][] = [
  ["VAT", "Standard VAT", 20, "20% – full input credit, no cascading (Ghana VAT Act 2013 as amended)"],
  ["CIT", "Standard corporate", 25, "IAA 896 s.6"],
  ["CIT", "Mining corporate", 35, "Minerals & Mining Act 729"],
  ["CIT", "Agricultural (5% on 80%)", 5, "IAA 896 s.10(4)"],
  ["CIT", "Petroleum Production Tax", 35, "PPT Act 2015 (Act 894) – 50% special cases"],
  ["CIT", "ECG Levy (large companies)", 2.5, "ECG Act 170 (turnover > GHS 30m)"],
  ["ROYALTY", "Mining royalty (gross value)", 5, "MMA 729 – 4% bauxite"],
  ["ROYALTY", "Oil rent (produced)", 8, "Petroleum Act 2011 – 15% concession rent cases"],
  ["WHT_RES", "Goods sold / supplies", 7.5, "14th Schedule IAA 896"],
  ["WHT_RES", "Services", 5, "Resident services"],
  ["WHT_RES", "Professional services", 15, "Fees for professional services (accounting, legal, etc.)"],
  ["WHT_RES", "Rent (improved property)", 8, ""],
  ["WHT_RES", "Rent (unimproved land)", 15, ""],
  ["WHT_RES", "Interest", 15, ""],
  ["WHT_RES", "Dividends", 8, ""],
  ["WHT_RES", "Royalties", 15, ""],
  ["WHT_RES", "Management fees", 15, ""],
  ["WHT_RES", "Technical / consultancy fees", 15, ""],
  ["WHT_RES", "Commission", 15, ""],
  ["WHT_NR", "Services (non-resident)", 15, ""],
  ["WHT_NR", "Professional fees (non-resident)", 15, ""],
  ["WHT_NR", "Management fees (non-resident)", 15, ""],
  ["WHT_NR", "Royalties (non-resident)", 15, ""],
  ["WHT_NR", "Interest (non-resident)", 15, ""],
  ["WHT_NR", "Dividends (non-resident)", 8, ""],
  ["WHT_NR", "Rent (non-resident)", 15, ""],
  ["WHT_NR", "Technical / consultancy fees (non-resident)", 15, ""],
  ["WHT_NR", "Commission (non-resident)", 15, ""],
  ["WHT_NR", "Shipping / carriage (non-resident)", 15, ""],
  ["WHT_NR", "Air transport (non-resident)", 15, ""],
  ["SSNIT", "Employee Tier 1", 5.5, "On full gross"],
  ["SSNIT", "Employee Tier 2 (capped)", 5, "On gross capped at Tier 2 cap"],
  ["SSNIT", "Employer Tier 2 (capped)", 13, "Employer contribution, capped"],
  ["SSNIT", "Tier 2 cap (GHS)", 13000, "Cap amount – not a percentage"],
  ["NHIL", "Employee 2.5%", 2.5, "On gross"],
  ["HOUSING", "Housing on basic", 5, "Housing component on basic"],
  ["PAYE", "Personal relief (GHS)", 0, "Deducted before band computation"],
];

const PAYE_BANDS_SEED = [
  { lower: 0, upper: 3500, rate: 5 },
  { lower: 3500, upper: 13000, rate: 10 },
  { lower: 13000, upper: 25000, rate: 17.5 },
  { lower: 25000, upper: 37000, rate: 25 },
  { lower: 37000, upper: 57000, rate: 30 },
  { lower: 57000, upper: null, rate: 35 },
];

const CURRENCIES_SEED: [string, string, number][] = [
  ["GHS", "Ghana Cedi (base)", 1],
  ["USD", "US Dollar", 12.55],
  ["EUR", "Euro", 14.55],
  ["GBP", "British Pound", 16.9],
  ["CNY", "Chinese Yuan", 1.72],
];

const PAY_COMPONENTS_SEED: [string, string, number | null, string, number][] = [
  ["SSNIT Tier 1 (employee)", "gross", 5.5, "deduction", 1],
  ["SSNIT Tier 2 (employee)", "gross", 5, "deduction", 2],
  ["PAYE", "gross", null, "deduction", 3],
  ["NHIL", "gross", 2.5, "deduction", 4],
  ["Housing component", "basic", 5, "deduction", 5],
  ["SSNIT Tier 2 (employer)", "gross", 13, "employer", 6],
];

export const OWNER_USERNAME = "owner";
export const HQ_CLIENT_ID = 1;

/**
 * Documented bootstrap credentials. They are enforced on every server start, so
 * access can never be lost by an unlucky sequence of admin actions (a lost
 * authenticator, an expired demo password, a mistyped reset).
 *
 * The owner is expected to change the password from My Security after first
 * sign-in — these exist so the platform is never unreachable.
 */
export const BOOTSTRAP_OWNER_PASSWORD = "BpzOwner2026!";
export const BOOTSTRAP_DEMO_USERNAME = "demo";
export const BOOTSTRAP_DEMO_PASSWORD = "BpzDemo2026!";

/** Jurisdiction profiles (global coverage) — seeded once, owner-editable. */
async function seedJurisdictions() {
  const { JURISDICTIONS } = await import("@/data/jurisdictions");
  const { jurisdictions } = await import("@/db/employees-schema");
  for (const j of JURISDICTIONS) {
    await db
      .insert(jurisdictions)
      .values({
        code: j.code, name: j.name, currency: j.currency, vatName: j.vatName,
        vatRate: String(j.vatRate), citRate: String(j.citRate),
        payrollScheme: j.payrollScheme, notes: j.notes,
      })
      .onConflictDoNothing({ target: jurisdictions.code });
  }
  // Generic payroll default rates per non-Ghana jurisdiction (owner-editable in Admin)
  for (const j of JURISDICTIONS) {
    if (j.payrollScheme === "ghana") continue;
    await db.insert(taxRates).values([
      { category: "PAYROLL", name: `Flat income tax (${j.code})`, rate: "0", effectiveFrom: "2026-01-01", notes: `Set the statutory income tax rate for ${j.name}, or add progressive bands under tax code PAYE:${j.code}.` },
      { category: "PAYROLL", name: `Pension employee (${j.code})`, rate: "0", effectiveFrom: "2026-01-01", notes: `${j.name} employee social security / pension rate.` },
      { category: "PAYROLL", name: `Pension employer (${j.code})`, rate: "0", effectiveFrom: "2026-01-01", notes: `${j.name} employer social security / pension rate.` },
      { category: "PAYROLL", name: `Other statutory deductions (${j.code})`, rate: "0", effectiveFrom: "2026-01-01", notes: `${j.name} health/housing/levy deductions combined.` },
    ]);
  }
}

let seeded = false;

export async function ensureSeed(): Promise<void> {
  if (seeded) return;

  await db.insert(clients).values([
    { id: HQ_CLIENT_ID, code: "HQ", name: "Head Office (BPZ Firm)" },
  ]).onConflictDoNothing({ target: clients.id });

  await seedJurisdictions();

  await db.insert(accounts).values(
    CHART_OF_ACCOUNTS.map(([accountNo, description, type]) => ({ accountNo, description, type }))
  ).onConflictDoNothing();
  // Account 143000 originally mixed costs and unbilled performance. IFRS 15
  // requires it to represent only the net contract asset; costs are expensed as
  // incurred. Keep existing deployments aligned with the corrected definition.
  await db
    .update(accounts)
    .set({ description: "Contract Asset - Unbilled Work (IFRS 15)" })
    .where(eq(accounts.accountNo, "143000"));
  await db.insert(partners).values(
    PARTNERS.map(([bpNo, name, type]) => ({ bpNo, clientId: HQ_CLIENT_ID, name, type }))
  ).onConflictDoNothing();
  await db.insert(costCenters).values(
    COST_CENTERS.map(([ccCode, ccName]) => ({ ccCode, ccName }))
  ).onConflictDoNothing();
  await db.insert(materials).values(
    MATERIALS.map(([materialNo, description, type, stdPrice]) => ({
      materialNo, description, type, stdPrice: stdPrice.toFixed(2),
    }))
  ).onConflictDoNothing();

  await db.insert(meta).values([
    { key: "uj", clientId: HQ_CLIENT_ID, value: 5_000_000_000 },
    { key: "po", clientId: HQ_CLIENT_ID, value: 4_500_000_000 },
    { key: "so", clientId: HQ_CLIENT_ID, value: 3_000_000_000 },
  ]).onConflictDoNothing({ target: [meta.key, meta.clientId] });

  // Currencies
  for (const [code, name, rateGhs] of CURRENCIES_SEED) {
    await db
      .insert(currencies)
      .values({ code, name, rateGhs: rateGhs.toFixed(6), source: code === "GHS" ? "Base" : "Seeded – refresh for live BOG mid" })
      .onConflictDoNothing({ target: currencies.code });
  }

  // Tax schedule (insert per category if missing)
  for (const cat of [...new Set(TAX_SEED.map((r) => r[0]))]) {
    const existing = await db.select({ id: taxRates.id }).from(taxRates).where(eq(taxRates.category, cat));
    if (!existing.length) {
      await db.insert(taxRates).values(
        TAX_SEED.filter((r) => r[0] === cat).map(([c, name, rate, notes]) => ({
          category: c, name, rate: String(rate), effectiveFrom: "2026-01-01", notes,
        }))
      );
    }
  }

  // PAYE bands (schedule effective 2026-09-01)
  const bands = await db.select({ id: taxBands.id }).from(taxBands).where(eq(taxBands.tax, "PAYE"));
  if (!bands.length) {
    await db.insert(taxBands).values(
      PAYE_BANDS_SEED.map((b) => ({
        tax: "PAYE", lower: String(b.lower), upper: b.upper === null ? null : String(b.upper),
        rate: String(b.rate), effectiveFrom: "2026-09-01",
      }))
    );
  }

  // Payroll components
  const comps = await db.select({ id: payComponents.id }).from(payComponents);
  if (!comps.length) {
    await db.insert(payComponents).values(
      PAY_COMPONENTS_SEED.map(([name, base, rate, side, ordinal]) => ({
        name, base, rate: rate === null ? null : String(rate), fixedAmount: "0", side, ordinal, active: true,
      }))
    );
  }

  // Asset classes
  await db.insert(assetClasses).values(
    ASSET_CLASSES.map((a) => ({
      code: a.code, name: a.name, scope: a.scope, method: a.method,
      rate: String(a.rate), lifeYears: a.lifeYears,
    }))
  ).onConflictDoNothing({ target: assetClasses.code });

  // Work templates
  await db.insert(workTemplates).values(
    WORK_TEMPLATES.map((t) => ({
      name: t.name, serviceLine: t.serviceLine, checklist: JSON.stringify(t.checklist),
    }))
  ).onConflictDoNothing({ target: workTemplates.name });

  // HQ default bank account
  const bacs = await db.select({ id: bankAccounts.id }).from(bankAccounts).where(eq(bankAccounts.clientId, HQ_CLIENT_ID));
  if (!bacs.length) {
    await db.insert(bankAccounts).values([
      { clientId: HQ_CLIENT_ID, name: "SCB Current", bank: "Standard Chartered", accountCode: "101000", currency: "GHS", opening: "0" },
    ]);
  }

  // Owner account
  // --- Owner: create if missing, otherwise keep the account reachable ---
  const ownerRow = (await db.select().from(users).where(eq(users.username, OWNER_USERNAME)))[0];
  if (!ownerRow) {
    await db.insert(users).values({
      username: OWNER_USERNAME,
      passwordHash: hashPassword(BOOTSTRAP_OWNER_PASSWORD),
      name: "System Owner",
      role: "owner",
      clientId: HQ_CLIENT_ID,
      active: true,
      usesBootstrapPassword: true,
      acceptedTermsAt: new Date(),
    });
  } else {
    // Keep the documented bootstrap password valid until the owner sets their own.
    // Never touches a password the owner has personalised.
    if (ownerRow.usesBootstrapPassword) {
      await db
        .update(users)
        .set({
          passwordHash: hashPassword(BOOTSTRAP_OWNER_PASSWORD),
          active: true,
          mustChangePassword: false,
          acceptedTermsAt: ownerRow.acceptedTermsAt ?? new Date(),
        })
        .where(eq(users.id, ownerRow.id));
    } else if (!ownerRow.active) {
      await db.update(users).set({ active: true }).where(eq(users.id, ownerRow.id));
    }
  }

  // --- Demo client workspace: always present, always reachable ---
  let demoClient = (await db.select().from(clients).where(eq(clients.code, "CLI-DEMO")))[0];
  if (!demoClient) {
    try {
      await db.insert(clients).values({
        code: "CLI-DEMO",
        name: "Demo Client Ltd",
        sector: "trade_retail",
        baseCurrency: "GHS",
        serviceLines: "bookkeeping,payroll,tax_compliance",
        feeModel: "Monthly service lines",
        active: true,
      });
    } catch {
      /* race / unique — re-read below */
    }
    demoClient = (await db.select().from(clients).where(eq(clients.code, "CLI-DEMO")))[0];
    if (demoClient) {
      await db.insert(meta).values([
        { key: "uj", clientId: demoClient.id, value: 5_000_000_000 },
        { key: "po", clientId: demoClient.id, value: 4_500_000_000 },
        { key: "so", clientId: demoClient.id, value: 3_000_000_000 },
      ]).onConflictDoNothing({ target: [meta.key, meta.clientId] });
    }
  }
  if (demoClient) {
    const demoUser = (await db.select().from(users).where(eq(users.username, BOOTSTRAP_DEMO_USERNAME)))[0];
    if (!demoUser) {
      await db.insert(users).values({
        username: BOOTSTRAP_DEMO_USERNAME,
        passwordHash: hashPassword(BOOTSTRAP_DEMO_PASSWORD),
        name: "Demo Client User",
        role: "client",
        clientId: demoClient.id,
        active: true,
        mustChangePassword: false,
        acceptedTermsAt: new Date(),
      }).onConflictDoNothing({ target: users.username });
    } else if (!demoUser.active) {
      await db.update(users).set({ active: true }).where(eq(users.id, demoUser.id));
    }
    // Give the demo workspace its own master data so it is never empty.
    const demoPartners = await db.select({ bpNo: partners.bpNo }).from(partners).where(eq(partners.clientId, demoClient.id));
    if (!demoPartners.length) {
      await db.insert(partners).values(
        PARTNERS.slice(0, 6).map(([bpNo, name, type]) => ({
          bpNo, clientId: demoClient.id, name: `${name} (demo)`, type,
        }))
      ).onConflictDoNothing();
    }
  }

  try {
    await seedGlobalTax();
  } catch (e) {
    console.error("seedGlobalTax", e);
  }

  // Seed a default OIDC SSO provider shell (disabled until owner configures secrets)
  try {
    const { ssoProviders } = await import("@/db/schema");
    const existing = await db.select().from(ssoProviders).limit(1);
    if (!existing.length) {
      await db.insert(ssoProviders).values({
        name: "Enterprise OIDC (Big Four IdP)",
        protocol: "oidc",
        enabled: true,
        issuer: "https://login.microsoftonline.com/{tenant}/v2.0",
        authorizationUrl: "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize",
        tokenUrl: "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        jwksUrl: "https://login.microsoftonline.com/{tenant}/discovery/v2.0/keys",
        defaultRole: "accountant",
        allowedDomains: "firm.com,pwc.com,kpmg.com,ey.com,delotte.com,deloitte.com",
        metadata: JSON.stringify({ note: "Enable after filling client_id/secret. Supports SAML and SCIM too." }),
      });
      await db.insert(ssoProviders).values({
        name: "Enterprise SAML 2.0",
        protocol: "saml",
        enabled: false,
        samlEntryPoint: "https://idp.example.com/sso/saml",
        defaultRole: "viewer",
        allowedDomains: "",
      });
    }
  } catch (e) {
    console.error("seed sso", e);
  }

  seeded = true;
}

