/**
 * Loan and borrowing amortisation — pure rules, covered by regression tests.
 *
 * Facility types
 *   amortising    equal instalments of interest + principal (annuity)
 *   interest_only interest-only during the term; principal repaid at maturity
 *   bullet        interest accrues and is paid with principal at maturity
 */

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export type FacilityType = "amortising" | "interest_only" | "bullet";
export type Frequency = "monthly" | "quarterly" | "annually";

export function periodsPerYear(f: Frequency): number {
  return f === "monthly" ? 12 : f === "quarterly" ? 4 : 1;
}

export function numberOfPeriods(termMonths: number, f: Frequency): number {
  if (f === "monthly") return Math.max(1, termMonths);
  if (f === "quarterly") return Math.max(1, Math.ceil(termMonths / 3));
  return Math.max(1, Math.ceil(termMonths / 12));
}

export function periodRate(annualRate: number, f: Frequency): number {
  return annualRate / 100 / periodsPerYear(f);
}

export type ScheduleRow = {
  seq: number;
  opening: number;
  interest: number;
  fee: number;
  principal: number;
  payment: number;
  closing: number;
};

export type LoanTerms = {
  principal: number;
  annualRate: number;
  termMonths: number;
  frequency: Frequency;
  facilityType: FacilityType;
  moratoriumMonths: number;
  arrangementFee: number;
  feeSpreadMonths: number;
};

/**
 * The constant instalment that amortises the principal over the term.
 * A = P · i / (1 − (1+i)^−n)
 */
export function annuityInstalment(principal: number, periodRatePct: number, periods: number): number {
  const i = periodRatePct / 100;
  if (periods <= 0) return round2(principal);
  if (i === 0) return round2(principal / periods);
  const factor = Math.pow(1 + i, periods);
  return round2((principal * i) / (1 - 1 / factor));
}

/**
 * Build the full facility schedule. A moratorium defers principal (and for
 * bullet facilities, all cash) while interest continues to accrue — it is never
 * forgiven.
 */
export function buildLoanSchedule(terms: LoanTerms): {
  rows: ScheduleRow[];
  instalment: number;
  totalInterest: number;
  totalFees: number;
  totalPaid: number;
  effectiveCost: number;
} {
  const principal = Math.max(0, terms.principal);
  const i = periodRate(terms.annualRate, terms.frequency);
  const totalPeriods = numberOfPeriods(terms.termMonths, terms.frequency);
  const moratorium = Math.max(0, Math.min(terms.moratoriumMonths, totalPeriods - 1));
  const moratoriumPeriods = Math.min(moratorium, totalPeriods);
  const feePeriods = Math.max(1, terms.feeSpreadMonths || totalPeriods);
  const feePerPeriod = terms.arrangementFee > 0 ? terms.arrangementFee / feePeriods : 0;

  const repayingPeriods = totalPeriods - moratoriumPeriods;
  // The annuity must be computed with the PER-PERIOD rate, not the annual rate.
  // Passing the annual rate produced an instalment ~8× too large, repaying most
  // of the principal in the first month.
  const instalment = annuityInstalment(principal, i * 100, repayingPeriods);

  const rows: ScheduleRow[] = [];
  let balance = principal;
  let totalInterest = 0;
  let totalFees = 0;
  let totalPaid = 0;

  for (let seq = 1; seq <= totalPeriods; seq++) {
    const opening = round2(balance);
    const interest = round2(opening * i);
    const fee = round2(Math.min(feePerPeriod, Math.max(0, terms.arrangementFee - totalFees)));
    let principalRepayment = 0;
    let payment = 0;

    const inMoratorium = seq <= moratoriumPeriods;
    const isFinal = seq === totalPeriods;

    if (terms.facilityType === "amortising") {
      if (inMoratorium) {
        payment = round2(interest + fee); // interest-only during moratorium
      } else if (isFinal) {
        principalRepayment = opening; // clear any rounding residual
        payment = round2(interest + fee + principalRepayment);
      } else {
        payment = round2(instalment + fee);
        principalRepayment = round2(Math.min(opening, Math.max(0, payment - interest - fee)));
      }
    } else if (terms.facilityType === "interest_only") {
      payment = round2(interest + fee);
      if (isFinal) {
        principalRepayment = opening;
        payment = round2(interest + fee + principalRepayment);
      }
    } else {
      // Bullet: nothing is paid until maturity; interest capitalises.
      if (!isFinal) {
        payment = fee;
        balance = round2(opening + interest);
        rows.push({ seq, opening, interest, fee, principal: 0, payment, closing: balance });
        totalInterest = round2(totalInterest + interest);
        totalFees = round2(totalFees + fee);
        totalPaid = round2(totalPaid + payment);
        continue;
      }
      principalRepayment = balance;
      payment = round2(balance + interest + fee);
    }

    balance = round2(opening - principalRepayment);
    if (balance < 0.005) balance = 0;
    rows.push({ seq, opening, interest, fee, principal: principalRepayment, payment, closing: balance });
    totalInterest = round2(totalInterest + interest);
    totalFees = round2(totalFees + fee);
    totalPaid = round2(totalPaid + payment);
  }

  const effectiveCost = round2(totalInterest + totalFees);
  return { rows, instalment, totalInterest, totalFees, totalPaid, effectiveCost };
}

/** Split a liability balance between current and non-current for the balance sheet. */
export function loanCurrentSplit(
  schedule: ScheduleRow[],
  openingOutstanding: number
): { currentPortion: number; nonCurrentPortion: number } {
  const outstanding = round2(openingOutstanding);
  let toRepay = 0;
  for (const r of schedule.slice(0, periodsPerYear("monthly") > 0 ? undefined : undefined)) {
    toRepay += r.principal;
    if (toRepay >= outstanding) break;
  }
  const current = round2(Math.min(outstanding, toRepay));
  return { currentPortion: current, nonCurrentPortion: round2(Math.max(0, outstanding - current)) };
}

/** Effective interest rate implied by the schedule, including fees (IRR). */
export function effectiveInterestRate(terms: LoanTerms): number {
  const { rows } = buildLoanSchedule(terms);
  const netProceeds = terms.principal - terms.arrangementFee;
  let low = 0;
  let high = terms.annualRate / 100 * 4 + 0.5;
  const perYear = periodsPerYear(terms.frequency);
  const npv = (rate: number) => {
    let v = -netProceeds;
    for (const r of rows) v += r.payment / Math.pow(1 + rate, r.seq);
    return v;
  };
  for (let k = 0; k < 80; k++) {
    const mid = (low + high) / 2;
    if (npv(mid) > 0) low = mid;
    else high = mid;
  }
  return round2(((low + high) / 2) * perYear * 100 * 100) / 100;
}

/** Covenant and exposure metrics a lender or reviewer will ask for. */
export function loanMetrics(terms: LoanTerms, outstanding: number) {
  const { rows, totalInterest, totalFees } = buildLoanSchedule(terms);
  const remaining = rows.filter((r) => r.closing > 0 || r.principal > 0);
  const debtService12m = round2(
    remaining.slice(0, terms.frequency === "monthly" ? 12 : terms.frequency === "quarterly" ? 4 : 1).reduce(
      (s, r) => s + r.payment,
      0
    )
  );
  return {
    outstanding: round2(outstanding),
    remainingPeriods: remaining.length,
    debtService12m,
    totalInterest: round2(totalInterest),
    totalFees: round2(totalFees),
    gearingToPrincipal: terms.principal > 0 ? round2((outstanding / terms.principal) * 100) : 0,
  };
}
