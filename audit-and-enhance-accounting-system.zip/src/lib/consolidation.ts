/**
 * IFRS 10 — Consolidated Financial Statements
 * Line-by-line consolidation with intercompany eliminations and NCI.
 */
import { db } from "@/db";
import {
  groups,
  groupMembers,
  intercompanyLinks,
  clients,
  journalLines,
  accounts,
} from "@/db/schema";
import { and, eq, sql, inArray } from "drizzle-orm";
import { trialBalance, pnl, balanceSheet, type TbRow } from "./reports";
import { PostingError } from "./posting";
import { ensureSeed } from "./init";

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const sumExpr = (col: typeof journalLines.debit) =>
  sql<number>`coalesce(sum(${col}), 0)::float8`;

export type GroupInfo = {
  id: number;
  code: string;
  name: string;
  parentClientId: number;
  reportingCurrency: string;
  members: {
    id: number;
    clientId: number;
    clientCode: string;
    clientName: string;
    ownershipPct: number;
    method: string;
    nciShare: number;
    goodwill: number;
  }[];
};

export async function listGroups(): Promise<GroupInfo[]> {
  await ensureSeed();
  const gs = await db.select().from(groups);
  const out: GroupInfo[] = [];
  for (const g of gs) {
    const mems = await db.select().from(groupMembers).where(and(eq(groupMembers.groupId, g.id), eq(groupMembers.active, true)));
    const memberDetails = await Promise.all(
      mems.map(async (m) => {
        const c = (await db.select().from(clients).where(eq(clients.id, m.clientId)))[0];
        return {
          id: m.id,
          clientId: m.clientId,
          clientCode: c?.code ?? String(m.clientId),
          clientName: c?.name ?? "",
          ownershipPct: Number(m.ownershipPct),
          method: m.method,
          nciShare: Number(m.nciShare),
          goodwill: Number(m.goodwill),
        };
      })
    );
    out.push({
      id: g.id,
      code: g.code,
      name: g.name,
      parentClientId: g.parentClientId,
      reportingCurrency: g.reportingCurrency,
      members: memberDetails,
    });
  }
  return out;
}

export async function createGroup(input: {
  code: string;
  name: string;
  parentClientId: number;
  reportingCurrency?: string;
  notes?: string;
}) {
  if (!input.code || !input.name) throw new PostingError("Group code and name are required.");
  const parent = (await db.select().from(clients).where(eq(clients.id, input.parentClientId)))[0];
  if (!parent) throw new PostingError("Parent client not found.");
  const rows = await db
    .insert(groups)
    .values({
      code: input.code.toUpperCase(),
      name: input.name,
      parentClientId: input.parentClientId,
      reportingCurrency: input.reportingCurrency ?? parent.baseCurrency ?? "GHS",
      notes: input.notes ?? "",
    })
    .returning();
  // Parent is always a full member at 100%
  await db.insert(groupMembers).values({
    groupId: rows[0].id,
    clientId: input.parentClientId,
    ownershipPct: "100",
    method: "full",
    nciShare: "0",
  });
  return rows[0];
}

export async function addGroupMember(input: {
  groupId: number;
  clientId: number;
  ownershipPct: number;
  method?: string;
  acquisitionDate?: string;
  goodwill?: number;
}) {
  if (input.ownershipPct <= 0 || input.ownershipPct > 100)
    throw new PostingError("Ownership % must be between 0 and 100.");
  const method = input.method ?? (input.ownershipPct >= 50 ? "full" : "equity");
  const nci = method === "full" ? r2(100 - input.ownershipPct) : 0;
  await db
    .insert(groupMembers)
    .values({
      groupId: input.groupId,
      clientId: input.clientId,
      ownershipPct: String(input.ownershipPct),
      method,
      acquisitionDate: input.acquisitionDate ?? "",
      goodwill: String(input.goodwill ?? 0),
      nciShare: String(nci),
      active: true,
    })
    .onConflictDoNothing();
  return { ok: true, method, nciShare: nci };
}

export async function recordIntercompany(input: {
  groupId: number;
  fromClientId: number;
  toClientId: number;
  nature: string;
  fromAccount?: string;
  toAccount?: string;
  amount: number;
  period: string;
  notes?: string;
}) {
  if (input.fromClientId === input.toClientId)
    throw new PostingError("Intercompany parties must be different entities.");
  if (!Number.isFinite(input.amount) || input.amount === 0)
    throw new PostingError("Amount must be non-zero.");
  const row = await db
    .insert(intercompanyLinks)
    .values({
      groupId: input.groupId,
      fromClientId: input.fromClientId,
      toClientId: input.toClientId,
      nature: input.nature || "trade",
      fromAccount: input.fromAccount ?? "",
      toAccount: input.toAccount ?? "",
      amount: String(r2(input.amount)),
      period: input.period,
      notes: input.notes ?? "",
    })
    .returning();
  return row[0];
}

export type ConsolTB = {
  account: string;
  description: string;
  type: string;
  entities: Record<string, number>;
  subtotal: number;
  eliminations: number;
  consolidated: number;
};

/**
 * Build a consolidated trial balance:
 * 1. Sum line-by-line for full-method subsidiaries
 * 2. Equity-method: only investment line (simplified — ownership × equity)
 * 3. Eliminate intercompany balances
 * 4. Recognise NCI share of net assets / profit
 */
export async function consolidatedTrialBalance(
  groupId: number,
  from?: string,
  to?: string
): Promise<{
  group: GroupInfo;
  rows: ConsolTB[];
  nci: number;
  goodwill: number;
  eliminations: { id: number; nature: string; amount: number; from: string; to: string }[];
  balanced: boolean;
}> {
  await ensureSeed();
  const all = await listGroups();
  const group = all.find((g) => g.id === groupId);
  if (!group) throw new PostingError("Group not found.");

  const fullMembers = group.members.filter((m) => m.method === "full");
  const equityMembers = group.members.filter((m) => m.method === "equity");

  // Collect per-entity trial balances
  const entityTBs: { member: GroupInfo["members"][0]; rows: TbRow[] }[] = [];
  for (const m of fullMembers) {
    const { rows } = await trialBalance(m.clientId, from, to);
    entityTBs.push({ member: m, rows });
  }

  // Union of all accounts
  const accs = await db.select().from(accounts);
  const accMap = new Map(accs.map((a) => [a.accountNo, a]));
  const allAccounts = new Set<string>();
  for (const et of entityTBs) et.rows.forEach((r) => allAccounts.add(r.account));

  const elimLinks = await db
    .select()
    .from(intercompanyLinks)
    .where(
      and(
        eq(intercompanyLinks.groupId, groupId),
        from ? sql`${intercompanyLinks.period} >= ${from}` : undefined,
        to ? sql`${intercompanyLinks.period} <= ${to}` : undefined
      )
    );

  // Build consolidated rows
  const rows: ConsolTB[] = [];
  for (const account of [...allAccounts].sort()) {
    const entities: Record<string, number> = {};
    let subtotal = 0;
    for (const et of entityTBs) {
      const hit = et.rows.find((r) => r.account === account);
      const bal = hit?.bal ?? 0;
      entities[et.member.clientCode] = bal;
      subtotal += bal;
    }
    // Eliminations targeting this account
    let eliminations = 0;
    for (const link of elimLinks) {
      if (link.fromAccount === account || (!link.fromAccount && (account.startsWith("1") || account.startsWith("2")))) {
        // simplified: reduce receivable/payable style accounts
        if (link.fromAccount === account) eliminations -= Number(link.amount);
        if (link.toAccount === account) eliminations += Number(link.amount);
      }
    }
    const consolidated = r2(subtotal + eliminations);
    if (Math.abs(subtotal) < 0.005 && Math.abs(eliminations) < 0.005) continue;
    rows.push({
      account,
      description: accMap.get(account)?.description ?? account,
      type: accMap.get(account)?.type ?? "—",
      entities,
      subtotal: r2(subtotal),
      eliminations: r2(eliminations),
      consolidated,
    });
  }

  // NCI = sum over full members of nciShare% × (assets - liabilities) simplified via equity-ish
  let nci = 0;
  let goodwill = 0;
  for (const m of fullMembers) {
    goodwill += m.goodwill;
    if (m.nciShare > 0) {
      const bs = await balanceSheet(m.clientId, from, to);
      // Net assets ≈ assets + liabilities(credit neg) — use tAssets - |tLiab| style
      const netAssets = bs.tAssets + bs.tLiab; // liab bals are typically credit (negative in our TB sign)
      // Our TB: asset bal >0, liability bal <0, equity bal <0
      // Net assets attributable = assets + liab + equity_of_sub... use equity side
      const equitySide = Math.abs(bs.tEquity) + (bs.net || 0);
      nci += r2((m.nciShare / 100) * equitySide);
    }
  }

  // Equity-method pick-up (simplified disclosure line)
  for (const m of equityMembers) {
    const bs = await balanceSheet(m.clientId, from, to);
    const equitySide = Math.abs(bs.tEquity) + (bs.net || 0);
    const pickup = r2((m.ownershipPct / 100) * equitySide);
    rows.push({
      account: `EQM-${m.clientCode}`,
      description: `Investment in associate ${m.clientName} (equity method)`,
      type: "Asset",
      entities: { [m.clientCode]: pickup },
      subtotal: pickup,
      eliminations: 0,
      consolidated: pickup,
    });
  }

  const total = rows.reduce((s, r) => s + r.consolidated, 0);

  return {
    group,
    rows,
    nci: r2(nci),
    goodwill: r2(goodwill),
    eliminations: elimLinks.map((l) => ({
      id: l.id,
      nature: l.nature,
      amount: Number(l.amount),
      from: String(l.fromClientId),
      to: String(l.toClientId),
    })),
    balanced: Math.abs(total) < 1, // consol TB of signed bals approaches 0 when complete
  };
}

export async function markEliminated(linkId: number, docNo: string) {
  await db
    .update(intercompanyLinks)
    .set({ eliminated: true, elimDocNo: docNo })
    .where(eq(intercompanyLinks.id, linkId));
}
