import { requireWorkspace } from "@/lib/auth";
import { runAssurance } from "@/lib/assurance";
import { PageHeader } from "@/components/ui";
import { AssuranceRunner } from "@/components/AssuranceRunner";

export const dynamic = "force-dynamic";

export default async function AssurancePage() {
  await requireWorkspace();
  const initial = await runAssurance();

  return (
    <>
      <PageHeader
        kicker="ADM · Control assurance"
        title="System Assurance"
        desc="Automated verification of the controls your clients' auditors will test: double-entry integrity, tenant isolation, posting controls, tax computation accuracy, authentication strength, period locking, audit-trail capture and backup recency."
      />
      <AssuranceRunner initial={initial.checks} />
    </>
  );
}
