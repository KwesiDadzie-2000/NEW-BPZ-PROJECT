import { requireWorkspace } from "@/lib/auth";
import { PageHeader, Card, Icon } from "@/components/ui";
import { MigrationDesk } from "@/components/MigrationDesk";

export const dynamic = "force-dynamic";

export default async function MigrationPage() {
  const ws = await requireWorkspace();

  return (
    <>
      <PageHeader
        kicker={`Onboarding · ${ws.client.code}`}
        title="Client Migration"
        desc="Bring a real client's books in from CSV: opening trial balance, customer and supplier master, payroll employees and the fixed-asset register. Import in any order, correct and re-upload safely — duplicates are skipped."
      />

      <div className="grid items-start gap-4 xl:grid-cols-[1fr_360px]">
        <MigrationDesk />

        <div className="space-y-4">
          <Card title="Recommended order">
            <ol className="space-y-2.5">
              {[
                ["Partners", "Load customers and suppliers first so invoices and orders can reference them."],
                ["Employees", "Load the payroll master so you can run the first payroll."],
                ["Fixed assets", "Capitalise the register so depreciation starts from the right base."],
                ["Opening balances", "Post the trial balance last — it must agree to the ledger you just built."],
              ].map(([t, why], i) => (
                <li key={t} className="flex gap-2.5">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gold-400/15 font-mono text-[11px] font-bold text-gold-300">
                    {i + 1}
                  </span>
                  <div>
                    <div className="text-[13px] font-semibold text-mist-100">{t}</div>
                    <div className="mt-0.5 text-[12px] leading-snug text-mist-500">{why}</div>
                  </div>
                </li>
              ))}
            </ol>
          </Card>

          <Card title="Before you import">
            <ul className="space-y-2 text-[12.5px] leading-relaxed text-mist-500">
              <li className="flex gap-2">
                <Icon name="check" size={13} className="mt-0.5 shrink-0 text-gold-400" />
                Account codes must exist in the chart of accounts — check Master Data first.
              </li>
              <li className="flex gap-2">
                <Icon name="check" size={13} className="mt-0.5 shrink-0 text-gold-400" />
                Amounts can carry commas, spaces or GHC — they are cleaned automatically.
              </li>
              <li className="flex gap-2">
                <Icon name="check" size={13} className="mt-0.5 shrink-0 text-gold-400" />
                Column names are matched loosely: "Cost", "CostPrice" and "COST" all work.
              </li>
              <li className="flex gap-2">
                <Icon name="check" size={13} className="mt-0.5 shrink-0 text-gold-400" />
                Every import is written to the Audit Log with your username and the row count.
              </li>
            </ul>
          </Card>

          <Card title="After the trial balance">
            <p className="text-[12.5px] leading-relaxed text-mist-500">
              If the debits and credits do not agree, the difference is posted to Equity as{" "}
              <span className="text-mist-300">Opening balance difference</span> so you can start work immediately.
              Review it in the Universal Journal, clear it with an adjustment, and note the reason — that is what an
              auditor will look for.
            </p>
          </Card>
        </div>
      </div>
    </>
  );
}
