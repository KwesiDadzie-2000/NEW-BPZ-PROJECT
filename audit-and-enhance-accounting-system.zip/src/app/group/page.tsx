import { requireWorkspace } from "@/lib/auth";
import { listGroups, consolidatedTrialBalance } from "@/lib/consolidation";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { asc } from "drizzle-orm";
import { Card, PageHeader, Badge } from "@/components/ui";
import { SimpleActionForm } from "@/components/SimpleActionForm";
import { thisPeriod } from "@/lib/periods";

export const dynamic = "force-dynamic";

export default async function GroupPage({
  searchParams,
}: {
  searchParams: Promise<{ groupId?: string }>;
}) {
  const ws = await requireWorkspace();
  const sp = await searchParams;
  const groups = await listGroups();
  const allClients = await db.select().from(clients).orderBy(asc(clients.code));
  const groupId = Number(sp.groupId || groups[0]?.id || 0);
  let consol = null as Awaited<ReturnType<typeof consolidatedTrialBalance>> | null;
  if (groupId) {
    try {
      consol = await consolidatedTrialBalance(groupId);
    } catch {
      consol = null;
    }
  }
  const period = thisPeriod();

  return (
    <div className="space-y-6">
      <PageHeader
        kicker="IFRS 10 · Consolidated Financial Statements"
        title="Group consolidation"
        desc="Multi-entity groups with ownership %, full/equity methods, intercompany eliminations and NCI. Closes the Big Four hard blocker on consolidation / intercompany eliminations."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Create group" sub="Parent entity is added at 100% full consolidation">
          <SimpleActionForm
            action="group.create"
            label="Create group"
            fields={{
              code: { label: "Code", placeholder: "GRP-01", required: true },
              name: { label: "Name", placeholder: "BPZ Holdings", required: true },
              parentClientId: { label: "Parent client id", defaultValue: String(ws.client.id), type: "number" },
              reportingCurrency: { label: "Reporting currency", defaultValue: "GHS" },
              notes: { label: "Notes", placeholder: "Optional", wide: true },
            }}
          />
        </Card>

        <Card title="Add member" sub="Ownership under 50% defaults to equity method">
          <SimpleActionForm
            action="group.add_member"
            label="Add member"
            fields={{
              groupId: { label: "Group id", defaultValue: String(groupId || ""), type: "number", required: true },
              memberClientId: { label: "Member client id", type: "number", required: true },
              ownershipPct: { label: "Ownership %", defaultValue: "80", type: "number" },
              method: { label: "Method (full|equity|nci)", defaultValue: "full" },
              goodwill: { label: "Goodwill", defaultValue: "0", type: "number" },
              acquisitionDate: { label: "Acquisition date", placeholder: "2026-01-01" },
            }}
          />
        </Card>

        <Card title="Intercompany balance" sub="Flagged for elimination at consolidation">
          <SimpleActionForm
            action="group.intercompany"
            label="Record IC link"
            fields={{
              groupId: { label: "Group id", defaultValue: String(groupId || ""), type: "number" },
              fromClientId: { label: "From client id", type: "number", required: true },
              toClientId: { label: "To client id", type: "number", required: true },
              nature: { label: "Nature", defaultValue: "trade" },
              fromAccount: { label: "From account", defaultValue: "110000" },
              toAccount: { label: "To account", defaultValue: "200000" },
              amount: { label: "Amount", type: "number", required: true },
              period: { label: "Period", defaultValue: period },
              notes: { label: "Notes", wide: true },
            }}
          />
        </Card>

        <Card title="Workspaces" sub="Use client ids when adding members">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-mist-400">
                <th className="py-1">ID</th>
                <th>Code</th>
                <th>Name</th>
                <th>Sector</th>
              </tr>
            </thead>
            <tbody>
              {allClients.map((c) => (
                <tr key={c.id} className="border-t border-ink-800">
                  <td className="py-1 font-mono">{c.id}</td>
                  <td>{c.code}</td>
                  <td>{c.name}</td>
                  <td className="text-mist-400">{c.sector}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <Card title="Groups" sub="Select a group to view consolidated TB">
        <div className="flex flex-wrap gap-2">
          {groups.length === 0 && <p className="text-sm text-mist-400">No groups yet — create one above.</p>}
          {groups.map((g) => (
            <a
              key={g.id}
              href={`/group?groupId=${g.id}`}
              className={`rounded-lg border px-3 py-2 text-sm ${
                g.id === groupId ? "border-gold-400 bg-gold-400/10 text-gold-400" : "border-ink-600 text-mist-200"
              }`}
            >
              {g.code} · {g.name} <Badge tone="slate">{g.members.length} members</Badge>
            </a>
          ))}
        </div>
        {groups
          .filter((g) => g.id === groupId)
          .map((g) => (
            <div key={g.id} className="mt-4 overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="text-left text-mist-400">
                    <th className="py-1">Client</th>
                    <th>Ownership</th>
                    <th>Method</th>
                    <th>NCI %</th>
                    <th>Goodwill</th>
                  </tr>
                </thead>
                <tbody>
                  {g.members.map((m) => (
                    <tr key={m.id} className="border-t border-ink-800">
                      <td className="py-1">{m.clientCode} — {m.clientName}</td>
                      <td>{m.ownershipPct}%</td>
                      <td>{m.method}</td>
                      <td>{m.nciShare}%</td>
                      <td>{m.goodwill.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
      </Card>

      {consol && (
        <Card
          title={`Consolidated trial balance — ${consol.group.code}`}
          sub={`NCI ${consol.nci.toLocaleString()} · Goodwill ${consol.goodwill.toLocaleString()} · Eliminations ${consol.eliminations.length}`}
        >
          <div className="overflow-x-auto">
            <table className="min-w-full text-[12.5px]">
              <thead>
                <tr className="border-b border-ink-700 text-left text-mist-400">
                  <th className="px-3 py-2">Account</th>
                  <th>Description</th>
                  <th>Type</th>
                  <th className="text-right">Subtotal</th>
                  <th className="text-right">Eliminations</th>
                  <th className="text-right">Consolidated</th>
                </tr>
              </thead>
              <tbody>
                {consol.rows.map((r) => (
                  <tr key={r.account} className="border-b border-ink-900/70">
                    <td className="px-3 py-1.5 font-mono">{r.account}</td>
                    <td>{r.description}</td>
                    <td className="text-mist-400">{r.type}</td>
                    <td className="text-right tabular-nums">{r.subtotal.toLocaleString()}</td>
                    <td className="text-right tabular-nums">{r.eliminations.toLocaleString()}</td>
                    <td className="text-right font-semibold tabular-nums">{r.consolidated.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 text-sm text-mist-400">
            Export: <a className="text-gold-400 underline" href={`/api/export?sheet=group`}>Group sheets in Excel</a>
          </div>
        </Card>
      )}
    </div>
  );
}
