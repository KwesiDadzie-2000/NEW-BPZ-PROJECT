import { requireWorkspace } from "@/lib/auth";
import { masterData, stockValuation } from "@/lib/reports";
import { num, money } from "@/lib/format";
import { PageHeader, Card, ExportLink, EmptyState, Stat, tdCls, thCls, numCls, rowCls } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";

export const dynamic = "force-dynamic";

export default async function InventoryPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const { mats } = await masterData(clientId);
  const stock = await stockValuation(clientId);
  const totalValue = stock.reduce((s, r) => s + r.value, 0);
  const byType = (t: string) => stock.filter((s) => s.type === t).reduce((x, r) => x + r.value, 0);

  return (
    <>
      <PageHeader
        kicker={`INV · Inventory & Stock · ${ws.client.code}`}
        title="Inventory Management"
        desc="Stock receipts, issues and valuation in one place — book value from the Universal Journal (IAS 2), quantities from movements, standard prices from the material master."
      >
        <ExportLink sheet="stock" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Raw Materials" value={money(byType("Raw Material"))} sub="Account 120000" />
        <Stat label="Finished Goods" value={money(byType("Finished Good"))} sub="Account 121000" />
        <Stat label="Consumables & Spares" value={money(byType("Consumable"))} sub="Account 124000" />
        <Stat label="Total Stock Value" value={money(totalValue)} tone="text-gold-300" sub="Book value, IAS 2" />
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-[380px_1fr]">
        <ActionForm
          action="stock_move"
          title="Record Stock Movement"
          sub="Stock in posts Inventory Dr / Payables Cr · stock out posts Expense Dr / Inventory Cr"
          submitLabel="Record movement"
          userDefault="storekeeper"
          periodField
          fields={[
            {
              name: "material", label: "Material", type: "select",
              options: mats.map((m) => ({ value: m.materialNo, label: `${m.materialNo} · ${m.description} (${num(Number(m.stdPrice))})` })),
            },
            { name: "qtyIn", label: "Qty in (receive)", type: "number", step: "0.01", min: 0, defaultValue: "0", required: false },
            { name: "qtyOut", label: "Qty out (issue)", type: "number", step: "0.01", min: 0, defaultValue: "0", required: false },
            { name: "amountIn", label: "Value in (blank = std price)", type: "number", step: "0.01", min: 0, defaultValue: "0", required: false },
            { name: "amountOut", label: "Value out (blank = std price)", type: "number", step: "0.01", min: 0, defaultValue: "0", required: false },
            { name: "ref", label: "Reference / reason", type: "text", placeholder: "e.g. GR for PO 4500000003", defaultValue: "", required: false },
          ]}
        />

        <Card title="Stock Valuation" sub="Per material — book value from the journal, quantities from movements" pad={false}>
          {stock.length === 0 ? (
            <div className="p-4">
              <EmptyState icon="box" title="No stock yet" body="Record movements on the left, receive goods against POs, or run production orders to build stock." />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px]">
                <thead>
                  <tr className="border-b border-ink-700/70">
                    <th className={thCls}>Material</th>
                    <th className={thCls}>Description</th>
                    <th className={thCls}>Type</th>
                    <th className={thCls + " text-right"}>Qty (moves)</th>
                    <th className={thCls + " text-right"}>Std price</th>
                    <th className={thCls + " text-right"}>Book value</th>
                    <th className={thCls + " text-right"}>Variance vs std</th>
                  </tr>
                </thead>
                <tbody>
                  {stock.map((s) => {
                    const stdVal = s.qty * s.stdPrice;
                    const varr = s.value - stdVal;
                    return (
                      <tr key={s.material} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{s.material}</span></td>
                        <td className={tdCls}><span className="text-[13px]">{s.description}</span></td>
                        <td className={tdCls}><span className="text-[12px] text-mist-500">{s.type}</span></td>
                        <td className={numCls}>{num(s.qty)}</td>
                        <td className={numCls}>{num(s.stdPrice)}</td>
                        <td className={numCls + " font-semibold text-mist-100"}>{num(s.value)}</td>
                        <td className={numCls + (Math.abs(varr) < 0.01 ? "text-mist-600" : varr > 0 ? "text-neg" : "text-pos")}>{num(varr)}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t border-ink-600 bg-ink-900/60">
                    <td className={tdCls + " font-semibold text-mist-100"} colSpan={5}>Total inventory value</td>
                    <td className={numCls + " font-bold text-gold-300"}>{num(totalValue)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
