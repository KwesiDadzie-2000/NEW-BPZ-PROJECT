import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { dashboardData } from "@/lib/reports";
import { getRates } from "@/lib/fx";
import { sectorByCode } from "@/data/sectors";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { money, num, fmtDate } from "@/lib/format";
import {
  PageHeader, Card, Stat, ModuleTag, ExportLink, Bar, Icon, btn, tdCls, thCls, numCls, rowCls,
} from "@/components/ui";
import { SimulatePanel } from "@/components/SimulatePanel";
import { DonutChart } from "@/components/Charts";
import { db as database } from "@/db";
import { activityLog } from "@/db/schema";

export const dynamic = "force-dynamic";

const MODULE_BAR: Record<string, string> = {
  MM: "bg-mm", SD: "bg-sd", HR: "bg-hr", "FI-AA": "bg-aa", ADMIN: "bg-ad", FI: "bg-fi", INV: "bg-gold-400",
};

export default async function DashboardPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const d = await dashboardData(clientId);
  const rates = await getRates();
  const client = (await db.select().from(clients).where(eq(clients.id, clientId)))[0];
  const sector = sectorByCode(client?.sector ?? "services");
  const recentActivity = await db
    .select()
    .from(activityLog)
    .where(eq(activityLog.clientId, ws.client.id))
    .orderBy(desc(activityLog.id))
    .limit(8);

  const empty = d.totals.lineCount === 0;
  const maxMod = Math.max(...d.mod.map((m) => m.dr), 1);
  const maxCC = Math.max(...d.cc.map((c) => c.dr), 1);

  return (
    <>
      <PageHeader
        kicker={`Command Center · ${ws.client.code} · ${sector.name}`}
        title={ws.client.name}
        desc="Every department posts to one Universal Journal — accounting updates itself. IFRS/IAS statements, Ghana tax and live FX, all in real time."
      >
        <ExportLink sheet="all" label="Full workbook (.xlsx)" />
      </PageHeader>

      {/* Live FX strip */}
      <div className="mb-5 flex flex-wrap items-center gap-x-5 gap-y-2 rounded-xl border border-ink-700 bg-ink-850/70 px-4 py-3">
        <span className="text-[12.5px] font-bold uppercase tracking-[0.16em] text-mist-500">Live rates (BOG mid proxy)</span>
        {rates.filter((r) => r.code !== "GHS").map((r) => (
          <span key={r.code} className="font-mono text-[13px] tabular-nums text-mist-300">
            <span className="font-bold text-gold-300">{r.code}</span> {num(r.rateGhs)}
            <span className="ml-1.5 text-[12px] text-mist-600">₵</span>
          </span>
        ))}
        <span className="ml-auto text-[12px] text-mist-600">
          Updated {rates.find((r) => r.code === "USD")?.updatedAt ? fmtDate(rates.find((r) => r.code === "USD")?.updatedAt.slice(0, 10) ?? "") : "—"} · FX gain/loss auto-recognised on payments & month-end
        </span>
      </div>

      {empty ? (
        <SimulatePanel variant="hero" />
      ) : (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
            <Stat label="Cash & Bank" value={money(d.bank)} sub="All bank + cash accounts" />
            <Stat label="Accounts Receivable" value={money(d.ar)} sub="Customer open balances" />
            <Stat label="Accounts Payable" value={money(d.ap)} sub="Supplier open balances" />
            <Stat label="Revenue" value={money(d.rev)} tone="text-pos" sub="All income accounts" />
            <Stat label="Operating Expenses" value={money(d.exp)} tone="text-neg" sub="All expense accounts" />
            <Stat label="Net Income" value={money(d.net)} tone={d.net >= 0 ? "text-pos" : "text-neg"} sub="Revenue − expenses" />
            <Stat label="VAT Payable" value={money(d.grir)} sub="Output VAT position" tone={d.grir > 0 ? "text-aa" : undefined} />
            <Stat label="Documents" value={d.totals.docCount.toLocaleString()} sub={`${d.totals.docsToday} posted today`} />
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            <Card title="Activity by Module" sub="Debit volume generated per department">
              <div className="space-y-3.5">
                {d.mod.map((m) => (
                  <div key={m.module}>
                    <div className="mb-1.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <ModuleTag m={m.module} />
                        <span className="text-xs text-mist-500">{m.docs} docs</span>
                      </div>
                      <span className="font-mono text-xs tabular-nums text-mist-300">{money(m.dr)}</span>
                    </div>
                    <Bar pct={(m.dr / maxMod) * 100} cls={MODULE_BAR[m.module]} />
                  </div>
                ))}
              </div>
            </Card>

            <Card title={"Sector Position — " + sector.name} sub="Tailored regulatory context for this workspace">
              <p className="mb-2 text-[13px] leading-relaxed text-mist-400">{sector.corpTaxNote}</p>
              <ul className="mb-3 space-y-1.5">
                {sector.sectorTaxNotes.slice(0, 4).map((n) => (
                  <li key={n} className="flex items-start gap-2 text-[12.5px] leading-snug text-mist-500">
                    <Icon name="check" size={13} className="mt-0.5 shrink-0 text-gold-400" />
                    {n}
                  </li>
                ))}
              </ul>
              <div className="rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12px] text-mist-500">
                <span className="font-bold text-gold-300">BPZ advisory focus: </span>
                {sector.advisoryFocus}
              </div>
              <div className="mt-3 flex gap-2">
                <Link href="/sector-ops" className={btn.tiny}><Icon name="bolt" size={13} /> Sector operations</Link>
                <Link href="/advisory" className={btn.tiny}><Icon name="doc" size={13} /> Workpapers</Link>
              </div>
            </Card>
          </div>

          <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
            <Card
              title="Recent Journal Activity"
              sub="Latest lines from the Universal Journal"
              pad={false}
              action={
                <Link href="/universal-journal" className={btn.tiny}>
                  Open journal
                  <Icon name="back" size={13} className="rotate-180" />
                </Link>
              }
            >
              <div className="overflow-x-auto">
                <table className="w-full min-w-[680px]">
                  <thead>
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Doc</th>
                      <th className={thCls}>Period</th>
                      <th className={thCls}>Module</th>
                      <th className={thCls}>Account</th>
                      <th className={thCls}>Description</th>
                      <th className={thCls + " text-right"}>Debit</th>
                      <th className={thCls + " text-right"}>Credit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.recent.map((r) => (
                      <tr key={r.id} className={rowCls}>
                        <td className={tdCls}>
                          <Link href={`/universal-journal?doc=${r.docNo}`} className="font-mono text-[12.5px] text-gold-300 hover:underline">
                            {r.docNo}
                          </Link>
                        </td>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{r.period}</span></td>
                        <td className={tdCls}><ModuleTag m={r.module} /></td>
                        <td className={tdCls}>
                          <span className="font-mono text-[12.5px] text-mist-100">{r.account}</span>
                          <div className="mt-0.5 max-w-[150px] truncate text-[12.5px] text-mist-600">{r.accDesc}</div>
                        </td>
                        <td className={tdCls}>
                          <span className="block max-w-[200px] truncate text-[13px]">{r.description}</span>
                        </td>
                        <td className={numCls + " text-aa"}>{r.debit ? num(r.debit) : ""}</td>
                        <td className={numCls + " text-pos"}>{r.credit ? num(r.credit) : ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            <SimulatePanel />
          </div>
        </div>
      )}
    </>
  );
}
