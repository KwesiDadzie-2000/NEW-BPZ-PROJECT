import ExcelJS from "exceljs";
import { db } from "@/db";
import { accounts, partners, costCenters, materials, purchaseOrders, salesOrders, invoices, bankLines, bankAccounts, assets, payrollRuns, feeInvoices, budgetLines, budgetScenarios } from "@/db/schema";
import { eq, and, asc, desc } from "drizzle-orm";
import {
  journalRows,
  trialBalance,
  byModule,
  byCostCenter,
  pnl,
  balanceSheet,
  cashFlow,
  statementOfChangesInEquity,
  aging,
  stockValuation,
  budgetVariance,
  bpLedger,
} from "@/lib/reports";
import { requireApiWorkspace } from "@/lib/auth";
import { num as n2 } from "@/lib/format";

export const dynamic = "force-dynamic";

type Row = (string | number)[];

function sheet(wb: ExcelJS.Workbook, name: string, header: Row, rows: Row[], widths?: number[]) {
  const ws = wb.addWorksheet(name, {
    views: [{ state: "frozen", ySplit: 1 }],
  });
  const head = ws.addRow(header);
  head.font = { bold: true, color: { argb: "0xE3BE5A" } };
  head.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "0x122234" } };
  for (const r of rows) ws.addRow(r);
  if (widths) widths.forEach((w, idx) => (ws.getColumn(idx + 1).width = w));
  return ws;
}

export async function GET(req: Request) {
  let ws;
  try {
    ws = await requireApiWorkspace();
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Not authenticated." }, { status: 401 });
  }
  const clientId = ws.client.id;
  const tag = ws.client.code;
  const url = new URL(req.url);
  const sheetName = url.searchParams.get("sheet") ?? "journal";
  const from = url.searchParams.get("from") ?? undefined;
  const to = url.searchParams.get("to") ?? undefined;
  const bp = url.searchParams.get("bp") ?? undefined;
  const scenarioId = Number(url.searchParams.get("scenario") ?? 0);

  const wb = new ExcelJS.Workbook();
  wb.creator = "BPZ & Co. Ltd";
  wb.created = new Date();

  const push = (name: string, header: Row, rows: Row[], widths?: number[]) => sheet(wb, name, header, rows, widths);

  if (sheetName === "journal" || sheetName === "all") {
    const rows = await journalRows({ clientId, from, to, limit: 100_000 });
    push("Universal_Journal",
      ["Doc", "Period", "Date", "Module", "Type", "Account", "BP", "CC", "Material", "Description", "Debit", "Credit", "By", "Reference"],
      rows.map((r) => [r.docNo, r.period, r.postDate, r.module, r.docType, r.account, r.bp, r.costCenter, r.material, r.description, n2(r.debit), n2(r.credit), r.createdBy, r.reference]),
      [14, 8, 11, 7, 6, 9, 7, 8, 9, 38, 12, 12, 14, 22]);
  }
  if (sheetName === "trial_balance" || sheetName === "all") {
    const tb = await trialBalance(clientId, from, to);
    push("Trial_Balance",
      ["Account", "Description", "Type", "Total Dr", "Total Cr", "Balance"],
      [...tb.rows.map((r) => [r.account, r.description, r.type, n2(r.dr), n2(r.cr), n2(r.bal)]), ["", "TOTALS", "", n2(tb.totalDr), n2(tb.totalCr), n2(tb.totalDr - tb.totalCr)]],
      [9, 40, 11, 14, 14, 14]);
  }
  if (sheetName === "by_module" || sheetName === "all") {
    const rows = await byModule(clientId, from, to);
    push("By_Module", ["Module", "Documents", "Debits", "Credits"], rows.map((r) => [r.module, r.docs, n2(r.dr), n2(r.cr)]), [12, 12, 14, 14]);
  }
  if (sheetName === "by_cost_center" || sheetName === "all") {
    const rows = await byCostCenter(clientId, from, to);
    push("By_Cost_Center", ["CC", "Name", "Debits", "Credits"], rows.map((r) => [r.cc, r.name, n2(r.dr), n2(r.cr)]), [10, 24, 14, 14]);
  }
  if (sheetName === "pnl" || sheetName === "all") {
    const p = await pnl(clientId, from, to);
    push("Profit_and_Loss",
      ["Section", "Account", "Description", "Amount"],
      [
        ...p.revenue.map((r) => ["Revenue", r.account, r.description, n2(r.amount)] as Row),
        ["Revenue", "", "Total revenue", n2(p.totalRev)],
        ...p.expense.map((r) => ["Expense", r.account, r.description, n2(r.amount)] as Row),
        ["Expense", "", "Total expenses", n2(p.totalExp)],
        ["", "", "NET INCOME", n2(p.net)],
      ],
      [10, 9, 40, 14]);
  }
  if (sheetName === "balance_sheet" || sheetName === "all") {
    const b = await balanceSheet(clientId, from, to);
    push("Balance_Sheet",
      ["Section", "Account", "Description", "Amount"],
      [
        ...b.assets.map((r) => ["Assets", r.account, r.description, n2(r.bal)] as Row),
        ["Assets", "", "Total assets", n2(b.tAssets)],
        ...b.liab.map((r) => ["Liabilities", r.account, r.description, n2(-r.bal)] as Row),
        ...b.equity.map((r) => ["Equity", r.account, r.description, n2(-r.bal)] as Row),
        ["Equity", "", "Add: net income (loss)", n2(b.net)],
        ["Liabilities + Equity", "", "Total", n2(b.tLiabEqNet)],
      ],
      [18, 9, 40, 14]);
  }
  if (sheetName === "cash_flow" || sheetName === "all") {
    const cf = await cashFlow(clientId, from, to);
    push("Cash_Flow_IAS7",
      ["Line", "Amount"],
      [
        ...cf.operatingLines.map((l) => [l.label, n2(l.v)] as Row),
        ["Operating subtotal", n2(cf.operating)],
        ...cf.investingLines.map((l) => [l.label, n2(l.v)] as Row),
        ...cf.financingLines.map((l) => [l.label, n2(l.v)] as Row),
        ["Net change (computed)", n2(cf.change)],
        ["Cash at start", n2(cf.cashOpen)],
        ["Cash at end (per books)", n2(cf.cashClose)],
        ["Actual change in cash", n2(cf.changeActual)],
      ],
      [42, 14]);
  }
  if (sheetName === "soce" || sheetName === "all") {
    const s = await statementOfChangesInEquity(clientId, from, to);
    push("Stmt_Changes_Equity",
      ["Account", "Description", "Opening", "Movement", "Closing"],
      [
        ...s.rows.map((r) => [r.account, r.description, n2(r.opening), n2(r.movement), n2(r.closing)] as Row),
        ["", "Net income (loss) for period", "", n2(s.net), ""],
      ],
      [9, 38, 14, 14, 14]);
  }
  if (sheetName === "aging_ap" || sheetName === "all") {
    const rows = await aging(clientId, "AP");
    push("Aging_AP",
      ["Supplier", "Name", "Current", "1–30", "31–60", "61–90", ">90", "Total"],
      rows.map((r) => [r.bp, r.name, n2(r.buckets[0]), n2(r.buckets[1]), n2(r.buckets[2]), n2(r.buckets[3]), n2(r.buckets[4]), n2(r.total)]),
      [8, 32, 12, 12, 12, 12, 12, 14]);
  }
  if (sheetName === "aging_ar" || sheetName === "all") {
    const rows = await aging(clientId, "AR");
    push("Aging_AR",
      ["Customer", "Name", "Current", "1–30", "31–60", "61–90", ">90", "Total"],
      rows.map((r) => [r.bp, r.name, n2(r.buckets[0]), n2(r.buckets[1]), n2(r.buckets[2]), n2(r.buckets[3]), n2(r.buckets[4]), n2(r.total)]),
      [8, 32, 12, 12, 12, 12, 12, 14]);
  }
  if (sheetName === "stock" || sheetName === "all") {
    const rows = await stockValuation(clientId, from, to);
    push("Stock_Valuation",
      ["Material", "Description", "Type", "Qty (per moves)", "Book value (journal)", "Std price"],
      rows.map((r) => [r.material, r.description, r.type, r.qty, n2(r.value), n2(r.stdPrice)]),
      [10, 28, 14, 16, 18, 10]);
  }
  if (sheetName === "bp_ledger" && bp) {
    const l = await bpLedger(clientId, bp, from, to);
    push(`Ledger_${bp}`,
      ["Doc", "Period", "Date", "Module", "Description", "Debit", "Credit", "Running"],
      l.lines.map((x) => [x.docNo, x.period, x.postDate, x.module, x.description, n2(x.debit), n2(x.credit), n2(x.running)]),
      [14, 8, 11, 7, 40, 12, 12, 12]);
  }
  if (sheetName === "budget" && scenarioId) {
    const rows = await budgetVariance(clientId, scenarioId, from, to);
    push("Budget_Variance",
      ["Account", "Description", "Type", "Budget", "Actual", "Variance", "Note"],
      rows.map((r) => [r.account, r.description, r.type, n2(r.budget), n2(r.actual), n2(r.variance), r.note]),
      [9, 40, 10, 14, 14, 14, 24]);
  }
  if (sheetName === "coa" || sheetName === "all") {
    const rows = await db.select().from(accounts).orderBy(asc(accounts.accountNo));
    push("Chart_of_Accounts", ["Account", "Description", "Type"], rows.map((r) => [r.accountNo, r.description, r.type]), [9, 44, 10]);
  }
  if (sheetName === "partners" || sheetName === "all") {
    const rows = await db.select().from(partners).orderBy(asc(partners.bpNo));
    push("Business_Partners", ["BP", "Name", "Type"], rows.map((r) => [r.bpNo, r.name, r.type]), [8, 36, 10]);
  }
  if (sheetName === "cost_centers" || sheetName === "all") {
    const rows = await db.select().from(costCenters).orderBy(asc(costCenters.ccCode));
    push("Cost_Centers", ["Code", "Name"], rows.map((r) => [r.ccCode, r.ccName]), [10, 24]);
  }
  if (sheetName === "materials" || sheetName === "all") {
    const rows = await db.select().from(materials).orderBy(asc(materials.materialNo));
    push("Materials", ["Material", "Description", "Type", "Std price"], rows.map((r) => [r.materialNo, r.description, r.type, n2(Number(r.stdPrice))]), [10, 30, 14, 10]);
  }
  if (sheetName === "purchase_orders" || sheetName === "all") {
    const rows = await db.select().from(purchaseOrders).where(eq(purchaseOrders.clientId, clientId)).orderBy(asc(purchaseOrders.id));
    push(`POs_${tag}`, ["PO", "Vendor", "Material", "Qty", "Price", "Total", "CC", "Status"], rows.map((r) => [r.poNo, r.vendor, r.material, r.qty, n2(Number(r.price)), n2(Number(r.total)), r.cc, r.status]), [13, 9, 9, 6, 10, 12, 8, 14]);
  }
  if (sheetName === "sales_orders" || sheetName === "all") {
    const rows = await db.select().from(salesOrders).where(eq(salesOrders.clientId, clientId)).orderBy(asc(salesOrders.id));
    push(`SOs_${tag}`, ["SO", "Customer", "Material", "Qty", "Price", "Total", "Status"], rows.map((r) => [r.soNo, r.customer, r.material, r.qty, n2(Number(r.price)), n2(Number(r.total)), r.status]), [13, 9, 9, 6, 10, 12, 10]);
  }
  if (sheetName === "invoices" || sheetName === "all") {
    const rows = await db.select().from(invoices).where(eq(invoices.clientId, clientId)).orderBy(desc(invoices.id)).limit(500);
    push(`Invoices_${tag}`, ["No", "Direction", "Type", "BP", "Currency", "Rate", "Subtotal", "VAT 20%", "Total", "Paid", "Status", "Period", "Doc"], rows.map((r) => [r.no, r.direction, r.docType, r.bp, r.currency, n2(Number(r.rate)), n2(Number(r.subtotal)), n2(Number(r.vat)), n2(Number(r.total)), n2(Number(r.paid)), r.status, r.period, r.docNo]), [9, 9, 8, 8, 7, 8, 12, 10, 12, 10, 9, 8, 13]);
  }
  if (sheetName === "bank" || sheetName === "all") {
    const accs = await db.select().from(bankAccounts).where(eq(bankAccounts.clientId, clientId));
    const all: Row[] = [];
    for (const a of accs) {
      const lines = await db.select().from(bankLines).where(eq(bankLines.accountId, a.id));
      for (const l of lines) all.push([a.name, l.txnDate, l.ref, l.description, n2(Number(l.amount)), l.status, l.note]);
    }
    push(`Bank_Statements_${tag}`, ["Account", "Date", "Ref", "Description", "Amount", "Status", "Note"], all, [16, 11, 12, 40, 12, 10, 20]);
  }
  if (sheetName === "payroll" || sheetName === "all") {
    const rows = await db.select().from(payrollRuns).where(eq(payrollRuns.clientId, clientId)).orderBy(desc(payrollRuns.id));
    push(`Payroll_${tag}`, ["Period", "Employee", "Basic", "Allowance", "Gross", "PAYE", "SSNIT T1", "SSNIT T2", "NHIL", "Housing", "Net", "Employer cost", "Paid", "Doc"], rows.map((r) => [r.period, r.bpNo, n2(Number(r.basic)), n2(Number(r.allowance)), n2(Number(r.gross)), n2(Number(r.paye)), n2(Number(r.ssnitT1)), n2(Number(r.ssnitT2)), n2(Number(r.nhil)), n2(Number(r.housing)), n2(Number(r.net)), n2(Number(r.employerCost)), n2(Number(r.paid)), r.docNo]), [8, 8, 10, 10, 10, 10, 10, 10, 10, 9, 10, 12, 10, 13]);
  }
  if (sheetName === "assets" || sheetName === "all") {
    const rows = await db.select().from(assets).where(eq(assets.clientId, clientId)).orderBy(asc(assets.id));
    push(`Assets_${tag}`, ["Asset", "Class", "Cost", "Accum dep", "NBV", "In service", "CC", "Doc"], rows.map((r) => [r.name, r.classCode, n2(Number(r.cost)), n2(Number(r.accumDep)), n2(Number(r.nbv)), r.inService, r.cc, r.docNo]), [30, 12, 12, 12, 12, 11, 8, 13]);
  }
  if (sheetName === "employees" || sheetName === "all") {
    const { listEmployees } = await import("@/lib/employees");
    const rows = await listEmployees(clientId);
    push(`Payroll_Master_${tag}`,
      ["Code", "Name", "Position", "Department", "Jurisdiction", "Currency", "Type", "Basic", "Allowances", "TIN", "SSNIT/Pension", "Bank account", "Email", "Phone", "Hire date", "End date", "Status"],
      rows.map((r) => [r.code, r.name, r.position, r.department, r.jurisdiction, r.currency, r.employmentType, n2(r.basicSalary), n2(r.allowances), r.tin, r.ssnitNo, r.bankAccount, r.email, r.phone, r.hireDate, r.endDate, r.status]),
      [9, 26, 20, 10, 11, 8, 11, 11, 11, 13, 14, 18, 22, 13, 11, 11, 9]);
  }
  if (sheetName === "vat" || sheetName === "all") {
    const { vatReturn, whtSchedule } = await import("@/lib/reports");
    const v = await vatReturn(clientId, from ?? undefined, to ?? undefined);
    const w = await whtSchedule(clientId, from ?? undefined, to ?? undefined);
    push(`VAT_Return_${tag}`,
      ["Line", "Amount"],
      [
        ["Standard-rated sales (net of VAT)", n2(v.salesBase)],
        ["Output VAT @ 20%", n2(v.output)],
        ["Purchases / expenses (net of VAT)", n2(v.purchasesBase)],
        ["Input VAT recoverable", n2(v.input)],
        ["NET VAT PAYABLE", n2(v.netPayable)],
        ["Period", `${from ?? "start"} to ${to ?? "now"}`],
      ],
      [42, 16]);
    push(`WHT_Schedule_${tag}`,
      ["Supplier", "Name", "WHT type", "Deducted"],
      [...w.byPartner.map((x) => [x.bp, x.name, x.detail, n2(x.deducted)]), ["", "", "TOTAL TO REMIT", n2(w.payable)]],
      [10, 32, 40, 14]);
  }
  if (sheetName === "contracts" || sheetName === "all") {
    const { contractPortfolio, listCertificates } = await import("@/lib/contracts");
    const pf = await contractPortfolio(clientId);
    push(`Contracts_IFRS15_${tag}`,
      ["Contract", "Title", "Customer", "Method", "Start", "End", "Value", "Est cost", "% complete", "Revenue to date", "Cost to date", "Profit to date", "Billed", "Contract asset", "Contract liability", "Retention held", "Status", "Onerous"],
      pf.all.map((c) => [c.no, c.title, c.counterparty, c.method, c.startDate, c.endDate, n2(c.totalValue), n2(c.estimatedCost), c.pctComplete.toFixed(1), n2(c.revenueToDate), n2(c.costToDate), n2(c.cumulativeProfit), n2(c.billed), n2(c.contractAsset), n2(c.contractLiability), n2(c.retentionHeld), c.status, c.isLossMaking ? "YES" : "no"]),
      [12, 34, 10, 18, 11, 11, 13, 13, 11, 15, 13, 13, 13, 14, 15, 13, 10, 8]);
    const certs = await listCertificates(clientId);
    push(`Certificates_${tag}`,
      ["Certificate", "Contract", "Period", "Gross", "Retention", "Net due", "Paid", "Status", "Doc"],
      certs.map((c) => [c.certNo, c.period, c.period, n2(Number(c.grossValue)), n2(Number(c.retention)), n2(Number(c.netPayable)), n2(Number(c.paid)), c.status, c.docNo]),
      [16, 12, 10, 13, 12, 13, 12, 10, 14]);
  }
  if (sheetName === "standards" || sheetName === "all") {
    const { listInstruments } = await import("@/lib/ifrs9");
    const { listLeases } = await import("@/lib/ifrs16");
    const { listImpairmentTests, listHeldForSale, standardsBalances } = await import("@/lib/impairment");
    push(`IFRS9_Instruments_${tag}`,
      ["Code", "Name", "Category", "Type", "Carrying", "ECL allowance", "Stage", "EIR %", "Collateral", "Status"],
      (await listInstruments(clientId)).map((x) => [x.code, x.name, x.category, x.instrumentType, n2(Number(x.carryingAmount)), n2(Number(x.eclAllowance)), x.stage, n2(Number(x.effectiveRate)), n2(Number(x.collateralValue)), x.status]),
      [12, 30, 16, 16, 14, 14, 8, 10, 14, 10]);
    push(`IFRS9_ECL_Movement_${tag}`,
      ["Line", "Amount"],
      Object.entries(await standardsBalances(clientId)).map(([k, v]) => [k, n2(v)]),
      [28, 16]);
    push(`IFRS16_Leases_${tag}`,
      ["Code", "Description", "Lessor", "Term (mths)", "Payment", "Rate %", "ROU", "Accum dep", "Liability", "Status"],
      (await listLeases(clientId)).map((x) => [x.code, x.description, x.lessor, x.termMonths, n2(Number(x.payment)), n2(Number(x.discountRate)), n2(Number(x.rouAsset)), n2(Number(x.accumulatedDepreciation)), n2(Number(x.leaseLiability)), x.status]),
      [12, 30, 16, 12, 14, 10, 14, 14, 14, 10]);
    push(`IAS36_Impairment_${tag}`,
      ["Period", "Asset / CGU", "Carrying", "Value in use", "FV less costs", "Recoverable", "Loss", "Doc"],
      (await listImpairmentTests(clientId)).map((x) => [x.period, x.unitName, n2(Number(x.carryingAmount)), n2(Number(x.valueInUse)), n2(Number(x.fairValueLessCosts)), n2(Number(x.recoverableAmount)), n2(Number(x.impairmentLoss)), x.docNo]),
      [10, 28, 14, 14, 14, 14, 14, 14]);
    push(`IFRS5_HeldForSale_${tag}`,
      ["Asset", "Description", "Cost", "Accum dep", "Carrying", "FV less costs", "Write-down", "Discontinued", "Status"],
      (await listHeldForSale(clientId)).map((x) => [x.assetCode, x.description, n2(Number(x.originalCost)), n2(Number(x.accumulatedDepreciation)), n2(Number(x.carryingAmount)), n2(Number(x.fairValueLessCosts)), n2(Number(x.writeDown)), x.discontinuedOperation ? "yes" : "no", x.status]),
      [12, 30, 14, 14, 14, 14, 14, 12, 14]);
  }
  if (sheetName === "loans" || sheetName === "all") {
    const { listLoans, listSchedule } = await import("@/lib/loans-service");
    const all = await listLoans(clientId);
    push(`Loans_Facilities_${tag}`,
      ["Code", "Lender", "Type", "Principal", "Rate %", "Term (mths)", "Outstanding", "Status"],
      all.map((x) => [x.code, x.lender, x.facilityType, n2(Number(x.principal)), n2(Number(x.annualRate)), x.termMonths, n2(Number(x.outstanding)), x.status]),
      [14, 24, 14, 14, 10, 12, 14, 10]);
    for (const l of all.slice(0, 8)) {
      const sch = await listSchedule(clientId, l.id);
      if (!sch.length) continue;
      push(`Sched_${l.code.replace(/[^A-Za-z0-9]/g, "")}_${tag}`,
        ["#", "Period", "Opening", "Interest", "Fee", "Principal", "Payment", "Closing", "Status", "Doc"],
        sch.map((s) => [s.seq, s.period, n2(Number(s.opening)), n2(Number(s.interest)), n2(Number(s.fee)), n2(Number(s.principal)), n2(Number(s.payment)), n2(Number(s.closing)), s.status, s.docNo]),
        [5, 10, 14, 14, 10, 14, 14, 14, 10, 14]);
    }
  }
  if (sheetName === "activity" || sheetName === "all") {
    const { listActivity } = await import("@/lib/security");
    const isOwner = ws.user.role === "owner";
    const rows = await listActivity(isOwner ? null : clientId, 5000);
    push(`System_Audit_Log_${tag}`,
      ["When (UTC)", "User", "Role", "Workspace", "Action", "Outcome", "Detail", "IP"],
      rows.map((r) => [new Date(r.at).toISOString().replace("T", " ").slice(0, 19), r.username, r.role, r.workspace, r.action, r.ok ? "success" : "blocked", r.detail, r.ip]),
      [20, 14, 11, 11, 22, 10, 50, 15]);
  }
  if (sheetName === "fx_history" || sheetName === "all") {
    const { fxRateHistory } = await import("@/lib/security");
    const { getRates } = await import("@/lib/fx");
    const codes = (await getRates()).map((r) => r.code).filter((c) => c !== "GHS");
    const rows: Row[] = [];
    for (const c of codes) {
      for (const h of await fxRateHistory(c, 200)) {
        rows.push([c, n2(h.rate), h.source, new Date(h.capturedAt).toISOString().replace("T", " ").slice(0, 19)]);
      }
    }
    push(`FX_Rate_History_${tag}`,
      ["Currency", "GHS per unit", "Source", "Captured (UTC)"],
      rows.length ? rows : [["No rate history yet — rates are recorded on every refresh or override."]],
      [10, 14, 34, 20]);
  }
  if (sheetName === "fees" || sheetName === "all") {
    const rows = await db.select().from(feeInvoices).where(eq(feeInvoices.clientId, clientId)).orderBy(desc(feeInvoices.id));
    push(`BPZ_Fees_${tag}`, ["Client", "Service line", "Period", "Amount", "Status", "Doc"], rows.map((r) => [ws.client.name, r.serviceLine, r.period, n2(Number(r.amount)), r.status, r.docNo]), [24, 26, 8, 12, 9, 13]);
  }
  if (sheetName === "budgets") {
    const scs = await db.select().from(budgetScenarios).where(eq(budgetScenarios.clientId, clientId));
    for (const s of scs) {
      const rows = await db.select().from(budgetLines).where(and(eq(budgetLines.clientId, clientId), eq(budgetLines.scenarioId, s.id)));
      push(s.name.replace(/\s+/g, "_") + "_" + s.fiscalYear, ["Account", "Amount", "Note"], rows.map((r) => [r.account, n2(Number(r.amount)), r.note]), [10, 14, 26]);
    }
  }


  if (sheetName === "notes" || sheetName === "all") {
    const { buildNotesToAccounts } = await import("@/lib/disclosures");
    const pack = await buildNotesToAccounts(clientId, from || undefined, to || undefined);
    push(`Notes_to_Accounts_${tag}`,
      ["#", "Title", "Standard", "Applicable", "N/A reason", "Body"],
      pack.notes.map((n, idx) => [idx + 1, n.title, n.standardRef, n.applicable ? "Yes" : "No", n.notApplicableReason || "", n.body.slice(0, 500)]),
      [5, 40, 16, 10, 40, 80]);
    for (const n of pack.notes) {
      if (!n.tables) continue;
      for (let ti = 0; ti < n.tables.length; ti++) {
        const t = n.tables[ti];
        const sheetSafe = (`Note_${n.key}_${ti}_` + tag).replace(/[^\w\-]+/g, "_").slice(0, 28);
        push(sheetSafe, t.headers, t.rows.map((r) => r.map((c) => (typeof c === "number" ? n2(c) : c))), t.headers.map(() => 16));
      }
    }
    push(`Accounting_Policies_${tag}`,
      ["Order", "Policy", "Standard", "Body"],
      pack.policies.map((p) => [p.sortOrder, p.title, p.standardRef, p.body]),
      [8, 30, 16, 80]);
  }
  if (sheetName === "provisions" || sheetName === "all") {
    const { listProvisions } = await import("@/lib/standards-service");
    const rows = await listProvisions(clientId);
    push(`IAS37_Provisions_${tag}`,
      ["Code", "Title", "Category", "Best est.", "PV", "Carrying", "Prob %", "Status", "Contingent", "Doc", "Notes"],
      rows.map((p) => [p.code, p.title, p.category, n2(Number(p.bestEstimate)), n2(Number(p.presentValue)), n2(Number(p.carryingAmount)), n2(Number(p.probability)), p.status, p.contingent ? "yes" : "no", p.docNo, p.notes.slice(0, 120)]),
      [12, 28, 14, 12, 12, 12, 10, 12, 10, 14, 40]);
  }
  if (sheetName === "group" || sheetName === "all") {
    const { listGroups, consolidatedTrialBalance } = await import("@/lib/consolidation");
    const gs = await listGroups();
    push(`Groups_${tag}`,
      ["Code", "Name", "Parent client", "Currency", "Members"],
      gs.map((g) => [g.code, g.name, g.parentClientId, g.reportingCurrency, g.members.length]),
      [12, 28, 12, 10, 10]);
    for (const g of gs.slice(0, 3)) {
      try {
        const c = await consolidatedTrialBalance(g.id, from || undefined, to || undefined);
        push(`Consol_TB_${g.code}_${tag}`.slice(0, 28),
          ["Account", "Description", "Type", "Subtotal", "Eliminations", "Consolidated"],
          c.rows.map((r) => [r.account, r.description, r.type, n2(r.subtotal), n2(r.eliminations), n2(r.consolidated)]),
          [12, 32, 12, 14, 14, 14]);
      } catch { /* empty group */ }
    }
  }

  if (!wb.worksheets.length) {
    sheet(wb, "Export", ["Info"], [["No data for the selected sheet."]]);
  }

  const buf = new Uint8Array(await wb.xlsx.writeBuffer());
  return new Response(buf, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="BPZ_${ws.client.code}_${sheetName === "all" ? "full_workbook" : sheetName}.xlsx"`,
    },
  });
}
