import { NextResponse } from "next/server";
import { db } from "@/db";
import { clients, users, meta } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireApiWorkspace } from "@/lib/auth";
import { hashPassword } from "@/lib/password";
import { passwordProblem } from "@/lib/totp";
import { SECTORS } from "@/data/sectors";
import { jurisdictionByCode } from "@/data/jurisdictions";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const ws = await requireApiWorkspace();
    if (ws.user.role !== "owner") {
      return NextResponse.json({ ok: false, error: "Only the owner can manage clients." }, { status: 403 });
    }

    const body = (await req.json()) as Record<string, unknown>;
    const clientName = String(body.clientName ?? "").trim();
    const username = String(body.username ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const displayName = String(body.displayName ?? "").trim() || username;
    const sector = String(body.sector ?? "services");
    const jurisdiction = String(body.jurisdiction ?? "GH");
    const serviceLines = String(body.serviceLines ?? "").split(",").map((s) => s.trim()).filter(Boolean).join(",");
    const feeModel = String(body.feeModel ?? "").trim();

    if (clientName.length < 2) {
      return NextResponse.json({ ok: false, error: "Client name must be at least 2 characters." }, { status: 400 });
    }
    if (!/^[a-z0-9_.-]{3,30}$/.test(username)) {
      return NextResponse.json({ ok: false, error: "Username must be 3–30 characters (letters, numbers, dot, dash, underscore)." }, { status: 400 });
    }
    const pwProblem = passwordProblem(password);
    if (pwProblem) return NextResponse.json({ ok: false, error: `Temporary password: ${pwProblem}` }, { status: 400 });
    if (!SECTORS.some((s) => s.code === sector)) {
      return NextResponse.json({ ok: false, error: "Unknown sector — pick one from the list." }, { status: 400 });
    }
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.username, username));
    if (existing.length) {
      return NextResponse.json({ ok: false, error: `Username "${username}" is already taken.` }, { status: 409 });
    }

    const jur = jurisdictionByCode(jurisdiction);
    const created = await db.transaction(async (tx) => {
      const all = await tx.select().from(clients);
      const code = `CLI-${String(Math.max(0, ...all.map((c) => c.id)) + 1).padStart(3, "0")}`;

      const [client] = await tx
        .insert(clients)
        .values({ code, name: clientName, sector, serviceLines, feeModel, baseCurrency: jur.currency, active: true })
        .returning({ id: clients.id, code: clients.code, name: clients.name, sector: clients.sector });

      await tx.insert(users).values({
        username,
        passwordHash: hashPassword(password),
        name: displayName,
        role: "client",
        clientId: client.id,
        active: true,
        mustChangePassword: true,
      });

      await tx.insert(meta).values([
        { key: "uj", clientId: client.id, value: 5_000_000_000 },
        { key: "po", clientId: client.id, value: 4_500_000_000 },
        { key: "so", clientId: client.id, value: 3_000_000_000 },
      ]);

      return client;
    });

    const requestUrl = new URL(req.url);
    const forwardedHost = req.headers.get("x-forwarded-host");
    const publicHost = forwardedHost ?? requestUrl.host;
    const isLocal = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(publicHost);
    // Some reverse proxies terminate TLS and forward internally over HTTP. The
    // handover must contain the PUBLIC secure URL, not that internal protocol.
    const publicProtocol = isLocal
      ? req.headers.get("x-forwarded-proto") ?? requestUrl.protocol.replace(":", "")
      : "https";
    const loginLink = `${publicProtocol}://${publicHost}/login`;

    return NextResponse.json({
      ok: true,
      client: created,
      message: `Client "${clientName}" created — workspace ${created.code} (${sector}) is live.`,
      credentials: {
        username,
        temporaryPassword: password,
        portalUrl: loginLink,
        mustResetPassword: true,
      },
      tempPassword: password,
      loginLink,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unexpected server error.";
    return NextResponse.json({ ok: false, error: msg }, { status: 400 });
  }
}
