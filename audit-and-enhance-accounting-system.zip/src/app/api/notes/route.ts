import { NextResponse } from "next/server";
import { requireApiWorkspace } from "@/lib/auth";
import { buildNotesToAccounts, renderNotesMarkdown } from "@/lib/disclosures";
import { ensureSeed } from "@/lib/init";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed();
  const ws = await requireApiWorkspace();
  const url = new URL(req.url);
  const from = url.searchParams.get("from") || undefined;
  const to = url.searchParams.get("to") || undefined;
  const format = url.searchParams.get("format") || "json";
  const pack = await buildNotesToAccounts(ws.client.id, from, to);
  if (format === "md" || format === "markdown") {
    return new NextResponse(renderNotesMarkdown(pack), {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": `attachment; filename="Notes_to_Accounts_${ws.client.code}.md"`,
      },
    });
  }
  return NextResponse.json({ ok: true, ...pack });
}
