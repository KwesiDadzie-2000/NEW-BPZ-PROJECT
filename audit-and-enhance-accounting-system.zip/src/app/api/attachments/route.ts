import { NextResponse } from "next/server";
import { requireApiWorkspace } from "@/lib/auth";
import { saveAttachment, listAttachments, readAttachment } from "@/lib/integrations";
import { sameOrigin } from "@/lib/security";
import { ensureSeed } from "@/lib/init";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed();
  const ws = await requireApiWorkspace();
  const url = new URL(req.url);
  const id = Number(url.searchParams.get("id") || 0);
  if (id) {
    const { row, data } = await readAttachment(id, ws.client.id);
    return new NextResponse(new Uint8Array(data), {
      headers: {
        "Content-Type": row.mimeType || "application/octet-stream",
        "Content-Disposition": `attachment; filename="${row.fileName}"`,
        "Content-Length": String(data.length),
      },
    });
  }
  const entityType = url.searchParams.get("entityType") || undefined;
  const entityId = url.searchParams.get("entityId") || undefined;
  const rows = await listAttachments(ws.client.id, entityType, entityId);
  return NextResponse.json({ ok: true, attachments: rows });
}

export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ ok: false, error: "CSRF" }, { status: 403 });
  try {
    await ensureSeed();
    const ws = await requireApiWorkspace();
    if (ws.user.role === "viewer") return NextResponse.json({ ok: false, error: "Read-only" }, { status: 403 });
    const ct = req.headers.get("content-type") || "";
    if (ct.includes("multipart/form-data")) {
      const form = await req.formData();
      const file = form.get("file");
      if (!(file instanceof File)) return NextResponse.json({ ok: false, error: "file required" }, { status: 400 });
      const buf = Buffer.from(await file.arrayBuffer());
      const saved = await saveAttachment({
        clientId: ws.client.id,
        entityType: String(form.get("entityType") || "other"),
        entityId: String(form.get("entityId") || "0"),
        fileName: file.name,
        mimeType: file.type,
        data: buf,
        uploadedBy: ws.user.username,
      });
      return NextResponse.json({ ok: true, ...saved });
    }
    const body = await req.json();
    const buf = Buffer.from(String(body.base64 || ""), "base64");
    const saved = await saveAttachment({
      clientId: ws.client.id,
      entityType: String(body.entityType || "other"),
      entityId: String(body.entityId || "0"),
      fileName: String(body.fileName || "upload.bin"),
      mimeType: String(body.mimeType || "application/octet-stream"),
      data: buf,
      uploadedBy: ws.user.username,
    });
    return NextResponse.json({ ok: true, ...saved, note: "Stored on filesystem — not as base64 in Postgres." });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Error" }, { status: 400 });
  }
}
