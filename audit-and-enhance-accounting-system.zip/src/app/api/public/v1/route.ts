import { NextResponse } from "next/server";
import { verifyApiKey } from "@/lib/integrations";
import { trialBalance, pnl, balanceSheet, cashFlow, journalRows, dashboardData } from "@/lib/reports";
import { buildNotesToAccounts } from "@/lib/disclosures";
import { listGroups, consolidatedTrialBalance } from "@/lib/consolidation";
import { ensureSeed } from "@/lib/init";

export const dynamic = "force-dynamic";

async function auth(req: Request) {
  const hdr = req.headers.get("authorization") || "";
  const key = hdr.toLowerCase().startsWith("bearer ") ? hdr.slice(7).trim() : req.headers.get("x-api-key") || "";
  const session = await verifyApiKey(key);
  if (!session) return null;
  return session;
}

export async function GET(req: Request) {
  await ensureSeed();
  const session = await auth(req);
  if (!session) return NextResponse.json({ ok: false, error: "Invalid or missing API key." }, { status: 401 });

  const url = new URL(req.url);
  const resource = url.searchParams.get("resource") || "health";
  const clientId = Number(url.searchParams.get("clientId") || session.clientId || 0);
  const from = url.searchParams.get("from") || undefined;
  const to = url.searchParams.get("to") || undefined;

  const need = (scope: string) => session.scopes.includes(scope) || session.scopes.includes("*") || session.scopes.includes("read:reports");

  try {
    switch (resource) {
      case "health":
        return NextResponse.json({
          ok: true,
          version: "1.0",
          scopes: session.scopes,
          resources: [
            "health",
            "trial_balance",
            "pnl",
            "balance_sheet",
            "cash_flow",
            "journal",
            "dashboard",
            "notes",
            "groups",
            "consolidated_tb",
          ],
        });
      case "trial_balance": {
        if (!need("read:reports") || !clientId) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        return NextResponse.json({ ok: true, data: await trialBalance(clientId, from, to) });
      }
      case "pnl": {
        if (!need("read:reports") || !clientId) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        return NextResponse.json({ ok: true, data: await pnl(clientId, from, to) });
      }
      case "balance_sheet": {
        if (!need("read:reports") || !clientId) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        return NextResponse.json({ ok: true, data: await balanceSheet(clientId, from, to) });
      }
      case "cash_flow": {
        if (!need("read:reports") || !clientId) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        return NextResponse.json({ ok: true, data: await cashFlow(clientId, from, to) });
      }
      case "journal": {
        if (!need("read:journal") && !need("read:reports")) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        if (!clientId) return NextResponse.json({ ok: false, error: "clientId required" }, { status: 400 });
        const rows = await journalRows({ clientId, from, to, limit: 500 });
        return NextResponse.json({ ok: true, data: rows });
      }
      case "dashboard": {
        if (!need("read:reports") || !clientId) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        return NextResponse.json({ ok: true, data: await dashboardData(clientId) });
      }
      case "notes": {
        if (!need("read:reports") || !clientId) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        const pack = await buildNotesToAccounts(clientId, from, to);
        return NextResponse.json({ ok: true, data: pack });
      }
      case "groups": {
        if (!need("read:reports")) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        return NextResponse.json({ ok: true, data: await listGroups() });
      }
      case "consolidated_tb": {
        if (!need("read:reports")) return NextResponse.json({ ok: false, error: "Forbidden" }, { status: 403 });
        const groupId = Number(url.searchParams.get("groupId") || 0);
        if (!groupId) return NextResponse.json({ ok: false, error: "groupId required" }, { status: 400 });
        return NextResponse.json({ ok: true, data: await consolidatedTrialBalance(groupId, from, to) });
      }
      default:
        return NextResponse.json({ ok: false, error: `Unknown resource ${resource}` }, { status: 400 });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Error" }, { status: 400 });
  }
}
