import { requireApiWorkspace } from "@/lib/auth";
import { buildSnapshot, recordBackup } from "@/lib/backup";
import { runAssurance } from "@/lib/assurance";
import { sameOrigin, clientIp, logActivity } from "@/lib/security";

export const dynamic = "force-dynamic";

/** GET /api/assurance?mode=snapshot|check */
export async function GET(req: Request) {
  try {
    const ws = await requireApiWorkspace();
    const url = new URL(req.url);
    const mode = url.searchParams.get("mode") ?? "check";

    if (mode === "snapshot") {
      const snap = await buildSnapshot(ws.client.id, ws.client.code, ws.client.name, ws.client.sector ?? "services");
      const json = JSON.stringify(snap, null, 1);
      const bytes = Buffer.byteLength(json, "utf8");
      await recordBackup(ws.client.id, bytes, ws.user.username, "workspace", snap.counts.journal_lines ?? 0);
      return new Response(json, {
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Content-Disposition": `attachment; filename="BPZ_${ws.client.code}_snapshot_${new Date().toISOString().slice(0, 10)}.json"`,
        },
      });
    }

    const result = await runAssurance();
    return Response.json({ ok: true, ...result });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}

/** POST /api/assurance — records a check event in the audit trail. */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ ok: false, error: "Cross-origin request blocked." }, { status: 403 });
  try {
    const ws = await requireApiWorkspace();
    const result = await runAssurance();
    await logActivity({
      clientId: ws.client.id, workspace: ws.client.code, username: ws.user.username, role: ws.user.role,
      action: "assurance_run", ok: result.failed === 0,
      detail: `Assurance: ${result.passed} passed, ${result.failed} failed, ${result.warned} warned`,
      ip: clientIp(req),
    });
    return Response.json({ ok: true, ...result });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}
