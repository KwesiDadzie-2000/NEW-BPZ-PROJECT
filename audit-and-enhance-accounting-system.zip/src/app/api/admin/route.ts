import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, journalLines, purchaseOrders, salesOrders, invoices, bankLines, assets, payrollRuns, stockMoves, productionOrders, contracts, budgetLines, engagements, feeInvoices, meta } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireApiWorkspace } from "@/lib/auth";
import { hashPassword } from "@/lib/password";
import { passwordProblem } from "@/lib/totp";
import { upsertRate, setPayeBands, upsertPayComponent } from "@/lib/tax";
import { PostingError } from "@/lib/posting";

export const dynamic = "force-dynamic";

const str = (v: unknown) => (v === undefined || v === null ? undefined : String(v).trim() || undefined);

export async function POST(req: Request) {
  try {
    const ws = await requireApiWorkspace();
    const body = (await req.json()) as Record<string, unknown>;
    const { action } = body;
    const isOwner = ws.user.role === "owner";
    const isFirmStaff = isOwner || ws.user.clientId === null;

    switch (action) {
      case "profile": {
        if (!str(body.name)) throw new PostingError("Name is required.");
        await db.update(users).set({ name: str(body.name)! }).where(eq(users.id, ws.user.id));
        return NextResponse.json({ ok: true, message: "Profile updated." });
      }

      case "users_list": {
        if (!isFirmStaff) throw new PostingError("Not permitted.");
        const rows = await db.select().from(users);
        return NextResponse.json({ ok: true, users: rows });
      }

      case "add_user": {
        if (!isFirmStaff) throw new PostingError("Only firm staff can manage logins.");
        const username = str(body.username)?.toLowerCase() ?? "";
        if (!/^[a-z0-9_.-]{3,30}$/.test(username)) throw new PostingError("Username must be 3–30 characters (letters, numbers, dot, dash).");
        const pwProblem = passwordProblem(String(body.password ?? ""));
        if (pwProblem) throw new PostingError(pwProblem);
        const taken = (await db.select({ id: users.id }).from(users).where(eq(users.username, username)))[0];
        if (taken) throw new PostingError(`Username "${username}" is already taken.`);
        const role = ["owner", "admin", "accountant", "viewer"].includes(str(body.role) ?? "") ? str(body.role) : "accountant";
        const clientId = body.clientId ? Number(body.clientId) : null;
        if (clientId) {
          const c = (await db.select({ id: users.clientId }).from(users).where(eq(users.id, 0)))[0];
          void c;
        }
        const created = await db.insert(users).values({
          username,
          passwordHash: hashPassword(String(body.password)),
          name: str(body.name) ?? username,
          role: role as never,
          clientId,
          active: true,
          mustChangePassword: !!body.mustChange,
        }).returning({ id: users.id });
        return NextResponse.json({ ok: true, id: created[0].id, message: `Login "${username}" created (${role}).` });
      }

      case "reissue_temp": {
        if (!isFirmStaff) throw new PostingError("Only firm staff can manage logins.");
        const u = (await db.select().from(users).where(eq(users.id, Number(body.userId))))[0];
        if (!u) throw new PostingError("User not found.");
        // Temporary password satisfies the platform policy (10+ chars, upper, lower, digit)
        // so the recipient can sign in immediately and is then required to set their own.
        const words = ["Cedi", "Accra", "Kente", "Baobab", "Harmattan", "Volta", "Ashanti", "Sahel"];
        const w = words[Math.floor(Math.random() * words.length)];
        const digits = String(Math.floor(1000 + Math.random() * 9000));
        const temp = `Bpz-${w}-${digits}!`;
        await db.update(users).set({ passwordHash: hashPassword(temp), mustChangePassword: true, usesBootstrapPassword: false }).where(eq(users.id, u.id));
        return NextResponse.json({
          ok: true,
          tempPassword: temp,
          link: "Open the preview link and sign in",
          message: `Temporary password issued to ${u.username}: ${temp}. They must reset it on first login.`,
        });
      }

      case "toggle_user": {
        if (!isFirmStaff) throw new PostingError("Only firm staff can manage logins.");
        const u = (await db.select().from(users).where(eq(users.id, Number(body.userId))))[0];
        if (!u) throw new PostingError("User not found.");
        if (u.role === "owner" && u.id === ws.user.id) throw new PostingError("You cannot deactivate yourself.");
        await db.update(users).set({ active: body.active !== false }).where(eq(users.id, u.id));
        return NextResponse.json({ ok: true, message: `User ${body.active !== false ? "activated" : "restricted"}.` });
      }

      case "set_role": {
        if (!isFirmStaff) throw new PostingError("Only firm staff can manage logins.");
        const role = str(body.role) ?? "";
        if (!["admin", "accountant", "viewer"].includes(role)) throw new PostingError("Choose admin, accountant or viewer.");
        await db.update(users).set({ role: role as never }).where(eq(users.id, Number(body.userId)));
        return NextResponse.json({ ok: true, message: `Role set to ${role}.` });
      }

      // ---- tax & rate administration (owner only) ----
      case "save_rate": {
        if (!isOwner) throw new PostingError("Only the owner can amend statutory rates.");
        await upsertRate({
          category: str(body.category) ?? "",
          name: str(body.name) ?? "",
          rate: Number(body.rate),
          effectiveFrom: str(body.effectiveFrom),
          notes: str(body.notes),
        });
        return NextResponse.json({ ok: true, message: "Rate updated — applies to all future runs." });
      }
      case "save_paye_bands": {
        if (!isOwner) throw new PostingError("Only the owner can amend PAYE bands.");
        const bands = Array.isArray(body.bands) ? (body.bands as { lower: number; upper: number | null; rate: number }[]) : [];
        if (!bands.length) throw new PostingError("At least one band is required.");
        await setPayeBands(bands, str(body.effectiveFrom) ?? "2026-09-01");
        return NextResponse.json({ ok: true, message: "PAYE schedule updated for all future payroll runs." });
      }
      case "save_pay_component": {
        if (!isOwner) throw new PostingError("Only the owner can amend payroll components.");
        await upsertPayComponent({
          id: body.id ? Number(body.id) : undefined,
          name: str(body.name) ?? "",
          base: ["gross", "basic", "net"].includes(str(body.base) ?? "") ? (str(body.base) as string) : "gross",
          rate: body.rate === null || body.rate === "" ? null : Number(body.rate),
          fixedAmount: Number(body.fixedAmount ?? 0),
          side: ["deduction", "income", "employer"].includes(str(body.side) ?? "") ? (str(body.side) as string) : "deduction",
          ordinal: Number(body.ordinal ?? 0),
          active: body.active !== false,
        });
        return NextResponse.json({ ok: true, message: "Payroll component saved." });
      }

      case "reset_system": {
        if (!isOwner) throw new PostingError("Only the owner can reset the system.");
        if (str(body.confirm) !== "RESET") throw new PostingError('Type RESET in the confirm box to reset the whole system.');
        await db.transaction(async () => {
          await db.delete(engagements);
          await db.delete(budgetLines);
          await db.delete(feeInvoices);
          await db.delete(stockMoves);
          await db.delete(productionOrders);
          await db.delete(contracts);
          await db.delete(payrollRuns);
          await db.delete(bankLines);
          await db.delete(invoices);
          await db.delete(assets);
          await db.delete(salesOrders);
          await db.delete(purchaseOrders);
          await db.delete(journalLines);
          const counters = await db.select({ key: meta.key, clientId: meta.clientId }).from(meta);
          for (const c of counters) {
            const base = c.key === "uj" ? 5_000_000_000 : c.key === "po" ? 4_500_000_000 : 3_000_000_000;
            await db.update(meta).set({ value: base }).where(and(eq(meta.key, c.key), eq(meta.clientId, c.clientId)));
          }
        });
        return NextResponse.json({ ok: true, message: "Entire system reset — all workspaces cleared, logins and master data preserved." });
      }

      default:
        throw new PostingError(`Unknown admin action "${String(action)}".`);
    }
  } catch (e) {
    const msg = e instanceof PostingError ? e.message : e instanceof Error ? e.message : "Unexpected error.";
    return NextResponse.json({ ok: false, error: msg }, { status: 400 });
  }
}
