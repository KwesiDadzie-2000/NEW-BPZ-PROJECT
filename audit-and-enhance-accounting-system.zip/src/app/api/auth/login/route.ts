import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { db } from "@/db";
import { clients, sessions, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { ensureSeed } from "@/lib/init";
import { verifyPassword } from "@/lib/password";
import { SESSION_COOKIE } from "@/lib/auth";
import { loginAllowed, recordLoginAttempt, clearLoginFailures, clientIp, logActivity } from "@/lib/security";
import { report } from "@/lib/observability";

export const dynamic = "force-dynamic";

const MAX_AGE = 7 * 24 * 60 * 60;

export async function POST(req: Request) {
  try {
    return await handleLogin(req);
  } catch (e) {
    await report("Login request failed", { route: "/api/auth/login" }, e);
    return NextResponse.json(
      { ok: false, error: "Sign-in failed unexpectedly. Please try again." },
      { status: 500 }
    );
  }
}

async function handleLogin(req: Request) {
  const body = await req.json().catch(() => ({}));
  const username = String((body as { username?: string }).username ?? "").trim().toLowerCase();
  const password = String((body as { password?: string }).password ?? "");
  if (!username || !password) {
    return NextResponse.json({ ok: false, error: "Enter your username and password." }, { status: 400 });
  }

  await ensureSeed();
  const ip = clientIp(req);

  // Housekeeping: drop expired sessions so the table cannot grow without bound.
  await db.delete(sessions).where(sql`${sessions.expiresAt} < now()`).catch(() => undefined);

  // Brute-force lockout: 8 failed attempts per username within 15 minutes.
  const gate = await loginAllowed(username, ip);
  if (!gate.allowed) {
    await recordLoginAttempt(username, false, ip);
    await logActivity({ username, action: "login_blocked", ok: false, detail: "Too many failed attempts", ip });
    return NextResponse.json(
      { ok: false, error: "Too many failed attempts. This account is locked for 15 minutes." },
      { status: 429 }
    );
  }

  const rows = await db.select().from(users).where(eq(users.username, username));
  const user = rows[0];
  if (!user || !user.active || !verifyPassword(password, user.passwordHash)) {
    await recordLoginAttempt(username, false, ip);
    await logActivity({ clientId: user?.clientId ?? null, username, action: "login_failed", ok: false, detail: "Invalid credentials", ip });
    return NextResponse.json(
      { ok: false, error: "Invalid username or password." },
      { status: 401 }
    );
  }

  if (user.role === "client" && user.clientId) {
    const client = (await db.select().from(clients).where(eq(clients.id, user.clientId)))[0];
    if (!client || !client.active) {
      return NextResponse.json(
        { ok: false, error: "This workspace has been deactivated. Contact the owner." },
        { status: 403 }
      );
    }
  }

  await clearLoginFailures(username);
  await recordLoginAttempt(username, true, ip);
  await logActivity({
    clientId: user.clientId, username: user.username, role: user.role,
    action: "login", ok: true, detail: `${user.name} signed in`, ip,
  });

  const token = randomBytes(32).toString("hex");

  // If 2FA is enabled, issue a PENDING session — it grants no data access
  // until the authenticator code is verified.
  if (user.totpEnabled) {
    await db
      .insert(sessions)
      .values({
        id: token,
        userId: user.id,
        expiresAt: new Date(Date.now() + 5 * 60 * 1000),
        pending: true,
        ip,
      })
      .onConflictDoNothing({ target: sessions.id });
    await logActivity({ clientId: user.clientId, username: user.username, role: user.role, action: "2fa_required", ok: true, detail: "Password accepted, awaiting second factor", ip });
    const p = NextResponse.json({ ok: true, needs2fa: true, ticket: token, name: user.name });
    p.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true, sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/", maxAge: 300,
    });
    return p;
  }

  // Standard session: no second factor configured for this account.
  await db
    .insert(sessions)
    .values({
      id: token,
      userId: user.id,
      expiresAt: new Date(Date.now() + MAX_AGE * 1000),
      pending: false,
      ip,
    })
    .onConflictDoNothing({ target: sessions.id });

  const res = NextResponse.json({ ok: true, name: user.name, role: user.role, mustChange: user.mustChangePassword, termsAccepted: !!user.acceptedTermsAt });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE,
  });
  return res;
}
