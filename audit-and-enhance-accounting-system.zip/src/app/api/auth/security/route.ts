import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireSessionUser } from "@/lib/auth";
import { verifyPassword, hashPassword } from "@/lib/password";
import { passwordProblem, generateSecret, otpauthUri, verifyTotp } from "@/lib/totp";
import { logActivity, clientIp } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const user = await requireSessionUser();
    const body = (await req.json()) as Record<string, unknown>;
    const op = String(body.op ?? "");
    const ip = clientIp(req);

    // ---- Accept terms of engagement (Ghana DPA 2012 / ISQC 1) ----
    if (op === "accept_terms") {
      await db.update(users).set({ acceptedTermsAt: new Date() }).where(eq(users.id, user.id));
      await logActivity({ clientId: user.clientId, username: user.username, role: user.role, action: "terms_accepted", ok: true, detail: "Terms of engagement accepted", ip });
      return NextResponse.json({ ok: true, message: "Terms accepted." });
    }

    // ---- Change password (policy enforced) ----
    if (op === "change_password") {
      const current = String(body.current ?? "");
      const next = String(body.next ?? "");
      const problem = passwordProblem(next);
      if (problem) return NextResponse.json({ ok: false, error: problem }, { status: 400 });
      const row = (await db.select().from(users).where(eq(users.id, user.id)))[0];
      if (!row || !verifyPassword(current, row.passwordHash)) {
        return NextResponse.json({ ok: false, error: "Current password is incorrect." }, { status: 400 });
      }
      if (user.totpEnabled && !verifyTotp(row.totpSecret, String(body.totp ?? ""))) {
        return NextResponse.json({ ok: false, error: "Enter a valid authenticator code to confirm this change." }, { status: 400 });
      }
      await db
        .update(users)
        .set({
          passwordHash: hashPassword(next),
          mustChangePassword: false,
          passwordChangedAt: new Date(),
          usesBootstrapPassword: false,
        })
        .where(eq(users.id, user.id));
      await logActivity({ clientId: user.clientId, username: user.username, role: user.role, action: "password_changed", ok: true, detail: "Password changed", ip });
      return NextResponse.json({ ok: true, message: "Password updated." });
    }

    // ---- Begin 2FA enrolment: returns a secret + otpauth URI ----
    if (op === "2fa_begin") {
      const row = (await db.select().from(users).where(eq(users.id, user.id)))[0];
      const secret = generateSecret();
      await db.update(users).set({ totpSecret: secret, totpEnabled: false }).where(eq(users.id, user.id));
      return NextResponse.json({ ok: true, secret, uri: otpauthUri(secret, user.username) });
    }

    // ---- Confirm enrolment with a live code ----
    if (op === "2fa_confirm") {
      const row = (await db.select().from(users).where(eq(users.id, user.id)))[0];
      if (!row?.totpSecret) return NextResponse.json({ ok: false, error: "Start enrolment first." }, { status: 400 });
      if (!verifyTotp(row.totpSecret, String(body.code ?? ""))) {
        return NextResponse.json({ ok: false, error: "That code did not match. Make sure your phone clock is set to automatic." }, { status: 400 });
      }
      await db.update(users).set({ totpEnabled: true }).where(eq(users.id, user.id));
      await logActivity({ clientId: user.clientId, username: user.username, role: user.role, action: "2fa_enabled", ok: true, detail: "Two-factor authentication enabled", ip });
      return NextResponse.json({ ok: true, message: "Two-factor authentication is now active on your account." });
    }

    if (op === "2fa_disable") {
      const row = (await db.select().from(users).where(eq(users.id, user.id)))[0];
      if (user.totpEnabled && !verifyTotp(row.totpSecret, String(body.code ?? ""))) {
        return NextResponse.json({ ok: false, error: "Enter a valid authenticator code to disable 2FA." }, { status: 400 });
      }
      await db.update(users).set({ totpEnabled: false, totpSecret: "" }).where(eq(users.id, user.id));
      await logActivity({ clientId: user.clientId, username: user.username, role: user.role, action: "2fa_disabled", ok: true, detail: "Two-factor authentication disabled", ip });
      return NextResponse.json({ ok: true, message: "Two-factor authentication disabled." });
    }

    return NextResponse.json({ ok: false, error: "Unknown security operation." }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}
