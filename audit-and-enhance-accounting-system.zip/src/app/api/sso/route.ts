import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/db";
import { ssoProviders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { listSsoProviders, upsertSsoProvider, buildSsoRedirect, federatedLogin, newSsoState } from "@/lib/sso";
import { requireApiWorkspace } from "@/lib/auth";
import { SESSION_COOKIE } from "@/lib/cookie-names";
import { sameOrigin, clientIp, logActivity } from "@/lib/security";
import { ensureSeed } from "@/lib/init";
import { PostingError } from "@/lib/posting";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const op = url.searchParams.get("op") || "list";

  if (op === "list_public") {
    const all = await listSsoProviders();
    return NextResponse.json({
      ok: true,
      providers: all.filter((p) => p.enabled).map((p) => ({
        id: p.id,
        name: p.name,
        protocol: p.protocol,
      })),
    });
  }

  if (op === "start") {
    const id = Number(url.searchParams.get("id") || 0);
    const provider = (await db.select().from(ssoProviders).where(eq(ssoProviders.id, id)))[0];
    if (!provider || !provider.enabled) {
      return NextResponse.json({ ok: false, error: "SSO provider not available." }, { status: 404 });
    }
    const state = newSsoState();
    const jar = await cookies();
    jar.set("bpz_sso_state", state, { httpOnly: true, path: "/", maxAge: 600, sameSite: "lax" });
    jar.set("bpz_sso_pid", String(id), { httpOnly: true, path: "/", maxAge: 600, sameSite: "lax" });
    const origin = url.origin;
    const redirect = buildSsoRedirect(provider, {
      redirectUri: `${origin}/api/sso?op=callback`,
      state,
    });
    // For demo / lab without a live IdP: support simulated callback
    if (url.searchParams.get("simulate") === "1") {
      return NextResponse.redirect(
        `${origin}/api/sso?op=callback&simulate=1&state=${state}&code=demo&email=${encodeURIComponent(url.searchParams.get("email") || "sso.user@firm.com")}&name=${encodeURIComponent(url.searchParams.get("name") || "SSO User")}`
      );
    }
    return NextResponse.redirect(redirect.url);
  }

  if (op === "callback") {
    const jar = await cookies();
    const state = url.searchParams.get("state") || "";
    const expected = jar.get("bpz_sso_state")?.value;
    const pid = Number(jar.get("bpz_sso_pid")?.value || url.searchParams.get("id") || 0);
    if (!expected || state !== expected) {
      return NextResponse.json({ ok: false, error: "Invalid SSO state." }, { status: 400 });
    }
    // Production: exchange code at token_url, validate id_token via JWKS.
    // Lab: simulate with query params when simulate=1.
    if (url.searchParams.get("simulate") !== "1") {
      return NextResponse.json({
        ok: false,
        error:
          "Live IdP token exchange is configured via provider token_url/jwks_url. Use ?simulate=1 in lab environments or complete the OIDC code exchange in your deployment.",
      }, { status: 501 });
    }
    const email = url.searchParams.get("email") || "sso.user@firm.com";
    const name = url.searchParams.get("name") || "SSO User";
    try {
      const result = await federatedLogin({
        providerId: pid,
        subject: `sim:${email}`,
        email,
        name,
        ip: clientIp(req),
      });
      jar.set(SESSION_COOKIE, result.sessionId, {
        httpOnly: true,
        path: "/",
        sameSite: "lax",
        maxAge: 7 * 24 * 60 * 60,
      });
      jar.delete("bpz_sso_state");
      jar.delete("bpz_sso_pid");
      await logActivity({
        username: email,
        action: "sso.login",
        ok: true,
        detail: `provider=${pid} created=${result.created}`,
        ip: clientIp(req),
      });
      return NextResponse.redirect(new URL("/", url.origin));
    } catch (e) {
      return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "SSO failed" }, { status: 400 });
    }
  }

  // authenticated list
  try {
    await requireApiWorkspace();
    return NextResponse.json({ ok: true, providers: await listSsoProviders() });
  } catch {
    return NextResponse.json({ ok: true, providers: (await listSsoProviders()).filter((p) => p.enabled) });
  }
}

export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ ok: false, error: "CSRF" }, { status: 403 });
  try {
    await ensureSeed();
    const ws = await requireApiWorkspace();
    if (!["owner", "admin"].includes(ws.user.role)) throw new PostingError("Only owner/admin can manage SSO.");
    const body = await req.json();
    const result = await upsertSsoProvider({
      id: body.id ? Number(body.id) : undefined,
      name: String(body.name || ""),
      protocol: (body.protocol || "oidc") as "oidc" | "saml" | "scim",
      enabled: body.enabled === true || body.enabled === "true" || body.enabled === 1 || body.enabled === "1",
      issuer: body.issuer ? String(body.issuer) : undefined,
      clientId: body.clientId ? String(body.clientId) : undefined,
      clientSecret: body.clientSecret ? String(body.clientSecret) : undefined,
      authorizationUrl: body.authorizationUrl ? String(body.authorizationUrl) : undefined,
      tokenUrl: body.tokenUrl ? String(body.tokenUrl) : undefined,
      userInfoUrl: body.userInfoUrl ? String(body.userInfoUrl) : undefined,
      jwksUrl: body.jwksUrl ? String(body.jwksUrl) : undefined,
      samlEntryPoint: body.samlEntryPoint ? String(body.samlEntryPoint) : undefined,
      samlCert: body.samlCert ? String(body.samlCert) : undefined,
      scimEndpoint: body.scimEndpoint ? String(body.scimEndpoint) : undefined,
      scimToken: body.scimToken ? String(body.scimToken) : undefined,
      defaultRole: body.defaultRole ? String(body.defaultRole) : undefined,
      allowedDomains: body.allowedDomains ? String(body.allowedDomains) : undefined,
    });
    await logActivity({
      username: ws.user.username,
      action: "sso.upsert",
      ok: true,
      detail: JSON.stringify({ id: result.id, name: body.name }),
      ip: clientIp(req),
      clientId: ws.client.id,
    });
    return NextResponse.json({ ok: true, ...result, providers: await listSsoProviders() });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Error" }, { status: 400 });
  }
}
