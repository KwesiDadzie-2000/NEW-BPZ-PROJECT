import { subscribeCloseEvents } from "@/lib/integrations";
import { apiWorkspace } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(req: Request) {
  let clientId = 0;
  try {
    const ws = await apiWorkspace();
    clientId = ws?.client?.id ?? 0;
  } catch {
    clientId = 0;
  }

  const stream = new ReadableStream({
    start(controller) {
      const enc = new TextEncoder();
      const send = (event: string, data: unknown) => {
        controller.enqueue(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };
      send("connected", { clientId, at: new Date().toISOString() });
      const unsub = subscribeCloseEvents((evt) => {
        if (clientId && evt.clientId !== clientId) return;
        send(evt.type, evt);
      });
      const ping = setInterval(() => {
        try {
          send("ping", { at: new Date().toISOString() });
        } catch {
          clearInterval(ping);
        }
      }, 15000);
      req.signal.addEventListener("abort", () => {
        unsub();
        clearInterval(ping);
        try {
          controller.close();
        } catch {
          /* closed */
        }
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
