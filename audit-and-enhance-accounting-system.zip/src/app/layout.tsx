import type { Metadata } from "next";
import type { ReactNode } from "react";
import { headers } from "next/headers";
import "./globals.css";
import { Sidebar } from "@/components/Sidebar";
import { apiWorkspace } from "@/lib/auth";
import { journalTotals } from "@/lib/reports";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { asc } from "drizzle-orm";

export const metadata: Metadata = {
  title: "BPZ CONSULT — Enterprise Accounting & Advisory Platform",
  description:
    "BPZ CONSULT, Financial Experts. Multi-sector, multi-jurisdiction enterprise accounting on a single Universal Journal — IFRS reporting, payroll, tax, banking, business advisory and client workspaces. Ghana-first, built for the global economy.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const pathname = (await headers()).get("x-bpz-pathname") ?? "";
  const onAuthScreen =
    pathname.startsWith("/login") ||
    pathname.startsWith("/accept-terms") ||
    pathname.startsWith("/invoices/");

  let ws = null;
  try {
    ws = await apiWorkspace();
  } catch {
    ws = null;
  }

  let docCount = 0;
  let lineCount = 0;
  let balanced = true;
  let workspaces: { id: number; code: string; name: string }[] = [];

  // On the login / acceptance / print screens the shell must stay a plain
  // centred frame. Rendering the sidebar there is what pushed a brand-new
  // client back to the owner dashboard view.
  if (onAuthScreen) {
    return (
      <html lang="en">
        <body className="antialiased">{children}</body>
      </html>
    );
  }

  if (ws && !ws.user.mustChangePassword) {
    const t = await journalTotals(ws.client.id);
    docCount = t.docCount;
    lineCount = t.lineCount;
    balanced = Math.abs(t.totalDr - t.totalCr) < 0.01;
    if (ws.user.role === "owner") {
      const all = await db.select().from(clients).orderBy(asc(clients.id));
      workspaces = all.filter((c) => c.active).map((c) => ({ id: c.id, code: c.code, name: c.name }));
    } else {
      workspaces = [{ id: ws.client.id, code: ws.client.code, name: ws.client.name }];
    }
  }

  const showShell = ws ? !ws.user.mustChangePassword : false;

  return (
    <html lang="en">
      <body>
        {ws && showShell ? (
          <div className="flex min-h-screen flex-col md:flex-row">
            <Sidebar
              docCount={docCount}
              lineCount={lineCount}
              balanced={balanced}
              role={ws.user.role}
              userName={ws.user.name}
              workspaces={workspaces}
              currentWs={ws.client}
            />
            <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</main>
          </div>
        ) : (
          children
        )}
      </body>
    </html>
  );
}
