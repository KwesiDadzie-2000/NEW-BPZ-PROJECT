import { requireWorkspace } from "@/lib/auth";
import { masterData } from "@/lib/reports";
import { getRates } from "@/lib/fx";
import { num, fmtDate } from "@/lib/format";
import { PageHeader, Card, Badge, ExportLink, tdCls, thCls, numCls, rowCls, type Tone } from "@/components/ui";
import { PartnerManager } from "@/components/PartnerManager";

export const dynamic = "force-dynamic";

const ACCT_TONE: Record<string, Tone> = { Asset: "fi", Liability: "amber", Equity: "hr", Revenue: "sd", Expense: "red" };
const BP_TONE: Record<string, Tone> = { Vendor: "mm", Customer: "sd", Employee: "hr" };
const MAT_TONE: Record<string, Tone> = { "Raw Material": "mm", Consumable: "slate", "Finished Good": "sd", "Work in Progress": "amber" };

export default async function MasterDataPage() {
  const ws = await requireWorkspace();
  const { accs, bps, ccs, mats } = await masterData(ws.client.id);
  const rates = await getRates();

  return (
    <>
      <PageHeader
        kicker="Reference · Shared across workspaces"
        title="Master Data"
        desc="The comprehensive Ghana/IFRS chart of accounts (all sectors — mining, oil & gas, energy, construction, manufacturing, financial, agri…), business partners, cost centers, materials and the live currency table."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {rates.map((r) => (
          <div key={r.code} className="rounded-xl border border-ink-700 bg-ink-850/80 px-4 py-3">
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-500">
              {r.name} {r.code === "GHS" && "· base"}
            </div>
            <div className="mt-1 font-mono text-lg tabular-nums text-mist-100">
              {r.code === "GHS" ? "₵ base" : num(r.rateGhs) + " GHS"}
            </div>
            <div className="mt-0.5 text-[12px] text-mist-600">
              {r.source}
              {r.updatedAt ? ` · ${fmtDate(r.updatedAt.slice(0, 10))}` : ""}
            </div>
          </div>
        ))}
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <Card title={`Chart of Accounts — ${accs.length} accounts`} sub="IFRS-structured, sector-tailored (mining, O&G, energy, construction, financial, agri…)" pad={false} action={<ExportLink sheet="coa" label="CSV" />}>
          <div className="max-h-[560px] overflow-auto">
            <table className="w-full min-w-[520px]">
              <thead className="sticky top-0 bg-ink-850">
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>Account</th>
                  <th className={thCls}>Description</th>
                  <th className={thCls}>Type</th>
                </tr>
              </thead>
              <tbody>
                {accs.map((a) => (
                  <tr key={a.accountNo} className={rowCls}>
                    <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{a.accountNo}</span></td>
                    <td className={tdCls}><span className="text-[13px]">{a.description}</span></td>
                    <td className={tdCls}><Badge tone={ACCT_TONE[a.type] ?? "slate"}>{a.type}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-4">
          <PartnerManager
            partners={bps.map((b) => ({
              bpNo: b.bpNo, name: b.name, type: b.type,
              tin: b.tin, phone: b.phone, email: b.email,
              defaultExpenseAccount: b.defaultExpenseAccount,
            }))}
          />

          <Card title="Partner export" sub="Download the full partner list" pad={false} action={<ExportLink sheet="partners" label="Export" />}>
            <p className="px-4 py-3 text-[12.5px] text-mist-500">
              Partners are specific to this workspace. Invoices, orders, payroll runs and ledgers all reference
              them, and each carries its own running balance in the business-partner ledger.
            </p>
          </Card>

          <Card title="Business Partners (reference)" sub="Vendors, customers, employees — one BP master" pad={false}>
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>BP</th>
                  <th className={thCls}>Name</th>
                  <th className={thCls}>Type</th>
                </tr>
              </thead>
              <tbody>
                {bps.map((b) => (
                  <tr key={b.bpNo} className={rowCls}>
                    <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{b.bpNo}</span></td>
                    <td className={tdCls}><span className="text-[13px]">{b.name}</span></td>
                    <td className={tdCls}><Badge tone={BP_TONE[b.type] ?? "slate"}>{b.type}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card title="Cost Centers" sub="Departments" pad={false} action={<ExportLink sheet="cost_centers" label="CSV" />}>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-ink-700/70">
                    <th className={thCls}>Code</th>
                    <th className={thCls}>Name</th>
                  </tr>
                </thead>
                <tbody>
                  {ccs.map((c) => (
                    <tr key={c.ccCode} className={rowCls}>
                      <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-gold-300">{c.ccCode}</span></td>
                      <td className={tdCls}><span className="text-[13px]">{c.ccName}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>

            <Card title="Materials" sub="Inventory master" pad={false} action={<ExportLink sheet="materials" label="CSV" />}>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-ink-700/70">
                    <th className={thCls}>Material</th>
                    <th className={thCls}>Type</th>
                    <th className={thCls + " text-right"}>Std price</th>
                  </tr>
                </thead>
                <tbody>
                  {mats.map((m) => (
                    <tr key={m.materialNo} className={rowCls}>
                      <td className={tdCls}>
                        <span className="font-mono text-[12.5px] font-semibold text-mist-100">{m.materialNo}</span>
                        <div className="mt-0.5 text-[12.5px] text-mist-600">{m.description}</div>
                      </td>
                      <td className={tdCls}><Badge tone={MAT_TONE[m.type] ?? "slate"}>{m.type}</Badge></td>
                      <td className={numCls}>{num(Number(m.stdPrice))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
