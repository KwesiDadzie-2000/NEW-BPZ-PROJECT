import { requireWorkspace } from "@/lib/auth";
import { listSsoProviders } from "@/lib/sso";
import { listApiKeys, listWebhooks, listSocEvidence, listAttachments } from "@/lib/integrations";
import { Card, PageHeader, Badge } from "@/components/ui";
import { SimpleActionForm } from "@/components/SimpleActionForm";

export const dynamic = "force-dynamic";

export default async function IntegrationsPage() {
  const ws = await requireWorkspace();
  const isAdmin = ["owner", "admin"].includes(ws.user.role);
  const providers = await listSsoProviders();
  const keys = isAdmin ? await listApiKeys() : [];
  const hooks = await listWebhooks(ws.client.id);
  const soc = await listSocEvidence(30);
  const atts = await listAttachments(ws.client.id);

  return (
    <div className="space-y-6">
      <PageHeader
        kicker="Enterprise integrations · SSO · API · Webhooks · SOC"
        title="Integrations & ITGC evidence"
        desc="Closes Big Four hard blockers: enterprise SSO (SAML/OIDC/SCIM), public API, webhooks (no 25s polling), filesystem attachments (not base64 in Postgres), and SOC/HA evidence trail."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Enterprise SSO" sub="SAML 2.0 · OIDC · SCIM directory sync">
          <p className="mb-3 text-sm text-mist-300">
            Big Four mandates federated identity. Password-only login fails RFP stage. Configure your IdP below, then enable.
            Lab simulation: use Simulate SSO login without a live IdP.
          </p>
          <div className="mb-4 space-y-2">
            {providers.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-ink-700 px-3 py-2">
                <div>
                  <div className="font-semibold text-mist-100">
                    {p.name}{" "}
                    <Badge tone={p.enabled ? "green" : "slate"}>{p.enabled ? "enabled" : "disabled"}</Badge>{" "}
                    <Badge tone="gold">{p.protocol.toUpperCase()}</Badge>
                  </div>
                  <div className="text-xs text-mist-500">{p.issuer || p.authorizationUrl || p.scimEndpoint || "Not fully configured"}</div>
                </div>
                <div className="flex gap-2">
                  {p.enabled && (
                    <a className="rounded bg-gold-400 px-2 py-1 text-xs font-bold text-brand-navy" href={`/api/sso?op=start&id=${p.id}&simulate=1`}>
                      Simulate SSO login
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
          {isAdmin && (
            <SimpleActionForm
              action="sso.upsert"
              label="Save SSO provider"
              endpoint="/api/sso"
              fields={{
                name: { label: "Name", defaultValue: "Firm Azure AD", required: true },
                protocol: { label: "Protocol (oidc|saml|scim)", defaultValue: "oidc" },
                enabled: { label: "Enabled (true/false)", defaultValue: "true" },
                issuer: { label: "Issuer", placeholder: "https://login.microsoftonline.com/.../v2.0", wide: true },
                clientId: { label: "Client ID" },
                clientSecret: { label: "Client secret" },
                authorizationUrl: { label: "Authorization URL", wide: true },
                tokenUrl: { label: "Token URL", wide: true },
                jwksUrl: { label: "JWKS URL", wide: true },
                samlEntryPoint: { label: "SAML entry point", wide: true },
                allowedDomains: { label: "Allowed email domains (csv)", defaultValue: "firm.com" },
                defaultRole: { label: "Default role", defaultValue: "accountant" },
              }}
            />
          )}
        </Card>

        <Card title="Public API keys" sub="Bearer bpz_… · scoped · hashed at rest">
          <p className="mb-3 text-sm text-mist-300">
            REST surface at <code className="text-gold-400">/api/public/v1?resource=trial_balance&amp;clientId=</code> with header{" "}
            <code className="text-gold-400">Authorization: Bearer bpz_…</code>.
          </p>
          {isAdmin && (
            <>
              <SimpleActionForm
                action="integrations.api_key"
                label="Create API key"
                fields={{
                  name: { label: "Name", defaultValue: "Audit extract", required: true },
                  scopes: { label: "Scopes", defaultValue: "read:reports,read:journal" },
                  expiresDays: { label: "Expires in days (0=never)", defaultValue: "365", type: "number" },
                  scopeWorkspace: { label: "Bind to this workspace (true/false)", defaultValue: "true" },
                }}
              />
              <div className="mt-3 overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-mist-400">
                      <th className="py-1">Name</th>
                      <th>Prefix</th>
                      <th>Scopes</th>
                      <th>Active</th>
                    </tr>
                  </thead>
                  <tbody>
                    {keys.map((k) => (
                      <tr key={k.id} className="border-t border-ink-800">
                        <td className="py-1">{k.name}</td>
                        <td className="font-mono text-xs">{k.prefix}…</td>
                        <td className="text-xs">{k.scopes}</td>
                        <td>{k.active ? "yes" : "revoked"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </Card>

        <Card title="Webhooks" sub="period.closed · invoice.posted · payroll.run — replaces 25s polling">
          <p className="mb-3 text-sm text-mist-300">
            Period close publishes SSE on <code className="text-gold-400">/api/events</code> and POSTs signed payloads to registered endpoints.
          </p>
          {isAdmin && (
            <SimpleActionForm
              action="integrations.webhook"
              label="Register webhook"
              fields={{
                name: { label: "Name", defaultValue: "Close notifier", required: true },
                url: { label: "URL", placeholder: "https://example.com/hooks/bpz", required: true, wide: true },
                events: { label: "Events (csv)", defaultValue: "period.closed,invoice.posted,payroll.run", wide: true },
                scopeWorkspace: { label: "This workspace only (true/false)", defaultValue: "true" },
              }}
            />
          )}
          <ul className="mt-3 space-y-1 text-sm">
            {hooks.map((h) => (
              <li key={h.id} className="rounded border border-ink-700 px-2 py-1">
                <span className="font-semibold">{h.name}</span> · {h.url} ·{" "}
                <Badge tone={h.active ? "green" : "slate"}>{h.active ? "active" : "off"}</Badge>
              </li>
            ))}
            {!hooks.length && <li className="text-mist-500">No webhooks yet.</li>}
          </ul>
        </Card>

        <Card title="Attachments" sub="Filesystem store — never base64 in Postgres">
          <p className="mb-3 text-sm text-mist-300">
            Upload via <code className="text-gold-400">POST /api/attachments</code>. Metadata in Postgres; bytes under data/attachments/ with SHA-256.
          </p>
          <form action="/api/attachments" method="post" encType="multipart/form-data" className="flex flex-wrap items-end gap-2">
            <input type="hidden" name="entityType" value="workspace" />
            <input type="hidden" name="entityId" value={String(ws.client.id)} />
            <input type="file" name="file" className="text-sm" />
            <button className="rounded-lg bg-gold-400 px-3 py-1.5 text-sm font-bold text-brand-navy">Upload</button>
          </form>
          <ul className="mt-3 max-h-40 space-y-1 overflow-auto text-sm">
            {atts.map((a) => (
              <li key={a.id}>
                <a className="text-gold-400 underline" href={`/api/attachments?id=${a.id}`}>{a.fileName}</a>{" "}
                <span className="text-mist-500">({a.sizeBytes} bytes · {a.mimeType})</span>
              </li>
            ))}
            {!atts.length && <li className="text-mist-500">No attachments yet.</li>}
          </ul>
        </Card>
      </div>

      <Card title="SOC / ITGC evidence" sub="Backup · HA posture · access · monitoring — auditor walkthrough pack">
        {isAdmin && (
          <div className="mb-3 flex flex-wrap gap-4">
            <SimpleActionForm action="integrations.soc_check" label="Run SOC self-check" fields={{}} />
            <SimpleActionForm action="integrations.seed_global_tax" label="Seed global tax (US/UK/EU/NG/KE/ZA/AE)" fields={{}} />
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-mist-400">
                <th className="py-1">When</th>
                <th>Category</th>
                <th>Title</th>
                <th>Status</th>
                <th>Detail</th>
              </tr>
            </thead>
            <tbody>
              {soc.map((s) => (
                <tr key={s.id} className="border-t border-ink-800 align-top">
                  <td className="py-1 whitespace-nowrap text-xs">{s.takenAt?.toISOString?.().slice(0, 19) ?? ""}</td>
                  <td>{s.category}</td>
                  <td>{s.title}</td>
                  <td>
                    <Badge tone={s.status === "pass" ? "green" : s.status === "warn" ? "gold" : "slate"}>{s.status}</Badge>
                  </td>
                  <td className="max-w-xl text-xs text-mist-300">{s.detail}</td>
                </tr>
              ))}
              {!soc.length && (
                <tr>
                  <td colSpan={5} className="py-2 text-mist-500">No evidence yet — run the SOC self-check.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-mist-500">
          HA note: this sandbox is single-node Postgres. Production Big Four deployments must set HA_MODE=multi-az with streaming replicas, automated failover, PITR and offsite backups. The control is documented and evidenced above rather than silently claimed.
        </p>
      </Card>
    </div>
  );
}
