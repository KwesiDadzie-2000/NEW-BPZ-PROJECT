import { requireWorkspace } from "@/lib/auth";
import { masterData, orderBooks } from "@/lib/reports";
import { db } from "@/db";
import { invoices } from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";
import { getRates } from "@/lib/fx";
import { num, fmtDate } from "@/lib/format";
import { PageHeader, Card, ExportLink, EmptyState, StatusBadge, tdCls, thCls, numCls, rowCls, Badge } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";
import { RowAction } from "@/components/RowAction";
import { InvoiceForm } from "@/components/bpforms";

export const dynamic = "force-dynamic";

export default async function ProcurementPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const { bps, mats } = await masterData(clientId);
  const { pos, bpName } = await orderBooks(clientId);
  const vendors = bps.filter((b) => b.type === "Vendor");
  const rates = await getRates();
  const currencyOptions = rates.map((r) => ({ value: r.code, label: r.code === "GHS" ? "GHS — Cedi (base)" : `${r.code} — ${num(r.rateGhs)}/GHS live` }));

  const { accs, ccs } = await masterData(clientId);
  const expenseAccounts = accs
    .filter((a) => a.type === "Expense" || a.type === "Asset")
    .map((a) => ({ value: a.accountNo, label: `${a.accountNo} · ${a.description}` }));
  const ccOptions = ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }));

  const docList = await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.clientId, clientId), eq(invoices.direction, "purchase")))
    .orderBy(desc(invoices.id))
    .limit(25);

  return (
    <>
      <PageHeader
        kicker={`MM · Procurement · ${ws.client.code}`}
        title="Procurement"
        desc="Purchase orders, goods receipt into inventory (auto-selected raw/FG account), supplier invoices with 20% input VAT (fully recoverable — no cascading), credit notes, and payments with resident/non-resident withholding tax at the Payment Desk."
      >
        <ExportLink sheet="purchase_orders" label="Export .xlsx" />
      </PageHeader>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <div className="space-y-4">
          <ActionForm
            action="create_po"
            title="New Purchase Order"
            sub="Create the PO — goods receipt and invoice post the accounting entries"
            submitLabel="Create PO"
            userDefault="procurement_user"
            totalFrom={["qty", "price"]}
            chargeable
            serviceLines={[
              { value: "bookkeeping", label: "Bookkeeping" },
              { value: "business_advisory", label: "Business Advisory" },
            ]}
            fields={[
              { name: "vendor", label: "Vendor", type: "select", options: vendors.map((v) => ({ value: v.bpNo, label: `${v.bpNo} · ${v.name}` })) },
              { name: "material", label: "Material", type: "select", options: mats.map((m) => ({ value: m.materialNo, label: `${m.materialNo} · ${m.description}` })) },
              { name: "qty", label: "Quantity", type: "number", step: "1", min: 1, defaultValue: "10" },
              { name: "price", label: "Unit price", type: "number", step: "0.01", min: 0.01, defaultValue: "50.00" },
              { name: "cc", label: "Cost center", type: "select", required: false, options: ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` })) },
            ]}
          />
          <InvoiceForm
              direction="purchase"
              bpOptions={vendors.map((v) => ({ value: v.bpNo, label: `${v.bpNo} · ${v.name}` }))}
              currencies={currencyOptions}
              expenseOptions={expenseAccounts}
              ccOptions={ccOptions}
            />
        </div>

        <div className="space-y-4">
          <Card title="Supplier Documents" sub="Invoices carry 20% recoverable input VAT — credit notes reverse cleanly" pad={false}>
            {docList.length === 0 ? (
              <div className="p-4"><EmptyState icon="cart" title="No supplier documents" body="Raise a supplier quote/invoice on the left or receive goods against a PO." /></div>
            ) : (
              <div className="max-h-[420px] overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>No</th>
                      <th className={thCls}>Type</th>
                      <th className={thCls}>BP</th>
                      <th className={thCls + " text-right"}>Subtotal</th>
                      <th className={thCls + " text-right"}>VAT</th>
                      <th className={thCls + " text-right"}>Total</th>
                      <th className={thCls}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {docList.map((d) => (
                      <tr key={d.id} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[12px] font-semibold text-mist-100">{d.no}</span></td>
                        <td className={tdCls}><span className="text-[12px] capitalize text-mist-400">{d.docType === "credit" ? "Credit note" : d.docType === "debit" ? "Debit note" : d.docType}</span></td>
                        <td className={tdCls}><span className="font-mono text-[12.5px]">{d.bp}</span> <span className="font-mono text-[12px] text-mm">{d.currency}</span></td>
                        <td className={numCls}>{num(Number(d.subtotal))}</td>
                        <td className={numCls}>{num(Number(d.vat))}</td>
                        <td className={numCls + " font-semibold"}>{num(Number(d.total))}</td>
                        <td className={tdCls}><StatusBadge status={d.status === "paid" ? "Paid" : d.status === "partial" ? "Invoiced" : "Open"} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card title="Purchase Orders" sub="Open → goods received (inventory in) → invoiced (AP + input VAT) → paid at Payment Desk" pad={false}>
            {pos.length === 0 ? (
              <div className="p-4"><EmptyState icon="cart" title="No purchase orders" body="Create a PO on the left, then walk it through receipt and invoice." /></div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px]">
                  <thead>
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>PO</th>
                      <th className={thCls}>Vendor</th>
                      <th className={thCls}>Material</th>
                      <th className={thCls + " text-right"}>Total</th>
                      <th className={thCls}>CC</th>
                      <th className={thCls}>Status</th>
                      <th className={thCls + " text-right"}>Next step</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pos.map((po) => (
                      <tr key={po.poNo} className={rowCls}>
                        <td className={tdCls}>
                          <span className="font-mono text-[12.5px] font-semibold text-mist-100">{po.poNo}</span>
                          <div className="mt-0.5 text-[12.5px] text-mist-600">{fmtDate(po.createdAt.toISOString().slice(0, 10))}</div>
                        </td>
                        <td className={tdCls}>
                          <span className="font-mono text-[12px]">{po.vendor}</span>
                          <div className="mt-0.5 max-w-[140px] truncate text-[12px] text-mist-600">{bpName.get(po.vendor)}</div>
                        </td>
                        <td className={tdCls}><span className="font-mono text-[12px]">{po.material} × {po.qty}</span></td>
                        <td className={numCls + " font-semibold"}>{num(Number(po.total))}</td>
                        <td className={tdCls}><Badge tone="slate">{po.cc || "—"}</Badge></td>
                        <td className={tdCls}><StatusBadge status={po.status} /></td>
                        <td className={tdCls}>
                          <div className="flex justify-end">
                            {po.status === "Open" && (
                              <RowAction action="receive_goods" payload={{ poNo: po.poNo }} label="Receive goods" tone="gold" user="procurement_user" />
                            )}
                            {po.status === "Goods Received" && (
                              <RowAction action="post_vendor_invoice" payload={{ poNo: po.poNo }} label="Post invoice" tone="gold" user="procurement_user" />
                            )}
                            {po.status === "Invoiced" && <span className="text-[12.5px] text-mist-500">Pay at Payment Desk</span>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
