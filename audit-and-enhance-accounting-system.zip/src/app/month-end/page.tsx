import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { fiscalPeriods } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { thisPeriod, shiftPeriod, periodLabel } from "@/lib/periods";
import { trialBalance } from "@/lib/reports";
import { money } from "@/lib/format";
import { PageHeader, Card, Badge, Stat } from "@/components/ui";
import { RowAction } from "@/components/RowAction";

export const dynamic = "force-dynamic";

export default async function MonthEndPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = thisPeriod();
  const tb = await trialBalance(clientId);
  const closed = await db
    .select()
    .from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, clientId), eq(fiscalPeriods.status, "closed")))
    .orderBy(fiscalPeriods.period);

  const checklist = [
    {
      label: "Depreciation run",
      detail: "All depreciable assets, class rates applied — posts 550000 / 139000.",
      action: { action: "depreciation_run", payload: { period }, label: "Run depreciation", user: "ops_user" },
    },
    {
      label: "FX revaluation (IAS 21)",
      detail: "Open multi-currency invoices revalued at the live mid-rate — FX gain/loss to 491000 / 580000.",
      action: { action: "revalue_fx", payload: { period }, label: "Revalue open FX", user: "bpz" },
    },
    {
      label: "Trial balance review",
      detail: `Current position: Dr ${money(tb.totalDr)} = Cr ${money(tb.totalCr)} — ${tb.balanced ? "balanced" : "OUT OF BALANCE"}.`,
      action: null,
    },
  ];

  return (
    <>
      <PageHeader
        kicker={`MCC · Month-End Close · ${ws.client.code}`}
        title="Month-End Close"
        desc="The close checklist for the current period. Close the period to freeze it — postings to closed periods are rejected until reopened (correcting entries only, with reasons)."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Current Period" value={period} sub={periodLabel(period)} />
        <Stat label="Closed Periods" value={closed.length} sub="Frozen in this workspace" />
        <Stat label="Journal Balance" value={money(Math.abs(tb.totalDr - tb.totalCr))} tone={tb.balanced ? "text-pos" : "text-neg"} sub={tb.balanced ? "Dr = Cr — ready to close" : "Resolve before closing"} />
        <Stat label="Periods Supported" value="Unlimited" sub="YYYY-MM strings — any year, any month" />
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <Card title={"Close Checklist — " + period} sub="Run each step, then close the period">
          <div className="space-y-3">
            {checklist.map((c) => (
              <div key={c.label} className="flex items-start gap-3 rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
                <Badge tone="gold">MCC</Badge>
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-semibold text-mist-200">{c.label}</div>
                  <div className="mt-0.5 text-[12px] leading-snug text-mist-500">{c.detail}</div>
                </div>
                {c.action && (
                  <RowAction action={c.action.action} payload={c.action.payload} label={c.action.label} tone="gold" user={c.action.user} />
                )}
              </div>
            ))}
            <div className="flex items-center justify-between rounded-lg border border-gold-400/30 bg-gold-400/5 px-3 py-3">
              <div>
                <div className="text-[13px] font-bold text-gold-300">Close period {period}</div>
                <div className="text-[12.5px] text-mist-500">Freezes all {period} lines. Reopen later if correcting entries are needed.</div>
              </div>
              <RowAction action="close_period" payload={{ period }} label="Close period" tone="gold" user="bpz" />
            </div>
          </div>
        </Card>

        <Card title="Closed Periods" sub="Reopen only for correcting entries (reason mandatory on the journal)">
          {closed.length === 0 ? (
            <p className="text-sm text-mist-500">No closed periods yet. Close {period} from the checklist once depreciation, FX revaluation and reviews are done.</p>
          ) : (
            <div className="space-y-2">
              {closed.map((p) => (
                <div key={p.period} className="flex items-center justify-between rounded-lg border border-ink-700/70 bg-ink-900/40 px-3 py-2.5">
                  <div>
                    <span className="font-mono text-[13px] font-semibold text-mist-100">{p.period}</span>
                    <span className="ml-2 text-[12.5px] text-mist-500">closed by {p.closedBy}</span>
                  </div>
                  <RowAction action="open_period" payload={{ period: p.period }} label="Reopen" user="bpz" />
                </div>
              ))}
            </div>
          )}
          <div className="mt-4 rounded-lg border border-ink-700 bg-ink-900/50 p-3 text-[12px] leading-relaxed text-mist-500">
            <span className="font-bold text-mist-300">Periodicity across modules:</span> journal lines, payroll runs, invoices, stock movements, sector tax runs and fee invoices all carry a fiscal period — so reports, ledgers and aging can be filtered to any range of years and months.
          </div>
        </Card>
      </div>
    </>
  );
}
