import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { budgetScenarios, budgetLines } from "@/db/schema";
import { and, eq, asc } from "drizzle-orm";
import { masterData, budgetVariance } from "@/lib/reports";
import { num, money } from "@/lib/format";
import { PageHeader, Card, EmptyState, tdCls, thCls, numCls, rowCls, Badge, Stat, btn } from "@/components/ui";
import { BudgetEditor } from "@/components/bpforms";

export const dynamic = "force-dynamic";

export default async function BudgetPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const scenarioId = sp.s ? Number(sp.s) : undefined;

  const { accs } = await masterData(clientId);
  const scenarios = await db.select().from(budgetScenarios).where(eq(budgetScenarios.clientId, clientId)).orderBy(asc(budgetScenarios.id));
  const active = scenarios.find((s) => s.id === scenarioId) ?? scenarios[0];
  const variance = active ? await budgetVariance(clientId, active.id) : [];
  const totalBudget = variance.reduce((s, v) => s + v.budget, 0);
  const totalActual = variance.reduce((s, v) => s + v.actual, 0);

  const accountOptions = accs.map((a) => ({ value: a.accountNo, label: `${a.accountNo} · ${a.description}` }));

  return (
    <>
      <PageHeader
        kicker={`CO · Budgets, Forecasts & Scenarios · ${ws.client.code}`}
        title="Budgets & Scenarios"
        desc="Set budgets per fiscal year and scenario (Base, Upside, Downside — unlimited). The variance report compares budget to actuals per account, live from the journal."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Scenarios" value={scenarios.length} sub="This workspace" />
        <Stat label="Budgeted (scenario)" value={money(totalBudget)} sub={active ? `${active.name} ${active.fiscalYear}` : "—"} />
        <Stat label="Actual (all periods)" value={money(totalActual)} sub="Revenue as income, expenses as spend" />
        <Stat label="Variance" value={money(totalBudget - totalActual)} tone={totalBudget - totalActual >= 0 ? "text-pos" : "text-neg"} sub="Budget − actual" />
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {scenarios.length === 0 && (
          <span className="text-xs text-mist-500">No scenarios yet — save one on the left.</span>
        )}
        {scenarios.map((s) => (
          <Link
            key={s.id}
            href={`/budget?s=${s.id}`}
            className={`rounded-lg border px-3 py-2 text-xs font-semibold transition ${
              active?.id === s.id ? "border-gold-400/60 bg-gold-400/10 text-gold-300" : "border-ink-600 text-mist-400 hover:text-mist-200"
            }`}
          >
            {s.name} · FY{s.fiscalYear}
          </Link>
        ))}
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-[420px_1fr]">
        <BudgetEditor accountOptions={accountOptions} />

        <Card
          title={active ? `Variance — ${active.name} FY${active.fiscalYear}` : "Variance Report"}
          sub="Budget vs actual per account (actuals = full history; revenue positive, expenses positive)"
          pad={false}
        >
          {!active ? (
            <div className="p-4">
              <EmptyState icon="scale" title="No budget yet" body="Save a budget on the left — the variance table builds instantly." />
            </div>
          ) : (
            <div className="max-h-[620px] overflow-auto">
              <table className="w-full min-w-[720px]">
                <thead className="sticky top-0 bg-ink-850">
                  <tr className="border-b border-ink-700/70">
                    <th className={thCls}>Account</th>
                    <th className={thCls}>Description</th>
                    <th className={thCls}>Type</th>
                    <th className={thCls + " text-right"}>Budget</th>
                    <th className={thCls + " text-right"}>Actual</th>
                    <th className={thCls + " text-right"}>Variance</th>
                    <th className={thCls + " text-right"}>Used %</th>
                  </tr>
                </thead>
                <tbody>
                  {variance.map((v) => {
                    const pct = v.budget === 0 ? 0 : (v.actual / v.budget) * 100;
                    return (
                      <tr key={v.account} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{v.account}</span></td>
                        <td className={tdCls}><span className="block max-w-[240px] truncate text-[13px]">{v.description}</span></td>
                        <td className={tdCls}><span className="text-[12px] text-mist-500">{v.type}</span></td>
                        <td className={numCls}>{num(v.budget)}</td>
                        <td className={numCls}>{num(v.actual)}</td>
                        <td className={numCls + (v.variance >= 0 ? "text-pos" : "text-neg")}>{num(v.variance)}</td>
                        <td className={numCls + (pct > 100 ? " text-neg" : " text-mist-400")}>{v.budget > 0 ? Math.round(pct) + "%" : "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
