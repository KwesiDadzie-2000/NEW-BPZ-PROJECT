import { requireWorkspace } from "@/lib/auth";
import { masterData, trialBalance } from "@/lib/reports";
import { money } from "@/lib/format";
import { PageHeader, Stat, Card, Icon } from "@/components/ui";
import { ManualJournalForm } from "@/components/ManualJournalForm";
import { ReversalForm } from "@/components/ReversalForm";
import { ModuleHistory } from "@/components/ModuleHistory";

export const dynamic = "force-dynamic";

export default async function AccountingPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const { accs, ccs } = await masterData(clientId);
  const tb = await trialBalance(clientId);

  const accountOptions = accs.map((a) => ({ value: a.accountNo, label: `${a.accountNo} · ${a.description}` }));
  const ccOptions = ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }));

  return (
    <>
      <PageHeader
        kicker={`FI · Accounting · ${ws.client.code}`}
        title="Manual Journal"
        desc="Free-entry documents — standard journals, opening balances, prepayments and adjustments (reason mandatory) — plus full reversals. Every line lands in the Universal Journal."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-3">
        <Stat label="Trial Balance Dr" value={money(tb.totalDr)} sub="Total debits, full history" />
        <Stat label="Trial Balance Cr" value={money(tb.totalCr)} sub="Total credits, full history" />
        <Stat
          label="Balance Check"
          value={<span className={tb.balanced ? "text-pos" : "text-neg"}>{tb.balanced ? "Balanced" : "Out of balance"}</span>}
          sub={<>| Dr − Cr | = {money(Math.abs(tb.totalDr - tb.totalCr))}</>}
        />
      </div>

      <ManualJournalForm accountOptions={accountOptions} ccOptions={ccOptions} />

      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <ReversalForm />
        <Card title="How postings flow" sub="The Universal Journal principle">
          <ul className="space-y-2 text-[13px] leading-relaxed text-mist-500">
            <li className="flex gap-2"><Icon name="check" size={14} className="mt-0.5 shrink-0 text-gold-400" /> Every document is balanced and validated against the chart of accounts before it posts.</li>
            <li className="flex gap-2"><Icon name="check" size={14} className="mt-0.5 shrink-0 text-gold-400" /> Fiscal periods (YYYY-MM, unlimited) carry every line — close a period in Month-End Close to freeze it.</li>
            <li className="flex gap-2"><Icon name="check" size={14} className="mt-0.5 shrink-0 text-gold-400" /> Reversals and adjustments carry mandatory reasons in the reference field for the audit trail.</li>
            <li className="flex gap-2"><Icon name="check" size={14} className="mt-0.5 shrink-0 text-gold-400" /> All reports — IFRS statements, aging, ledgers — compute from these lines, per period.</li>
          </ul>
        </Card>
      </div>

      <div className="mt-4">
        <ModuleHistory clientId={clientId} module="FI" title="Manual Journal History" sub="Free-entry, opening, prepayment and adjustment documents" />
      </div>
    </>
  );
}
