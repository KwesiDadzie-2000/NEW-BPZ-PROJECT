import { requireOwnerWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { clients, users, journalLines } from "@/db/schema";
import { asc, sql } from "drizzle-orm";
import { SECTORS, SERVICE_LINES, SERVICE_LINE_NAMES } from "@/data/sectors";
import { JURISDICTIONS } from "@/data/jurisdictions";
import { num } from "@/lib/format";
import { PageHeader, Card, Badge, tdCls, thCls, numCls, rowCls, Field, inputCls, Icon, btn } from "@/components/ui";
import { ClientCreateForm } from "@/components/ClientCreateForm";
import { OpenWorkspace } from "@/components/OpenWorkspace";

export const dynamic = "force-dynamic";

export default async function ClientsPage() {
  await requireOwnerWorkspace();

  const all = await db.select().from(clients).orderBy(asc(clients.id));
  const stats = await db
    .select({
      clientId: journalLines.clientId,
      docs: sql<number>`count(distinct ${journalLines.docNo})::float8`,
      lines: sql<number>`count(*)::float8`,
    })
    .from(journalLines)
    .groupBy(journalLines.clientId);
  const statMap = new Map(stats.map((s) => [s.clientId, s]));
  const clientUsers = await db.select().from(users);

  return (
    <>
      <PageHeader
        kicker={`MGT · Client Management · Owner`}
        title="Clients"
        desc="Create client workspaces by sector — each gets a tailored chart context, its own books, document numbering, a temporary login (must be reset on first sign-in) and the BPZ service lines you assign."
      />

      <div className="grid items-start gap-4 xl:grid-cols-[420px_1fr]">
        <ClientCreateForm
          sectors={SECTORS.map((s) => ({ value: s.code, label: s.name }))}
          serviceLines={SERVICE_LINES.map((s) => ({ value: s.code, label: s.name }))}
          jurisdictions={JURISDICTIONS.filter((j) => j.code !== "ZA-X").map((j) => ({ value: j.code, label: `${j.name} (${j.currency})` }))}
        />

        <Card title="Client Workspaces" sub="Open any workspace to run its activities as owner — clients see only their own" pad={false}>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[880px]">
              <thead>
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>Code</th>
                  <th className={thCls}>Client</th>
                  <th className={thCls}>Sector</th>
                  <th className={thCls}>Service lines</th>
                  <th className={thCls}>Logins</th>
                  <th className={thCls + " text-right"}>Docs</th>
                  <th className={thCls}>Status</th>
                  <th className={thCls + " text-right"}>Open</th>
                </tr>
              </thead>
              <tbody>
                {all.map((c) => {
                  const s = SECTORS.find((x) => x.code === c.sector);
                  const st = statMap.get(c.id);
                  const logins = clientUsers.filter((u) => u.clientId === c.id);
                  return (
                    <tr key={c.id} className={rowCls}>
                      <td className={tdCls}><span className="font-mono text-[12.5px] font-bold text-gold-300">{c.code}</span></td>
                      <td className={tdCls}>
                        <span className="text-[13px] font-semibold text-mist-100">{c.name}</span>
                        <div className="mt-0.5 text-[12px] text-mist-600">{c.feeModel || "Monthly service lines"}</div>
                      </td>
                      <td className={tdCls}>
                        <Badge tone={c.sector === "mining" || c.sector === "oil_gas" || c.sector === "energy" ? "amber" : "mm"}>
                          {s?.name ?? c.sector}
                        </Badge>
                      </td>
                      <td className={tdCls}>
                        <div className="max-w-[190px] text-[12.5px] leading-snug text-mist-500">
                          {(c.serviceLines ? c.serviceLines.split(",") : []).map((l) => SERVICE_LINE_NAMES[l] ?? l).join(" · ") || "—"}
                        </div>
                      </td>
                      <td className={tdCls}>
                        {logins.map((u) => (
                          <div key={u.id} className="flex items-center gap-1.5">
                            <span className="font-mono text-[12.5px] text-mist-400">@{u.username}</span>
                            {!u.active && <Badge tone="red">restricted</Badge>}
                            {u.mustChangePassword && <Badge tone="amber">reset pending</Badge>}
                          </div>
                        ))}
                        {logins.length === 0 && <span className="text-[12.5px] text-mist-600">—</span>}
                      </td>
                      <td className={numCls}>{st?.docs ?? 0}</td>
                      <td className={tdCls}><Badge tone={c.active ? "green" : "red"}>{c.active ? "Active" : "Inactive"}</Badge></td>
                      <td className={tdCls}>
                        <div className="flex justify-end">
                          {c.active && <OpenWorkspace id={c.id} code={c.code} />}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </>
  );
}
