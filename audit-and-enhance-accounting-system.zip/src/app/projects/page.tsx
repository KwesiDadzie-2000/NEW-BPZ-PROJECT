import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { masterData } from "@/lib/reports";
import {
  contractPortfolio,
  listCertificates,
  listVariations,
  METHODS,
  type ContractRow,
} from "@/lib/contracts";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { eq } from "drizzle-orm";
import { num, money, fmtDate } from "@/lib/format";
import { PageHeader, Card, Badge, Stat, EmptyState, ExportLink, tdCls, thCls, numCls, rowCls, cn } from "@/components/ui";
import { ContractForms } from "@/components/ContractForms";
import { RowAction } from "@/components/RowAction";

export const dynamic = "force-dynamic";

const SECTOR_OPTS = [
  { value: "construction", label: "Construction & Civil works" },
  { value: "manufacturing", label: "Manufacturing – plant & fabrication" },
  { value: "it_telecom", label: "IT & Software implementation" },
  { value: "engineering", label: "Engineering & Energy projects" },
  { value: "oil_gas", label: "Oil & Gas services" },
  { value: "mining", label: "Mining contracts" },
  { value: "shipbuilding", label: "Shipbuilding & heavy fabrication" },
  { value: "real_estate", label: "Real estate development" },
];

export default async function ProjectsPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const client = (await db.select().from(clients).where(eq(clients.id, clientId)))[0];

  const { accs, bps, ccs } = await masterData(clientId);
  const portfolio = await contractPortfolio(clientId);
  const certs = await listCertificates(clientId);
  const variations = await listVariations(clientId);
  const customers = bps.filter((b) => b.type === "Customer");
  const vendors = bps.filter((b) => b.type === "Vendor");

  const active = portfolio.active;
  const contractOptions = portfolio.all.map((c) => ({ value: String(c.id), label: `${c.no} · ${c.title.slice(0, 40)} (${c.pctComplete.toFixed(0)}%)` }));
  const lossMaking = portfolio.lossMaking;

  const selected = active[0];

  return (
    <>
      <PageHeader
        kicker={`IFRS 15 · Projects & Contracts · ${ws.client.code}`}
        title="Long-term Contracts"
        desc="Revenue recognised over time as work is completed — the IFRS 15 five-step model. Create multi-year contracts, record costs as incurred, recognise revenue and matching cost at each period end, then raise interim payment certificates with retention. Contract assets and liabilities are derived for the balance sheet."
      >
        <ExportLink sheet="contracts" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Active contracts" value={active.length} sub={`${portfolio.all.length} total on record`} />
        <Stat label="Contract value" value={money(portfolio.totals.value)} sub="Aggregate transaction price" />
        <Stat label="Revenue recognised" value={money(portfolio.totals.revenue)} tone="text-pos" sub="Cumulative, over time" />
        <Stat label="Expected profit" value={money(portfolio.totals.expectedProfit)} tone={portfolio.totals.expectedProfit >= 0 ? "text-pos" : "text-neg"} sub={`${portfolio.totals.value > 0 ? ((portfolio.totals.expectedProfit / portfolio.totals.value) * 100).toFixed(1) : "0"}% blended margin`} />
      </div>

      {(portfolio.totals.contractAssets > 0 || portfolio.totals.contractLiabilities > 0 || portfolio.totals.retention > 0) && (
        <div className="mb-4 grid grid-cols-3 gap-3">
          <Stat label="Contract assets" value={money(portfolio.totals.contractAssets)} sub="Unbilled work performed (IFRS 15 §106)" tone="text-fi" />
          <Stat label="Contract liabilities" value={money(portfolio.totals.contractLiabilities)} sub="Billings and advances ahead of work" tone="text-aa" />
          <Stat label="Retention held" value={money(portfolio.totals.retention)} sub="Deducted from certificates" />
        </div>
      )}

      {lossMaking.length > 0 && (
        <Card className="mb-4" title="Onerous contracts — provision required" sub="IAS 37 / IFRS 15 §114: where expected costs exceed revenue, the loss is recognised immediately">
          <div className="space-y-2">
            {lossMaking.map((c) => (
              <div key={c.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2.5">
                <Badge tone="red">{c.no}</Badge>
                <span className="text-[13px] font-semibold text-mist-100">{c.title}</span>
                <span className="text-[12px] text-mist-400">Value {money(c.totalValue)} · Cost {money(c.estimatedCost)}</span>
                <span className="ml-auto font-mono text-[13px] font-bold text-neg">Provision {money(c.lossProvision)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <div className="grid items-start gap-4 xl:grid-cols-[1fr_400px]">
        <div className="space-y-4">
          <Card title="Contract portfolio" sub="Live IFRS 15 position for every contract" pad={false}>
            {portfolio.all.length === 0 ? (
              <div className="p-4">
                <EmptyState
                  icon="building"
                  title="No contracts yet"
                  body="Open your first long-term contract on the right. Construction, engineering, IT implementation, shipbuilding and real-estate development all recognise revenue this way."
                />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1080px]">
                  <thead>
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Contract</th>
                      <th className={thCls}>Customer</th>
                      <th className={thCls}>Term</th>
                      <th className={thCls + " text-right"}>Value</th>
                      <th className={thCls + " text-right"}>% complete</th>
                      <th className={thCls + " text-right"}>Revenue to date</th>
                      <th className={thCls + " text-right"}>Profit to date</th>
                      <th className={thCls + " text-right"}>Asset / (liability)</th>
                      <th className={thCls + " text-right"}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {portfolio.all.map((c: ContractRow) => (
                      <tr key={c.id} className={rowCls}>
                        <td className={tdCls}>
                          <Badge tone={c.status === "active" ? "sd" : c.status === "completed" ? "fi" : "red"}>{c.no}</Badge>
                          <div className="mt-1 max-w-[220px] truncate text-[12.5px] text-mist-200">{c.title}</div>
                          {c.isLossMaking && <div className="mt-0.5"><Badge tone="red">onerous</Badge></div>}
                        </td>
                        <td className={tdCls}>
                          <span className="font-mono text-[12px]">{c.counterparty}</span>
                          <div className="mt-0.5 text-[11px] text-mist-600">{METHODS.find((m) => m.code === c.method)?.label.split("(")[0]}</div>
                        </td>
                        <td className={tdCls}>
                          <span className="font-mono text-[11.5px] text-mist-500">
                            {c.startDate || "—"} → {c.endDate || "—"}
                          </span>
                        </td>
                        <td className={numCls + " font-semibold"}>{num(c.totalValue)}</td>
                        <td className={numCls}>
                          <span className={cn(c.pctComplete >= 100 ? "text-pos" : "text-mist-100")}>{c.pctComplete.toFixed(1)}%</span>
                          <div className="mt-1 h-1 w-16 overflow-hidden rounded-full bg-ink-800">
                            <div className="h-full rounded-full bg-gold-400" style={{ width: `${Math.min(100, c.pctComplete)}%` }} />
                          </div>
                        </td>
                        <td className={numCls + " text-pos"}>{num(c.revenueToDate)}</td>
                        <td className={numCls + (c.cumulativeProfit >= 0 ? " text-pos" : " text-neg")}>{num(c.cumulativeProfit)}</td>
                        <td className={numCls + (c.contractAsset - c.contractLiability >= 0 ? " text-fi" : " text-neg")}>
                          {num(c.contractAsset - c.contractLiability)}
                        </td>
                        <td className={tdCls}>
                          <div className="flex justify-end">
                            {c.status === "active" && (
                              <RowAction action="close_contract" payload={{ contractId: c.id }} label="Close" user="projects" />
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t border-ink-600 bg-ink-900/60">
                      <td className={tdCls + " font-semibold text-mist-100"} colSpan={3}>Portfolio totals (active)</td>
                      <td className={numCls + " font-bold"}>{num(portfolio.totals.value)}</td>
                      <td className={numCls} />
                      <td className={numCls + " font-bold text-pos"}>{num(portfolio.totals.revenue)}</td>
                      <td className={numCls + " font-bold"}>{num(portfolio.totals.revenue - portfolio.totals.cost)}</td>
                      <td className={numCls + " font-bold text-fi"}>{num(portfolio.totals.contractAssets - portfolio.totals.contractLiabilities)}</td>
                      <td />
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </Card>

          {variations.length > 0 && (
            <Card
              title="Approved variations & estimate revisions"
              sub="Audit trail of changes to transaction price and estimate at completion"
              pad={false}
            >
              <div className="max-h-[300px] overflow-auto">
                <table className="w-full min-w-[780px]">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Period</th>
                      <th className={thCls}>Type</th>
                      <th className={thCls + " text-right"}>Old value</th>
                      <th className={thCls + " text-right"}>New value</th>
                      <th className={thCls + " text-right"}>Old EAC</th>
                      <th className={thCls + " text-right"}>New EAC</th>
                      <th className={thCls}>Approved by</th>
                    </tr>
                  </thead>
                  <tbody>
                    {variations.map((v) => (
                      <tr key={v.id} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[11.5px]">{v.period}</span></td>
                        <td className={tdCls}><Badge tone="amber">{v.kind.replace("_", " ")}</Badge></td>
                        <td className={numCls}>{num(Number(v.oldValue))}</td>
                        <td className={numCls}>{num(Number(v.newValue))}</td>
                        <td className={numCls}>{num(Number(v.oldEstimatedCost))}</td>
                        <td className={numCls}>{num(Number(v.newEstimatedCost))}</td>
                        <td className={tdCls}>
                          <span className="text-[12px] text-mist-300">{v.approvedBy}</span>
                          <div className="mt-0.5 max-w-[220px] truncate text-[11.5px] text-mist-600" title={v.description}>{v.description}</div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          <Card title="Interim payment certificates" sub="IPCs raised against certified work, with retention deducted" pad={false}>
            {certs.length === 0 ? (
              <p className="p-4 text-sm text-mist-500">No certificates raised yet. Raise one after recognising revenue on a contract.</p>
            ) : (
              <div className="max-h-[420px] overflow-y-auto">
                <table className="w-full min-w-[860px]">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Certificate</th>
                      <th className={thCls}>Period</th>
                      <th className={thCls + " text-right"}>Gross</th>
                      <th className={thCls + " text-right"}>Retention</th>
                      <th className={thCls + " text-right"}>Net due</th>
                      <th className={thCls + " text-right"}>Paid</th>
                      <th className={thCls}>Status</th>
                      <th className={thCls + " text-right"}>Issue</th>
                    </tr>
                  </thead>
                  <tbody>
                    {certs.map((c) => (
                      <tr key={c.id} className={rowCls}>
                        <td className={tdCls}>
                          <span className="font-mono text-[12px] font-semibold text-gold-300">{c.certNo}</span>
                          <div className="mt-0.5 text-[11px] text-mist-600">doc {c.docNo}</div>
                        </td>
                        <td className={tdCls}><span className="font-mono text-[11.5px] text-mist-500">{c.period}</span></td>
                        <td className={numCls}>{num(Number(c.grossValue))}</td>
                        <td className={numCls + " text-aa"}>{num(Number(c.retention))}</td>
                        <td className={numCls + " font-semibold"}>{num(Number(c.netPayable))}</td>
                        <td className={numCls + " text-pos"}>{num(Number(c.paid))}</td>
                        <td className={tdCls}>
                          <Badge tone={c.status === "paid" ? "green" : c.status === "partial" ? "amber" : c.status === "cancelled" ? "red" : "slate"}>{c.status}</Badge>
                        </td>
                        <td className={tdCls}>
                          <div className="flex justify-end">
                            <Link
                              href={`/projects/certificates/${c.id}/print`}
                              target="_blank"
                              className="rounded-md border border-ink-600 bg-ink-800/70 px-2.5 py-1.5 text-xs font-semibold text-mist-300 hover:border-gold-400/50 hover:text-gold-300"
                            >
                              Print IPC
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        <ContractForms
          partnerOptions={customers.map((c) => ({ value: c.bpNo, label: `${c.bpNo} · ${c.name}` }))}
          ccOptions={ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }))}
          methodOptions={METHODS}
          sectorOptions={SECTOR_OPTS}
          contractOptions={contractOptions}
          vendorOptions={vendors.map((v) => ({
            value: v.bpNo,
            label: `${v.bpNo} · ${v.name}`,
          }))}
        />
      </div>

      <Card className="mt-4" title="How IFRS 15 over-time recognition works here" sub="The five-step model, applied automatically">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {[
            ["1 · Identify the contract", "Each contract is a separate performance obligation record with its own customer, value, term and recognition method."],
            ["2 · Transaction price", "The contract value, including any mobilisation advance. Fixed-price contracts are the default; variations are recorded as cost entries plus a value update."],
            ["3 · Performance obligation", "A single over-time obligation — the customer receives control of the work as it is performed, which is why revenue is recognised before final delivery."],
            ["4 · Measure progress", "Cost-to-cost (costs incurred ÷ total estimated cost), surveyor certification, output milestones, or straight line. The method is set per contract."],
            ["5 · Recognise revenue", "At each period end: cumulative revenue less previously recognised, with matching cost of sales. Profit is therefore recognised only as work completes."],
          ].map(([t, b]) => (
            <div key={t} className="rounded-lg border border-ink-700 bg-ink-900/40 p-3">
              <div className="text-[12.5px] font-bold text-gold-300">{t}</div>
              <div className="mt-1 text-[12px] leading-relaxed text-mist-400">{b}</div>
            </div>
          ))}
        </div>
        <div className="mt-3 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2.5 text-[12px] leading-relaxed text-mist-500">
          <span className="font-bold text-mist-300">Balance sheet presentation:</span> where cumulative revenue exceeds
          billings the difference is a <span className="text-fi">contract asset</span> (unbilled work performed);
          where billings and mobilisation advances exceed revenue it is a{" "}
          <span className="text-aa">contract liability</span>. Retention is shown separately as a receivable. Where
          expected costs exceed the transaction price, the loss is provided for immediately under IAS 37.
        </div>
      </Card>
    </>
  );
}
