import { requireWorkspace } from "@/lib/auth";
import { buildNotesToAccounts } from "@/lib/disclosures";
import { thisPeriod } from "@/lib/periods";
import { Card, PageHeader, Badge } from "@/components/ui";
import { SimpleActionForm } from "@/components/SimpleActionForm";

export const dynamic = "force-dynamic";

export default async function DisclosuresPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const ws = await requireWorkspace();
  const sp = await searchParams;
  const to = sp.to || thisPeriod();
  const from = sp.from || to.slice(0, 4) + "-01";
  const pack = await buildNotesToAccounts(ws.client.id, from, to);
  const applicable = pack.notes.filter((n) => n.applicable).length;
  const na = pack.notes.length - applicable;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`IAS 1 · Notes to Accounts · ${ws.client.code}`}
        title="Notes to the Financial Statements"
        desc="Full disclosure pack generated live from the Universal Journal and standards desks. Notes that do not apply say so honestly rather than printing empty tables. Available here and as a Notes_to_Accounts sheet in Excel export."
      />

      <div className="flex flex-wrap items-center gap-3">
        <Badge tone="gold">{pack.notes.length} notes</Badge>
        <Badge tone="green">{applicable} applicable</Badge>
        <Badge tone="slate">{na} not applicable (honest N/A)</Badge>
        <a className="rounded-lg bg-gold-400 px-3 py-1.5 text-sm font-semibold text-brand-navy" href={`/api/notes?from=${from}&to=${to}&format=md`}>
          Download Markdown
        </a>
        <a className="rounded-lg border border-ink-600 px-3 py-1.5 text-sm font-semibold text-mist-100" href={`/api/export?sheet=notes&from=${from}&to=${to}`}>
          Excel — Notes pack
        </a>
        <a className="rounded-lg border border-ink-600 px-3 py-1.5 text-sm font-semibold text-mist-100" href={`/api/export?sheet=all&from=${from}&to=${to}`}>
          Full workbook
        </a>
      </div>

      <Card title="Period filter" sub="Defaults to YTD of the current fiscal month">
        <form className="flex flex-wrap items-end gap-3" method="get">
          <label className="text-sm">
            <span className="mb-1 block text-mist-400">From</span>
            <input name="from" defaultValue={from} className="rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm" />
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-mist-400">To</span>
            <input name="to" defaultValue={to} className="rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm" />
          </label>
          <button className="rounded-lg bg-gold-400 px-4 py-2 text-sm font-bold text-brand-navy">Refresh</button>
        </form>
        <div className="mt-3">
          <SimpleActionForm action="notes.build" label="Rebuild & persist note flags" fields={{ from: { defaultValue: from }, to: { defaultValue: to } }} />
        </div>
      </Card>

      <div className="space-y-4">
        {pack.notes.map((n) => (
          <Card key={n.key} title={n.title} sub={`${n.standardRef}${n.applicable ? "" : " · NOT APPLICABLE"}`}>
            {!n.applicable && (
              <div className="mb-3 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-sm text-amber-100">
                <strong>Not applicable.</strong> {n.notApplicableReason}
              </div>
            )}
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-mist-200">{n.body}</p>
            {n.tables?.map((t, i) => (
              <div key={i} className="mt-4 overflow-x-auto">
                <table className="min-w-full text-left text-[12.5px]">
                  <thead>
                    <tr className="border-b border-ink-700 text-mist-400">
                      {t.headers.map((h) => (
                        <th key={h} className="px-2 py-1.5 font-semibold">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {t.rows.map((r, ri) => (
                      <tr key={ri} className="border-b border-ink-900/80">
                        {r.map((c, ci) => (
                          <td key={ci} className="px-2 py-1.5 text-mist-100">{String(c)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
          </Card>
        ))}
      </div>

      <Card title="Significant accounting policies (detail)" sub="IAS 1 / IAS 8 — full policy text">
        <div className="space-y-4">
          {pack.policies.map((p) => (
            <div key={p.key} className="border-b border-ink-800 pb-3">
              <div className="font-semibold text-mist-100">
                {p.title} <span className="text-xs font-normal text-gold-400">{p.standardRef}</span>
              </div>
              <p className="mt-1 text-sm text-mist-300">{p.body}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
