import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { assets, assetClasses } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { ASSET_CLASSES } from "@/data/sectors";
import { money, num } from "@/lib/format";
import { thisPeriod } from "@/lib/periods";
import { PageHeader, Card, ExportLink, EmptyState, Stat, tdCls, thCls, numCls, rowCls, Badge } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";
import { RowAction } from "@/components/RowAction";

export const dynamic = "force-dynamic";

export default async function AssetsPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = thisPeriod();

  const rows = await db.select().from(assets).where(eq(assets.clientId, clientId)).orderBy(asc(assets.id));
  const gross = rows.reduce((s, a) => s + Number(a.cost), 0);
  const accum = rows.reduce((s, a) => s + Number(a.accumDep), 0);
  const nbv = gross - accum;
  const depreciable = rows.filter((a) => a.active && Number(a.nbv) > 0.005 && (ASSET_CLASSES.find((c) => c.code === a.classCode)?.rate ?? 0) > 0);

  return (
    <>
      <PageHeader
        kicker={`FI-AA · Fixed Assets · ${ws.client.code}`}
        title="Fixed Asset Registry"
        desc="Sector-general and sector-specific classes (vehicles, buildings, plant, mining equipment, wells, CIP, intangibles). Acquisition capitalises at cost; the depreciation run posts straight-line or declining-balance per class, per month."
      >
        <ExportLink sheet="assets" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Gross Asset Value" value={money(gross)} sub="Cost, all classes" />
        <Stat label="Accumulated Depreciation" value={money(accum)} tone="text-aa" sub="All runs to date" />
        <Stat label="Net Book Value" value={money(nbv)} tone="text-pos" sub="Gross − accumulated" />
        <Stat label="Depreciable Assets" value={depreciable.length} sub="With NBV > 0 and active class rate" />
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-[400px_1fr]">
        <div className="space-y-4">
          <ActionForm
            action="add_asset"
            title="Capitalise Asset"
            sub="Posts 130000 Dr / 101000 Cr and registers the asset"
            submitLabel="Acquire & capitalise"
            userDefault="ops_user"
            periodField
            fields={[
              { name: "name", label: "Asset name", type: "text", placeholder: "e.g. Toyota Hilux / Crusher unit", defaultValue: "" },
              {
                name: "classCode", label: "Asset class", type: "select",
                options: ASSET_CLASSES.map((c) => ({ value: c.code, label: `${c.code} · ${c.name} (${c.method === "db" ? "declining" : "SL"} ${c.rate}%)` })),
              },
              { name: "cost", label: "Cost (GHS)", type: "number", step: "0.01", min: 0.01, defaultValue: "250000.00" },
              { name: "cc", label: "Cost center", type: "select", required: false, options: [] },
            ]}
          />
          <Card title="Run Monthly Depreciation" sub={`Period ${period} — posts 550000 Dr / 139000 Cr for every depreciable asset, class by class`}>
            <RowAction
              action="depreciation_run"
              payload={{ period }}
              label={`Run depreciation for ${period}`}
              tone="gold"
              user="ops_user"
            />
            <p className="mt-2 text-[12.5px] leading-relaxed text-mist-600">
              Straight-line classes depreciate cost × rate ÷ 12 · declining classes depreciate NBV × rate ÷ 12. Land and CIP carry 0% until reclassified.
            </p>
          </Card>
        </div>

        <Card title="Asset Register" sub="Per-asset cost, accumulated depreciation and net book value" pad={false}>
          {rows.length === 0 ? (
            <div className="p-4">
              <EmptyState icon="truck" title="No assets registered" body="Capitalise your first asset on the left — the journal entry posts automatically." />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px]">
                <thead>
                  <tr className="border-b border-ink-700/70">
                    <th className={thCls}>Asset</th>
                    <th className={thCls}>Class</th>
                    <th className={thCls}>In service</th>
                    <th className={thCls + " text-right"}>Cost</th>
                    <th className={thCls + " text-right"}>Accum dep</th>
                    <th className={thCls + " text-right"}>NBV</th>
                    <th className={thCls}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((a) => {
                    const cls = ASSET_CLASSES.find((c) => c.code === a.classCode);
                    return (
                      <tr key={a.id} className={rowCls}>
                        <td className={tdCls}>
                          <span className="text-[13px] font-semibold text-mist-100">{a.name}</span>
                          <div className="mt-0.5 font-mono text-[12px] text-mist-600">doc {a.docNo}</div>
                        </td>
                        <td className={tdCls}>
                          <span className="font-mono text-[12.5px] text-gold-300">{a.classCode}</span>
                          <div className="mt-0.5 text-[12.5px] text-mist-600">{cls?.method === "db" ? "Declining" : "Straight-line"} {cls?.rate ?? 0}%</div>
                        </td>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{a.inService}</span></td>
                        <td className={numCls}>{num(Number(a.cost))}</td>
                        <td className={numCls + " text-aa"}>{num(Number(a.accumDep))}</td>
                        <td className={numCls + " font-semibold text-pos"}>{num(Number(a.nbv))}</td>
                        <td className={tdCls}>
                          <Badge tone={a.active ? "green" : "slate"}>{a.active ? (Number(a.nbv) > 0.005 ? "Depreciating" : "Fully depreciated") : "Disposed"}</Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t border-ink-600 bg-ink-900/60">
                    <td className={tdCls + " font-semibold text-mist-100"} colSpan={3}>Totals</td>
                    <td className={numCls + " font-semibold"}>{num(gross)}</td>
                    <td className={numCls + " font-semibold text-aa"}>{num(accum)}</td>
                    <td className={numCls + " font-bold text-pos"}>{num(nbv)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
