import { requireWorkspace } from "@/lib/auth";
import { PageHeader, Card, Stat } from "@/components/ui";
import { SecurityPanel } from "@/components/SecurityPanel";

export const dynamic = "force-dynamic";

export default async function SecurityPage() {
  const ws = await requireWorkspace();

  return (
    <>
      <PageHeader
        kicker="ADM · My account"
        title="Security Settings"
        desc="Protect your account with a second factor and a strong password. Both are enforced by the platform, not by convention — a pending sign-in cannot see any client data until the authenticator code is verified."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Signed in as" value={ws.user.name} sub={`${ws.user.username} · ${ws.user.role}`} />
        <Stat label="Two-factor" value={ws.user.totpEnabled ? "Enabled" : "Off"} tone={ws.user.totpEnabled ? "text-pos" : "text-aa"} sub="Required at every sign-in when on" />
        <Stat label="Session" value="7 days" sub="Bound to this browser only" />
        <Stat label="Lockout policy" value="8 attempts" sub="15-minute lock after repeated failures" />
      </div>

      <SecurityPanel name={ws.user.name} totpEnabled={ws.user.totpEnabled} role={ws.user.role} />
    </>
  );
}
