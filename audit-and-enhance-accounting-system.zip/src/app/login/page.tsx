import { apiWorkspace, getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { LoginCard } from "@/components/LoginCard";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const user = await getSessionUser();
  const ticket = typeof sp.t === "string" ? sp.t : "";

  // A session awaiting 2FA must reach the 2FA screen, not be bounced.
  if (user && user.pending2fa && ticket) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4 py-10">
        <div className="w-full max-w-sm">
          <div className="mb-6 flex items-center justify-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold-400 font-display text-[15px] font-extrabold text-brand-navy">BPZ</span>
            <span>
              <span className="block font-display text-xl font-extrabold tracking-[0.03em] text-mist-100">BPZ CONSULT</span>
              <span className="block text-[12px] font-semibold uppercase tracking-[0.22em] text-gold-400">Financial Experts</span>
            </span>
          </div>
          <LoginCard pending2fa ticket={ticket} />
        </div>
      </div>
    );
  }
  // A signed-in client who still owes terms acceptance must land on the
  // acceptance screen, not be bounced to / or back here in a loop.
  if (user && !user.pending2fa && !user.mustChangePassword && !user.termsAccepted) {
    redirect("/accept-terms");
  }
  if (user && !user.pending2fa && !user.mustChangePassword) redirect("/");

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex items-center justify-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold-400 font-display text-[15px] font-extrabold text-brand-navy shadow-[0_0_32px_-6px_rgba(245,183,25,0.8)]">
            BPZ
          </span>
          <span>
            <span className="block font-display text-xl font-extrabold tracking-[0.03em] text-mist-100">BPZ CONSULT</span>
            <span className="block text-[12px] font-semibold uppercase tracking-[0.22em] text-gold-400">
              Financial Experts
            </span>
          </span>
        </div>
        <LoginCard mustChange={!!user?.mustChangePassword} />

        <div className="mt-4 rounded-xl border border-gold-400/25 bg-gold-400/5 p-3.5">
          <div className="mb-2 text-[12px] font-bold uppercase tracking-[0.16em] text-gold-400">
            Demonstration credentials
          </div>
          <table className="w-full text-[12.5px]">
            <tbody className="font-mono">
              <tr>
                <td className="py-0.5 pr-3 text-mist-500">Owner</td>
                <td className="py-0.5 text-gold-300">owner / BpzOwner2026!</td>
              </tr>
              <tr>
                <td className="py-0.5 pr-3 text-mist-500">Client</td>
                <td className="py-0.5 text-gold-300">demo / BpzDemo2026!</td>
              </tr>
            </tbody>
          </table>
          <p className="mt-2 text-[12px] leading-relaxed text-mist-600">
            These are restored automatically at startup so the platform is never unreachable. Change the owner
            password from <span className="text-mist-400">My Security</span> before live client use.
          </p>
        </div>
      </div>
    </div>
  );
}
