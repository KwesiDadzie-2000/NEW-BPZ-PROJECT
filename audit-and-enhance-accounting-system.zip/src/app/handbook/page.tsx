import { requireWorkspace } from "@/lib/auth";
import { PageHeader, Card, Badge, Icon } from "@/components/ui";

export const dynamic = "force-dynamic";

type Section = {
  id: string;
  title: string;
  intro: string;
  steps?: { what: string; why?: string }[];
  fields?: { name: string; meaning: string }[];
  notes?: string[];
};

const SECTIONS: Section[] = [
  {
    id: "start",
    title: "1 · Getting started",
    intro:
      "The platform runs one Universal Journal per client workspace. Every action you take in any module writes a balanced accounting entry there — you never post to a separate ledger, and reports are always live.",
    notes: [
      "Owner accounts manage every client workspace and can switch between them from the sidebar.",
      "Client accounts see only their own workspace — their master data, books and reports are isolated.",
      "Roles: owner (everything) · admin (firm-wide) · accountant (post and process) · viewer (read-only, posting blocked).",
    ],
  },
  {
    id: "concepts",
    title: "2 · The five things every posting carries",
    intro: "Every journal line stores these dimensions. They drive every report, filter and analysis.",
    fields: [
      { name: "Account", meaning: "Which chart-of-accounts line the value lands on (e.g. 110000 Accounts Receivable). Determines whether it appears in profit or in the balance sheet." },
      { name: "Period (YYYY-MM)", meaning: "The fiscal month. Every report, ledger and return filters on this. Closing a period freezes it against further posting." },
      { name: "Business partner (BP)", meaning: "The customer, supplier or employee the line relates to. Drives the AR/AP aging and individual ledgers. Each workspace keeps its own partner list." },
      { name: "Cost centre", meaning: "The department or project that owns the cost. Drives the cost-centre report and budget variance." },
      { name: "Reference", meaning: "Free text tying the line back to its source document (PO number, invoice number, reason for an adjustment)." },
      { name: "Expense account", meaning: "On a purchase, where the cost belongs: stock or materials to an inventory/COGS account, services and overheads to their own expense account. This is what makes your profit-and-loss analysis meaningful." },
    ],
  },
  {
    id: "partners",
    title: "Business partners — the people you trade with",
    intro:
      "Every invoice, order and payroll run names a partner. Each workspace keeps its own list, so one client's suppliers are never visible to another's. You can add a partner from Master Data, or directly from the invoice screen if you meet a new supplier mid-entry.",
    fields: [
      { name: "Code", meaning: "Your short reference. Most firms prefix suppliers with V and customers with C — V010, C007 — but any unique code works." },
      { name: "Type", meaning: "Supplier (vendor), customer or employee. Determines which screens offer the partner and which ledger it reports in." },
      { name: "TIN", meaning: "Tax identification number. Needed for withholding tax certificates and GRA reporting — capture it when you add the partner, not later." },
      { name: "Phone / email", meaning: "Contact details for chasing invoices and sending remittance advices." },
      { name: "Default expense account", meaning: "Optional shortcut so a recurring supplier always books to the right account." },
    ],
  },
  {
    id: "procurement",
    title: "3 · Buying — two routes, choose the right one",
    intro:
      "Not every purchase needs a purchase order. Use the full process for materials you will hold in stock; use a direct supplier invoice for services, rent, utilities and anything consumed immediately.",
    steps: [
      { what: "Route A — materials: PO → Receive goods → Vendor invoice → Pay", why: "Use when you take the items into stock. Receiving posts Inventory Dr and the supplier is not yet payable. The invoice then moves the value from GR-IR to Accounts Payable." },
      { what: "Route B — contracted services: Supplier invoice → Pay", why: "Use for consultancy, legal fees, marketing, repairs — services you select and contract. Go to Procurement → Supplier document, choose the expense account, and the invoice posts the cost and the payable in one step." },
      { what: "Route C — statutory bills: Expenses & Statutory → Raise bill → Payment Desk", why: "Use for utilities, taxes, pensions, insurance, regulatory fees, penalties and bank charges. These are fixed by law, a regulator or a contract, so there is nothing to procure. Raising the bill charges the expense and credits Accounts Payable; you then pay it from the Payment Desk in full or in part." },
    ],
    fields: [
      { name: "Expense account", meaning: "Route B only. Where the cost belongs: 500000 Cost of Goods Sold for resale items, 514000 Professional Fees for accountants and lawyers, 520000 Rent, 540000 Utilities, 530000 Repairs. Choosing well is what makes your P&L useful." },
      { name: "Cost centre", meaning: "Which department or project owns the cost. Leave blank if the whole company bears it. Drives the cost-centre report and budget variance." },
      { name: "VAT", meaning: "Applied at 20% by default. Input VAT on a valid invoice is recoverable against your output VAT, so untick it only for VAT-exempt purchases or blocked credits such as entertainment." },
    ],
    notes: [
      "Materials you buy for resale or for production belong in stock — Route A. Materials consumed immediately (fuel, small tools, consumables) can go straight to expense — Route B.",
      "Withholding tax is selected when you pay, not when you invoice, because that is when it becomes due for remittance to GRA.",
      "Goods and services carry different WHT rates (7.5% goods, 5% general services, 15% professional) — pick the right one from the schedule shown at the payment desk.",
      "Statutory expenses — utilities, taxes, pension, insurance, regulatory fees, penalties — never appear in Procurement. They live under Expenses & Statutory, which is a control, not a limitation: it keeps the PO register clean for items that genuinely need supplier approval.",
      "Penalties and fines are usually non-deductible for tax. Keeping them in their own category makes them easy to add back in the tax computation.",
    ],
  },
  {
    id: "sales",
    title: "4 · Sales (invoicing customers)",
    intro: "Quotes, invoices, credit notes and debit notes all live here. VAT at 20% is applied unless you untick it.",
    steps: [
      { what: "Raise a quotation", why: "No accounting entry — a quote is not yet a sale." },
      { what: "Accept the quote", why: "Converts it to an invoice and posts AR Dr / Output VAT Cr / Revenue Cr." },
      { what: "Receive payment", why: "Posts Bank Dr / AR Cr. Partial payments are supported and the invoice stays marked 'partial' until settled." },
      { what: "Issue a credit note", why: "Reverses all or part of an invoice — it posts the opposite of the original entry." },
    ],
    notes: [
      "Foreign-currency invoices record the rate used at the time. When you are paid, the platform compares that rate with the current live rate and posts the difference as FX gain or loss.",
      "To make an invoice recur monthly or quarterly, use Make recurring — useful for retainers and rent.",
    ],
  },
  {
    id: "payment",
    title: "5 · Payment desk",
    intro: "All money in and out runs through here, whether full or partial.",
    fields: [
      { name: "Amount", meaning: "Defaults to the full balance. Enter a smaller figure for a part payment — the invoice status becomes 'partial'." },
      { name: "WHT type", meaning: "Applies the statutory withholding rate to a supplier payment. The tax is deducted from the bank payment and credited to WHT Payable, ready to remit to GRA by the 15th." },
      { name: "Live rate", meaning: "Fetched automatically from the mid-market feed for foreign-currency settlements. You are never asked to type it." },
    ],
  },
  {
    id: "payroll",
    title: "6 · Payroll",
    intro: "Payroll is driven by an employee master you can grow at any time. Add employees whenever you like; their salary applies to future runs only.",
    steps: [
      { what: "Add the employee", why: "Captures name, position, department, jurisdiction, TIN, social-security number and bank account." },
      { what: "Set or change the salary", why: "Basic and allowances are stored per employee. Changing them never rewrites a run already posted." },
      { what: "Run payroll", why: "The engine applies PAYE bands, SSNIT Tier 1 and 2, NHIL and housing, then posts the complete journal entry." },
      { what: "Release net pay", why: "Posts the bank payment. Full or partial release is supported." },
    ],
    fields: [
      { name: "Basic salary", meaning: "The fixed contractual pay. Housing relief is computed on this figure only." },
      { name: "Allowances", meaning: "Variable pay added to basic to reach gross. Taxable." },
      { name: "Gross", meaning: "Basic + allowances. The figure all percentage deductions are based on." },
      { name: "Taxable income", meaning: "Gross less the employee's SSNIT contributions. PAYE bands apply to this." },
      { name: "Net pay", meaning: "What the employee actually receives — credited to Salaries Payable until released." },
      { name: "Employer cost", meaning: "The employer's SSNIT contribution, charged to expense on top of gross." },
    ],
  },
  {
    id: "banking",
    title: "7 · Banking and reconciliation",
    intro: "Add each real bank account, then reconcile the statement against the ledger.",
    steps: [
      { what: "Add the bank account", why: "Links a real account to its GL code and currency." },
      { what: "Import the statement", why: "Upload a CSV with date, description, amount. Lines land as unmatched." },
      { what: "Match each line", why: "Ties the statement line to its journal entry. Everything is editable — you can unmatch, re-edit amounts or correct the description." },
    ],
  },
  {
    id: "inventory",
    title: "8 · Inventory and stock",
    intro: "Stock is valued from the journal, quantities from the movement register.",
    fields: [
      { name: "Qty in", meaning: "Units received. Posts Inventory Dr at standard cost." },
      { name: "Qty out", meaning: "Units issued, sold or written off. Posts the expense and credits Inventory." },
      { name: "Book value", meaning: "What the ledger says the stock is worth — the authoritative IAS 2 figure." },
      { name: "Variance vs standard", meaning: "Difference between book value and quantity × standard price. A growing variance signals pricing or shrinkage problems." },
    ],
  },
  {
    id: "assets",
    title: "9 · Fixed assets",
    intro: "Capitalise an asset, then run depreciation monthly. Classes carry the rate and method.",
    fields: [
      { name: "Asset class", meaning: "Determines the GL account it is capitalised to, the depreciation rate and the method. Sector-specific classes (mining equipment, wells, generation plant) sit alongside general ones." },
      { name: "Cost", meaning: "Capitalised at acquisition, posted against the bank." },
      { name: "Accumulated depreciation", meaning: "Total charged to date — a contra-asset." },
      { name: "Net book value", meaning: "Cost less accumulated depreciation. The figure on the balance sheet." },
    ],
  },
  {
    id: "compliance",
    title: "10 · Tax and filing schedule",
    intro: "This page tells you exactly what to file, when, and for how much — computed live from your own books.",
    fields: [
      { name: "Net VAT payable", meaning: "Output VAT on sales less recoverable input VAT on purchases. A negative figure is a credit to carry forward." },
      { name: "PAYE to remit", meaning: "Tax deducted from employees in the period, due to GRA by the 15th of the following month." },
      { name: "WHT to remit", meaning: "Tax withheld from suppliers, with a per-supplier register so you can issue certificates." },
      { name: "SSNIT + NHIL", meaning: "Statutory social contributions, due by the 14th and 15th respectively." },
    ],
    notes: [
      "Every rate shown is editable in Admin & Compliance. When GRA changes a rate, update it once — all workspaces and all future computations follow.",
      "VAT and WHT schedules are exportable to Excel for your filing pack.",
    ],
  },
  {
    id: "journals",
    title: "11 · Manual journals, openings and adjustments",
    intro: "For anything the modules do not cover. Choose the document category first — it changes what is required.",
    fields: [
      { name: "Journal (FB50)", meaning: "Ordinary entry. Nothing extra required." },
      { name: "Opening balance", meaning: "Bringing in balances at the start of a financial year. A reason is mandatory and is stored in the audit trail." },
      { name: "Prepayment", meaning: "Money paid in advance of the expense being incurred." },
      { name: "Adjustment", meaning: "A correction. A reason is mandatory — this is what an auditor will read." },
    ],
    notes: [
      "The form shows debits and credits live. You cannot post until the two sides are equal.",
      "To reverse a posted document, go to the same page and use Reverse a document — the reason is mandatory and the reversal is linked to the original.",
    ],
  },
  {
    id: "close",
    title: "12 · Month-end close",
    intro: "Run the checklist, then close the period to freeze it.",
    steps: [
      { what: "Run depreciation", why: "Charges every depreciable asset for the month." },
      { what: "Revalue foreign currency", why: "Revalues open foreign-currency invoices at the live rate and posts the FX gain or loss." },
      { what: "Review the trial balance", why: "Confirm debits equal credits and the figures look right." },
      { what: "Close the period", why: "Locks it. Nothing further can be posted to that month until you reopen it." },
    ],
    notes: ["Fiscal periods are unlimited — any month of any year. Reports filter by any range of periods."],
  },
  {
    id: "reports",
    title: "13 · Reports",
    intro: "Everything is computed live from the journal; nothing needs to be refreshed.",
    fields: [
      { name: "Trial balance", meaning: "Every account with its debits, credits and balance. Must always balance." },
      { name: "Profit or loss", meaning: "Revenue less expenses for the period selected." },
      { name: "Financial position", meaning: "Assets, liabilities and equity at the period end." },
      { name: "Cash flow", meaning: "IAS 7 indirect method — operating, investing and financing." },
      { name: "Changes in equity", meaning: "Movement in each equity account, opening to closing." },
      { name: "AP / AR aging", meaning: "Who owes you and who you owe, bucketed by how old the balance is." },
      { name: "BP ledger", meaning: "Every transaction with one customer or supplier, with a running balance." },
    ],
    notes: ["Every report exports to Excel. The dashboard offers the complete multi-sheet workbook."],
  },
  {
    id: "admin",
    title: "14 · Administration and assurance",
    intro: "Owner-controlled settings and the evidence your auditors will ask for.",
    notes: [
      "Admin & Compliance — logins, roles, restrictions, temporary passwords, and every statutory rate.",
      "Clients — create client workspaces with their sector, jurisdiction, service lines and a temporary login.",
      "Audit Log — an immutable record of who did what, when, in which workspace, and whether it succeeded.",
      "System Assurance — fifteen automated control tests including double-entry integrity, tenant isolation and tax computation accuracy. Run it before issuing reports.",
      "Data Protection — download a complete restore point of a workspace.",
    ],
  },
];

export default async function HandbookPage() {
  await requireWorkspace();
  return (
    <>
      <PageHeader
        kicker="Reference"
        title="User Handbook"
        desc="How the platform fits together, what every variable means, and the exact order to work through each module. Written for the person doing the work, not for an accountant explaining it to one."
      />

      <Card className="mb-4" title="The one principle to remember">
        <p className="text-[13px] leading-relaxed text-mist-400">
          You never post to accounting directly. You run a business process — raise an order, receive goods, pay a
          supplier, run a payroll — and the platform writes the correct, balanced accounting entry for you. If a report
          looks wrong, find the business document behind it rather than adjusting the ledger: use
          <span className="text-mist-200"> Universal Journal</span> to trace any figure back to the document that created
          it, and <span className="text-mist-200">Reverse a document</span> if it was a mistake.
        </p>
      </Card>

      <div className="mb-4 flex flex-wrap gap-1.5">
        {SECTIONS.map((s) => (
          <a key={s.id} href={`#${s.id}`} className="rounded-lg border border-ink-600 px-2.5 py-1.5 text-[12.5px] font-semibold text-mist-400 transition hover:border-gold-400/50 hover:text-gold-300">
            {s.title.split("·")[0].trim()}
          </a>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {SECTIONS.map((sec) => (
          <Card key={sec.id} title={<span id={sec.id}>{sec.title}</span>}>
            <p className="mb-3 text-[13px] leading-relaxed text-mist-400">{sec.intro}</p>

            {sec.steps && (
              <ol className="mb-3 space-y-2">
                {sec.steps.map((st, i) => (
                  <li key={st.what} className="flex gap-2.5">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gold-400/15 font-mono text-[12.5px] font-bold text-gold-300">
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="text-[13px] font-semibold text-mist-100">{st.what}</div>
                      {st.why && <div className="mt-0.5 text-[12.5px] leading-snug text-mist-500">{st.why}</div>}
                    </div>
                  </li>
                ))}
              </ol>
            )}

            {sec.fields && (
              <div className="mb-3 overflow-hidden rounded-lg border border-ink-700">
                <table className="w-full">
                  <tbody>
                    {sec.fields.map((f) => (
                      <tr key={f.name} className="border-b border-ink-800/70 last:border-0">
                        <td className="w-1/3 bg-ink-900/50 px-3 py-2 align-top text-[12px] font-semibold text-gold-300">{f.name}</td>
                        <td className="px-3 py-2 text-[12.5px] leading-snug text-mist-400">{f.meaning}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {sec.notes && (
              <ul className="space-y-1.5">
                {sec.notes.map((n) => (
                  <li key={n.slice(0, 30)} className="flex gap-2 text-[12.5px] leading-relaxed text-mist-500">
                    <Icon name="check" size={13} className="mt-0.5 shrink-0 text-gold-400" />
                    {n}
                  </li>
                ))}
              </ul>
            )}
          </Card>
        ))}
      </div>

      <Card className="mt-4" title="If something looks wrong">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <div className="mb-1 text-[12px] font-bold text-mist-200">A balance looks wrong</div>
            <p className="text-[12.5px] leading-relaxed text-mist-500">
              Open Universal Journal, filter by the period and the account, and click the document number to see the
              full balanced entry. Every line shows the user who posted it and the reference it came from.
            </p>
          </div>
          <div>
            <div className="mb-1 text-[12px] font-bold text-mist-200">I posted something by mistake</div>
            <p className="text-[12.5px] leading-relaxed text-mist-500">
              Do not reverse it with a manual journal — use <span className="text-mist-300">Manual Journal → Reverse a
              document</span>, enter the document number and a reason. It mirrors every line and keeps the audit trail
              intact.
            </p>
          </div>
          <div>
            <div className="mb-1 text-[12px] font-bold text-mist-200">The month is closed and I need to fix it</div>
            <p className="text-[12.5px] leading-relaxed text-mist-500">
              Reopen the period from Month-End Close, post a correcting adjustment with a reason, then close it again.
              The original entry is never overwritten.
            </p>
          </div>
          <div>
            <div className="mb-1 text-[12px] font-bold text-mist-200">I cannot post — the period is closed</div>
            <p className="text-[12.5px] leading-relaxed text-mist-500">
              That is the control working. Either post into the current open period or reopen the closed one
              deliberately. Closed periods are protected against accidental back-dating.
            </p>
          </div>
        </div>
      </Card>

      <div className="mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-ink-700 bg-ink-850/60 px-4 py-3 text-[12px] text-mist-500">
        <Badge tone="gold">Support</Badge>
        BPZ CONSULT · Financial Experts — bpzconsults@gmail.com · +233 53 898 1062 · +233 54 717 9469 · +233 24 341 8400
      </div>
    </>
  );
}
