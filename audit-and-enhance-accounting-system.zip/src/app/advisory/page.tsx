import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { workTemplates, engagements as engTable, feeInvoices, clients } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { SERVICE_LINES, SERVICE_LINE_NAMES } from "@/data/sectors";
import { num, money } from "@/lib/format";
import { PageHeader, Card, EmptyState, Stat, tdCls, thCls, numCls, rowCls, Badge, ExportLink } from "@/components/ui";
import { EngagementEditor } from "@/components/adminforms";
import { RowAction } from "@/components/RowAction";
import { FeeButton } from "@/components/FeeButton";

export const dynamic = "force-dynamic";

export default async function AdvisoryPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const ws = await requireWorkspace();
  const isOwner = ws.user.role === "owner";
  const targetClientId = isOwner && sp.client ? Number(sp.client) : ws.client.id;

  const templates = await db.select().from(workTemplates);
  const allClients = await db.select().from(clients);
  const targetClient = allClients.find((c) => c.id === targetClientId);
  const serviceLines = (targetClient?.serviceLines ?? "bookkeeping,payroll,tax_compliance").split(",").filter(Boolean);

  const engList = await db
    .select()
    .from(engTable)
    .where(eq(engTable.clientId, targetClientId))
    .orderBy(desc(engTable.id))
    .limit(30);

  const fees = await db
    .select()
    .from(feeInvoices)
    .where(eq(feeInvoices.clientId, targetClientId))
    .orderBy(desc(feeInvoices.id))
    .limit(30);
  const feeOpen = fees.filter((f) => f.status === "open").reduce((s, f) => s + Number(f.amount), 0);
  const feeCollected = fees.filter((f) => f.status === "paid").reduce((s, f) => s + Number(f.amount), 0);

  const firstTemplate = templates[0];
  const checklist = firstTemplate ? (JSON.parse(firstTemplate.checklist || "[]") as { type: "quant" | "qual"; label: string }[]) : [];

  const feeMap = Object.fromEntries(serviceLines.map((l) => [l, SERVICE_LINES.find((s) => s.code === l)?.defaultFee ?? 0]));

  return (
    <>
      <PageHeader
        kicker={`AD · BPZ Services · Advisory, Tax & Fees`}
        title="Advisory & Tax Services"
        desc="BPZ's service lines — bookkeeping, payroll, tax planning & preparation, IFRS reporting, audit support and sector specialist work. Quantitative + qualitative work templates per client and fiscal period, with fee billing."
      >
        <ExportLink sheet="fees" label="Export fees .xlsx" />
      </PageHeader>

      {isOwner && allClients.length > 1 && (
        <Card className="mb-4">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[12.5px] font-bold uppercase tracking-[0.16em] text-mist-500">Serving client</span>
            {allClients.map((c) => (
              <a
                key={c.id}
                href={`/advisory?client=${c.id}`}
                className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition ${
                  c.id === targetClientId ? "border-gold-400/60 bg-gold-400/10 text-gold-300" : "border-ink-600 text-mist-400 hover:text-mist-200"
                }`}
              >
                {c.code} · {c.name}
              </a>
            ))}
          </div>
        </Card>
      )}

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Service lines" value={serviceLines.length} sub={targetClient?.name ?? ws.client.name} />
        <Stat label="Workpapers" value={engList.length} sub="This client, all periods" />
        <Stat label="Fees outstanding" value={money(feeOpen)} tone={feeOpen > 0 ? "text-aa" : undefined} sub="Open BPZ fee invoices" />
        <Stat label="Fees collected" value={money(feeCollected)} tone="text-pos" sub="All periods" />
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <div className="space-y-4">
          <EngagementEditor
            serviceLineOptions={SERVICE_LINES.filter((s) => serviceLines.includes(s.code)).map((s) => ({ value: s.code, label: s.name }))}
            template="Workpaper"
            checklist={checklist}
          />
          <Card title="Service Line Catalogue" sub="BPZ standard fees (GHS/month) — used when billing clients">
            <div className="space-y-1.5">
              {SERVICE_LINES.map((s) => (
                <div key={s.code} className="flex items-center gap-3 text-[12.5px]">
                  <span className="min-w-0 flex-1 truncate text-mist-300">
                    {s.name}
                    <span className="ml-2 text-[12px] text-mist-600">{s.blurb}</span>
                  </span>
                  <span className="font-mono text-[12px] text-gold-300">₵{num(s.defaultFee)}</span>
                  {serviceLines.includes(s.code) && <Badge tone="green">active</Badge>}
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Engagement Register" sub="Workpapers by period — in progress → review → signed off" pad={false}>
            {engList.length === 0 ? (
              <div className="p-4">
                <EmptyState icon="doc" title="No workpapers yet" body="Save the first workpaper on the left — it registers here with its period and status." />
              </div>
            ) : (
              <div className="max-h-[400px] overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Service line</th>
                      <th className={thCls}>Period</th>
                      <th className={thCls}>Status</th>
                      <th className={thCls}>Updated by</th>
                    </tr>
                  </thead>
                  <tbody>
                    {engList.map((e) => (
                      <tr key={e.id} className={rowCls}>
                        <td className={tdCls}><span className="text-[12.5px]">{SERVICE_LINE_NAMES[e.serviceLine] ?? e.serviceLine}</span></td>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{e.period || "—"}</span></td>
                        <td className={tdCls}><Badge tone={e.status === "signed_off" ? "green" : e.status === "review" ? "amber" : "slate"}>{e.status.replace("_", " ")}</Badge></td>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{e.updatedBy}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card
            title="BPZ Fee Billing"
            sub="Monthly fees per assigned service line — generate, then collect (posts 101000 Dr / 410000 Cr)"
            pad={false}
            action={<FeeButton clientId={targetClientId} feeMap={feeMap} />}
          >
            {fees.length === 0 ? (
              <p className="p-4 text-sm text-mist-500">No fee invoices yet — generate this month's fees.</p>
            ) : (
              <div className="max-h-[320px] overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Service line</th>
                      <th className={thCls}>Period</th>
                      <th className={thCls + " text-right"}>Amount</th>
                      <th className={thCls}>Status</th>
                      <th className={thCls + " text-right"}>Collect</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fees.map((f) => (
                      <tr key={f.id} className={rowCls}>
                        <td className={tdCls}><span className="text-[12.5px]">{SERVICE_LINE_NAMES[f.serviceLine] ?? f.serviceLine}</span></td>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{f.period}</span></td>
                        <td className={numCls + " font-semibold"}>{num(Number(f.amount))}</td>
                        <td className={tdCls}><Badge tone={f.status === "paid" ? "green" : "amber"}>{f.status}</Badge></td>
                        <td className={tdCls}>
                          <div className="flex justify-end">
                            {f.status === "open" && (
                              <RowAction action="collect_fee" payload={{ feeId: f.id, period: f.period }} label="Collect" tone="gold" user="bpz" />
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
