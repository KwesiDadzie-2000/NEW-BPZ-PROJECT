import { requireWorkspace } from "@/lib/auth";
import { recentErrors, clearErrors } from "@/lib/observability";
import { PageHeader, Card, Stat, Badge, tdCls, thCls, rowCls, btn } from "@/components/ui";
import { ClearErrors } from "@/components/ClearErrors";

export const dynamic = "force-dynamic";

export default async function DiagnosticsPage() {
  const ws = await requireWorkspace();
  const isOwner = ws.user.role === "owner";
  const all = await recentErrors(60);
  const errors = isOwner ? all : all.filter((e) => e.clientId === ws.client.id);
  const last24h = errors.filter((e) => Date.now() - new Date(e.at).getTime() < 86_400_000).length;
  const affected = new Set(errors.map((e) => e.action).filter(Boolean)).size;

  return (
    <>
      <PageHeader
        kicker="ADM · Reliability"
        title="Diagnostics"
        desc="Retained server errors with their workspace, action, user and stack. Nothing fails silently — an unexpected error is recorded here and in the server log, so it can be diagnosed instead of surfacing as a blank response."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Retained errors" value={errors.length} sub={isOwner ? "All workspaces (owner view)" : "This workspace"} tone={errors.length ? "text-neg" : "text-pos"} />
        <Stat label="Last 24 hours" value={last24h} sub={last24h ? "Investigate" : "No recent failures"} tone={last24h ? "text-aa" : "text-pos"} />
        <Stat label="Affected actions" value={affected} sub="Distinct failing operations" />
        <Stat label="Retention" value="60 events" sub="Newest first, stack included" />
      </div>

      <Card
        title="Error log"
        sub="Validation failures are not listed here — only unexpected defects, which is what needs attention"
        pad={false}
        action={isOwner && errors.length > 0 ? <ClearErrors /> : undefined}
      >
        {errors.length === 0 ? (
          <p className="p-6 text-center text-sm text-mist-500">
            No unexpected errors recorded. When something breaks in production, it appears here with enough detail to
            diagnose it.
          </p>
        ) : (
          <div className="max-h-[600px] overflow-auto">
            <table className="w-full min-w-[880px]">
              <thead className="sticky top-0 bg-ink-850">
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>When</th>
                  <th className={thCls}>Workspace</th>
                  <th className={thCls}>User</th>
                  <th className={thCls}>Action</th>
                  <th className={thCls}>Message</th>
                </tr>
              </thead>
              <tbody>
                {errors.map((e) => (
                  <tr key={e.id} className={rowCls}>
                    <td className={tdCls}>
                      <span className="font-mono text-[12px] text-mist-400">
                        {new Date(e.at).toLocaleString("en-GB", { hour12: false })}
                      </span>
                    </td>
                    <td className={tdCls}><Badge tone="slate">{e.workspace || "—"}</Badge></td>
                    <td className={tdCls}><span className="font-mono text-[12px] text-mist-300">{e.username || "—"}</span></td>
                    <td className={tdCls}><span className="font-mono text-[12px] text-gold-300">{e.action || "—"}</span></td>
                    <td className={tdCls}>
                      <span className="block max-w-[420px] truncate text-[12.5px] text-mist-300" title={e.stack}>
                        {e.message}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
