import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { payrollRuns, payOverrides } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { listEmployees } from "@/lib/employees";
import { JURISDICTIONS } from "@/data/jurisdictions";
import { masterData, trialBalance } from "@/lib/reports";
import { ensureJurisdictions } from "@/lib/employees";
import { money, num } from "@/lib/format";
import { thisPeriod } from "@/lib/periods";
import { PageHeader, Stat, Card, ExportLink, EmptyState, tdCls, thCls, numCls, rowCls, Badge, btn, Icon } from "@/components/ui";
import { EmployeeManager } from "@/components/EmployeeManager";
import { ModuleHistory } from "@/components/ModuleHistory";
import { RowAction } from "@/components/RowAction";

export const dynamic = "force-dynamic";

export default async function PayrollPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = thisPeriod();

  await ensureJurisdictions();
  const staff = await listEmployees(clientId);
  const active = staff.filter((e) => e.status === "active");
  const { ccs } = await masterData(ws.client.id);
  const { rows: tb } = await trialBalance(clientId);

  const runs = await db
    .select()
    .from(payrollRuns)
    .where(eq(payrollRuns.clientId, clientId))
    .orderBy(desc(payrollRuns.id))
    .limit(50);

  const overrides = await db.select().from(payOverrides).where(eq(payOverrides.clientId, clientId));
  const basicByEmp = new Map<string, number>();
  for (const o of overrides.sort((a, b) => b.period.localeCompare(a.period))) {
    if (!basicByEmp.has(o.bpNo)) basicByEmp.set(o.bpNo, Number(o.basic));
  }

  const wageBill = active.reduce((s, e) => s + e.basicSalary + e.allowances, 0);
  const outstanding = -(tb.find((r) => r.account === "205000")?.bal ?? 0);
  const payrollExp = tb.find((r) => r.account === "510000")?.bal ?? 0;
  const jurisdictions = [...new Set(active.map((e) => e.jurisdiction))];

  return (
    <>
      <PageHeader
        kicker={`HR · Payroll Desk · ${ws.client.code}`}
        title="Payroll Desk"
        desc="A full employee master you can grow at any time. Each employee carries their own jurisdiction, currency, salary and statutory numbers — Ghana uses the complete statutory scheme (PAYE bands effective 1 Sep 2026, SSNIT T1/T2, NHIL, housing); other jurisdictions use their own configured bands and rates. Run payroll per employee or in a single batch, with partial or full net-pay release."
      >
        <ExportLink sheet="payroll" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Employees on payroll" value={active.length} sub={`${staff.length - active.length} inactive / former`} />
        <Stat label="Monthly wage bill" value={money(wageBill)} sub="Basic + allowances, active staff" />
        <Stat label="Net pay outstanding" value={money(outstanding)} sub="205000 salaries payable" tone={outstanding > 0 ? "text-gold-300" : undefined} />
        <Stat label="Salaries expense" value={money(payrollExp)} sub="510000, all periods" />
      </div>

      {jurisdictions.length > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-ink-700 bg-ink-850/70 px-4 py-3">
          <span className="text-[12.5px] font-bold uppercase tracking-[0.16em] text-mist-500">Jurisdictions on this payroll</span>
          {jurisdictions.map((j) => (
            <Badge key={j} tone="gold">
              {JURISDICTIONS.find((x) => x.code === j)?.name ?? j} · {JURISDICTIONS.find((x) => x.code === j)?.payrollScheme === "ghana" ? "full statutory" : "configured bands"}
            </Badge>
          ))}
        </div>
      )}

      <EmployeeManager
        employees={staff}
        jurisdictionOptions={JURISDICTIONS.filter((j) => j.code !== "ZA-X").map((j) => ({ value: j.code, label: `${j.name} (${j.currency})` }))}
        ccOptions={ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }))}
      />

      <Card
        className="mt-4"
        title={`Run Payroll — ${period}`}
        sub="Per employee, or all active staff in one batch. Salaries pre-fill from the employee master."
        action={
          active.length > 0 ? (
            <RowAction action="run_batch_payroll" payload={{ period }} label={`Batch run all ${active.length}`} tone="gold" user="hr_user" />
          ) : null
        }
      >
        {active.length === 0 ? (
          <EmptyState icon="users" title="No active employees" body="Add employees to the payroll master above — then run payroll for one or all of them." />
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {active.map((e) => {
              const basic = basicByEmp.get(e.code) ?? e.basicSalary;
              return (
                <div key={e.id} className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[12.5px] font-bold text-gold-300">{e.code}</span>
                    <span className="min-w-0 flex-1 truncate text-[13px] font-semibold text-mist-100">{e.name}</span>
                  </div>
                  <div className="mt-0.5 text-[12.5px] text-mist-500">
                    {e.position || "—"} · {e.jurisdiction} · basic {num(basic)} {e.currency}
                  </div>
                  <div className="mt-2">
                    <RowAction
                      action="run_payroll"
                      payload={{ employeeId: e.id, period }}
                      label="Run payroll"
                      tone="gold"
                      user="hr_user"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      <Card className="mt-4" title="Payroll Runs" sub="Statutory breakdown per run — release net pay fully or partially from the bank" pad={false}>
        {runs.length === 0 ? (
          <div className="p-4"><EmptyState icon="users" title="No payroll runs yet" body="Run payroll above — the engine computes tax and social contributions, then posts the balanced journal entry." /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1040px]">
              <thead>
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>Period</th>
                  <th className={thCls}>Employee</th>
                  <th className={thCls + " text-right"}>Basic</th>
                  <th className={thCls + " text-right"}>Gross</th>
                  <th className={thCls + " text-right"}>Income tax</th>
                  <th className={thCls + " text-right"}>Pension/SSNIT</th>
                  <th className={thCls + " text-right"}>Other</th>
                  <th className={thCls + " text-right"}>Net</th>
                  <th className={thCls + " text-right"}>Employer</th>
                  <th className={thCls}>Status</th>
                  <th className={thCls + " text-right"}>Action</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((r) => {
                  const paid = Number(r.paid);
                  const net = Number(r.net);
                  return (
                    <tr key={r.id} className={rowCls}>
                      <td className={tdCls}><span className="font-mono text-[12px] text-mist-400">{r.period}</span></td>
                      <td className={tdCls}>
                        <span className="font-mono text-[12.5px] font-semibold text-mist-100">{r.bpNo}</span>
                        <div className="mt-0.5 font-mono text-[12px] text-mist-600">doc {r.docNo}</div>
                      </td>
                      <td className={numCls}>{num(Number(r.basic))}</td>
                      <td className={numCls}>{num(Number(r.gross))}</td>
                      <td className={numCls + " text-neg"}>{num(Number(r.paye))}</td>
                      <td className={numCls + " text-neg"}>{num(Number(r.ssnitT1))}</td>
                      <td className={numCls + " text-neg"}>{num(Number(r.nhil))}</td>
                      <td className={numCls + " font-semibold text-pos"}>{num(net)}</td>
                      <td className={numCls + " text-gold-300"}>{num(Number(r.employerCost))}</td>
                      <td className={tdCls}>
                        {paid >= net - 0.009 ? <Badge tone="green">Paid</Badge> : paid > 0 ? <Badge tone="amber">Part {num(paid)}</Badge> : <Badge tone="slate">Outstanding</Badge>}
                      </td>
                      <td className={tdCls}>
                        <div className="flex justify-end">
                          {paid < net - 0.009 && (
                            <RowAction action="pay_payroll" payload={{ runId: r.id, period: r.period }} label={`Pay ${num(net - paid)}`} tone="gold" user="hr_user" />
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <div className="mt-4">
        <ModuleHistory clientId={clientId} module="HR" title="Payroll Journal Lines" sub="All payroll postings in the Universal Journal" />
      </div>
    </>
  );
}
