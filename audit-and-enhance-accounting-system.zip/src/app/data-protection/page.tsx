import { requireWorkspace } from "@/lib/auth";
import { listBackups } from "@/lib/backup";
import { db } from "@/db";
import { journalLines } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { fmtDate } from "@/lib/format";
import { PageHeader, Card, Stat, Badge, rowCls, tdCls, thCls, btn, Icon } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function DataProtectionPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const backups = await listBackups(ws.user.role === "owner" ? null : clientId, 25);
  const docs = (await db.select({ n: sql<number>`count(distinct doc_no)::int` }).from(journalLines).where(eq(journalLines.clientId, clientId)))[0]?.n ?? 0;
  const lines = (await db.select({ n: sql<number>`count(*)::int` }).from(journalLines).where(eq(journalLines.clientId, clientId)))[0]?.n ?? 0;
  const last = backups[0];
  const ageH = last ? (Date.now() - new Date(last.takenAt).getTime()) / 3_600_000 : null;

  return (
    <>
      <PageHeader
        kicker="ADM · Data protection"
        title="Backups & Data Safety"
        desc="Downloadable restore points for every workspace. A snapshot captures the complete books, payroll, banking, assets, invoices, budgets and the statutory configuration — everything needed to reconstruct the ledger."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat
          label="Last snapshot"
          value={last ? fmtDate(last.takenAt.slice(0, 10)) : "Never"}
          sub={ageH === null ? "Take one now to establish a baseline" : `${ageH.toFixed(1)} hours ago`}
          tone={ageH === null ? "text-neg" : ageH > 168 ? "text-aa" : "text-pos"}
        />
        <Stat label="Journal lines protected" value={lines.toLocaleString()} sub={`${docs} documents in this workspace`} />
        <Stat label="Snapshots retained" value={backups.length} sub="Register kept permanently" />
        <Stat label="Scope" value={ws.client.code} sub="Workspace + shared reference data" />
      </div>

      <Card
        title="Take a restore point"
        sub="Downloads a complete, human-readable JSON snapshot and records it in the backup register"
        action={
          <a className={btn.gold} href="/api/assurance?mode=snapshot">
            <Icon name="download" size={15} /> Download snapshot now
          </a>
        }
      >
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-lg border border-ink-700 bg-ink-900/50 p-3">
            <div className="text-[12px] font-bold text-mist-200">What a snapshot contains</div>
            <ul className="mt-1.5 space-y-1 text-[12px] leading-relaxed text-mist-500">
              <li>• Universal Journal (every document and line)</li>
              <li>• Invoices, quotes, credit/debit notes and settlement state</li>
              <li>• Payroll runs and the full employee master</li>
              <li>• Fixed-asset register with cost, accumulated depreciation and NBV</li>
              <li>• Bank accounts and imported statement lines</li>
              <li>• Budgets, scenarios, contracts and production orders</li>
              <li>• Fiscal-period lock state and the statutory rate tables</li>
            </ul>
          </div>
          <div className="rounded-lg border border-ink-700 bg-ink-900/50 p-3">
            <div className="text-[12px] font-bold text-mist-200">What is deliberately excluded</div>
            <ul className="mt-1.5 space-y-1 text-[12px] leading-relaxed text-mist-500">
              <li>• Password hashes and session tokens</li>
              <li>• TOTP secrets</li>
              <li>• Login attempt records</li>
            </ul>
            <div className="mt-3 rounded-lg border border-aa/30 bg-aa/10 px-3 py-2 text-[12.5px] leading-relaxed text-aa">
              Snapshots are for restore and client hand-over. For full disaster recovery the hosting
              database must also run scheduled server-side backups with point-in-time recovery — confirm
              this with whoever operates the infrastructure before going live with client data.
            </div>
          </div>
        </div>
      </Card>

      <Card className="mt-4" title="Backup register" sub="Evidence of data protection — every snapshot is logged and exportable" pad={false}>
        {backups.length === 0 ? (
          <p className="p-6 text-center text-sm text-mist-500">
            No snapshot has been taken yet. Download one above — it takes a second and gives you an immediate restore point.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px]">
              <thead>
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>When</th>
                  <th className={thCls}>Workspace</th>
                  <th className={thCls}>Scope</th>
                  <th className={thCls + " text-right"}>Journal docs</th>
                  <th className={thCls + " text-right"}>Size</th>
                  <th className={thCls}>Taken by</th>
                </tr>
              </thead>
              <tbody>
                {backups.map((b) => (
                  <tr key={b.id} className={rowCls}>
                    <td className={tdCls}>
                      <span className="font-mono text-[12.5px] text-mist-400">
                        {new Date(b.takenAt).toLocaleString("en-GB", { hour12: false })}
                      </span>
                    </td>
                    <td className={tdCls}><Badge tone="slate">{b.clientId ?? "—"}</Badge></td>
                    <td className={tdCls}><span className="text-[12.5px] capitalize">{b.scope}</span></td>
                    <td className={tdCls + " text-right font-mono text-[12px]"}>{b.docs}</td>
                    <td className={tdCls + " text-right font-mono text-[12px]"}>{Math.round((b.sizeBytes || 0) / 1024)} KB</td>
                    <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{b.takenBy}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
