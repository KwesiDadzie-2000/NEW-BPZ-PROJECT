import type { ReactNode } from "react";
import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import {
  trialBalance, byModule, byCostCenter, pnl, balanceSheet, cashFlow,
  statementOfChangesInEquity, aging, bpActivity, bpLedger, journalRows, stockValuation,
  type TbRow,
} from "@/lib/reports";
import { money, num, fmtDate } from "@/lib/format";
import {
  PageHeader, Card, ModuleTag, Badge, ExportLink, EmptyState, Icon, btn, inputCls, Field,
  tdCls, thCls, numCls, rowCls, cn,
} from "@/components/ui";

export const dynamic = "force-dynamic";

const TABS = [
  { id: "tb", label: "Trial Balance", sheet: "trial_balance" },
  { id: "pnl", label: "Profit & Loss", sheet: "pnl" },
  { id: "bs", label: "Balance Sheet", sheet: "balance_sheet" },
  { id: "cf", label: "Cash Flow (IAS 7)", sheet: "cash_flow" },
  { id: "soce", label: "Changes in Equity", sheet: "soce" },
  { id: "module", label: "By Module", sheet: "by_module" },
  { id: "cc", label: "Cost Centers", sheet: "by_cost_center" },
  { id: "ap", label: "AP Aging", sheet: "aging_ap" },
  { id: "ar", label: "AR Aging", sheet: "aging_ar" },
  { id: "stock", label: "Stock Valuation", sheet: "stock" },
  { id: "bp", label: "BP Ledger", sheet: "journal" },
  { id: "audit", label: "Audit Trail", sheet: "journal" },
] as const;
type TabId = (typeof TABS)[number]["id"];

function SectionTable({ title, rows, tone }: { title: string; rows: TbRow[]; tone?: "rev" | "exp" }) {
  return (
    <div>
      <div className="mb-2">
        <span className="text-[12.5px] font-bold uppercase tracking-[0.16em] text-mist-500">{title}</span>
      </div>
      <table className="w-full">
        <tbody>
          {rows.map((r) => (
            <tr key={r.account} className={rowCls}>
              <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{r.account}</span></td>
              <td className={tdCls}><span className="block max-w-[320px] truncate text-[13px]">{r.description}</span></td>
              <td className={cn(numCls, tone === "rev" ? "text-pos" : tone === "exp" ? "text-neg" : "text-mist-100")}>{num(r.bal)}</td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td className={tdCls + " text-mist-600"} colSpan={3}>No postings on {title.toLowerCase()} accounts in this period.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

function MiniTable({ head, rows }: { head: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px]">
        <thead>
          <tr className="border-b border-ink-700/70">
            {head.map((h, i) => (
              <th key={h + i} className={cn(thCls, i > 2 && "text-right")}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 && (
            <tr>
              <td className={tdCls + " text-mist-600"} colSpan={head.length}>No data in this period.</td>
            </tr>
          )}
          {rows.map((r, i) => (
            <tr key={i} className={rowCls}>
              {r.map((c, j) => (
                <td key={j} className={cn(tdCls, j > 2 && "text-right font-mono text-[12.5px] tabular-nums")}>{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default async function ReportsPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const rawTab = typeof sp.t === "string" ? sp.t : "tb";
  const tab: TabId = (TABS.some((x) => x.id === rawTab) ? rawTab : "tb") as TabId;
  const bp = typeof sp.bp === "string" && sp.bp ? sp.bp : undefined;
  const from = typeof sp.from === "string" && sp.from ? sp.from : undefined;
  const to = typeof sp.to === "string" && sp.to ? sp.to : undefined;
  const activeTab = TABS.find((t) => t.id === tab)!;

  const ws = await requireWorkspace();
  const clientId = ws.client.id;

  let content: ReactNode = null;

  if (tab === "tb") {
    const tb = await trialBalance(clientId, from, to);
    content = (
      <Card title={`Trial Balance · ${ws.client.name}`} sub={`Fiscal period ${from ?? "start"} → ${to ?? "now"}`} pad={false}
        action={<Badge tone={tb.balanced ? "green" : "red"}><Icon name={tb.balanced ? "check" : "x"} size={11} />{tb.balanced ? "Balanced" : "Out of balance"}</Badge>}>
        <MiniTable
          head={["Account", "Description", "Type", "Total Dr", "Total Cr", "Balance"]}
          rows={[
            ...tb.rows.map((r) => [r.account, r.description, r.type, num(r.dr), num(r.cr), num(r.bal)]),
            ["", "TOTALS", "", num(tb.totalDr), num(tb.totalCr), num(tb.totalDr - tb.totalCr)],
          ]}
        />
      </Card>
    );
  }

  if (tab === "pnl") {
    const p = await pnl(clientId, from, to);
    content = (
      <Card title={`Statement of Profit or Loss and Other Comprehensive Income · ${ws.client.name}`} sub="IFRS 1 / IAS 8 presentation" pad={false}
        action={<span className={cn("font-mono text-sm font-semibold tabular-nums", p.net >= 0 ? "text-pos" : "text-neg")}>Net {p.net >= 0 ? "+" : ""}{money(p.net)}</span>}>
        <div className="space-y-6 overflow-x-auto">
          <SectionTable title="Revenue" rows={p.revenue} tone="rev" />
          <div className="flex justify-between rounded-lg border border-ink-700 bg-ink-900/60 px-3 py-2 text-sm">
            <span className="font-semibold">Total revenue</span>
            <span className="font-mono tabular-nums text-pos">{money(p.totalRev)}</span>
          </div>
          <SectionTable title="Expenses" rows={p.expense} tone="exp" />
          <div className="flex justify-between rounded-lg border border-ink-700 bg-ink-900/60 px-3 py-2 text-sm">
            <span className="font-semibold">Total expenses</span>
            <span className="font-mono tabular-nums text-neg">{money(p.totalExp)}</span>
          </div>
          <div className={cn("flex items-center justify-between rounded-lg border px-4 py-3", p.net >= 0 ? "border-pos/40 bg-pos/10" : "border-neg/40 bg-neg/10")}>
            <span className="font-display text-sm font-bold uppercase tracking-[0.14em] text-mist-100">Net {p.net >= 0 ? "profit" : "loss"}</span>
            <span className={cn("font-mono text-lg font-semibold tabular-nums", p.net >= 0 ? "text-pos" : "text-neg")}>{money(p.net)}</span>
          </div>
        </div>
      </Card>
    );
  }

  if (tab === "bs") {
    const b = await balanceSheet(clientId, from, to);
    content = (
      <Card title={`Statement of Financial Position · ${ws.client.name}`} sub="IFRS 1 — current / non-current split per the chart" pad={false}
        action={<Badge tone={b.balanced ? "green" : "red"}><Icon name={b.balanced ? "check" : "x"} size={11} />{b.balanced ? "Balances to" : "Does not balance"}</Badge>}>
        <div className="space-y-6 overflow-x-auto">
          <SectionTable title="Assets" rows={b.assets} />
          <div className="flex justify-between rounded-lg border border-ink-700 bg-ink-900/60 px-3 py-2 text-sm">
            <span className="font-semibold">Total assets</span>
            <span className="font-mono tabular-nums text-mist-100">{money(b.tAssets)}</span>
          </div>
          <SectionTable title="Liabilities" rows={b.liab.map((r) => ({ ...r, bal: -r.bal }))} />
          <SectionTable title="Equity" rows={b.equity.map((r) => ({ ...r, bal: -r.bal }))} />
          <div className="flex justify-between rounded-lg border border-ink-700 bg-ink-900/60 px-3 py-2 text-sm">
            <span className="font-semibold">Add: net profit / (loss) for the period</span>
            <span className={cn("font-mono tabular-nums", b.net >= 0 ? "text-pos" : "text-neg")}>{money(b.net)}</span>
          </div>
          <div className="flex justify-between rounded-lg border border-ink-700 bg-ink-900/60 px-3 py-2 text-sm">
            <span className="font-semibold">Total liabilities + equity</span>
            <span className="font-mono tabular-nums text-mist-100">{money(b.tLiabEqNet)}</span>
          </div>
        </div>
      </Card>
    );
  }

  if (tab === "cf") {
    const cf = await cashFlow(clientId, from, to);
    content = (
      <Card title={`Statement of Cash Flows (indirect method) · ${ws.client.name}`} sub="IAS 7 — operating / investing / financing" pad={false}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px]">
            <tbody>
              {[
                ...cf.operatingLines.map((l) => [l.label, num(l.v)] as [string, string]),
                ["Cash generated from operations", num(cf.operating)],
                ...cf.investingLines.map((l) => [l.label, num(l.v)] as [string, string]),
                ...cf.financingLines.map((l) => [l.label, num(l.v)] as [string, string]),
                ["Net increase / (decrease) in cash", num(cf.change)],
                ["Cash and equivalents at start of period", num(cf.cashOpen)],
                ["Cash and equivalents at end of period", num(cf.cashClose)],
              ].map(([label, v], i) => (
                <tr key={i} className={rowCls}>
                  <td className={cn(tdCls, label.startsWith("Cash generated") || label.startsWith("Net increase") || label.startsWith("Cash and") ? "font-semibold text-mist-100" : "text-mist-400")}>{label}</td>
                  <td className={cn(numCls, "font-semibold")}>{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    );
  }

  if (tab === "soce") {
    const s = await statementOfChangesInEquity(clientId, from, to);
    content = (
      <Card title={`Statement of Changes in Equity · ${ws.client.name}`} sub="IFRS 1 / IAS 8" pad={false}>
        <MiniTable
          head={["Account", "Description", "Opening", "Movement", "Closing"]}
          rows={[
            ...s.rows.map((r) => [r.account, r.description, num(r.opening), num(r.movement), num(r.closing)]),
            ["", "Net profit / (loss) for the period", "", num(s.net), ""],
          ]}
        />
      </Card>
    );
  }

  if (tab === "module") {
    const rows = await byModule(clientId, from, to);
    content = (
      <Card title="Activity by Module" sub="Department-level volume in this workspace" pad={false}>
        <MiniTable head={["Module", "Documents", "Debits", "Credits"]} rows={rows.map((r) => [r.module, r.docs, num(r.dr), num(r.cr)])} />
      </Card>
    );
  }

  if (tab === "cc") {
    const rows = await byCostCenter(clientId, from, to);
    content = (
      <Card title="Cost Center Report (CO)" sub="Debit postings per department" pad={false}>
        <MiniTable head={["Code", "Name", "Debits", "Credits"]} rows={rows.map((r) => [r.cc, r.name, num(r.dr), num(r.cr)])} />
      </Card>
    );
  }

  if (tab === "ap" || tab === "ar") {
    const rows = await aging(clientId, tab === "ap" ? "AP" : "AR");
    content = (
      <Card title={tab === "ap" ? "Accounts Payable Aging" : "Accounts Receivable Aging"} sub="Open items bucketed by age (per line)" pad={false}>
        <MiniTable
          head={["BP", "Name", "Current", "1–30", "31–60", "61–90", ">90", "Total"]}
          rows={rows.map((r) => [r.bp, r.name, num(r.buckets[0]), num(r.buckets[1]), num(r.buckets[2]), num(r.buckets[3]), num(r.buckets[4]), num(r.total)])}
        />
      </Card>
    );
  }

  if (tab === "stock") {
    const rows = await stockValuation(clientId, from, to);
    const total = rows.reduce((s, r) => s + r.value, 0);
    content = (
      <Card title="Inventory Valuation (IAS 2)" sub="Book value from the Universal Journal; quantities from stock movements" pad={false}
        action={<span className="font-mono text-sm font-semibold text-gold-300">Total {money(total)}</span>}>
        <MiniTable
          head={["Material", "Description", "Type", "Qty", "Book value", "Std price"]}
          rows={rows.map((r) => [r.material, r.description, r.type, num(r.qty), num(r.value), num(r.stdPrice)])}
        />
      </Card>
    );
  }

  if (tab === "bp") {
    const activity = await bpActivity(clientId, from, to);
    if (bp) {
      const ledger = await bpLedger(clientId, bp, from, to);
      const name = activity.find((a) => a.bp === bp)?.name ?? bp;
      content = (
        <Card title={`Business Partner Ledger — ${name}`} sub="Running balance per document" pad={false}
          action={<span className={cn("font-mono text-sm font-semibold", ledger.total >= 0 ? "text-pos" : "text-neg")}>Balance {money(ledger.total)}</span>}>
          {ledger.lines.length === 0 ? (
            <div className="p-4"><EmptyState icon="doc" title="No activity" body={`Partner ${bp} has no lines in this period.`} /></div>
          ) : (
            <MiniTable
              head={["Doc", "Period", "Date", "Module", "Description", "Debit", "Credit", "Running"]}
              rows={ledger.lines.map((l) => [
                <Link key={l.id} href={`/universal-journal?doc=${l.docNo}`} className="font-mono text-gold-300 hover:underline">{l.docNo}</Link>,
                l.period, fmtDate(l.postDate), l.module, l.description, num(l.debit), num(l.credit), num(l.running),
              ])}
            />
          )}
        </Card>
      );
    } else {
      content = (
        <Card title="Business Partners" sub="Open a ledger" pad={false}>
          <MiniTable
            head={["BP", "Name", "Type", "Debits", "Credits", "Open balance"]}
            rows={activity.map((a) => [
              <Link key={a.bp} href={`/reports?t=bp&bp=${a.bp}${from ? `&from=${from}` : ""}${to ? `&to=${to}` : ""}`} className="font-mono text-gold-300 hover:underline">Open</Link>,
              a.bp + " · " + a.name, a.type, num(a.dr), num(a.cr), num(a.bal),
            ])}
          />
        </Card>
      );
    }
  }

  if (tab === "audit") {
    const rows = await journalRows({ clientId, from, to, limit: 300 });
    content = (
      <Card title="Audit Trail" sub="Every line with its origin — document, module, user" pad={false}>
        <MiniTable
          head={["Doc", "Period", "Date", "Module", "Posted by", "Account", "BP", "Description", "Debit", "Credit"]}
          rows={rows.map((r) => [
            <Link key={r.id} href={`/universal-journal?doc=${r.docNo}`} className="font-mono text-gold-300 hover:underline">{r.docNo}</Link>,
            r.period, fmtDate(r.postDate), r.module, r.createdBy, r.account, r.bp || "—", r.description, num(r.debit), num(r.credit),
          ])}
        />
      </Card>
    );
  }

  return (
    <>
      <PageHeader
        kicker={`Reporting · ${ws.client.code} · IFRS/IAS`}
        title="Financial Reports"
        desc="Periodic, computed live from the Universal Journal. Every statement follows IFRS/IAS presentation; export any workbook to Excel."
      >
        <ExportLink sheet={activeTab.sheet} label="Export .xlsx" />
      </PageHeader>

      <Card className="mb-4">
        <form method="GET" action="/reports" className="grid gap-3 md:grid-cols-4">
          <input type="hidden" name="t" value={tab} />
          {bp && <input type="hidden" name="bp" value={bp} />}
          <Field label="From period (month)">
            <input type="month" name="from" defaultValue={from ?? ""} className={inputCls + " font-mono text-xs"} />
          </Field>
          <Field label="To period (month)">
            <input type="month" name="to" defaultValue={to ?? ""} className={inputCls + " font-mono text-xs"} />
          </Field>
          <div className="flex items-end">
            <button type="submit" className={btn.gold}><Icon name="search" size={15} /> Apply period</button>
          </div>
          <div className="flex items-end">
            <Link href={`/reports?t=${tab}`} className={btn.ghost}>Full history</Link>
          </div>
        </form>
      </Card>

      <div className="mb-4 flex flex-wrap gap-1.5 rounded-xl border border-ink-700 bg-ink-850/60 p-1.5">
        {TABS.map((t) => (
          <Link
            key={t.id}
            href={`/reports?t=${t.id}${bp && t.id === "bp" ? `&bp=${bp}` : ""}${from ? `&from=${from}` : ""}${to ? `&to=${to}` : ""}`}
            className={cn("rounded-lg px-3 py-1.5 text-xs font-semibold transition", t.id === tab ? "bg-gold-400 text-brand-navy" : "text-mist-400 hover:bg-ink-800 hover:text-mist-100")}
          >
            {t.label}
          </Link>
        ))}
      </div>

      {content}
    </>
  );
}
