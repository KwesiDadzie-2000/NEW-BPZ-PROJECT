import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { TermsAccept } from "@/components/TermsAccept";

export const dynamic = "force-dynamic";

export default async function AcceptTermsPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.termsAccepted) redirect("/");

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4 py-10">
      <div className="w-full max-w-2xl">
      <div className="mb-6 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold-400 font-display text-[14px] font-extrabold text-brand-navy">
          BPZ
        </span>
        <span>
          <span className="block font-display text-lg font-extrabold tracking-[0.03em] text-mist-100">BPZ CONSULT</span>
          <span className="block text-[12px] font-semibold uppercase tracking-[0.2em] text-gold-400">Financial Experts</span>
        </span>
      </div>
        <TermsAccept name={user.name} role={user.role} />
      </div>
    </div>
  );
}
