import pg from "pg";
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db" });
const q = (sql, params = []) => pool.query(sql, params);

async function main() {
  const { rows: clients } = await q(`SELECT id, code FROM clients`);
  const byCode = Object.fromEntries(clients.map((c) => [c.code, c.id]));
  console.log("clients", byCode);

  await q(`INSERT INTO groups (code, name, parent_client_id, reporting_currency)
    VALUES ('GRP-BPZ', 'BPZ Group', $1, 'GHS') ON CONFLICT (code) DO NOTHING`, [byCode.HQ || 1]);
  const { rows: gs } = await q(`SELECT id FROM groups WHERE code='GRP-BPZ'`);
  const gid = gs[0]?.id;
  if (gid) {
    for (const [code, pct, method] of [["HQ",100,"full"],["CLI-DEMO",100,"full"],["CLI-SUB1",80,"full"],["CLI-SUB2",40,"equity"]]) {
      if (!byCode[code]) continue;
      await q(`INSERT INTO group_members (group_id, client_id, ownership_pct, method, nci_share, goodwill, active)
        VALUES ($1,$2,$3,$4,$5,$6,true) ON CONFLICT DO NOTHING`,
        [gid, byCode[code], pct, method, method==="full"?100-pct:0, code==="CLI-SUB1"?50000:0]);
    }
    if (byCode["CLI-SUB1"] && byCode.HQ) {
      await q(`INSERT INTO intercompany_links (group_id, from_client_id, to_client_id, nature, from_account, to_account, amount, period)
        VALUES ($1,$2,$3,'trade','110000','200000',25000,'2026-03')`, [gid, byCode["CLI-SUB1"], byCode.HQ]);
    }
  }

  const demoId = byCode["CLI-DEMO"] || byCode.HQ;
  const { rows: jl } = await q(`SELECT count(*)::int AS c FROM journal_lines WHERE client_id=$1`, [demoId]);
  if ((jl[0]?.c || 0) < 5) {
    const doc = `SIM-DEMO`;
    const lines = [
      ["110000", 50000, 0, "Trade receivables"],
      ["400000", 0, 50000, "Sales revenue"],
      ["500000", 20000, 0, "Cost of sales"],
      ["120000", 15000, 0, "Inventories"],
      ["101000", 0, 15000, "Bank"],
      ["130000", 100000, 0, "PPE - cost"],
      ["101000", 0, 100000, "Bank PPE"],
      ["550000", 2000, 0, "Depreciation"],
      ["139000", 0, 2000, "Accumulated depreciation"],
      ["540000", 8000, 0, "Staff costs"],
      ["210000", 0, 8000, "Statutory payables"],
      ["101000", 30000, 0, "Cash from customers"],
      ["110000", 0, 30000, "AR settlement"],
    ];
    for (const [acc, dr, cr, desc] of lines) {
      await q(`INSERT INTO journal_lines (client_id, period, doc_no, post_date, module, doc_type, account, description, debit, credit, created_by, reference)
        VALUES ($1,'2026-03',$2,'2026-03-15','SIM','SA',$3,$4,$5,$6,'owner',$2)`, [demoId, doc, acc, desc, dr, cr]);
    }
    // balanced? check
    console.log("journal lines inserted for demo", demoId);
  }

  // Also seed HQ lightly
  const hq = byCode.HQ;
  if (hq) {
    const { rows: hjl } = await q(`SELECT count(*)::int AS c FROM journal_lines WHERE client_id=$1`, [hq]);
    if ((hjl[0]?.c || 0) < 3) {
      const doc = "SIM-HQ";
      for (const [acc, dr, cr, desc] of [["101000",200000,0,"HQ cash"],["300000",0,200000,"Share capital"]]) {
        await q(`INSERT INTO journal_lines (client_id, period, doc_no, post_date, module, doc_type, account, description, debit, credit, created_by, reference)
          VALUES ($1,'2026-03',$2,'2026-03-01','SIM','SA',$3,$4,$5,$6,'owner',$2)`, [hq, doc, acc, desc, dr, cr]);
      }
    }
  }

  await q(`INSERT INTO provisions (client_id, code, title, category, best_estimate, probability, present_value, carrying_amount, added, period, status, notes, created_by)
    VALUES ($1,'PROV-LEGAL','Customer claim','legal',30000,70,30000,30000,30000,'2026-03','recognised','Simulated IAS 37','owner')
    ON CONFLICT DO NOTHING`, [demoId]).catch(e=>console.log(e.message));

  await q(`INSERT INTO operating_segments (client_id, code, name, external_revenue, segment_profit, segment_assets, period, active)
    VALUES ($1,'SEG-TRADE','Trading',50000,28000,165000,'2026-03',true) ON CONFLICT DO NOTHING`, [demoId]).catch(e=>console.log(e.message));

  await q(`INSERT INTO related_parties (client_id, code, name, relationship, control_pct, nature, active)
    VALUES ($1,'RP-HOLD','BPZ Holdings','parent',100,'Ultimate parent',true) ON CONFLICT DO NOTHING`, [demoId]).catch(e=>console.log(e.message));

  await q(`INSERT INTO share_capital (client_id, class_name, par_value, authorised_shares, issued_shares, paid_up_capital, period)
    VALUES ($1,'Ordinary',1,1000000,500000,500000,'2026-03')`, [demoId]).catch(e=>console.log(e.message));

  await q(`INSERT INTO sso_providers (name, protocol, enabled, issuer, authorization_url, default_role, allowed_domains)
    VALUES ('Enterprise OIDC (Big Four IdP)','oidc',true,'https://login.microsoftonline.com/lab/v2.0','https://login.microsoftonline.com/lab/oauth2/v2.0/authorize','accountant','firm.com')
    ON CONFLICT DO NOTHING`).catch(e=>console.log('sso', e.message));

  await q(`INSERT INTO soc_evidence (category, title, detail, status, taken_by)
    VALUES ('backup','Simulation evidence','Big Four walkthrough seed','pass','simulate')`).catch(e=>console.log(e.message));

  console.log("simulation complete");
  await pool.end();
}
main().catch(e=>{console.error(e); process.exit(1);});
