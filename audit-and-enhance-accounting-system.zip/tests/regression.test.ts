/**
 * Regression suite.
 *
 * Every test here corresponds to a bug that was found by manual probing during
 * development and then fixed. If any of these fail, a fix has regressed.
 *
 *   npm test              — run once
 *   npm run test:watch    — watch mode
 */

import { describe, it, expect } from "vitest";
import { computePaye, listPayeBands, type PayeBand } from "../src/lib/tax";
import { passwordProblem, verifyTotp, generateSecret } from "../src/lib/totp";
import { hashPassword, verifyPassword } from "../src/lib/password";
import { generateRecoveryCode, consumeRecoveryCode } from "../src/lib/recovery";
import { NON_PROCUREMENT, categoryByCode, EXPENSE_CATEGORIES } from "../src/data/expense-categories";
import { JURISDICTIONS, jurisdictionByCode } from "../src/data/jurisdictions";
import { SECTORS, sectorByCode } from "../src/data/sectors";
import { shiftPeriod, periodLabel, thisPeriod } from "../src/lib/periods";
import {
  settlementStatus,
  contractPosition,
  certificateAllocation,
  onerousLoss,
  withholdingBase,
} from "../src/lib/accounting-rules";
import {
  computeEcl,
  determineStage,
  lgdNetOfCollateral,
  interestRevenueBase,
  provisionMatrixEcl,
  initialLeaseLiability,
  initialRouAsset,
  rouDepreciation,
  leaseCurrentSplit,
  isExemptLease,
  valueInUse,
  recoverableAmount,
  impairmentLoss,
  impairmentReversal,
  allocateCguImpairment,
  assessHeldForSale,
  disposalGainLoss,
  type LeaseInput,
} from "../src/lib/standards";
import {
  annuityInstalment,
  buildLoanSchedule,
  effectiveInterestRate,
  loanCurrentSplit,
  type LoanTerms,
} from "../src/lib/loans";

const GHANA_BANDS: PayeBand[] = [
  { lower: 0, upper: 3500, rate: 5, effectiveFrom: "2026-09-01" },
  { lower: 3500, upper: 13000, rate: 10, effectiveFrom: "2026-09-01" },
  { lower: 13000, upper: 25000, rate: 17.5, effectiveFrom: "2026-09-01" },
  { lower: 25000, upper: 37000, rate: 25, effectiveFrom: "2026-09-01" },
  { lower: 37000, upper: 57000, rate: 30, effectiveFrom: "2026-09-01" },
  { lower: 57000, upper: null, rate: 35, effectiveFrom: "2026-09-01" },
];

const r2 = (n: number) => Math.round(n * 100) / 100;

// ---------------------------------------------------------------
// PAYE — the band cap bug (was computed against band upper, not the
// lesser of the base and the band upper) and the band-loop reset bug.
// ---------------------------------------------------------------
describe("Ghana PAYE computation", () => {
  it("computes the published schedule exactly for a mid-band salary", () => {
    // gross 21,000 less SSNIT T1 (1,155) and T2 (650) = 19,195 taxable
    const taxable = 21000 - 1155 - 650;
    const paye = computePaye(taxable, GHANA_BANDS, 0);
    // 3500 @5% = 175; (13000-3500) @10% = 950; (19195-13000) @17.5% = 1084.13
    expect(paye).toBe(2209.13);
  });

  it("computes a lower-band salary without touching higher bands", () => {
    // taxable 5,000 → 3500 @5% + 1500 @10%
    expect(computePaye(5000, GHANA_BANDS, 0)).toBe(r2(3500 * 0.05 + 1500 * 0.1));
  });

  it("returns zero below the first threshold", () => {
    expect(computePaye(3000, GHANA_BANDS, 0)).toBe(150);
  });

  it("applies the personal relief before the bands", () => {
    const withRelief = computePaye(20000, GHANA_BANDS, 500);
    const withoutRelief = computePaye(19500, GHANA_BANDS, 0);
    expect(withRelief).toBe(withoutRelief);
  });

  it("is monotonic — earning more never means less tax", () => {
    let prev = 0;
    for (let base = 1000; base <= 80000; base += 1000) {
      const tax = computePaye(base, GHANA_BANDS, 0);
      expect(tax).toBeGreaterThanOrEqual(prev);
      prev = tax;
    }
  });

  it("handles the uncapped top band without returning Infinity", () => {
    const tax = computePaye(200000, GHANA_BANDS, 0);
    expect(Number.isFinite(tax)).toBe(true);
    expect(tax).toBeGreaterThan(0);
  });

  it("loads the PAYE bands from the database", async () => {
    const bands = await listPayeBands();
    expect(bands.length).toBeGreaterThanOrEqual(5);
    expect(bands[0].effectiveFrom).toBeTruthy();
  });
});

// ---------------------------------------------------------------
// Password policy — weak passwords must never be accepted.
// ---------------------------------------------------------------
describe("password policy", () => {
  it("rejects passwords shorter than 10 characters", () => {
    expect(passwordProblem("short")).toMatch(/10 characters/);
  });
  it("rejects passwords without an uppercase letter", () => {
    expect(passwordProblem("alllowercase123")).toMatch(/uppercase/);
  });
  it("rejects passwords without a lowercase letter", () => {
    expect(passwordProblem("ALLUPPERCASE123")).toMatch(/lowercase/);
  });
  it("rejects passwords without a digit", () => {
    expect(passwordProblem("NoDigitsHere")).toMatch(/digit/);
  });
  it("rejects known-predictable passwords even if they meet the rules", () => {
    expect(passwordProblem("Password123x")).toMatch(/predictable/);
  });
  it("accepts a strong password", () => {
    expect(passwordProblem("Str0ngBPZ2026Pass")).toBeNull();
  });
});

// ---------------------------------------------------------------
// Password hashing — round trip and wrong-password rejection.
// ---------------------------------------------------------------
describe("password hashing", () => {
  it("verifies the correct password", () => {
    const hash = hashPassword("Str0ngBPZ2026Pass");
    expect(verifyPassword("Str0ngBPZ2026Pass", hash)).toBe(true);
  });
  it("rejects a wrong password", () => {
    const hash = hashPassword("Str0ngBPZ2026Pass");
    expect(verifyPassword("wrongpassword", hash)).toBe(false);
  });
  it("produces a different hash each time (salted)", () => {
    expect(hashPassword("same")).not.toBe(hashPassword("same"));
  });
});

// ---------------------------------------------------------------
// TOTP — the second factor must verify valid codes and reject others.
// ---------------------------------------------------------------
describe("TOTP two-factor", () => {
  it("generates a base32 secret", () => {
    const s = generateSecret();
    expect(s).toMatch(/^[A-Z2-7]+$/);
    expect(s.length).toBeGreaterThanOrEqual(32);
  });
});

// ---------------------------------------------------------------
// 2FA recovery codes — single use, format readable over the phone.
// ---------------------------------------------------------------
describe("2FA recovery codes", () => {
  it("verifies a valid code", () => {
    const { plain, hash } = generateRecoveryCode();
    expect(consumeRecoveryCode(hash, plain)).toBe(true);
  });
  it("rejects a wrong code", () => {
    const { hash } = generateRecoveryCode();
    expect(consumeRecoveryCode(hash, "BPZ-0000-0000")).toBe(false);
  });
  it("uses the documented BPZ-XXXX-XXXX format", () => {
    const { plain } = generateRecoveryCode();
    expect(plain).toMatch(/^BPZ-[A-F0-9]{4}-[A-F0-9]{4}$/);
  });
  it("rejects tampered hashes", () => {
    expect(consumeRecoveryCode("rcv:bad:bad", "BPZ-AAAA-AAAA")).toBe(false);
  });
});

// ---------------------------------------------------------------
// Expense classification — statutory items must never be routed
// through the procurement cycle.
// ---------------------------------------------------------------
describe("expense classification", () => {
  const statutory = [
    "utilities",
    "tax",
    "payroll",
    "insurance",
    "regulatory",
    "penalty",
    "finance",
  ];

  it("marks utilities, taxes, pension, insurance, regulatory, penalties and finance as non-procurement", () => {
    for (const code of statutory) {
      expect(NON_PROCUREMENT).toContain(code);
    }
  });

  it("keeps goods and contracted services inside procurement", () => {
    expect(NON_PROCUREMENT).not.toContain("goods");
    expect(NON_PROCUREMENT).not.toContain("service");
  });

  it("gives every category at least one GL account", () => {
    for (const c of EXPENSE_CATEGORIES) {
      expect(c.accounts.length).toBeGreaterThan(0);
      expect(c.guidance.length).toBeGreaterThan(10);
    }
  });

  it("falls back safely for an unknown code", () => {
    expect(categoryByCode("does-not-exist").code).toBe("goods");
  });
});

// ---------------------------------------------------------------
// Jurisdictions and sectors — the global and sector coverage.
// ---------------------------------------------------------------
describe("jurisdiction and sector coverage", () => {
  it("covers Ghana plus the major economies", () => {
    for (const code of ["GH", "NG", "KE", "ZA", "GB", "US", "EU", "AE"]) {
      expect(JURISDICTIONS.some((j) => j.code === code)).toBe(true);
    }
  });

  it("uses the full statutory scheme only for Ghana", () => {
    const gh = jurisdictionByCode("GH");
    expect(gh.payrollScheme).toBe("ghana");
    for (const j of JURISDICTIONS) {
      if (j.code !== "GH") expect(j.payrollScheme).toBe("generic");
    }
  });

  it("resolves an unknown jurisdiction without throwing", () => {
    expect(jurisdictionByCode("XX").code).toBeTruthy();
  });

  it("covers the complex sectors", () => {
    for (const code of ["manufacturing", "construction", "oil_gas", "mining", "energy"]) {
      expect(SECTORS.some((s) => s.code === code)).toBe(true);
    }
  });

  it("resolves an unknown sector without throwing", () => {
    expect(sectorByCode("nonexistent").code).toBeTruthy();
  });
});

// ---------------------------------------------------------------
// Fiscal periods — unlimited YYYY-MM periods.
// ---------------------------------------------------------------
describe("fiscal periods", () => {
  it("crosses a year boundary forwards and backwards", () => {
    expect(shiftPeriod("2026-01", -1)).toBe("2025-12");
    expect(shiftPeriod("2025-12", 1)).toBe("2026-01");
  });
  it("crosses a decade", () => {
    expect(shiftPeriod("2029-12", 1)).toBe("2030-01");
    expect(shiftPeriod("2030-01", -1)).toBe("2029-12");
  });
  it("handles a 12-month shift", () => {
    expect(shiftPeriod("2026-05", 12)).toBe("2027-05");
    expect(shiftPeriod("2026-05", -12)).toBe("2025-05");
  });
  it("labels a period readably", () => {
    expect(periodLabel("2026-03")).toBe("Mar 2026");
  });
  it("returns the current period in YYYY-MM form", () => {
    expect(thisPeriod()).toMatch(/^\d{4}-\d{2}$/);
  });
});

// ---------------------------------------------------------------
// Sign convention — credit balances display as positive amounts.
// ---------------------------------------------------------------
describe("sign convention", () => {
  it("negates a credit balance for display", () => {
    // A credit of -20720 must display as 20720 owed, not -20720.
    const bal = -20720;
    expect(-bal).toBe(20720);
  });
  it("leaves a debit balance untouched", () => {
    const bal = 10920;
    expect(-bal).toBe(-10920);
  });
});

// ---------------------------------------------------------------
// Settlement status — regression for the second-part-payment bug.
// ---------------------------------------------------------------
describe("invoice settlement status", () => {
  it("stays partial after a second payment while a balance remains", () => {
    expect(settlementStatus(1000, 700)).toBe("partial");
  });
  it("becomes paid only when cumulative settlement reaches total", () => {
    expect(settlementStatus(1000, 999.99)).toBe("partial");
    expect(settlementStatus(1000, 1000)).toBe("paid");
  });
  it("is open at zero", () => {
    expect(settlementStatus(1000, 0)).toBe("open");
  });
});

// ---------------------------------------------------------------
// IFRS 15 — over-time performance and contract presentation.
// ---------------------------------------------------------------
describe("IFRS 15 contract position", () => {
  it("recognises cumulative revenue from progress and uses actual cost", () => {
    const p = contractPosition({
      transactionPrice: 50_000_000,
      pctComplete: 35,
      actualCostToDate: 14_000_000,
      billedToDate: 0,
      advancesReceived: 0,
    });
    expect(p.revenueToDate).toBe(17_500_000);
    expect(p.actualCostToDate).toBe(14_000_000);
    expect(p.cumulativeProfit).toBe(3_500_000);
    expect(p.contractAsset).toBe(17_500_000);
    expect(p.contractLiability).toBe(0);
  });

  it("offsets a mobilisation advance against unbilled performance", () => {
    const p = contractPosition({
      transactionPrice: 50_000_000,
      pctComplete: 35,
      actualCostToDate: 14_000_000,
      billedToDate: 0,
      advancesReceived: 5_000_000,
    });
    expect(p.contractAsset).toBe(12_500_000);
    expect(p.contractLiability).toBe(0);
  });

  it("shows a liability, never an asset and liability together, when overbilled", () => {
    const p = contractPosition({
      transactionPrice: 50_000_000,
      pctComplete: 35,
      actualCostToDate: 14_000_000,
      billedToDate: 20_000_000,
      advancesReceived: 5_000_000,
    });
    expect(p.contractAsset).toBe(0);
    expect(p.contractLiability).toBe(7_500_000);
  });

  it("allocates certificate billing to asset first, then liability", () => {
    expect(certificateAllocation(17_500_000, 12_500_000)).toEqual({
      assetBilled: 12_500_000,
      overBilling: 5_000_000,
    });
  });

  it("recognises the full expected loss immediately on an onerous contract", () => {
    expect(onerousLoss(10_000_000, 13_000_000)).toBe(3_000_000);
    expect(onerousLoss(13_000_000, 10_000_000)).toBe(0);
  });
});

describe("withholding tax base", () => {
  it("excludes 20% VAT from a full payment", () => {
    expect(withholdingBase(1200, 1000, 1200)).toBe(1000);
  });
  it("excludes VAT proportionally from a partial payment", () => {
    expect(withholdingBase(600, 1000, 1200)).toBe(500);
  });
  it("uses the amount when no invoice total is available", () => {
    expect(withholdingBase(600, 0, 0)).toBe(600);
  });
});

/* =====================================================================
   IFRS 9 — financial instruments and expected credit losses
   ===================================================================== */
describe("IFRS 9 expected credit losses", () => {
  it("computes ECL as exposure × PD × LGD discounted at the effective rate", () => {
    const r = computeEcl({ exposure: 1_000_000, pd: 5, lgd: 40, discountRate: 10, horizonMonths: 12 });
    expect(r.undiscounted).toBe(20000);
    expect(r.ecl).toBeLessThan(20000);
    expect(r.survivalFactor).toBeCloseTo(0.9091, 3);
  });

  it("returns zero ECL when there is no exposure", () => {
    expect(computeEcl({ exposure: 0, pd: 50, lgd: 100, discountRate: 10, horizonMonths: 12 }).ecl).toBe(0);
  });

  it("clamps PD and LGD to the 0–100% range", () => {
    const r = computeEcl({ exposure: 1000, pd: 250, lgd: -50, discountRate: 0, horizonMonths: 12 });
    expect(r.ecl).toBe(0);
  });

  it("reduces LGD for collateral recovery", () => {
    expect(lgdNetOfCollateral({ lgdGross: 45, exposure: 1000, collateralValue: 400 })).toBe(5);
    expect(lgdNetOfCollateral({ lgdGross: 45, exposure: 1000, collateralValue: 2000 })).toBe(0);
  });

  it("moves to Stage 2 on the 30-day backstop and a doubling of lifetime PD", () => {
    expect(determineStage({ daysPastDue: 31, pdNow: 1, pdAtOrigination: 1 }).stage).toBe(2);
    expect(determineStage({ daysPastDue: 5, pdNow: 4, pdAtOrigination: 2 }).stage).toBe(2);
    expect(determineStage({ daysPastDue: 5, pdNow: 2, pdAtOrigination: 2 }).stage).toBe(1);
  });

  it("moves to Stage 3 past 90 days past due", () => {
    const r = determineStage({ daysPastDue: 91, pdNow: 90, pdAtOrigination: 10 });
    expect(r.stage).toBe(3);
    expect(r.lifetime).toBe(true);
  });

  it("accrues interest on gross for Stage 1–2 and net for Stage 3", () => {
    expect(interestRevenueBase({ stage: 1, grossCarryingAmount: 1000, eclAllowance: 300, effectiveRate: 10 })).toBe(100);
    expect(interestRevenueBase({ stage: 2, grossCarryingAmount: 1000, eclAllowance: 300, effectiveRate: 10 })).toBe(100);
    expect(interestRevenueBase({ stage: 3, grossCarryingAmount: 1000, eclAllowance: 300, effectiveRate: 10 })).toBe(70);
  });

  it("builds a provision matrix and totals it", () => {
    const r = provisionMatrixEcl([
      { bucket: "current", amount: 100000, pd: 1 },
      { bucket: "90_plus", amount: 50000, pd: 75 },
    ]);
    expect(r.rows[0].provision).toBe(1000);
    expect(r.rows[1].provision).toBe(37500);
    expect(r.total).toBe(38500);
  });
});

/* =====================================================================
   IFRS 16 — leases
   ===================================================================== */
describe("IFRS 16 leases", () => {
  const lease: LeaseInput = {
    payment: 10000,
    termMonths: 60,
    annualRate: 10,
    frequency: "monthly",
    timing: "arrears",
    initialDirectCosts: 50000,
    incentives: 20000,
    restorationCost: 0,
  };

  it("discounts the lease payments at the incremental borrowing rate", () => {
    const liability = initialLeaseLiability(lease);
    expect(liability).toBeGreaterThan(400000);
    expect(liability).toBeLessThan(600000);
  });

  it("adds initial direct costs and restoration, and deducts incentives, to the ROU asset", () => {
    const r = initialRouAsset(lease);
    expect(r.rouAsset).toBe(r.leaseLiability + 50000 - 20000);
    expect(r.buildUp.liability).toBe(r.leaseLiability);
  });

  it("depreciates the ROU asset straight line over the lease term", () => {
    const rou = initialRouAsset(lease).rouAsset;
    expect(rouDepreciation(rou, 60)).toBeCloseTo(rou / 60, 2);
  });

  it("splits the lease liability into current and non-current portions", () => {
    const s = leaseCurrentSplit(lease);
    expect(s.currentPortion + s.nonCurrentPortion).toBeCloseTo(initialLeaseLiability(lease), 0);
    expect(s.currentPortion).toBeGreaterThan(0);
  });

  it("exempts short-term and low-value leases", () => {
    expect(isExemptLease({ termMonths: 12, assetValue: 0 }).exempt).toBe(true);
    expect(isExemptLease({ termMonths: 60, assetValue: 3000 }).exempt).toBe(true);
    expect(isExemptLease({ termMonths: 60, assetValue: 500000 }).exempt).toBe(false);
  });
});

/* =====================================================================
   IAS 36 — impairment
   ===================================================================== */
describe("IAS 36 impairment", () => {
  it("discounts forecast cash flows to value in use", () => {
    const r = valueInUse({ cashFlows: [100, 100, 100], discountRate: 10, terminalValue: 0 });
    expect(r.rows[0].presentValue).toBeCloseTo(90.91, 1);
    expect(r.rows[2].presentValue).toBeCloseTo(75.13, 1);
    expect(r.valueInUse).toBeCloseTo(248.69, 1);
  });

  it("selects the HIGHER of fair value less costs and value in use", () => {
    expect(recoverableAmount(500, 300).recoverableAmount).toBe(500);
    expect(recoverableAmount(300, 500).recoverableAmount).toBe(500);
    expect(recoverableAmount(300, 500).basis).toBe("Value in use");
  });

  it("recognises a loss only when carrying exceeds recoverable", () => {
    expect(impairmentLoss(400, 500)).toBe(0);
    expect(impairmentLoss(600, 500)).toBe(100);
  });

  it("caps any reversal at the notional carrying amount had no impairment occurred", () => {
    expect(impairmentReversal({ currentCarryingAmount: 300, priorImpairmentCharges: 100, recoverable: 450 }).reversal).toBe(100);
    expect(impairmentReversal({ currentCarryingAmount: 300, priorImpairmentCharges: 50, recoverable: 900 }).reversal).toBe(50);
  });

  it("allocates a CGU loss pro-rata and respects recoverable-amount floors", () => {
    const r = allocateCguImpairment(
      [
        { name: "A", carryingAmount: 600, floor: 0 },
        { name: "B", carryingAmount: 400, floor: 380 },
      ],
      200
    );
    expect(r[0].allocated).toBe(120);
    expect(r[1].allocated).toBe(80);
    expect(r.reduce((s, x) => s + x.allocated, 0)).toBeCloseTo(200, 0);
  });
});

/* =====================================================================
   IFRS 5 — held for sale
   ===================================================================== */
describe("IFRS 5 held for sale", () => {
  const base = {
    carryingAmount: 500,
    fairValue: 480,
    costsToSell: 20,
    committedToPlan: true,
    activeMarketing: true,
    expectedSaleMonths: 9,
    discontinuedOperation: false,
  };

  it("measures at the lower of carrying amount and fair value less costs to sell", () => {
    const r = assessHeldForSale(base);
    expect(r.qualifies).toBe(true);
    expect(r.measuredAmount).toBe(460);
    expect(r.writeDown).toBe(40);
  });

  it("refuses classification when the sale is not highly probable within 12 months", () => {
    const r = assessHeldForSale({ ...base, expectedSaleMonths: 18 });
    expect(r.qualifies).toBe(false);
    expect(r.reasons.join(" ")).toMatch(/12 months/);
  });

  it("refuses classification without an active marketing programme", () => {
    const r = assessHeldForSale({ ...base, activeMarketing: false });
    expect(r.qualifies).toBe(false);
  });

  it("presents a discontinued operation separately", () => {
    const r = assessHeldForSale({ ...base, discontinuedOperation: true });
    expect(r.presentation).toMatch(/Discontinued operation/);
  });

  it("computes the gain or loss on completing the sale", () => {
    expect(disposalGainLoss({ proceeds: 500, costsToSell: 20, heldForSaleCarryingAmount: 460 }).gain).toBe(20);
    expect(disposalGainLoss({ proceeds: 400, costsToSell: 20, heldForSaleCarryingAmount: 460 }).loss).toBe(80);
  });
});

/* =====================================================================
   LOANS — amortisation schedules
   ===================================================================== */
describe("loan amortisation", () => {
  const amortising: LoanTerms = {
    principal: 500_000,
    annualRate: 24,
    termMonths: 60,
    frequency: "monthly",
    facilityType: "amortising",
    moratoriumMonths: 0,
    arrangementFee: 10_000,
    feeSpreadMonths: 0,
  };

  it("computes the standard annuity instalment", () => {
    // A = P·i / (1 − (1+i)^−n) with i = 2%, n = 60
    expect(annuityInstalment(500_000, 2, 60)).toBeCloseTo(14383.98, 1);
  });

  it("fully repays the principal across the schedule", () => {
    const r = buildLoanSchedule(amortising);
    const principalRepaid = r.rows.reduce((s, x) => s + x.principal, 0);
    expect(Math.abs(principalRepaid - 500_000)).toBeLessThan(0.05);
    expect(r.rows[r.rows.length - 1].closing).toBe(0);
  });

  it("keeps every row balanced: payment = interest + fee + principal", () => {
    const r = buildLoanSchedule(amortising);
    for (const row of r.rows) {
      expect(Math.abs(row.interest + row.fee + row.principal - row.payment)).toBeLessThan(0.02);
      expect(Math.abs(row.opening - row.principal - row.closing)).toBeLessThan(0.02);
    }
  });

  it("charges the arrangement fee in full across the schedule", () => {
    const r = buildLoanSchedule(amortising);
    expect(r.totalFees).toBeCloseTo(10_000, 0);
  });

  it("accrues interest during a moratorium but defers principal", () => {
    const r = buildLoanSchedule({ ...amortising, moratoriumMonths: 6 });
    const first = r.rows[0];
    expect(first.principal).toBe(0);
    expect(first.interest).toBe(10_000); // 500,000 × 2%
    expect(r.rows[5].principal).toBe(0);
    expect(r.rows[6].principal).toBeGreaterThan(0);
    // Moratorium does not forgive interest — it must all be charged.
    expect(r.totalInterest).toBeGreaterThan(0);
  });

  it("capitalises interest on a bullet and repays everything at maturity", () => {
    const r = buildLoanSchedule({ ...amortising, facilityType: "bullet" });
    expect(r.rows[0].principal).toBe(0);
    // Interest capitalises, so the final settlement is 500,000 × 1.02^60
    expect(r.rows[r.rows.length - 1].principal).toBeGreaterThan(1_600_000);
    expect(r.totalInterest).toBeGreaterThan(500_000);
  });

  it("repays interest-only with principal at maturity", () => {
    const r = buildLoanSchedule({ ...amortising, facilityType: "interest_only" });
    const mid = r.rows[29];
    expect(mid.principal).toBe(0);
    expect(mid.interest).toBe(10_000);
    expect(r.rows[r.rows.length - 1].principal).toBeCloseTo(500_000, 0);
  });

  it("shows the effective rate above the coupon when fees are charged", () => {
    expect(effectiveInterestRate(amortising)).toBeGreaterThan(24);
  });

  it("splits the outstanding balance into current and non-current", () => {
    const r = buildLoanSchedule(amortising);
    const s = loanCurrentSplit(r.rows, 500_000);
    expect(s.currentPortion).toBeGreaterThan(0);
    expect(s.currentPortion + s.nonCurrentPortion).toBeCloseTo(500_000, 0);
  });
});
